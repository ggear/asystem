# weewx-loopdata change history

## 7.5.2 2026/09/26
- The sample report's wind compass points with the same red arm as the
  dials beside it, and the gust with a plain lighter needle; both used to
  carry arrowheads.  The tip marks where the wind comes from, and an
  arrowhead invited reading it the other way, as the way the wind is
  going.  In a calm, with no red arm to carry, the hub takes the gust
  needle's color.
- The barometer's trend arc is drawn only when the change is big enough
  to show its head, about 1.3 hPa (0.04 inHg) over the trend window.  A
  smaller change used to draw a sliver too small to see or to read as an
  arrow.

## 7.5.1 2026/09/23
- The sample report's windrose sits on a dial face of its own, rimmed
  like the gauges beside it with the compass letters inside, and that face
  is exactly the size of theirs; in 7.5 the rose was drawn straight on its
  card and came out a different size from the dials in its row.  Its
  letters and its lines -- the rim, the rings, the hub's edge -- are drawn
  the same size on screen as the dials' too.  Its rings are a shade
  darker in the light theme, so they still stand out against the face.

## 7.5 2026/09/23
- The sample report's gauges are redrawn.  Each is a card: the dial,
  then under it the reading, a line saying what it means, and today's
  high above its low.  The light theme now draws light dials -- a pale
  face on a white card -- where it used to put the dark dials on a light
  page, and the dark theme draws deep dials on navy cards.  Each gauge
  has one red arm, as an analog gauge does; the wind's gust needle keeps
  a quieter color of its own.  The numerals stay inside the face, where they were, but no
  reading or caption is written across a dial any more; each sits below
  its dial instead.
- UV and air quality wear EPA's category colors on the rim and name the
  category under the reading.  UV follows EPA in naming the index
  rounded, so 5.5 is High.  The air quality dial now runs to 500, the top
  of EPA's Hazardous band, where it used to stop at 300.
- The wind gauge says which way the wind is from and how hard it is
  gusting, gives today's peak, and marks today's prevailing direction on
  the dial.  Feels like says how much warmer or cooler it is than the
  air, and rain says when the day has been dry so far.
- The numerals on the dials use the report's decimal point, as the
  readings under them already did.
- Fixed: on a metric station the rain and rain-rate dials printed their
  major numerals rounded -- "6", "13", "19" beside ticks at 6.25, 12.5 and
  18.75 mm.  The metric scale now runs to 20 mm, so every major tick falls
  on a whole millimeter, and so does every doubling on a big day.
- The gauges are SVG rather than canvas, and every color is a css
  property in index.html.tmpl, including the windrose's six speed-band
  shades, which were the last colors written in the javascript.
- The sample report declares more fields in its skin.conf, for the
  readings, units, peaks and wind words above.  A station that overrides
  one of the sample report's field groups under its stanza in weewx.conf
  replaces that group whole, so a gauge whose group was overridden shows
  "--" for any field the override leaves out; "What each gauge reads" in
  the manual lists what each gauge needs.
- Nineteen new strings for the gauges, in all nine languages.  The
  translations of those strings have not yet been reviewed by native
  speakers, German, French and Danish included.
- Internal: the change history is now changes.md, in Markdown, so it
  reads as formatted text on GitHub; it was changes.txt.

## 7.4.1 2026/09/17
- Fixed: on WeeWX earlier than 5.3, every report that declares a field
  holding a time lost its whole entry in loop-data.txt, on every packet,
  with one error logged for each such report.  7.4 reads the default
  time format -- the one a report uses for a time context its
  [[TimeFormats]] does not name -- from weewx.units.DEFAULT_TIME_FORMAT,
  and WeeWX added that name in 5.3; 4.6 through 5.2 write the same format
  inline and have no such name to read.  It is now resolved once, at
  startup, and where the name does not exist the format those releases
  write is used, so a time renders exactly as it does on the report's own
  pages.  A station running WeeWX 5.3 or later was never affected, in 7.4
  or now.  Reported by bellrichm (issue #17), citing WeeWX 5.0.0.
- Internal: three tests now ask the running WeeWX what it does rather
  than assuming the newest release's behavior, so the whole suite runs
  unchanged against an older WeeWX.  That is what guards the fix above:
  it is checked against the oldest WeeWX the suite can run on, not only
  against the one this machine happens to have.

## 7.4 2026/09/10
- Times and numbers now render in the language of the report that
  declared them, as everything else already did.  A month or weekday
  name -- 21. Juni, samedi -- and the decimal point in a formatted
  number come from the locale, and WeeWX keeps the locale in one
  process-wide setting that it changes for the duration of each report
  it generates.  LoopData writes its file on every loop packet, in a
  thread of its own, so it was reading whatever that setting happened
  to hold: a packet that landed while some report was being generated
  took that report's language and the next packet took weewxd's, and
  the same field could come out two ways one packet apart.  Each
  report's locale is now read once, at startup, and kept with its
  formatter and converter, so every value a report declares is rendered
  in that report's own language whatever else weewxd is doing.  This
  covers station.rain_year_str too, which WeeWX fixes when it builds
  the station rather than when the field is read.  A
  station whose reports do not set lang, or whose lang is not a locale
  name the machine has installed, sees no change at all.
- A formatted number now carries the report's decimal point, as the
  report's own pages always have.  On a station running in a language
  that writes 12,3 rather than 12.3, a field's .formatted was the one
  rendering that skipped this, so the page said 12,3 and .formatted
  beside it in loop-data.txt said 12.3 -- the same number, in the same
  file, for the same packet.  Unformatted .raw values are untouched:
  they are json numbers, and always were.
- Internal: two errors LoopData can log were missing from the manual's
  table of log messages, one of them because the test that keeps that
  table honest could not see a message written with double quotes.

## 7.3 2026/09/09
- ACTION REQUIRED IF YOU WANT THE DARK PAGE ON EVERY SCREEN: the sample
  report now follows the viewer's own system theme by default, and a
  browser with no preference set reports LIGHT rather than "no
  preference" -- so a machine where nobody has chosen a theme now gets
  the light page where it used to get the dark one.  To pin the dark
  page for everyone regardless of their setting, add theme = dark to
  the report's [[[Extras]]] in weewx.conf.  A fresh install writes the
  option commented out; an existing install has no such line and needs
  one added.  The manual's "Themes" section spells it out.
- The sample report has a light theme -- deep navy instruments on warm
  paper -- and picks between it and the dark one from the viewer's
  system setting.  Two people looking at the same page can see
  different themes, and a viewer who changes their setting while the
  page is open sees it change without a reload.  theme = auto (the
  default), dark or light in the report's [[[Extras]]] decides;
  anything unrecognized is treated as auto.  The page also declares its
  color-scheme now, so the browser's own scrollbars and focus rings
  follow the theme instead of staying light on a dark page.
- The sample page's gauges sit on rounded panels, and every row of the
  grid now reserves the height of the windrose's legend rather than only
  the row the windrose is in.  THIS ONE MOVES THE DARK PAGE TOO: the
  bottom row of gauges sits about twenty pixels lower than it did in
  7.2, so that the dials in each row line up with each other rather than
  the first row standing taller than the rest.
- Internal: the panel's palette is now written ONCE, as the css custom
  properties in index.html.tmpl.  realtime_updater.inc reads them
  rather than carrying a second copy of every color, so a theme is a
  css change and nothing else, and the test that kept the two lists in
  step is gone with the duplication it existed for.  The needle's glow,
  which was a third copy of the amber spelled rgba(), is derived from
  it.

## 7.2 2026/09/06
- A period's own boundaries are now fields.  start, end, length and
  dateTime are report tags on every period ($week.start, $month.length),
  and loopdata refused all of them.  Declare week.start.raw and every
  packet carries the instant this week began, so a page can work out for
  itself whether a period began today instead of being told once, at
  report time, by an answer that goes stale the moment midnight passes --
  which is what a kiosk page left up for a fortnight is living with.  All
  four are served on hour, day, week, month, year, rainyear and alltime,
  and take the usual unit override, round(n) and format specs.  start,
  end and dateTime are instants and render through the period's time
  format; length is a duration and renders as one.  The rolling periods
  (1m-1440m, 1h-24h) and trend have no fixed span and do not carry them.
- alltime.start is the time of the earliest record in the archive and
  alltime.end the time of the packet in hand, which is what the $alltime
  report tag spans.  alltime.end and alltime.length therefore move with
  every packet, where the calendar periods' do not.  That earliest record
  is read from the database once, when the accumulators are built on the
  first loop packet, and thereafter kept current from the archive records
  themselves, at no further cost to the database (except where
  [StdArchive] writes a different data_binding than the reports read, in
  which case loopdata cannot tell which archive a record belongs to and
  keeps to the startup reading, saying so in the log).  So a station whose
  archive was still empty at that moment -- weewx and loopdata installed
  together -- serves the alltime span properties from its first archive
  record, five minutes in by default, rather than waiting for a restart.
  A packet stamped before the archive's earliest record, which a console
  with a reset clock can produce, has no alltime span at all, so those
  fields are omitted for that packet.  Neither case affects any other
  field.
- A period's dateTime with an aggregate on it -- day.dateTime.max and its
  kin -- is no longer recognized, since a period's dateTime is now its
  start.  This is what the report tags have always done: $day.dateTime is
  the day's start, never the dateTime observation.  current.dateTime.raw
  is untouched; current is an instant, not a span.  The same holds for
  the other three names: under a period that has a span, start, end and
  length are the span's, so an observation named one of them --
  day.length.max -- is no longer recognized there either.  No standard
  weewx type carries any of those names.
- Internal: six tests drive the span properties through the machinery the
  first round stubbed out -- a period rolling over on a real accumulator,
  with the observations declared that make it roll at all; an archive
  record's stamp arriving among loop packets on the live writer thread,
  with every file written checked rather than the last one left on disk;
  a report declaring span properties and nothing else, end to end through
  a real service; the deprecated [[Include]] fields line, where a property
  the target report also declares is rendered once and copied flat; two
  reports in different unit systems reading one span; and the two days
  a year that are not twenty-four hours long.  The report-tag parity test
  now compares the rendered string as well as the raw instant, which is
  where a wrong time context shows.

## 7.1 2026/09/03
- Week, month, year, rain-year and all-time sums, counts and averages no
  longer count today twice after a restart.  Loopdata seeds those spans
  from the daily summary table and then adds today's running totals on
  top, but today has a row in that table too, so from a restart on,
  month.rain.sum and its kin read today's contribution double and every
  span average leaned toward today's mean.  Minimums and maximums were
  unaffected.  The error lasted until the span rolled over -- and for the
  all-time span, which never does, until the next restart doubled it
  afresh.
- When weewxd stops, loopdata stops its writer thread before the process
  ends, so a stop that lands while a packet is being written does not
  leave a LoopData temp file behind in the directory the loop-data file is
  served from.  Packets still queued at that moment are discarded rather
  than written and shipped to nobody.  Should the thread not stop within
  twenty seconds -- a stalled rsync could hold it that long -- the stop
  goes ahead without it and says so in the log.  A driver restart, where
  weewxd rebuilds its engine in the same process, likewise no longer
  leaves the previous writer thread and its accumulators behind.
- Should the writer thread die -- its traceback has always been logged --
  loop packets are no longer queued to it for the rest of weewxd's life,
  which grew memory by one packet every loop interval while the loop-data
  file sat frozen.  The loss is logged once more, saying the file will not
  update again.
- [[RsyncSpec]] skip_if_older_than must be at least 1.  Zero used to mean
  never skip, undocumented, and a station that set it would rsync every
  packet however late -- the backlog the option exists to prevent.  A
  value below 1, and a blank one, are now ignored with a warning and the
  default of 3 is used.
- When weewxd starts, the day accumulator is seeded from the daily summary
  of the first loop packet's day rather than the wall clock's.  The two
  differ only when a start straddles midnight in the second or so between
  a packet being stamped and being processed -- exceedingly unlikely in
  practice -- but when they did, the day's min/max/sum carried the wrong
  day's history until the packet-time day rolled over.
- Internal: the two archive database connections loopdata opened -- one
  when the service starts, one when the first loop packet builds the
  accumulators -- are closed when they are finished with, rather than
  held open for the life of weewxd.
- Internal: the test suite closes the files it writes, so a run no longer
  prints a ResourceWarning for each one.

## 7.0.1 2026/08/31
- Nothing below edits a weewx.conf that already exists, and there is
  nothing to do by hand.  The one change that reaches a station without an
  edit is the expiration_time default, immediately below.
- The sample page's default expiration_time is 24 hours, where it was 4,
  matching the sibling extensions.  This reaches a station that has no
  live expiration_time in weewx.conf: a fresh install, where the option is
  written commented out.  A station whose weewx.conf carries
  expiration_time = 4 as a live setting -- every install made before the
  option was demoted -- goes on expiring after 4 hours until that line is
  edited or removed.
- A fresh install writes eight options into weewx.conf commented out,
  each showing the value that will apply: compress, log_success, timeout
  and skip_if_older_than in [[RsyncSpec]], and loop_data_file,
  expiration_time, googleAnalyticsId and analytics_host in the sample
  report's [Extras] (the last two as examples -- their default is to be
  absent).  weectl fills in absent keys and never rewrites one, so an
  option written live freezes that station on today's default for ever,
  while a commented one leaves loopdata's own value to answer, including
  a better one a later release brings.  What stays live is what loopdata
  cannot supply for itself: the switches (enable), the placeholders a
  user must replace (remote_server, remote_user, remote_dir,
  page_update_pwd), what weectl needs (HTML_ROOT, skin), the station's
  loop cadence, the file's directory and name, and the sample report's
  string formats -- which are on the report's stanza so that a
  station-wide [[Defaults]] cannot put a decimal on a wind dial that has
  no room for one.
- Fixed: deleting enable, compress or log_success from [[RsyncSpec]] --
  or deleting the whole section -- stopped LoopData at startup with
  "Unknown boolean specifier: 'None'".  Each now falls back to false,
  which is what the installer has always written.
- The installer's [[ScriptData]] example of how to declare fields no
  longer lands in weewx.conf indented as though it belonged to
  [StdReport].  ConfigObj attaches a comment block to the next key and
  writes it at that key's indent, and the block sat after the section's
  last option.
- Fixed: a kiosk URL whose ?pageUpdate= password contains a space, or any
  other character a browser percent-encodes, now matches.  The password
  was compared still encoded, so such a password never exempted the page
  and the display went dead after expiration_time hours.  The URL value is
  compared both as typed and percent-decoded, so a URL that worked before
  -- including a password that itself contains a percent-escape -- goes on
  working untouched.
- Fixed: a quote or a backslash in page_update_pwd, refresh_rate or
  expiration_time no longer kills the page outright, and a page_update_pwd
  containing an accent or any other non-ASCII character now matches.  All
  three were written into the javascript as hand-quoted literals: a quote
  ended the string early, which is a parse error that stops the whole
  script -- no polling, no gauges -- and a non-ASCII password was rendered
  as a character reference, which could never equal what the URL supplied.
  All three are emitted with json.dumps now, as the page's translated
  strings already were, so a mistyped number falls back to its default
  instead of taking the page down.
- Fixed: blanking page_update_pwd no longer leaves every visitor's page
  polling for ever, and no URL exempts a page whose password is blank.
  An empty value used to be read as a password, so the empty ?pageUpdate=
  every visitor has matched it; it then fell back to a fixed word that is
  in the shipped source for anyone to read.  Now there is no password at
  all, which nothing in a URL can equal.  (An [Extras] option written
  empty is present, so the test for one fired on it.)
- expiration_time = 0 now means the page never expires, which is what a
  zero timeout ought to mean and what it never did: it expired the page
  before the first packet arrived, since ConfigObj yields strings and a
  '0' passed the template's test for a value.  It is the kiosk exemption
  without the ?pageUpdate= URL.
- Fixed: refresh_rate = 0 no longer polls as fast as the browser can; a
  page that never polls is a dead page, so zero means the default there.
  A negative, or a setting that is not a number, means the default for
  both -- rather than emitting javascript that stopped the whole script,
  and, for a negative expiration_time, rather than quietly never expiring.
- Fixed: a large expiration_time no longer expires the page at once.  Past
  2147483647 milliseconds (~596 hours) the delay overflows the browser's
  int32 timer and fires immediately, so an expiration_time of 1000, reached
  for as "effectively never", did the opposite.  It is clamped to that
  ceiling now, and zero is how you say never.
- Fixed: once the page has expired, the CLICK-ME prompt is written once
  rather than rewritten every couple of seconds for as long as the tab is
  open.  The test meant to prevent that compared the element itself
  against the string.
- Fixed: a page adapted without the sample skin's status elements no
  longer throws on every poll.  Each of the five places that writes the
  LIVE indicator or the timestamp -- including the OFFLINE, NO DATA and
  BAD DATA branches -- now goes through one guarded writer, and the gauges
  are drawn before the labels rather than after, so a missing label cannot
  stop the drawing.
- Fixed: a page adapted without the windrose legend's element no longer
  takes the eleven dials down with it.  The lookup is guarded, and the
  legend's cache key is now set only once the legend is built, which is
  what made the symptom intermittent.
- Fixed: a report that declares gauge fields but not the clock group now
  says BAD DATA -- check loop_data_file instead of reading "NaNs ago" and
  "Invalid Date" for ever.  The gauges still draw.
- Fixed: the sample page's windrose colors stretch to however many speed
  bands are configured.  The six shades were indexed one per band, so a
  seventh band wrapped around and painted the windiest band in the calmest
  band's color -- in the rose and in its legend alike, so the page did not
  even look wrong.  They are stops on a curve now, sampled for the band
  count in use; six bands, which is what the default edges and the shipped
  sample configuration both produce, get exactly the six shades they
  always did.
- A README correction: the list of [LoopData] options had every rsync
  option, plus the loop frequency, sitting under the heading that marks the
  three deprecated ones -- so options a fresh install does write, and the
  block just above it shows being written, read as deprecated.  The
  deprecated three (target_report, fields and the [LoopData] spelling of
  windrose_bands) are together at the end of the list now, under that
  heading and nothing else.
- Fixed: the sample page's data age is measured against the web server's
  clock instead of the browser's, so a viewer whose device has the wrong
  time no longer sees a false age -- or, since the page reads LIVE only
  while the packet is younger than three times refresh_rate (six seconds by
  default), never sees LIVE at all over a perfectly healthy feed.  The age
  now comes from the Date header of the response that carried the record,
  plus any Age a proxy reports, and never reads the viewer's clock while
  that header is there.  A monotonic floor -- how long since the data last
  changed -- catches a cached copy whose header reads younger than its
  body.  Where no Date header reaches the page at all the viewer's clock is
  still the only measure available and is used, since otherwise a feed that
  had already stopped before the page loaded would read LIVE.
- Fixed: running weectl report run no longer drops a zero-byte LoopData
  file into the directory the loop-data file is written to -- which is
  inside the web-served report tree by default, and got one more on every
  run.  LoopData reserves a unique name at startup to write each packet to
  before renaming it onto loop-data.txt, and was leaving the empty file
  itself behind; only the name was wanted.  weewxd never left one, which is
  why this went unseen: the file is renamed away by every packet, and the
  cleanup that existed ran on the loop-processor thread, which weectl
  report run never starts even though report_services builds the service.
- The windrose manual page gains a picture of one: the sample skin's rose on
  a real morning, with the default bands, captioned so that the calm center
  and the two-lobed shape illustrate the advice on choosing edges that
  follows it.
- Manual corrections: the windrose page's advice on the top band edge said
  the darkest color flags the strongest wind.  It is the other way round on
  the sample page, whose ramp runs dim for calm to bright for windy; some
  other windrose tools do run dark for fast, which is where the sentence
  came from.  The troubleshooting page's BAD DATA row gave only one of the
  three things that show it -- a body that is not json -- and not the two
  that name a report: no entry for this report at all, or an entry with no
  current.dateTime.raw in it.
- Fixed: a gauge whose cell is hidden because the station has no such
  sensor is re-sized when the sensor reappears.  A hidden element measures
  zero, so its canvas was built at a fallback size, and only the windrose
  was ever checked for that drift.
- Internal: three guard tests on the installer stanza -- the commented
  options pinned as a complete set with their values, each value checked
  against the fallback that governs when the key is absent, and comment
  placement checked through weecfg's own merge, counted so that a block
  dropped outright (which happens silently when it attaches to a section
  weewx.conf already has) fails.

## 7.0 2026/08/26
- ACTION REQUIRED, 1 of 3 -- WeeWX 4.6 or later: this release requires WeeWX
  4.6 or later, where 6.x required 4.0.  Both the installer and the
  service refuse to run on anything older.  4.6 is where WeeWX made its
  skin-dictionary builder a module-level function, which is how loopdata
  assembles each report's units, formats and language, and it is also
  where $gettext arrived, which the sample skin has needed since 6.4.
- ACTION REQUIRED, 2 of 3 -- FINISH THE MIGRATION by running user.loopdata
  as a command (the manual's Declaring fields page gives the command line
  for each way of installing WeeWX).  The fields line does
  not remove itself, and an upgraded station should remove it once every
  extension whose pages read the loop-data file declares its own fields.
  The command reports which report now covers each entry on the line and
  which are covered by nobody -- almost always cruft, entries a page asked
  for years ago and no longer reads -- and changes nothing until every
  entry is accounted for and it is run with --apply, which backs up
  weewx.conf, deletes [[Include]] and [[Formatting]], and moves
  [LoopData] windrose_bands onto the stanza of the report whose rose it
  bands (see the windrose_bands bullet below).  A relative loop_data_dir
  is pinned to the directory the file is in today first, since it was
  measured from target_report and that is going -- no page finds its URL
  gone.  It also runs with the fields line already deleted, to remove
  what is left.  The startup warning names the command.
- ACTION REQUIRED, 3 of 3 -- a live page of your own that reads
  loop-data.txt: declare its fields under its report and have the page read
  that report's entry, before the fields line goes.  Nothing is required
  for the sample page, weewx-celestial or weewx-weatherboard: upgrade each
  and it declares its own fields, and until then they keep working through
  the fields line exactly as before.
- Reports declare the fields they need.  A skin's skin.conf carries a
  [LoopData] [[fields]] section of named groups (see
  skins/LoopData/skin.conf), and every enabled report whose skin declares
  fields is its own target: its fields are rendered with its own
  formatter, converter, [Texts], [Almanac] names, $station and
  [Units] [Trend] time_delta, and written into loop-data.txt under the
  REPORT's name (the [StdReport] section name -- one skin can be listed
  under two reports, in two unit systems, and each gets its own values).
  A report can add to or override its skin's groups from weewx.conf
  ([StdReport] [[MyReport]] [[[LoopData]]] [[[[fields]]]]), which is how
  an extension declares fields that depend on your configuration.
  Accumulation is shared: one set of accumulators feeds every report.  The
  two report settings that reach the accumulators -- the trend window and
  the windrose band edges -- select an accumulator by value, so reports
  that agree share one and a report that differs gets its own.
- A fields line entry that any report declares and renders identically is
  rendered ONCE, in that report's entry, and copied flat, so a station
  still carrying the line pays almost nothing for it.  Two reports count
  as rendering identically when their units, formats, labels, texts,
  almanac names, trend window and windrose bands all match, which on a
  station whose reports inherit [StdReport] [[Defaults]] is every report.
  Only fields nothing declares, or that no matching report declares, are
  rendered for the line itself.
- windrose_bands is a report option.  On a report's stanza in [StdReport]
  it is in that report's windSpeed unit; under [StdReport] [[Defaults]] it
  applies to every report, in the Defaults' unit, converted to each
  report's and rounded to one decimal; a skin.conf may carry one too.
  The pre-7.0 [LoopData] windrose_bands is deprecated.  It bands
  target_report's rose and no other -- which is the one rose it banded
  before 7.0, the one in the flat file -- so that report keeps its bands
  and every other report takes the WRPLOT defaults until someone chooses
  otherwise.  Finishing the migration moves the value to that report's
  stanza, in the unit it is already written in, or simply drops it when
  that report already gets its bands from somewhere nearer.
- The [LoopData] [[Include]] fields line and [[Formatting]] target_report
  are deprecated, together with the flat top-level keys they produce.
  All three still work exactly as before on an upgraded station, so an
  existing page keeps reading what it always read, and the per-report
  entries appear in the same file beside them.  A fresh install writes
  neither.  weewxd logs a warning at startup while the line is present;
  do not edit it by hand -- an extension declares its own fields when
  installed, and a later loopdata release removes the line once every
  extension that used it declares its fields.  A live page of your own
  should declare its fields under its report (see the manual's Declaring
  fields page) before that happens.
- target_report keeps one job while it exists: a relative loop_data_dir
  is relative to its directory, LoopDataReport when target_report is not
  set.  So keep the [[LoopDataReport]] section -- enable = false turns
  the page off, and the installer puts a deleted section back.  A
  target_report kept after the fields line is gone is warned about at
  startup: set loop_data_dir to an absolute path before the release that
  removes it, or the file moves.
- A FRESH install writes no fields line, and weewx-celestial 8.4's
  installer only adds to a line that already exists, so a fresh station
  needs a weewx-celestial newer than 8.4 for the Celestial page to have
  live values.  Upgraded stations keep their line and are unaffected.
- One report's fields failing to render no longer stops the file.  Every
  enabled report's declaration is rendered on every packet now, including
  skins this station's operator never wrote; a failure drops that
  report's entry, logs once and leaves every other report's values
  written, where before it would have ended the loop-data thread and
  frozen the file while weewxd carried on.
- A report for consumers that are not reports.  A script, an SNMP
  extension or a monitoring check has no skin to declare fields in, and
  parking them on a page's report means an upgrade overwrites them.  The
  installer now writes a disabled [StdReport] [[ScriptData]] stanza and
  ships skins/ScriptData, a skin that generates nothing: enable the
  report, declare your fields under its stanza in weewx.conf, and they
  arrive in the loop-data file under "ScriptData".  The manual's
  Declaring fields page has the details.
- A field none of the parsers accept is now logged as a warning, naming
  the report that declared it.  It was dropped silently.
- A single-field fields value (no comma, which ConfigObj hands back as a
  string) is read as one field.  It was iterated character by character.
- The sample skin declares its fields in its skin.conf, grouped by gauge,
  and its page reads its own report's entries.  The installer no longer
  writes a fields line or a target_report.
- Internal: Configuration is split into the shared half and a
  ReportContext per report; generate_loopdata_dictionary is split into
  accumulate_packet and render_report; the almanac and station
  evaluators are per report (their caches hold rendered values).

## 6.11.3 2026/08/24
- The sample page no longer loads Google Analytics when no analytics id
  is configured.  analytics.inc tested whether googleAnalyticsId was
  PRESENT, not whether it had a value -- and the installer writes it
  present but empty.  Every install that took the default therefore
  fetched https://www.googletagmanager.com/gtag/js?id= on every page
  view, with an empty id: a third-party request nobody asked for, on a
  page whose owner had never configured analytics.  The companion option
  failed the same way in the other direction: with analytics_host present
  but empty the page compared its hostname against "", which is never
  true, so a user who did set an id and left the host alone got the
  script loaded and not one event reported.  Both now test the value.
  Empty means off for googleAnalyticsId, and means report from wherever
  the page is served for analytics_host -- which is what both options
  always claimed.  Existing installs pick this up on their next report
  cycle; no configuration change is needed.  The manual documents both
  options for the first time -- they had never appeared in docs/ or the
  README, and the test that is supposed to catch that read only
  skin.conf, where both sit commented out and so were invisible to it.
  It now also reads the [[[Extras]]] the installer writes.
- Blanking refresh_rate or expiration_time in weewx.conf no longer kills
  the sample page.  realtime_updater.inc tested those two for PRESENCE and
  emitted the value straight into a javascript assignment, so an empty one
  rendered "refresh_rate = ;" -- a parse error that took down the whole
  script block, and with it the polling, the gauges and the translated
  strings, not merely the one setting.  Both now test the value and fall
  back to their defaults, as a missing option always did.  Same fix as the
  analytics options above; page_update_pwd was never affected, its value
  being quoted.
- The [LoopData] stanza a fresh install writes into weewx.conf arrives
  commented.  It had always landed as bare key = value lines with
  nothing to say what any of them did, which left the manual as the only
  way to find out what, say, [[LoopFrequency]] seconds was for -- and
  that is the option whose wrong value silently scales every windrun and
  every windrose distance.  Now each section and each option carries a
  line or two explaining itself, the three placeholders in
  [[RsyncSpec]] say they are placeholders, and the fields line says what
  a field is and where the full grammar lives.  The cause was that the
  installer built its stanza as a Python dict: weectl merges it with
  weeutil.config.conditional_merge, which copies a key's comments across
  only if the source has any, and a dict has none.  The stanza is now a
  ConfigObj, which does.  Existing installs are untouched -- the merge
  fills in absent keys only, and every value written is unchanged, so
  this matters only on a fresh install.
- The manual no longer says the sample panel calls its data stale after
  expiration_time seconds.  Both halves were wrong: expiration_time is in
  hours, and it is the poll-forever timeout, not a staleness test.  The
  panel reads LIVE while the packet is no older than three times the
  skin's refresh_rate -- six seconds by default -- and shows the age
  instead once it is older.  The passage's point is unchanged; only its
  numbers were.
- Internal: three tests pin the new stanza -- that every section and
  option in it is commented, that the comments survive a merge driven
  through weecfg's own ExtensionEngine._inject_config (which is where the
  stanza is copied, and the copy is what decides whether comments survive
  at all), and the values a fresh install writes.
- Internal: install.py builds its ConfigObj inside the installer rather
  than at import time, so loader()'s "requires WeeWX 4" message is
  reachable again.  A module-level import of weeutil.config ran before
  that check and could not survive a WeeWX 3 install -- the module is
  absent before 3.9, and 3.9's copy has no config_from_str -- so the
  user got a raw traceback instead of the message.

## 6.11.2 2026/08/24
- The manual says where the loop-data file should live.  The default --
  inside your reports tree, in the target report's own directory --
  works, and is what most stations keep.  Two things are worth knowing
  all the same: the file is rewritten on every loop packet, which a
  station running from an SD card may rather have land in RAM, and the
  report sync copies that tree every report cycle, which buys nothing
  when the pages are served from the same machine.  A memory filesystem outside the web root answers both, for
  anyone comfortable editing a web server configuration: the new
  section carries the /dev/shm and fstab recipes, the Apache and nginx
  aliases (with the no-store header a live page wants), the URL the
  reading page then needs, and the case none of it helps: where the
  report sync is the only way to reach the machine serving the pages,
  as it is when publishing by FTP, the file crosses only at report
  cadence and cannot feed a live page at all.  That wants loopdata's
  own rsync, or pages served from the machine weewx runs on.
- Upgrading gains a 6.11.2 line.
- The manual no longer calls the loop frequency crucial without saying
  what it costs.  It is crucial; now it says why.  Only live packets are
  weighted with this value: every period that outlives weewxd's startup
  -- hour, day, week, month, year, rainyear, alltime and the rolling
  windows -- is seeded from what is already in the database, at the
  weights the archive gives it.  So a wrong value skews the ratio
  between the seeded part of a period and the live part rather than
  canceling out of the average, and the manual works an example
  through: a station emitting every two seconds but configured for four
  counts its evening twice over, and day.outTemp.avg reads 16.0 where
  it should read 17.5.  The skew is bounded by the period's own length
  -- it clears when the period rolls or the seeded records age out of a
  rolling window -- and minima and maxima never use the weight at all.
  windrun and windrose are the ones that do not recover: both are wind
  speed times that interval, so they scale straight with the error and
  no roll-over cleans them, and day.windrose.banded is what the sample
  panel draws.  Two seconds is also no longer stated as a fact about
  hardware in general: it is what a Davis Vantage emits, with nothing
  to set on the station side, while a driver you poll on a schedule
  hands you the number directly.
- The manual carries the new section everywhere a reader chooses the
  value, not just where the option is defined: Installation and Build a
  live page both point at it, and Troubleshooting's NO DATA (HTTP 404)
  row no longer reads as a warning against the very arrangement the
  manual now recommends -- keeping the file outside the web root is
  fine, it just has to be served and named.
- The fstab recipe in that section says to create the mount point and
  give it to the user weewxd runs as.  A root-owned mode=0755 tmpfs is
  not writable by a weewxd running as anyone else, and the failure is
  unhelpful: the directory exists so makedirs succeeds, and it is the
  temp file opened next that raises PermissionError, during service
  init, so weewxd does not start.  /dev/shm needs neither step.
- Internal: the absolute-manual-URL audit checks a link's #fragment
  against the target page's headings again.  It had been made to strip
  the fragment so an anchored link would pass the .html check, which
  left the repo's first anchored absolute link unverified -- rename the
  section and the link would have died silently.
- The sample skin's shipped loop_data_file is the value every install
  actually runs: loop-data.txt, the file beside the page, matching the
  default loop_data_dir = . .  skin.conf shipped ../loop-data.txt --
  dead text, since weewx.conf's own entry overrides it -- and the
  manual documented that value and explained it wrongly.  No install
  changes behavior; a reader of either file is no longer misled.

## 6.11.1 2026/08/14
- The sample report drops the loopdata field names printed under each
  gauge.  They were meant as a key to what the panel reads, but on a
  live page they read as a template that failed to render -- one user
  asked which part of his install was broken.  The mapping lives in the
  manual instead, gauge by gauge.
- Troubleshooting covers a single gauge missing its needle.  An old
  fields line carried over an upgrade is already documented, but only as
  the whole panel losing its needles, bands and windrose; a hand-tuned
  fields line can be short one .raw field and cost exactly one needle,
  which is what the same user hit before he replaced his fields line.

## 6.11 2026/08/13
- The sample report's dark theme is higher contrast and much easier to
  read: white readouts, brighter numerals and labels, a recessed track
  you can see on every dial, and windrose bands that no longer vanish
  into the disc.  The field captions lose an opacity that had them
  under AA for text that size.
- The windrose is now the same size as the other eleven gauges, with
  its N/E/S/W letters moved inside the disc.
- Internal: a test pins the panel's two palettes to each other -- :root
  in index.html.tmpl and the C object in realtime_updater.inc -- since
  the canvases cannot read css variables and nothing else stopped the
  copies drifting.

## 6.10 2026/08/13
- Almanac fields work again on WeeWX earlier than 5.3.  WeeWX 5.3
  renamed the Almanac constructor's language argument: it now takes
  texts (the target report's whole [Almanac] section -- moon phases,
  body names, constellation names), where earlier versions took
  moon_phases, the eight phase names alone.  Since almanac fields
  shipped in 5.0 loopdata has passed texts unconditionally, which is a
  TypeError on WeeWX 4.x through 5.2: at the first loop packet the
  LoopData thread logged a traceback and stopped, and loop-data.txt was
  never written again -- weewxd itself kept running, so the only signs
  were the traceback in the log and a page frozen at its last values.
  A fields line with no almanac field never built an Almanac and was
  unaffected.  loopdata now asks the Almanac constructor which spelling
  it takes and passes that one; on a pre-5.3 WeeWX it passes the moon
  phases when the target report overrides them and otherwise leaves
  WeeWX's own default in place -- what a report on that version does.
  Reported by bellrichm (issue #15), running 5.2.
- The manual and README have been overhauled.  The manual gains an
  Upgrading page that gathers the action-required items previously
  scattered across four pages, and the README is now a front door that
  deep-links into the manual rather than duplicating it.  The
  [[RsyncSpec]] remote_port option is documented for the first time --
  the code has always read it -- and so is [Extras] refresh_rate.  The
  driver-support note now says what a mismatched driver actually costs
  (windrun and the other time integrals, not the averages) instead of
  "at your own risk".  The two items below came out of that review.
- The German and French translations are marked Beta again.  The
  manual described both as native-speaker reviewed, and 6.6 declared
  the French out of Beta, on the strength of reviews that covered the
  vocabulary this skin shares with weewx-skyfield and weewx-celestial
  -- body names, moon phases, compass ordinates and the constellation
  names -- which is copied verbatim from those files.  Those reviews
  did not cover the strings only this skin renders: of the 36 [Texts]
  keys in lang/de.conf, 7 are shared and 29 are loopdata's own,
  including every gauge heading and all nine trend.barometer.desc
  descriptions.  The translations themselves are unchanged; only the
  claim made about them is.  Corrections welcome.
- The sample skin's skin.conf comments are corrected.  The URL
  parameter that keeps a page auto-updating is pageUpdate, not
  page_update_pwd as the comment had said since the sample skin
  shipped in 2.6 -- a reader who followed the comment would have had
  the page time out on them.  The lang comment, four releases stale,
  now lists all eight translations, and two typos are fixed.

## 6.9 2026/08/08
- A next_* almanac field now expires the moment its event's own instant
  passes, instead of being kept until midnight: a "next" value whose
  instant is behind us no longer is what the field name promises.
  Fields naming the same event -- say a satellite pass's rise, set and
  maximum altitude -- are computed together and expire together, at the
  latest time-typed value among them (for a pass, the set time), so an
  in-progress pass keeps serving until it ends and the very next packet
  carries the following pass, every field switching at once.
  Recomputes stay rare by construction, since each one returns the next
  occurrence, re-arming the cache: next_full_moon recomputes once per
  lunar month, a satellite's next_pass once per pass.  A group with no
  time-typed field cannot see its event end and keeps the once-per-day
  refresh -- include a pass time field to get event-time expiry.
  previous_* fields are unchanged (their instant is always in the past;
  they refresh once per local day).  The stale window has been there
  since almanac fields shipped in 5.0 -- almanac.next_full_moon serves
  the old event from the instant it passes until midnight -- but it
  took developing weewx-celestial 8.0's "Next pass overhead" panel
  against this code to make it glaring: driven by the old caching, the
  panel showed a morning pass as "just set" until the day's end.  Fixed
  before either shipped.
- A day- or event-tier almanac field that evaluates to no data is no
  longer cached until the next local day: every packet retries, so the
  field picks up its value the moment the almanac has data.  Seen live
  with weewx-skyfield satellites: a newly added satellite's rise,
  set and pass fields honestly read N/A until its orbital elements
  downloaded, but before this fix they kept reading N/A until midnight
  even though the elements arrived moments after startup.
- Complete Italian, Norwegian (Bokmål) and Swedish translations ship
  with the sample LoopData skin (all three Beta, awaiting
  native-speaker review -- corrections welcome): lang/it.conf,
  lang/no.conf and lang/sv.conf, each including the
  trend.barometer.desc tendency vocabulary and, for a loopdata instance
  whose target report is in that language, the moon phases, body names
  and all 88 constellation names -- the shared vocabulary in step with
  weewx-skyfield's and weewx-celestial's files of the same names (the
  cross-repo test pins it, as for the other languages).  Select one
  with lang = it (or no, sv) in the report.  Matches the three new
  languages of weewx-skyfield 2.0 and weewx-celestial 8.0.

## 6.8 2026/08/02
- A complete Danish translation ships with the sample LoopData skin,
  contributed by native speaker Gert Andersen:
  lang/da.conf, including the trend.barometer.desc tendency vocabulary
  and the shared almanac vocabulary (body names, moon phases, compass
  points and all 88 constellations) in step with weewx-skyfield's and
  weewx-celestial's da.conf files (a test pins this).  Select it with
  lang = da in the report.

## 6.7 2026/07/31
- A complete Spanish translation ships with the sample LoopData skin
  (Beta, awaiting native-speaker review -- corrections welcome):
  lang/es.conf, including the trend.barometer.desc tendency vocabulary
  and, for a loopdata instance whose target report is Spanish, the moon
  phases, body names and all 88 constellation names -- the shared
  vocabulary in step with weewx-skyfield's and weewx-celestial's
  es.conf (the cross-repo test pins it, as for the German, French and
  Dutch).  Select it with lang = es in the report.

## 6.6 2026/07/30
- Almanac fields take a unit segment, completing the grammar --
  observation fields (day.outTemp.avg.degree_C) and station fields
  (station.altitude.meter.raw) already took one:
  almanac.sunrise.unix_epoch.raw, almanac.sun.visible.second.raw,
  almanac.sun.visible.hour.round(2).raw.  The unit segment pins the unit
  no matter what the target report's unit settings say.  Without one, raw
  values follow the target report's converter (unchanged, by design) --
  including any [Units] [[Groups]] overrides, so a report that sets
  group_deltatime = hour turns almanac.sun.visible.raw into hours.  Pin
  the unit on any .raw field a page consumes numerically.
- Attribute chains now walk exactly as Cheetah's NameMapper walks a
  report tag: a segment that resolves to a method or function is
  auto-called at every dot, not only at the end of the chain (under
  weewx-skyfield <= 1.14, almanac.moon.parallactic_angle.degrees failed
  as a loopdata field even though the report tag worked), and a callable
  instance is never auto-called, exactly as Cheetah leaves them alone.
  Applies to almanac and station fields alike.
- The French translation is out of Beta: lang/fr.conf has been
  native-speaker reviewed, in step with weewx-skyfield's and
  weewx-celestial's reviewed French (the cross-repo test pins the
  three together).
- A complete Dutch translation ships with the sample LoopData skin
  (Beta, awaiting native-speaker review -- corrections welcome):
  lang/nl.conf, including the trend.barometer.desc tendency vocabulary
  and, for a loopdata instance whose target report is Dutch, the moon
  phases, body names and all 88 constellation names -- the shared
  vocabulary in step with weewx-skyfield's and weewx-celestial's
  nl.conf (the cross-repo test pins it, as for the German and French).
  Select it with lang = nl in the report.
- Internal: tests/spec_only_runner.py caught up with 6.5's i18n test
  renames (it referenced the old German-only test name, so it errored
  out instead of running).

## 6.5 2026/07/29
- A complete French translation ships with the sample LoopData skin
  (Beta, awaiting native-speaker review -- corrections welcome):
  lang/fr.conf, including the trend.barometer.desc tendency vocabulary
  and, for a loopdata instance whose target report is French, the moon
  phases, body names and all 88 constellation names -- the shared
  vocabulary in step with weewx-skyfield's and weewx-celestial's
  fr.conf (a test pins this, as for the German).  Select it with
  lang = fr in the report.

## 6.4 Release 2026/07/28
ACTION REQUIRED for users who customized [[BarometerTrendDescriptions]]:
the [LoopData] [[BarometerTrendDescriptions]] section is REMOVED and now
ignored -- delete it from weewx.conf.  The trend.barometer.desc
descriptions are now gettext-style [Texts] keys in the TARGET report
(the English description is the key), so they translate through the same
lang-file machinery as everything else -- the shipped lang/de.conf
carries all nine in German -- and a custom wording goes on the target
report's stanza instead:

```
[StdReport] [[LoopDataReport]] [[[Texts]]] "Steady" = "Holding"
```

Users who never touched the section need do nothing: the English
defaults are unchanged.

The sample report is translatable, and German ships.  The same
WeeWX-native machinery as weewx-skyfield 1.12 and weewx-celestial 7.2:
every string the page renders is a gettext-style [Texts] key (the
English string IS the key, so a missing entry falls back to English one
string at a time), lang/en.conf is the reference dictionary, and
lang/de.conf is a complete German translation whose shared vocabulary
is copied verbatim from those extensions' native-speaker-reviewed
files (a test pins the repos together).  Everything the live
javascript composes -- the LIVE/OFFLINE badge, the dial readout lines,
the compass and windrose cardinal letters -- is translated at
generation time and fed to the script through json.dumps.  Select with
lang = de on the report's stanza in weewx.conf.

Two languages meet on the page, and the manual's new Translations page
documents the coupling: the page's own labels follow the sample
report's lang, but the live VALUES in loop-data.txt
(.ordinal_compass, moon_phase, `almanac.<body>.label`, trend and
station fields) render in the language of loopdata's [LoopData]
target report.  Setting [StdReport] [[Defaults]] lang = de in
weewx.conf sets both at once.  The shipped lang files carry the
target-report sections too (ordinates, moon phases, body and all 88
constellation names, hemispheres), so a German LoopDataReport serves
German values.

## 6.3 Release 2026/07/25
New: station fields.  Any $station report tag can be listed as a field
with the $ removed: station.uptime.raw, station.uptime.long_form(),
station.os_uptime.raw, station.version, station.location,
station.altitude.meter.raw, ...  Values are evaluated against
weewx.station.Station -- the exact object behind the report's $station
tag -- with loopdata's usual round(n) and format specs.  uptime and
os_uptime are recomputed every packet, so a live uptime readout is
correct within one packet of a weewxd or server restart (the report-cycle
workaround -- extrapolating from an uptime frozen at generation time --
shows the pre-restart uptime still climbing until the next report cycle).
Every other $station attribute is constant for the life of the process
and is computed once.

A field whose endpoint is a tuple of scalars is now emitted as a json
array instead of Python's str() of the tuple: station.latitude renders as
["37", "24.00", "N"] -- the same (degrees, minutes, hemisphere) parts a
template indexes -- and an almanac field ending in, e.g., moon_phases
gets the same treatment.

## 6.2 Release 2026/07/24
The sample skin's LIVE indicator now reports a failed loop-data fetch.
When the poll for loop_data_file returns anything but the json -- the
classic being the web server's 404 page because loopdata writes outside
HTML_ROOT (say /dev/shm) with nothing serving it -- the indicator reads
"NO DATA (HTTP 404) -- check loop_data_file" (or "BAD DATA -- check
loop_data_file" for a 200 that isn't json); a network-level failure shows
OFFLINE.  Previously the only trace was a JSON.parse error in the browser
console and a silently dead panel.  A later successful poll rewrites the
indicator to LIVE as always.  (Same change as weewx-celestial 7.1, which
shares the poll's ancestry.)

## 6.1 Release 2026/07/24
Fixed: a dead or hanging rsync remote could stall loop processing for
minutes per attempt despite timeout = 1.  That setting only reached rsync's
--timeout, which bounds rsync protocol I/O, not the phases ssh owns: a
black-holed TCP connect, a stalled handshake, or an auth prompt could each
block the LoopProcessor thread far longer (the file kept its full age
backlog: written minutes after the packet inside it was stamped, dial pages
frozen).  LoopData now folds ssh-side bounds into the rsync transport --
`ConnectTimeout=<timeout>`, `ServerAliveInterval=<timeout>`,
ServerAliveCountMax=2 and BatchMode=yes -- each applied only if your own
ssh_options doesn't set that keyword, so anything you set wins.  Previously
the ConnectTimeout=1 default lived in the ssh_options default value itself,
so setting ssh_options at all (a key file, a port) silently discarded it.
Setting timeout = 0 disables the time bounds (BatchMode is still applied:
an interactive prompt can never be answered under weewxd).

## 6.0 Release 2026/07/22
Action required if you publish the sample report: upgrading replaces the
sample skin's page with the new instrument panel (below) but keeps your
existing [LoopData] fields line, and the panel reads fields the old default
never included (.raw geometry, unit.label scales, day.windrose.*) -- so with
an old fields line the new page serves half-dead: text readouts but no
needles, min-max bands or windrose.  Replace the fields line under
[LoopData] [[Include]] with the one in the README's sample configuration
(exactly the fields the panel reads; append any fields other pages of yours
use) and restart weewxd.  Fresh installs get it by default.

Removed (action required if you used them): the experimental `windrun_<dir>`
observation types (windrun_N ... windrun_NNW) are gone, replaced by the
first-class windrose observation below.  Fields naming them are now ignored.
To migrate: day.windrun_N.sum is element 0 of day.windrose.sum,
day.windrun_NNE.sum element 1, and so on clockwise through NNW (element 15).
The `windrun_<dir>` types were always documented as experimental and likely to
change; this is that change.

New: windrose.  A NOAA-style windrose for any period except current and trend
-- including week, month, year, rainyear and alltime, which `windrun_<dir>`
never supported.  Per period, loopdata accumulates 16 compass bins x N speed
bands, each cell tracking both seconds and distance, plus a directionless
calm total (wind below the calm threshold, or no wind direction).  Four
aggregates project the matrix into json: .sum (16 distances -- windrun
parity, unit-convertible, .formatted-able; sub-calm-threshold wind counts as
calm time, not distance), .time (16 durations in seconds),
.banded (the 16xN seconds matrix -- the NOAA rose), .calm (scalar seconds).
Arrays emit json numbers; .round(n) applies per element.  A windrose.bands
key (band edges, target report windSpeed units) is emitted automatically so
page legends never hardcode the bands, and unit.label.windrose gives the
distance label.  Band edges default to the classic WRPLOT/NOAA bands (0.5,
2.1, 3.6, 5.7, 8.8, 11.1 m/s, shown in report units); override with
[LoopData] windrose_bands (ascending edges in the target report's windSpeed
unit; the first edge is the calm threshold).  Span periods seed at startup
with a single SQL aggregate per period, so even alltime.windrose starts fully
primed.  The sample LoopData skin now draws a live canvas windrose.

Fixed (via the windrose rework): after a weewxd restart, hour-period and
continuous-period (1m-1440m/1h-24h) `windrun_<dir>` buckets started EMPTY and
silently filled as packets arrived -- archive-replay priming never carried
the bucketed values.  windrose accumulators seed every period from the
archive at startup.

Changed (check your pages): time-of-event fields (maxtime, mintime,
firsttime, lasttime) now format with the field's period as the time context,
exactly as WeeWX report tags do -- the target report's [Units][TimeFormats]
entry for that period applies.  With the standard TimeFormats, day.*
times now render as 12:00:00 instead of 07/01/20 12:00:00, hour.* times as
12:00, week.* times as 12:00:00 (Wednesday); month/year/rainyear are
unchanged, and alltime uses the year format (the context WeeWX binds for the
$alltime tag), also unchanged with the standard TimeFormats.  Continuous
periods (1m-1440m, 1h-24h) keep the 'current' format.  In addition, .formatted on a time-of-event field now
yields the same context-formatted time (times carry no label) instead of an
unusable raw-number rendering.  If your page relied on the old full
date-time rendering for day/hour/week times, either adjust the page or set
that period's format in the target report's [Units][TimeFormats].

New: unit override in the fields grammar.  A field may now name an explicit
unit between the aggregation and the format spec
(period.obstype[.agg_type][.unit][.format_spec]), exactly as WeeWX report
tags allow (e.g., current.windSpeed.beaufort, day.outTemp.avg.degree_C.raw,
10m.windGust.max.knot.raw, trend.barometer.mbar.formatted).  Any unit WeeWX
knows for the observation's unit group is accepted, regardless of the target
report's configured units -- handy for gauges (e.g. Beaufort wind) that expect
a fixed unit.  The override is on value fields only; the unit.label prefix form
is unchanged (WeeWX parity: $unit.label is obstype-only).  A unit incompatible
with the observation's group causes the field to be omitted.

New: call-syntax format specs.  The formatting methods WeeWX report tags can
call are now format specs, with the same names, arguments and output:
format(format_string, None_string, add_label, localize), nolabel(format_string,
None_string), string(None_string) and long_form(format_string, None_string) --
e.g. day.outTemp.maxtime.format("%H:%M"), current.outTemp.format(add_label=False),
day.windGust.max.nolabel("%.0f"), day.sunshineDur.sum.long_form().  Arguments
must be literals; positional arguments bind exactly as the report tag's do.  A
bare spec name (day.rain.sum.string) is a zero-argument call, as Cheetah
renders it.  The unit override composes (day.outTemp.avg.degree_C.nolabel("%.2f")),
and the calls work on almanac fields too (almanac.sunrise.format("%H:%M")).
string(), or an explicit None_string argument, additionally makes a field with
missing data EMIT its None rendering (N/A or the None_string), overriding
loopdata's omit-missing-fields default -- handy for pages that want every key
present from the first packet.  NOTE: a call containing a comma must be quoted
in weewx.conf ('day.rain.sum.format("%.2f", add_label=False)') or ConfigObj
splits the entry at the comma.

New: round(n).  A field may round its value before rendering, exactly as
report tags allow -- day.outTemp.max.round(1).raw, or with a unit override,
day.barometer.max.mbar.round(1).raw.  Ordered between the unit override and
the format spec (period.obstype[.agg_type][.unit][.round(n)][.format_spec]);
composes with every format spec (round(2).format("%.3f") renders the rounded
value) and works on almanac fields (almanac.moon.az.round(1).raw).  Most
useful with .raw, to publish numbers with limited digits (29.93 instead of
29.927100000000002).

Fixed: the target report's options are now assembled by WeeWX's own
build_skin_dict when it exists (loopdata was looking it up under a stale name,
so it always fell back to its own assembly), and the fallback now disables
ConfigObj interpolation exactly as WeeWX does.  Without this, the %(hour)d-style
delta-time format strings misparse and long_form() cannot render.

New: the sample LoopData skin is a live instrument panel.  A NOAA windrose
plus eleven canvas gauges in three rows of four -- temperature, dew point,
feels-like and humidity dials wearing today's min-max as a band, a wind
compass with a ghost needle at the 10-minute gust direction, a barometer
with the 3-hour trend drawn as an arc (chevron showing the direction of
travel), rain and rain-rate dials that rescale themselves on a big day,
UV, solar radiation and air quality (weewx-purple's pm2_5_aqi) -- in a few
hundred lines of dependency-free javascript to crib from, replacing the
old tables page.  The gauges scale with the window: the engine draws in a
240-unit coordinate system stretched to the css size, so geometry and
fonts grow together on a wide display (faces cap at 480px).  Gauges for
observations the station does not report
(UV/radiation/air quality without the sensor, feels-like without appTemp)
hide themselves and reappear if the field shows up.  The .raw fields drive
the geometry, report-formatted fields supply every readout, and unit.label
fields pick the dial scales, so the panel follows the target report's
units (metric or US) automatically.  Fresh installs get the fields line
the panel needs; upgrading installs keep their existing fields line -- see
the action-required item at the top of this release.

Docs: the README now opens with the point -- report tags updated on every
loop packet -- and a four-step example (report tags, the same tags on the
fields line, the loop-data.txt they produce, and the javascript that makes
the page live).

Internal: the per-aggregate dispatch in add_period_obstype was refactored into
per-stats-kind extractor tables (SCALAR_AGGS/VEC_AGGS/FIRSTLAST_AGGS), and the
grammar's set of valid aggregate types is now derived from those tables, so
the parser and the dispatch can never drift apart.  No behavior change.

Internal: the format-spec render block that was repeated in the current,
period and trend paths is now a single renderer dispatching through a
FORMAT_SPECS table, and the grammar's set of valid format specs (and the
almanac grammar's) is derived from that table, just like the aggregate
types.  No behavior change.

Internal: the test suite moved from bin/user/tests to a top-level tests
directory.  No change to the installed extension.

## 5.0 Release 2026/07/19
New: almanac fields.  Any WeeWX report almanac tag can now be listed in
[LoopData] [[Include]] fields with the $ removed (e.g., almanac.sunrise,
almanac.sunrise.raw, almanac.moon_phase, almanac.sun.az,
almanac(horizon=-6).sun(use_center=1).rise.raw, almanac.next_solstice.raw).
Values are computed with whatever almanac WeeWX has registered (weewx-skyfield,
PyEphem, or the built-in fallback) and formatted with the target report's
formatter/converter, exactly as the report tag would render.  One loopdata
extension: almanac(days=±N) evaluates at the same wall-clock time N local
calendar days away (e.g., almanac(days=1).sunrise.raw is tomorrow's sunrise).
Almanac fields are current-only (no period prefixes or aggregates) and are
cached by attribute class: positions/distances recompute every packet,
rise/set/transit/visible once per local day, and `next_*`/`previous_*` events are
kept until the local day advances past the cached event.
This makes celestial loop fields available without any packet-injecting
service: weewx-celestial's loop fields can be replaced by almanac.* entries.

## 4.1 Release 2026/07/12
Fix: weewx could fail to shut down if SIGTERM landed while LoopData was
starting up or priming its accumulators from the database on the first loop
cycle (the broad error handlers there swallowed weewxd's Terminate exception;
they now pass it through).

## 4.0 Release 2026/07/11
No configuration changes are required; this is a drop-in upgrade.
The sortedcontainers package is no longer required.  Its SortedDict is replaced
by MinMaxDict, a minimal min/max-tracking mapping (two heaps with lazy deletion)
tailored to the continuous accumulators — faster than SortedDict at every key
count, with no pathological worst case.  The upstream project has had no
release since 2021, and dropping it simplifies installation (no more pip/apt
prerequisite step).
Continuous accumulators are ~5x faster per packet: the future-debit and
per-value timestamp lists are now deques, making the once-per-packet
front-removal O(1) instead of an O(window-length) list shift.
README: new "Using LoopData in Your Own Skin" section; corrected field
examples, config option names and defaults; many typo fixes.

## 3.9 Release 2026/06/27
Add plumbing for first/last observation types (in case WeeWX fully supports thenm in the future)

## 3.8 Release 2026/07/27
Many tests added after mutation testing.
Support .count which was mistakenly not allowed by the parser

## 3.6 Release 2026/06/25
Fix three potential latent bugs.
Added tests to boost code coverage to 76%.  Minus I/O plumbing, test coverage is > 92%.

## 3.5 Release 2026/06/24
Bug fix for continuous vector accumulator.
Code cleanup.

## 3.4 Release 2026/06/20
Ensure temporary loop data file to actual is atomic.

## 3.3.2 Release 2022/12/19
Don't try to convert string observations to string.

## 3.3.1 Release 2022/12/08
Fix for Issue #10.  Due to foloating point errors, one could
get math domain error for calling sqrt on a negative number.
Thanks https://github.com/hoetzgit for reporting this.

## 3.3 Release 2022/11/23
1. Rather than just being able to use the 2m, 10m and 24h rolling
   time period tags, one can now use arbitrary minute tags from
   1m to 1440m; and also arbitrary hour tags from 1h to 24h.
   For example, the maximum windspeed in the last 15 minutes
   is specified as 15m.wind.max.  In the last 17 minutes, it is
   specified as 17m.wind.max.

## 3.2 Release 2022/11/22
1. Lots of code refactoring.
2. Functionally equivalent to v3.1.

## 3.1 Release 2022/11/19
1. Add support for alltime tag.

   Note: The sample skin is updated to use alltime tags.
   For existing installations that actually use the sample skin, you
   need to add the following fields to the fields clause in the
   LoopData section in weewx.conf:

   ```
   'alltime.outTemp.max.formatted'
   'alltime.outTemp.min.formatted'
   'alltime.rain.sum.formatted'
   'alltime.wind.rms.formatted'
   'alltime.windGust.max.formatted'
   ```

## 3.0.1 Release 2022/10/30
1. Much more efficient rolling time periods (2m, 10m, 24h, trend).
2. Add support 24h tag.

   Note: The sample skin is updated to use 24h tags.
   For existing installations that actually use the sample skin, you
   need to add the following fields to the fields clause in the
   LoopData section in weewx.conf:

   ```
   '24h.outTemp.max.formatted'
   '24h.outTemp.min.formatted'
   '24h.rain.sum.formatted'
   '24h.wind.rms.formatted'
   '24h.windGust.max.formatted'
   ```
3. The python3-sortedcontainers package is now required.  To install
   it on debian, type:

   ```
   sudo apt install python3-sortedcontainers
   ```

## 2.11 Release 2022/09/25
1. Specify what drivers this extension has been tested with.
2. Continue if windrun and/or beaufort can't be calculated.

## 2.10 Release 2022/02/18
1. Bugfix.  Use loop frequency as the weight when adding to the accumulators.


## 2.9 Release 13 February 2022
1. Fix to work with WeeWX 4.6

## 2.8 Release ?? ??? 2020
1. Add support hour tag.

   Note: The sample skin is updated to use the hour tags.
   For existing installations that actually use the sample skin, you
   need to add the following fields to the fields clause in the
   LoopData section in weewx.conf:

   ```
   'hour.outTemp.max.formatted'
   'hour.outTemp.min.formatted'
   'hour.rain.sum.formatted'
   'hour.wind.rms.formatted'
   'hour.windGust.max.formatted'
   ```
2. Add support for 2m tag.

   Note: The sample skin is updated to use the hour tags.
   For existing installations that actually use the sample skin, you
   need to add the following fields to the fields clause in the
   LoopData section in weewx.conf:

   ```
   '2m.outTemp.max.formatted'
   '2m.outTemp.min.formatted'
   '2m.rain.sum.formatted'
   '2m.wind.rms.formatted'
   '2m.windGust.max.formatted'
   ```
3. In addition to the already supported trend.barometer.desc,
   trend.barometer.code is also supported.  The code can
   be an integer between -4 and 4, where the value
   correspsonds to:

   ```
   -4 Falling Rapidly
   -3 Falling Quickly
   -2 Falling
   -1 Falling Slowly
    0 Steady
    1 Rising Slowly
    2 Rising
    3 Rising Quickly
    4 Rising Rapidly
   ```

4. windrun and beaufort (the deprecated syntax for beaufort) now work correctly.

5. Experimental feature -- It is likely these observations will be moved to a
   separate plugin (and available to loopdata).
   current, 10m, trend, hour and day periods now support `windrun_<dir>`.  That is,
   the following (which can be used to make a windrose):

   ```
   windrun_N
   windrun_NNE
   windrun_NE
   windrun_ENE
   windrun_E
   windrun_ESE
   windrun_SE
   windrun_SSE
   windrun_S
   windrun_SSW
   windrun_SW
   windrun_WSW
   windrun_W
   windrun_WNW
   windrun_NW
   windrun_NNW
   ```

## 2.7.2 Release 16 Nov 2020
1. Fix for customer reported problem.  Exception in
   code when no rainyear fields are included in
   fields list.

## 2.7.1 Release 28 Aug 2020
1. Ignore aggreagate fields base on xtypes as there are
   no day accumulators from which to reconstruct inital
   values at start up for these fields.

## 2.7 Release 11 Aug 2020
1. Bug fix for accumulators at startup from daily summaries.
   The daily summary was not being selected in each accumulator
   range.
2. Include tests where week_start is 0 (rather than default 6).

## 2.6 Release 9 Aug 2020
1. Include sample report LoopDataReport to demonstrate
   capabilities of the loopdata extension.

## 2.5 Release 2 Aug 2020
1. Add support for week, month, year and rainyear.
2. Add LoopData>LoopFrequency>seconds setting in weewx.conf.
   This should be set to the number of seconds between
   loop packets.  This is needed to pass the proper
   weights to the accumulator.  This setting defaults
   to 2.5 (2.5 seconds is the frequency of loop packets
   for the Davis Vantage Pro 2).
3. Limit time_delta used for trends to 259200 (3 days).

## 2.5.b2
Fix for LoopFrequency being ignored (was always using default).
Delay accumulator creation until the station time is known (first loop packet).

## 2.5.b1 Release
1. Add support for week, month, year and rainyear.
2. Add LoopData>LoopFrequency>seconds setting in weewx.conf.
   This should be set to the number of seconds between
   loop packets.  This is needed to pass the proper
   weights to the accumulator.  This setting defaults
   to 2.5 (2.5 seconds is the frequency of loop packets
   for the Davis Vantage Pro 2).

## 2.0.1 Release
1. Handle case where driver emits packets in a unit_system
   other than the database unit_system.

## 2.0 Release
1. The release is identical to rc0; except for a small
   type annotation change and additional tests.
2. Updated documentation (README).

## 2.0.rc0 07/22/2020
Release Candidate 0
1. Fix regression in day accumulator introduced in 2.0.b14.
2. Add test to cover above (added a previous day packet
   so that tests cover a day boundary.
3. Only accumulate specified day fields in the day accumulator.

## 2.0.b15 07/21/2020
1. Breaking change.  If loop_data_dir is a relative path, it
   is now relative to the target_report directory.  After
   installing, check loop_data_dir before you restart WeeWX.
2. Default target_report is now WeatherBoard (it was Seasons).
3. For new installs of WeatherBoard and LoopData, this will
   now work out of the box for all flavors of WeeWX 4/Py3.7+
   installs.

## 2.0.b14 07/21/2020
[No user facing changes (but please report issues).]
1. Internal refactoring so that tests use identical code
   path on each loop packet as production uses.

## 2.0.b13 07/21/2020
[No user facing changes (but please report issues).]
1. Clean up dead code.
2. Simplify creation of target report converter.
3. Elminate unused archivet period accumulator.

## 2.0.b12 07/20/2020
1. Test and fixes for trend.barometer.desc

## 2.0.b11 07/20/2020
1. Ability to localize trend.barometer.desc text in weewx.conf.

## 2.0.b10 07/19/2020
1. Substantial refactoring.  More tests.

## 2.0.b9 07/19/2020
1. 10m. is now a full fledged time period (rolling 10 minutes)
   and supports all that day. supports.  For example, 10m.wind.gustdir

## 2.0.b8 07/18/2020
1. Save values for trends for only trend fields specified in fields clause.
2. Only parse fields one time.

## 2.0.b7 07/18/2020
1. trend no longer restricted to barometer.

## 2.0.b6 07/13/2020
1. Install no longer adds the rename line to weewx.conf.  rename
   is no longer supported.  Note: it will not remove rename on
   existing installations, but rename will be ignored.
1. Updated README.

## 2.0.b5 07/12/2020
1. Fix for case where barometer is reported intermittently.
2. LoopData now tested in simulator for both intermittent case and
   when batometer/pressure never reported.

## 2.0.b4 07/12/2020
1. If not observation available, the key/value pair
   will not be present in the json file.

## 2.0.b3 07/12/2020
1. Handle stations with no barometer.

## 2.0.b2 07/12/2020
1. Watch for None when formatting.

2. pyflakes and mypy cleanup.

## 2.0.b1 07/11/2020
1. Rewritten to use cheetah like identifiers for fields (e.g., $day.rain.sum).

2. Old names are NOT supported.  For existing installations, fields need to be
   renamed in weewx.conf (LoopData fields), your Cheetah templates/JavasScript.

## 1.3.19 07/09/2020
1. Catch and log setup errors.  Allow WeeWX to continue with LoopData.

## 1.3.18 07/09/2020
1. Handle null barometer values in database.

## 1.3.17 07/08/2020
1. Bug fix for wind (not FMT_) version of day stats.
   The values were not being formatted to the proper
   number of decimal places.

2. Add missing highs and lows for vector stats (aka, wind).

## 1.3.16 07/07/2020
1. Add missing highs and lows for vector stats (aka, wind).
2. Add formatting for all times (e.g., FMT_dateTime, FMT_T_HI_wind)

## 1.3.15 07/06/2020
Fix OutOfSpan error caused by creating accumulator with current time
rather than packet time.

## 1.3.14 07/06/2020
1. Add support for VectorStats:  Wind Avg, Wind RMS, Wind Vector Avg, Wind Vector Dir.
2. More tests written.


## 1.3.13 07/05/2020
Fall back to using copy.deepcopy for earlier WeeWX 4 versions.

## 1.3.12 07/05/2020
1. Properly import weeutil.config

## 1.3.11 07/05/2020
1. pyflakes found some issues including lots of unused imports.
2. Update one test.

## 1.3.10 07/05/2020
1. Redo how 10m max gust is handled when windGust not in packet.
   Simply substitue windSpeed for windGust.
2. Test overriding km_per_hour label in weewx.conf Defaults>Units.
3. Add test of CC3000 packets.
4. Add test of IP100 packets.
5. Add test of Simulator packets.

## 1.3.9 07/05/2020
1. Properly construct dictionary of target_report so formatting
   and conversion actually does what it should.
2. Fix a problem reported by a user running pyflakes.  USUnit
   wasn't qualified.
3. Fix an issue reported. windGust was assumed to be in the
   packet.  Now, if not present, max windSpeed in the archive period
   accumulator stats is used to compute 10m gust.

## 1.3.8 07/05/2020
Require at least Python 3.7.
Handle None for windSpeed and and windDir in the database (as some drivers write None rather than omitting).
More tests.


## 1.3.7 07/04/2020
Refactor loopdata.py to facilitate testing.

## 1.3.6 07/04/2020
Add tests for conversions and formatting:
weewx.METRIC   -> metric reports
weewx.METRIC   -> us     reports
weewx.US       -> metric reports
weewx.US       -> us     reports
weewx.METRICWX -> metric reports
weewx.METRICWX -> us     reports

## 1.3.5 07/03/2020
Converting to report units was being done correctly for observations.
This release fixes conversions for highs, lows, sums, averages and weighed averages.

## 1.3.4 07/02/2020
Installer uses FMT_SUM_rain rather than FMT_day_rain_total in LoopData section of weewx.conf.
day_rain_total is not emitted by many drivers and was a source of confusion.

## 1.3.3 07/02/2020
Refrain from trying to format the sum of unix_epoch observations.

## 1.3.2 07/02/2020
Catch FMT_SUM_ formatting exceptions and print error to log with obstype,
unit_type and unit_group.

## 1.3.1 06/30/2020
Fixed issue when specifying port in rsync section.  RsyncUpload was expecting a string
for port, loopdata was passing an int.

## 1.3 06/29/2020
Introduced AVG_/FMT_AVG_ and WAVG_/FMT_WAVG_ prefixes for today's average
and weighted average of an observation, respectively.

## 1.2.2 06/28/2020
Introduced SUM_ and FMT_SUM_ prefixes for today's totals of observations.
This is most useful for rain, where SUM_rain (or FMT_SUM_rain) will yield
today's cumultive rainfall.

## 1.2.1 06/27/2020
Inexplicably, just a version bump.  No other changes.

## 1.2 06/27/2020
Fixed issue where loop thread was created multiple times.


## 1.1 06/27/2020
Fixes to work with Metric/Mixed database and to correctly target
non-US reports.


## 1.0 01/19/2020
Initial release of loopdata.
