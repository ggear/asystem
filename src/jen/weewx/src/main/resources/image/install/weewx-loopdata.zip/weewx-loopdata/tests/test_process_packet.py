#    Copyright (c) 2022-2026 John A Kline <john@johnkline.com>
#
#    See the file LICENSE.txt for your full rights.
#
#    HOW TO RUN THESE TESTS
#    ----------------------
#    Run from the repository root (~/software/weewx-loopdata), NOT from the
#    tests directory.  The harness loads its config files via paths relative
#    to the current directory (e.g. 'tests/weewx.conf.us'), so the
#    working directory must be the repo root or every config-loading test
#    fails with KeyError: 'StdConvert' (an empty config from a missing file).
#
#    Activate the weewx venv first so weewx/weeutil import.
#
#    Both 'bin' and 'tests' must be on PYTHONPATH:
#      - bin   -> resolves 'import user.loopdata'
#      - tests -> resolves the packet-data modules
#               (cc3000_packets, ip100_packets, etc.)
#
#    Command (uses Python's built-in unittest runner; pytest not required):
#
#      cd ~/software/weewx-loopdata
#      PYTHONPATH=bin:tests python3 tests/test_process_packet.py
#
#    Add -v for per-test names, or append a test name to run just one, e.g.:
#
#      PYTHONPATH=bin:tests python3 tests/test_process_packet.py -v
#      PYTHONPATH=bin:tests python3 tests/test_process_packet.py \
#          ProcessPacketTests.test_wind
#
"""Test processing packets."""

import configobj
import contextlib
import importlib
import importlib.util
import inspect
import io
import json
import locale
import logging
import math
import os
import pathlib
import queue
import random
import re
import shutil
import decimal
import string
import subprocess
import threading
import tempfile
import time
import unittest

from datetime import date, datetime

import weewx
import weewx.accum
import weewx.almanac
import weewx.defaults
import weewx.reportengine
import weewx.manager
import weewx.station
import weewx.units
from weewx.schemas.wview_extended import schema as wview_extended_schema
from weeutil.weeutil import to_bool
from weeutil.weeutil import to_int
from weeutil.weeutil import timestamp_to_string

from typing import Any, Dict, List, Optional, Set, Tuple

import weecfg.extension
import weeutil.config
import weeutil.logger

import user.loopdata
import cc3000_packets
import cc3000_cross_midnight_packets
import ip100_packets
import simulator_packets
import vantagepro2_packets

# Rendering reads a locale.  A report with no lang renders under weewxd's
# ENVIRONMENT locale -- that is what reportengine's set_locale('') selects,
# and loopdata now captures the same thing per report -- so the expected
# strings in this file would otherwise depend on the LANG of whoever runs
# the suite.  Pin it, exactly as TZ is pinned throughout.  A test that cares
# about a particular locale sets its own (see with_locale).
os.environ['LC_ALL'] = 'C'
os.environ['LANG'] = 'C'

log = logging.getLogger(__name__)

# Set up logging using the defaults.
weeutil.logger.setup('test_config', {})

class StubRadians(float):
    """A skyfield-1.15-shaped angle: a float that is also a callable
    instance and carries .degrees.  Cheetah's NameMapper never auto-calls a
    callable INSTANCE (only methods and functions), so __call__ raising pins
    that loopdata's evaluators leave it alone too, mid-chain or at the end
    of a chain."""
    @property
    def degrees(self) -> float:
        return math.degrees(float(self))

    def __call__(self) -> None:
        raise AssertionError('a callable instance must not be auto-called')

class StubAlmanacBinder:
    """Stands in for a heavenly-body binder (e.g. $almanac.sun)."""
    def __init__(self, stub: 'StubAlmanacType', almanac_obj: Any) -> None:
        self.stub = stub
        self.almanac_obj = almanac_obj
        self.use_center = 0

    def __call__(self, use_center: int = 0) -> 'StubAlmanacBinder':
        self.use_center = use_center
        return self

    @property
    def az(self) -> float:
        self.stub.count('sun.az')
        return 123.4

    @property
    def visible(self) -> weewx.units.ValueHelper:
        # Daylight as PyEphem/skyfield serve it: a duration ValueHelper in
        # seconds, converted per the almanac's converter when rendered.
        self.stub.count('sun.visible')
        return weewx.units.ValueHelper(
            weewx.units.ValueTuple(52921.0, 'second', 'group_deltatime'),
            context='ephem_day',
            formatter=self.almanac_obj.formatter,
            converter=self.almanac_obj.converter)

    def parallactic_angle(self) -> StubRadians:
        # A bound METHOD, as skyfield <= 1.14 served it: Cheetah auto-calls
        # it mid-chain, so the evaluator must too.
        self.stub.count('sun.parallactic_angle')
        return StubRadians(0.5)

    @property
    def callable_angle(self) -> StubRadians:
        self.stub.count('sun.callable_angle')
        return StubRadians(0.5)

    def duration_method(self) -> float:
        # A bound method at the END of a chain: auto-called, as always.
        self.stub.count('sun.duration_method')
        return 42.0

    @property
    def rise(self) -> weewx.units.ValueHelper:
        # 06:00 local on the almanac's local day, shifted one minute per
        # degree of horizon and ten minutes earlier for use_center, so the
        # test can verify both kwargs reached the computation.
        self.stub.count('sun.rise')
        day_start = time.mktime(date.fromtimestamp(self.almanac_obj.time_ts).timetuple())
        rise_ts = (day_start + 6 * 3600 + int(self.almanac_obj.horizon * 60)
                   - (600 if self.use_center else 0))
        return self.stub.time_vh(self.almanac_obj, rise_ts)

class StubPass:
    """A satellite-pass-shaped object, as wxskyfield's next_pass serves one:
    time-typed rise/set ValueHelpers, a group_deltatime duration, and a
    timeless max_altitude.  Selected by StubAlmanacType with wxskyfield's own
    rule -- the first pass whose set is strictly after the almanac's time --
    so an in-progress pass IS the next pass."""
    def __init__(self, stub: 'StubAlmanacType', almanac_obj: Any,
            rise_ts: Optional[float], set_ts: Optional[float],
            max_altitude: Optional[float]) -> None:
        self.stub = stub
        self.almanac_obj = almanac_obj
        self.rise_ts = rise_ts
        self.set_ts = set_ts
        self._max_altitude = max_altitude

    @property
    def rise(self) -> weewx.units.ValueHelper:
        self.stub.count('next_pass.rise')
        return StubAlmanacType.time_vh(self.almanac_obj, self.rise_ts)

    @property
    def set(self) -> weewx.units.ValueHelper:
        self.stub.count('next_pass.set')
        return StubAlmanacType.time_vh(self.almanac_obj, self.set_ts)

    @property
    def duration(self) -> weewx.units.ValueHelper:
        self.stub.count('next_pass.duration')
        seconds = (self.set_ts - self.rise_ts
                   if self.rise_ts is not None and self.set_ts is not None else None)
        return weewx.units.ValueHelper(
            weewx.units.ValueTuple(seconds, 'second', 'group_deltatime'),
            context='ephem_day',
            formatter=self.almanac_obj.formatter,
            converter=self.almanac_obj.converter)

    @property
    def max_altitude(self) -> Optional[float]:
        self.stub.count('next_pass.max_altitude')
        return self._max_altitude

class StubAlmanacType(weewx.almanac.AlmanacType):
    """Serves deterministic values so loopdata's almanac plumbing (parsing,
    evaluation, formatting, caching) can be tested from first principles,
    independent of any ephemeris."""
    def __init__(self) -> None:
        self.counts: Dict[str, int] = {}
        self.next_full_moon_ts: float = 0.0
        self.previous_full_moon_ts: float = 0.0
        self.passes: List[Tuple[float, float, float]] = []  # (rise_ts, set_ts, max_altitude)
        # Attrs currently answering with no data (an empty ValueHelper, raw
        # None) -- how skyfield reports a satellite whose elements have not
        # been fetched; evaluation never raises.
        self.no_data: Set[str] = set()

    def count(self, attr: str) -> None:
        self.counts[attr] = self.counts.get(attr, 0) + 1

    @staticmethod
    def time_vh(almanac_obj: Any, ts: Optional[float]) -> weewx.units.ValueHelper:
        return weewx.units.ValueHelper(
            weewx.units.ValueTuple(ts, 'unix_epoch', 'group_time'),
            context='ephem_day',
            formatter=almanac_obj.formatter,
            converter=almanac_obj.converter)

    def get_almanac_data(self, almanac_obj: Any, attr: str) -> Any:
        if attr == 'stub_time':
            self.count(attr)
            return almanac_obj.time_ts
        if attr == 'stub_horizon':
            self.count(attr)
            return almanac_obj.horizon
        if attr == 'sunrise':
            self.count(attr)
            if attr in self.no_data:
                return StubAlmanacType.time_vh(almanac_obj, None)
            day_start = time.mktime(date.fromtimestamp(almanac_obj.time_ts).timetuple())
            return StubAlmanacType.time_vh(almanac_obj, day_start + 6 * 3600)
        if attr == 'moon_index':
            self.count(attr)
            return 4
        if attr == 'next_full_moon':
            self.count(attr)
            if attr in self.no_data:
                return StubAlmanacType.time_vh(almanac_obj, None)
            return StubAlmanacType.time_vh(almanac_obj, self.next_full_moon_ts)
        if attr == 'previous_full_moon':
            self.count(attr)
            return StubAlmanacType.time_vh(almanac_obj, self.previous_full_moon_ts)
        if attr == 'next_pass':
            self.count(attr)
            if attr not in self.no_data:
                for rise_ts, set_ts, max_altitude in self.passes:
                    if set_ts > almanac_obj.time_ts:
                        return StubPass(self, almanac_obj, rise_ts, set_ts, max_altitude)
            return StubPass(self, almanac_obj, None, None, None)
        if attr == 'sun':
            return StubAlmanacBinder(self, almanac_obj)
        raise weewx.UnknownType(attr)

class ProcessPacketTests(unittest.TestCase):
    maxDiff = None

    def test_parse_cname(self) -> None:
        cname: Optional[user.loopdata.CheetahName] = user.loopdata.LoopData.parse_cname('unit.label.outTemp')
        assert cname is not None
        self.assertEqual(cname.field, 'unit.label.outTemp')
        self.assertEqual(cname.prefix, 'unit')
        self.assertEqual(cname.prefix2, 'label')
        self.assertEqual(cname.period, None)
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('2m.windGust.max.raw')
        assert cname is not None
        self.assertEqual(cname.field, '2m.windGust.max.raw')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, '2m')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, 'raw')

        cname = user.loopdata.LoopData.parse_cname('2m')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('2m.wind')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('2m.wind.max.formatted.foo')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('10m.windGust.max.raw')
        assert cname is not None
        self.assertEqual(cname.field, '10m.windGust.max.raw')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, '10m')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, 'raw')

        cname = user.loopdata.LoopData.parse_cname('10m')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('10m.wind')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('10m.wind.max.formatted.foo')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('current')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('current.wind.max.formatted.foo')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('day')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('hour')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('day.wind')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('hour.wind')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('day.wind.max.formatted.foo')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('hour.wind.max.formatted.foo')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('trend')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('trend.wind.formatted.foo')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('week')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('month')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('year')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('rainyear')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('alltime')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('week.outTemp')
        self.assertEqual(cname, None)

        # --- windrose grammar ---
        # Every span period accepts windrose (the old windrun_<dir> types
        # were day/hour-only; windrose is not), as do continuous periods.
        for period in ['hour', 'day', 'week', 'month', 'year', 'rainyear',
                'alltime', '10m', '24h']:
            for agg in ['sum', 'time', 'banded', 'calm']:
                cname = user.loopdata.LoopData.parse_cname('%s.windrose.%s' % (period, agg))
                assert cname is not None, '%s.windrose.%s should parse' % (period, agg)
                self.assertEqual(cname.period, period)
                self.assertEqual(cname.obstype, 'windrose')
                self.assertEqual(cname.agg_type, agg)

        # Not defined for current (one sample is not a rose) or trend (a
        # delta of a histogram is meaningless); an aggregate is required and
        # must be a windrose aggregate.
        self.assertEqual(user.loopdata.LoopData.parse_cname('current.windrose'), None)
        self.assertEqual(user.loopdata.LoopData.parse_cname('trend.windrose'), None)
        self.assertEqual(user.loopdata.LoopData.parse_cname('day.windrose'), None)
        self.assertEqual(user.loopdata.LoopData.parse_cname('day.windrose.max'), None)
        self.assertEqual(user.loopdata.LoopData.parse_cname('day.windrose.avg'), None)
        # 'time'/'banded'/'calm' exist only for windrose.
        self.assertEqual(user.loopdata.LoopData.parse_cname('day.outTemp.banded'), None)
        self.assertEqual(user.loopdata.LoopData.parse_cname('day.windSpeed.calm'), None)

        # Unit override, round(n) and raw/formatted compose on .sum.
        cname = user.loopdata.LoopData.parse_cname('day.windrose.sum.km.round(1).formatted')
        assert cname is not None
        self.assertEqual(cname.agg_type, 'sum')
        self.assertEqual(cname.unit, 'km')
        self.assertEqual(cname.round_ndigits, 1)
        self.assertEqual(cname.format_spec, 'formatted')
        # The seconds projections take round(n) and raw, but no unit override
        # and no .formatted (they are not group_distance values).
        cname = user.loopdata.LoopData.parse_cname('24h.windrose.banded.round(0)')
        assert cname is not None
        self.assertEqual(cname.round_ndigits, 0)
        cname = user.loopdata.LoopData.parse_cname('day.windrose.calm.raw')
        assert cname is not None
        self.assertEqual(cname.format_spec, 'raw')
        self.assertEqual(user.loopdata.LoopData.parse_cname('day.windrose.time.mile'), None)
        self.assertEqual(user.loopdata.LoopData.parse_cname('day.windrose.time.formatted'), None)
        self.assertEqual(user.loopdata.LoopData.parse_cname('day.windrose.calm.formatted'), None)
        # No call-syntax specs and no compass/baro specs (arrays, not scalars).
        self.assertEqual(user.loopdata.LoopData.parse_cname('day.windrose.sum.format("%.1f")'), None)
        self.assertEqual(user.loopdata.LoopData.parse_cname('day.windrose.sum.ordinal_compass'), None)
        self.assertEqual(user.loopdata.LoopData.parse_cname('day.windrose.sum.desc'), None)

        # The unit.label prefix form works (windrose distances label).
        cname = user.loopdata.LoopData.parse_cname('unit.label.windrose')
        assert cname is not None
        self.assertEqual(cname.prefix, 'unit')
        self.assertEqual(cname.prefix2, 'label')
        self.assertEqual(cname.obstype, 'windrose')

        cname = user.loopdata.LoopData.parse_cname('week.outTemp.avg')
        assert cname is not None
        self.assertEqual(cname.field, 'week.outTemp.avg')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'week')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, 'avg')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('month.outTemp.avg')
        assert cname is not None
        self.assertEqual(cname.field, 'month.outTemp.avg')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'month')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, 'avg')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('year.outTemp.avg')
        assert cname is not None
        self.assertEqual(cname.field, 'year.outTemp.avg')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'year')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, 'avg')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('rainyear.outTemp.avg')
        assert cname is not None
        self.assertEqual(cname.field, 'rainyear.outTemp.avg')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'rainyear')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, 'avg')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('alltime.outTemp.avg')
        assert cname is not None
        self.assertEqual(cname.field, 'alltime.outTemp.avg')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'alltime')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, 'avg')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('week.windGust.max.formatted')
        assert cname is not None
        self.assertEqual(cname.field, 'week.windGust.max.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'week')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('month.windGust.max.formatted')
        assert cname is not None
        self.assertEqual(cname.field, 'month.windGust.max.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'month')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('year.windGust.max.formatted')
        assert cname is not None
        self.assertEqual(cname.field, 'year.windGust.max.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'year')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('rainyear.windGust.max.formatted')
        assert cname is not None
        self.assertEqual(cname.field, 'rainyear.windGust.max.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'rainyear')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('alltime.windGust.max.formatted')
        assert cname is not None
        self.assertEqual(cname.field, 'alltime.windGust.max.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'alltime')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('2m.windGust.max.formatted')
        assert cname is not None
        self.assertEqual(cname.field, '2m.windGust.max.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, '2m')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('10m.windGust.max.formatted')
        assert cname is not None
        self.assertEqual(cname.field, '10m.windGust.max.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, '10m')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('10m.windGust.maxtime')
        assert cname is not None
        self.assertEqual(cname.field, '10m.windGust.maxtime')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, '10m')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'maxtime')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('10m.outTemp.max.raw')
        assert cname is not None
        self.assertEqual(cname.field, '10m.outTemp.max.raw')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, '10m')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, 'raw')

        cname = user.loopdata.LoopData.parse_cname('10m.outTemp.max.formatted')
        assert cname is not None
        self.assertEqual(cname.field, '10m.outTemp.max.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, '10m')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('10m.outTemp.maxtime')
        assert cname is not None
        self.assertEqual(cname.field, '10m.outTemp.maxtime')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, '10m')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, 'maxtime')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('unit.label.wind')
        assert cname is not None
        self.assertEqual(cname.field, 'unit.label.wind')
        self.assertEqual(cname.prefix, 'unit')
        self.assertEqual(cname.prefix2, 'label')
        self.assertEqual(cname.period, None)
        self.assertEqual(cname.obstype, 'wind')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('trend.barometer')
        assert cname is not None
        self.assertEqual(cname.field, 'trend.barometer')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'trend')
        self.assertEqual(cname.obstype, 'barometer')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('trend.barometer.formatted')
        assert cname is not None
        self.assertEqual(cname.field, 'trend.barometer.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'trend')
        self.assertEqual(cname.obstype, 'barometer')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('trend.barometer.code')
        assert cname is not None
        self.assertEqual(cname.field, 'trend.barometer.code')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'trend')
        self.assertEqual(cname.obstype, 'barometer')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, 'code')

        cname = user.loopdata.LoopData.parse_cname('trend.barometer.desc')
        assert cname is not None
        self.assertEqual(cname.field, 'trend.barometer.desc')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'trend')
        self.assertEqual(cname.obstype, 'barometer')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, 'desc')

        cname = user.loopdata.LoopData.parse_cname('trend.outTemp')
        assert cname is not None
        self.assertEqual(cname.field, 'trend.outTemp')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'trend')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('trend.outTemp.formatted')
        assert cname is not None
        self.assertEqual(cname.field, 'trend.outTemp.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'trend')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('trend.dewpoint')
        assert cname is not None
        self.assertEqual(cname.field, 'trend.dewpoint')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'trend')
        self.assertEqual(cname.obstype, 'dewpoint')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('trend.dewpoint.formatted')
        assert cname is not None
        self.assertEqual(cname.field, 'trend.dewpoint.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'trend')
        self.assertEqual(cname.obstype, 'dewpoint')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('current.outTemp')
        assert cname is not None
        self.assertEqual(cname.field, 'current.outTemp')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'current')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('current.dateTime')
        assert cname is not None
        self.assertEqual(cname.field, 'current.dateTime')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'current')
        self.assertEqual(cname.obstype, 'dateTime')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('current.dateTime.raw')
        assert cname is not None
        self.assertEqual(cname.field, 'current.dateTime.raw')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'current')
        self.assertEqual(cname.obstype, 'dateTime')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, 'raw')

        cname = user.loopdata.LoopData.parse_cname('current.windSpeed')
        assert cname is not None
        self.assertEqual(cname.field, 'current.windSpeed')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'current')
        self.assertEqual(cname.obstype, 'windSpeed')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('current.windSpeed.ordinal_compass')
        assert cname is not None
        self.assertEqual(cname.field, 'current.windSpeed.ordinal_compass')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'current')
        self.assertEqual(cname.obstype, 'windSpeed')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.format_spec, 'ordinal_compass')

        cname = user.loopdata.LoopData.parse_cname('day.rain.sum')
        assert cname is not None
        self.assertEqual(cname.field, 'day.rain.sum')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'rain')
        self.assertEqual(cname.agg_type, 'sum')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('hour.rain.sum')
        assert cname is not None
        self.assertEqual(cname.field, 'hour.rain.sum')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'hour')
        self.assertEqual(cname.obstype, 'rain')
        self.assertEqual(cname.agg_type, 'sum')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('day.rain.sum.raw')
        assert cname is not None
        self.assertEqual(cname.field, 'day.rain.sum.raw')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'rain')
        self.assertEqual(cname.agg_type, 'sum')
        self.assertEqual(cname.format_spec, 'raw')

        cname = user.loopdata.LoopData.parse_cname('hour.rain.sum.raw')
        assert cname is not None
        self.assertEqual(cname.field, 'hour.rain.sum.raw')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'hour')
        self.assertEqual(cname.obstype, 'rain')
        self.assertEqual(cname.agg_type, 'sum')
        self.assertEqual(cname.format_spec, 'raw')

        cname = user.loopdata.LoopData.parse_cname('24h.rain.sum.raw')
        assert cname is not None
        self.assertEqual(cname.field, '24h.rain.sum.raw')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, '24h')
        self.assertEqual(cname.obstype, 'rain')
        self.assertEqual(cname.agg_type, 'sum')
        self.assertEqual(cname.format_spec, 'raw')

        cname = user.loopdata.LoopData.parse_cname('day.rain.formatted')
        self.assertEqual(cname, None)

        cname = user.loopdata.LoopData.parse_cname('day.windGust.max')
        assert cname is not None
        self.assertEqual(cname.field, 'day.windGust.max')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('day.windDir.max')
        assert cname is not None
        self.assertEqual(cname.field, 'day.windDir.max')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'windDir')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('day.wind.maxtime')
        assert cname is not None
        self.assertEqual(cname.field, 'day.wind.maxtime')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'wind')
        self.assertEqual(cname.agg_type, 'maxtime')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('day.wind.max')
        assert cname is not None
        self.assertEqual(cname.field, 'day.wind.max')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'wind')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('day.wind.gustdir')
        assert cname is not None
        self.assertEqual(cname.field, 'day.wind.gustdir')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'wind')
        self.assertEqual(cname.agg_type, 'gustdir')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('day.wind.vecavg')
        assert cname is not None
        self.assertEqual(cname.field, 'day.wind.vecavg')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'wind')
        self.assertEqual(cname.agg_type, 'vecavg')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('day.wind.vecdir')
        assert cname is not None
        self.assertEqual(cname.field, 'day.wind.vecdir')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'wind')
        self.assertEqual(cname.agg_type, 'vecdir')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('day.wind.rms')
        assert cname is not None
        self.assertEqual(cname.field, 'day.wind.rms')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'wind')
        self.assertEqual(cname.agg_type, 'rms')
        self.assertEqual(cname.format_spec, None)


        cname = user.loopdata.LoopData.parse_cname('day.wind.avg')
        assert cname is not None
        self.assertEqual(cname.field, 'day.wind.avg')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'wind')
        self.assertEqual(cname.agg_type, 'avg')
        self.assertEqual(cname.format_spec, None)

        cname = user.loopdata.LoopData.parse_cname('year.windrun.sum.formatted')
        assert cname is not None
        self.assertEqual(cname.field, 'year.windrun.sum.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'year')
        self.assertEqual(cname.obstype, 'windrun')
        self.assertEqual(cname.agg_type, 'sum')
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('hour.windrun_ENE.sum.formatted')
        assert cname is not None
        self.assertEqual(cname.field, 'hour.windrun_ENE.sum.formatted')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'hour')
        self.assertEqual(cname.obstype, 'windrun_ENE')
        self.assertEqual(cname.agg_type, 'sum')
        self.assertEqual(cname.format_spec, 'formatted')

        cname = user.loopdata.LoopData.parse_cname('day.windrun_W.sum')
        assert cname is not None
        self.assertEqual(cname.field, 'day.windrun_W.sum')
        self.assertEqual(cname.prefix, None)
        self.assertEqual(cname.prefix2, None)
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'windrun_W')
        self.assertEqual(cname.agg_type, 'sum')
        self.assertEqual(cname.format_spec, None)

        # --- segment-guard branch (mutation-test target) ---
        # 'unit' prefix but the second segment is not 'label' -> the prefix2
        # else-branch returns None.
        self.assertEqual(
            user.loopdata.LoopData.parse_cname('unit.notlabel.outTemp'), None)

        # --- unit override grammar (6.0) ---
        # The optional unit segment sits between the agg_type and the
        # format_spec: [period].obstype[.agg_type][.unit][.format_spec].

        # current + unit override, no format_spec (windSpeed -> beaufort).
        cname = user.loopdata.LoopData.parse_cname('current.windSpeed.beaufort')
        assert cname is not None
        self.assertEqual(cname.period, 'current')
        self.assertEqual(cname.obstype, 'windSpeed')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.unit, 'beaufort')
        self.assertEqual(cname.format_spec, None)

        # current + unit override + format_spec.
        cname = user.loopdata.LoopData.parse_cname('current.windSpeed.beaufort.formatted')
        assert cname is not None
        self.assertEqual(cname.obstype, 'windSpeed')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.unit, 'beaufort')
        self.assertEqual(cname.format_spec, 'formatted')

        # period + agg_type + unit override + format_spec (all four optionals).
        cname = user.loopdata.LoopData.parse_cname('day.outTemp.avg.degree_C.formatted')
        assert cname is not None
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, 'avg')
        self.assertEqual(cname.unit, 'degree_C')
        self.assertEqual(cname.format_spec, 'formatted')

        # period + agg_type + unit override, no format_spec.
        cname = user.loopdata.LoopData.parse_cname('day.outTemp.avg.degree_C')
        assert cname is not None
        self.assertEqual(cname.agg_type, 'avg')
        self.assertEqual(cname.unit, 'degree_C')
        self.assertEqual(cname.format_spec, None)

        # continuous period + agg_type + unit override + format_spec.
        cname = user.loopdata.LoopData.parse_cname('10m.windGust.max.knot.raw')
        assert cname is not None
        self.assertEqual(cname.period, '10m')
        self.assertEqual(cname.obstype, 'windGust')
        self.assertEqual(cname.agg_type, 'max')
        self.assertEqual(cname.unit, 'knot')
        self.assertEqual(cname.format_spec, 'raw')

        # trend + unit override + format_spec (trend takes no agg_type).
        cname = user.loopdata.LoopData.parse_cname('trend.outTemp.degree_C.formatted')
        assert cname is not None
        self.assertEqual(cname.period, 'trend')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, None)
        self.assertEqual(cname.unit, 'degree_C')
        self.assertEqual(cname.format_spec, 'formatted')

        # A format_spec is NOT mistaken for a unit: no override here.
        cname = user.loopdata.LoopData.parse_cname('current.windSpeed.formatted')
        assert cname is not None
        self.assertEqual(cname.unit, None)
        self.assertEqual(cname.format_spec, 'formatted')

        # A non-unit, non-format_spec trailing segment is still rejected.
        self.assertEqual(
            user.loopdata.LoopData.parse_cname('current.windSpeed.notaunit'), None)

        # Unit override then a garbage trailing segment -> rejected.
        self.assertEqual(
            user.loopdata.LoopData.parse_cname('current.windSpeed.beaufort.foo'), None)

        # The unit.label prefix form takes NO override (WeeWX parity): the
        # trailing unit segment makes it unexpected extra -> None.
        self.assertEqual(
            user.loopdata.LoopData.parse_cname('unit.label.outTemp.degree_C'), None)

    def test_compose_loop_data_dir(self) -> None:
        config_dict       : Dict[str, Any] = { 'WEEWX_ROOT'   : '/etc/weewx' }
        target_report_dict: Dict[str, Any] = { 'HTML_ROOT'    : 'public_html/weatherboard'}
        file_spec_dict    : Dict[str, Any] = { 'loop_data_dir': '.'}

        self.assertEqual(user.loopdata.LoopData.compose_loop_data_dir(
            config_dict, target_report_dict, file_spec_dict), '/etc/weewx/public_html/weatherboard/.')

        self.assertEqual(user.loopdata.LoopData.compose_loop_data_dir(
            config_dict, target_report_dict, {'loop_data_dir':'/var/weewx/loopdata'}), '/var/weewx/loopdata')

        self.assertEqual(user.loopdata.LoopData.compose_loop_data_dir(
            config_dict, {'HTML_ROOT':'/home/weewx/public_html/weatherboard'}, file_spec_dict), '/home/weewx/public_html/weatherboard/.')

        self.assertEqual(user.loopdata.LoopData.compose_loop_data_dir(
            config_dict, target_report_dict, {'loop_data_dir':'foobar'}), '/etc/weewx/public_html/weatherboard/foobar')

    def test_compose_ssh_options(self) -> None:
        compose = user.loopdata.LoopData.compose_ssh_options

        # No user options: all four ssh-side bounds, timed ones from timeout.
        self.assertEqual(compose('', 1),
            '-o ConnectTimeout=1 -o ServerAliveInterval=1'
            ' -o ServerAliveCountMax=2 -o BatchMode=yes')
        self.assertEqual(compose('', 5),
            '-o ConnectTimeout=5 -o ServerAliveInterval=5'
            ' -o ServerAliveCountMax=2 -o BatchMode=yes')

        # User options come first and unrelated ones don't suppress defaults.
        self.assertEqual(compose('-i /home/weewx/.ssh/id_ed25519 -p 2222', 1),
            '-i /home/weewx/.ssh/id_ed25519 -p 2222'
            ' -o ConnectTimeout=1 -o ServerAliveInterval=1'
            ' -o ServerAliveCountMax=2 -o BatchMode=yes')

        # A keyword the user sets wins: no duplicate is appended, case-blind
        # (ssh keywords are case-insensitive).
        self.assertEqual(compose('-o ConnectTimeout=30', 1),
            '-o ConnectTimeout=30 -o ServerAliveInterval=1'
            ' -o ServerAliveCountMax=2 -o BatchMode=yes')
        self.assertEqual(compose('-o connecttimeout=30 -o batchmode=no', 1),
            '-o connecttimeout=30 -o batchmode=no'
            ' -o ServerAliveInterval=1 -o ServerAliveCountMax=2')
        self.assertEqual(compose('-o ServerAliveInterval=10', 2),
            '-o ServerAliveInterval=10 -o ConnectTimeout=2'
            ' -o ServerAliveCountMax=2 -o BatchMode=yes')

        # timeout <= 0 (rsync "no timeout"): no time bounds, BatchMode stays.
        self.assertEqual(compose('', 0), '-o BatchMode=yes')
        self.assertEqual(compose('-o BatchMode=no', 0), '-o BatchMode=no')

        # Whitespace-only user options behave like none at all.
        self.assertEqual(compose('  ', 0), '-o BatchMode=yes')

    def test_period_classification(self) -> None:
        # Pure-function coverage for the period-classification helpers:
        # is_minute_period, is_hour_period, is_continuous_period, is_valid_period.
        L = user.loopdata.LoopData

        # --- is_minute_period: valid range is 1m..1440m inclusive. ---
        self.assertTrue(L.is_minute_period('1m'))
        self.assertTrue(L.is_minute_period('2m'))
        self.assertTrue(L.is_minute_period('10m'))
        self.assertTrue(L.is_minute_period('1440m'))     # upper bound
        self.assertFalse(L.is_minute_period('0m'))       # below lower bound
        self.assertFalse(L.is_minute_period('1441m'))    # above upper bound
        self.assertFalse(L.is_minute_period('m'))        # no digits
        self.assertFalse(L.is_minute_period('10'))       # no 'm'
        self.assertFalse(L.is_minute_period('10h'))      # wrong unit
        self.assertFalse(L.is_minute_period('1.5m'))     # non-integer
        self.assertFalse(L.is_minute_period('-5m'))      # isdigit() rejects sign
        self.assertFalse(L.is_minute_period('day'))

        # --- is_hour_period: valid range is 1h..24h inclusive. ---
        self.assertTrue(L.is_hour_period('1h'))
        self.assertTrue(L.is_hour_period('2h'))
        self.assertTrue(L.is_hour_period('24h'))         # upper bound
        self.assertFalse(L.is_hour_period('0h'))         # below lower bound
        self.assertFalse(L.is_hour_period('25h'))        # above upper bound
        self.assertFalse(L.is_hour_period('h'))          # no digits
        self.assertFalse(L.is_hour_period('24'))         # no 'h'
        self.assertFalse(L.is_hour_period('2m'))         # wrong unit
        self.assertFalse(L.is_hour_period('1.5h'))       # non-integer
        self.assertFalse(L.is_hour_period('day'))

        # --- is_continuous_period: 'trend' or any valid minute/hour period. ---
        self.assertTrue(L.is_continuous_period('trend'))
        self.assertTrue(L.is_continuous_period('2m'))
        self.assertTrue(L.is_continuous_period('24h'))
        self.assertFalse(L.is_continuous_period('day'))
        self.assertFalse(L.is_continuous_period('current'))
        self.assertFalse(L.is_continuous_period('0m'))
        self.assertFalse(L.is_continuous_period('25h'))

        # --- is_valid_period: fixed periods OR continuous periods. ---
        for p in ['alltime', 'rainyear', 'year', 'month', 'week', 'current', 'hour', 'day']:
            self.assertTrue(L.is_valid_period(p), msg='%s should be valid' % p)
        self.assertTrue(L.is_valid_period('trend'))
        self.assertTrue(L.is_valid_period('1m'))
        self.assertTrue(L.is_valid_period('1440m'))
        self.assertTrue(L.is_valid_period('1h'))
        self.assertTrue(L.is_valid_period('24h'))
        self.assertFalse(L.is_valid_period('decade'))
        self.assertFalse(L.is_valid_period('0m'))
        self.assertFalse(L.is_valid_period('1441m'))
        self.assertFalse(L.is_valid_period('25h'))
        self.assertFalse(L.is_valid_period(''))

    def test_get_windrun_bucket(self) -> None:
        # Pure-function coverage for get_windrun_bucket: maps a wind direction
        # to one of 16 compass buckets (0=N, 1=NNE, ... 15=NNW).  Each bucket
        # is centered on its compass point (i * 22.5 deg) and spans +/-11.25.
        # Directions in [348.75, 360) wrap back to bucket 0 (N).
        L = user.loopdata.LoopProcessor

        # Each of the 16 compass-point centers maps to its own bucket, in order.
        for i in range(16):
            center = i * 22.5
            self.assertEqual(L.get_windrun_bucket(center), i,
                             msg='center %.1f should be bucket %d' % (center, i))

        # Just past each lower edge rounds up into the next bucket.
        self.assertEqual(L.get_windrun_bucket(11.25), 1)    # N/NNE edge -> NNE
        self.assertEqual(L.get_windrun_bucket(33.75), 2)    # NNE/NE edge -> NE
        self.assertEqual(L.get_windrun_bucket(326.25), 15)  # NW/NNW edge -> NNW

        # Wraparound: the top edge and everything up to 360 folds back to N(0).
        self.assertEqual(L.get_windrun_bucket(348.75), 0)
        self.assertEqual(L.get_windrun_bucket(355.0), 0)
        self.assertEqual(L.get_windrun_bucket(359.9), 0)
        self.assertEqual(L.get_windrun_bucket(360.0), 0)
        self.assertEqual(L.get_windrun_bucket(0.0), 0)

    def test_windrose_banding(self) -> None:
        # Spec: classify() maps (speed, dir) to (compass bin, speed band):
        # band i covers [edges[i], edges[i+1]), the last band is unbounded,
        # and calm -- speed below edges[0] OR no direction -- is (-1, -1).
        # distance() is calc_windrun parity: speed * seconds / divisor.
        WRB = user.loopdata.WindRoseBanding
        banding = WRB(unit_system=weewx.US, edges=[1.0, 5.0, 10.0],
                      seconds_per_distance=3600.0)

        self.assertEqual(banding.classify(0.5, 90.0), (-1, -1))   # below calm threshold
        self.assertEqual(banding.classify(12.0, None), (-1, -1))  # no direction
        self.assertEqual(banding.classify(1.0, 90.0), (4, 0))     # edge is inclusive
        self.assertEqual(banding.classify(4.99, 90.0), (4, 0))
        self.assertEqual(banding.classify(5.0, 0.0), (0, 1))
        self.assertEqual(banding.classify(30.0, 355.0), (0, 2))   # top band unbounded; N wrap

        # 10 mph for 360 seconds = 1 mile.
        self.assertAlmostEqual(banding.distance(10.0, 360.0), 1.0)
        # METRICWX divisor: 5 m/s for 200 seconds = 1000 m = 1 km.
        banding_mwx = WRB(unit_system=weewx.METRICWX, edges=[0.5],
                          seconds_per_distance=1000.0)
        self.assertAlmostEqual(banding_mwx.distance(5.0, 200.0), 1.0)

    def test_parse_windrose_bands(self) -> None:
        # Spec: [LoopData] windrose_bands is a list of ascending, non-negative
        # edges in the target report's windSpeed unit; anything else falls
        # back to the default -- the WRPLOT classic bands (0.5, 2.1, 3.6, 5.7,
        # 8.8, 11.1 m/s) converted to the report unit, rounded to 1 decimal.
        # Expected defaults computed by hand: m/s * 2.236936 (mph),
        # m/s * 3.6 (km/h).
        L = user.loopdata.LoopData
        us_converter = ProcessPacketTests._get_config(
            'us', 10800, 1, 6, []).legacy.converter
        metric_converter = ProcessPacketTests._get_config(
            'metric', 10800, 1, 6, []).legacy.converter

        self.assertEqual(L.parse_windrose_bands(None, us_converter),
                         [1.1, 4.7, 8.1, 12.8, 19.7, 24.8])
        self.assertEqual(L.parse_windrose_bands(None, metric_converter),
                         [1.8, 7.6, 13.0, 20.5, 31.7, 40.0])

        # Explicit edges pass through verbatim (already in report units);
        # ConfigObj yields a plain string for a single edge.
        self.assertEqual(L.parse_windrose_bands(['1', '4', '8.5'], us_converter),
                         [1.0, 4.0, 8.5])
        self.assertEqual(L.parse_windrose_bands('5', us_converter), [5.0])
        # A zero calm threshold is allowed (nothing is calm but null windDir).
        self.assertEqual(L.parse_windrose_bands(['0', '5'], us_converter),
                         [0.0, 5.0])

        # Invalid: not ascending, negative, non-numeric, empty -> default.
        default = [1.1, 4.7, 8.1, 12.8, 19.7, 24.8]
        self.assertEqual(L.parse_windrose_bands(['5', '3'], us_converter), default)
        self.assertEqual(L.parse_windrose_bands(['-1', '3'], us_converter), default)
        self.assertEqual(L.parse_windrose_bands(['abc'], us_converter), default)
        self.assertEqual(L.parse_windrose_bands([], us_converter), default)

    def test_get_windrose_periods(self) -> None:
        # windrose fields split into span periods (own accumulators, SQL
        # seeded) and continuous periods (rolling window); the unit.label
        # form names no period and lands in neither.
        fields = ['day.windrose.banded', 'month.windrose.sum', 'day.windrose.calm',
                  '30m.windrose.time', '2h.windrose.sum', 'unit.label.windrose',
                  'day.outTemp.max']
        (fields_to_include, _) = user.loopdata.LoopData.get_fields_to_include(fields)
        span, continuous = user.loopdata.LoopData.get_windrose_periods(fields_to_include)
        self.assertEqual(span, {'day', 'month'})
        self.assertEqual(continuous, {'30m', '2h'})

    def test_windrose_span_accum(self) -> None:
        # Spec: cells accumulate seconds and distance per (bin, band); calm
        # takes seconds only; a packet outside the span resets to the packet's
        # span; alltime (span_fn None) never resets.
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        banding = user.loopdata.WindRoseBanding(
            unit_system=weewx.US, edges=[1.0, 5.0, 10.0], seconds_per_distance=3600.0)
        noon = 1593630000  # 2020-07-01 12:00 PDT
        accum = user.loopdata.WindRoseSpanAccum(
            banding, weeutil.weeutil.archiveDaySpan, noon)

        accum.add(noon, 7.2, 90.0, 500.0)        # bin 4 (E), band 1
        accum.add(noon + 10, 0.5, 90.0, 300.0)   # calm: below threshold
        accum.add(noon + 20, 12.0, None, 100.0)  # calm: no direction
        self.assertAlmostEqual(accum.time_bins[4][1], 500.0)
        self.assertAlmostEqual(accum.dist_bins[4][1], 1.0)  # 7.2 mph * 500s / 3600
        self.assertAlmostEqual(accum.calm_seconds, 400.0)
        self.assertAlmostEqual(accum.bin_times()[4], 500.0)
        self.assertAlmostEqual(accum.bin_distances()[4], 1.0)

        # Next local day: self-reset, then the new sample is the only content.
        accum.add(noon + 86400, 3.0, 180.0, 200.0)  # bin 8 (S), band 0
        self.assertAlmostEqual(accum.calm_seconds, 0.0)
        self.assertAlmostEqual(accum.time_bins[4][1], 0.0)
        self.assertAlmostEqual(accum.time_bins[8][0], 200.0)
        self.assertTrue(accum.timespan.includesArchiveTime(noon + 86400))

        # alltime: no span function, never resets.
        alltime = user.loopdata.WindRoseSpanAccum(banding, None, noon)
        alltime.add(noon, 7.2, 90.0, 500.0)
        alltime.add(noon + 86400 * 400, 3.0, 180.0, 200.0)
        self.assertAlmostEqual(alltime.time_bins[4][1], 500.0)
        self.assertAlmostEqual(alltime.time_bins[8][0], 200.0)

    def test_windrose_continuous_accum(self) -> None:
        # Spec: a rolling window; every credit expires timelength seconds
        # after its timestamp (expiration <= now trims, the
        # ContinuousScalarStats convention), including calm credits.
        banding = user.loopdata.WindRoseBanding(
            unit_system=weewx.US, edges=[1.0, 5.0, 10.0], seconds_per_distance=3600.0)
        accum = user.loopdata.WindRoseContinuousAccum(banding, 600)

        accum.add(1000, 7.2, 90.0, 500.0)   # bin 4, band 1; expires at 1600
        accum.add(1300, 0.5, 90.0, 300.0)   # calm; expires at 1900
        accum.add(1599, 3.0, 90.0, 100.0)   # bin 4, band 0; expires at 2199
        self.assertAlmostEqual(accum.time_bins[4][1], 500.0)
        self.assertAlmostEqual(accum.dist_bins[4][1], 1.0)
        self.assertAlmostEqual(accum.time_bins[4][0], 100.0)
        self.assertAlmostEqual(accum.calm_seconds, 300.0)
        self.assertEqual(len(accum.future_debits), 3)

        # At 1600 the first credit ages out; the others survive.
        accum.add(1600, 20.0, 355.0, 100.0)  # bin 0, band 2
        self.assertAlmostEqual(accum.time_bins[4][1], 0.0)
        self.assertAlmostEqual(accum.dist_bins[4][1], 0.0)
        self.assertAlmostEqual(accum.calm_seconds, 300.0)
        self.assertAlmostEqual(accum.time_bins[0][2], 100.0)

        # At 2000 the calm credit has aged out too.
        accum.trimExpiredEntries(2000)
        self.assertAlmostEqual(accum.calm_seconds, 0.0)
        self.assertAlmostEqual(accum.time_bins[4][0], 100.0)  # expires at 2199

    def test_massage_near_zero(self) -> None:
        # Values within +/-1e-10 of zero are clamped to exactly 0.0; everything
        # else passes through unchanged.  Guards against -0.0-ish float dust in
        # the vector sums producing tiny non-zero artifacts.
        L = user.loopdata.LoopData
        self.assertEqual(L.massage_near_zero(0.0), 0.0)
        self.assertEqual(L.massage_near_zero(1e-11), 0.0)
        self.assertEqual(L.massage_near_zero(-1e-11), 0.0)
        # Just outside the window: unchanged.
        self.assertEqual(L.massage_near_zero(1e-9), 1e-9)
        self.assertEqual(L.massage_near_zero(-1e-9), -1e-9)
        self.assertEqual(L.massage_near_zero(5.0), 5.0)
        self.assertEqual(L.massage_near_zero(-273.15), -273.15)
        # Exact boundary: the window is STRICT (val > -1e-10 AND val < 1e-10),
        # so exactly +/-1e-10 is OUTSIDE and passes through unchanged.  This
        # distinguishes '<' from a mutated '<=' (and '>' from '>=').
        self.assertEqual(L.massage_near_zero(1e-10), 1e-10)
        self.assertEqual(L.massage_near_zero(-1e-10), -1e-10)
        # Just inside the strict window -> clamped.
        self.assertEqual(L.massage_near_zero(9.99e-11), 0.0)
        self.assertEqual(L.massage_near_zero(-9.99e-11), 0.0)

    def test_construct_baro_trend_descs(self) -> None:
        # Builds a BarometerTrend -> description map from the TARGET report's
        # [Texts]: each English description is a gettext-style key (6.4
        # replaced the old [LoopData] [[BarometerTrendDescriptions]] section
        # with this); missing keys fall back to the English one at a time.
        L = user.loopdata.LoopData
        BT = user.loopdata.BarometerTrend

        # The default table covers all nine trends, one distinct English
        # description each.
        defaults = user.loopdata.BARO_TREND_DESCS
        self.assertEqual(set(defaults), set(BT))
        self.assertEqual(len(set(defaults.values())), 9)

        # Empty [Texts] -> the English defaults for all nine trends.
        descs = L.construct_baro_trend_descs({})
        self.assertEqual(len(descs), 9)
        # Assert ALL nine mappings (asserting only a few lets mutations to
        # the others survive).
        self.assertEqual(descs[BT.RISING_VERY_RAPIDLY], 'Rising Very Rapidly')
        self.assertEqual(descs[BT.RISING_QUICKLY], 'Rising Quickly')
        self.assertEqual(descs[BT.RISING], 'Rising')
        self.assertEqual(descs[BT.RISING_SLOWLY], 'Rising Slowly')
        self.assertEqual(descs[BT.STEADY], 'Steady')
        self.assertEqual(descs[BT.FALLING_SLOWLY], 'Falling Slowly')
        self.assertEqual(descs[BT.FALLING], 'Falling')
        self.assertEqual(descs[BT.FALLING_QUICKLY], 'Falling Quickly')
        self.assertEqual(descs[BT.FALLING_VERY_RAPIDLY], 'Falling Very Rapidly')

        # Partial [Texts]: supplied keys win, the rest keep English --
        # exactly the per-string fallback of every other translated string.
        descs = L.construct_baro_trend_descs({
            'Steady': 'gleichbleibend',
            'Rising': 'steigend',
            'unrelated page string': 'x'})
        self.assertEqual(descs[BT.STEADY], 'gleichbleibend')
        self.assertEqual(descs[BT.RISING], 'steigend')
        self.assertEqual(descs[BT.FALLING], 'Falling')  # untouched English

        # To kill mutations of the lookup KEYS, supply a [Texts] containing
        # EVERY English description with a distinct sentinel value.  A
        # corrupted key would miss the dict and fall back to English,
        # producing a different string -- each mapping independently pinned.
        full = {english: 'X_' + english for english in defaults.values()}
        d2 = L.construct_baro_trend_descs(full)
        for trend, english in defaults.items():
            self.assertEqual(d2[trend], 'X_' + english)

        # The shipped lang files carry exactly the nine keys, translated.
        for name in ('en.conf', 'de.conf', 'fr.conf', 'nl.conf', 'es.conf',
                     'da.conf'):
            conf = self.i18n_lang_conf(
                os.path.join(self.I18N_SKIN_DIR, 'lang'), name)
            d3 = L.construct_baro_trend_descs(dict(conf['Texts']))
            self.assertEqual(len(d3), 9, name)
            for trend, english in defaults.items():
                self.assertEqual(d3[trend], conf['Texts'][english], name)
        # ...and each translation moves every one of them away from English.
        for name in ('de.conf', 'fr.conf', 'nl.conf', 'es.conf', 'da.conf'):
            conf = self.i18n_lang_conf(os.path.join(self.I18N_SKIN_DIR, 'lang'),
                                       name)
            d4 = L.construct_baro_trend_descs(dict(conf['Texts']))
            for trend, english in defaults.items():
                self.assertNotEqual(d4[trend], english, (name, english))

    def test_compute_period_obstypes(self) -> None:
        # For a given period, collect the obstypes of fields in that period and
        # auto-add the dependency obstypes for composite types (wind, appTemp,
        # windrun_*, beaufort).  Fields in other periods are ignored.
        L = user.loopdata.LoopData

        def cn(field):
            c = L.parse_cname(field)
            self.assertIsNotNone(c, msg='parse_cname failed for %s' % field)
            return c

        fields = {
            cn('day.outTemp.avg'),         # plain, no expansion
            cn('day.wind.vecavg'),         # wind -> +windSpeed/windDir/windGust/windGustDir
            cn('day.appTemp.avg'),         # appTemp -> +outTemp/outHumidity/windSpeed
            cn('day.windrun_N.sum'),       # windrun* -> +windSpeed/windDir
            cn('day.beaufort.max'),        # beaufort -> +windSpeed
            cn('2m.outTemp.avg')}          # different period: must be excluded

        result = L.compute_period_obstypes(fields, 'day')

        # Base obstypes for the 'day' fields.
        self.assertIn('outTemp', result)
        self.assertIn('wind', result)
        self.assertIn('appTemp', result)
        self.assertIn('windrun_N', result)
        self.assertIn('beaufort', result)
        # Auto-added dependencies.
        self.assertIn('windSpeed', result)
        self.assertIn('windDir', result)
        self.assertIn('windGust', result)
        self.assertIn('windGustDir', result)
        self.assertIn('outHumidity', result)
        # The 2m field's obstype must NOT leak into the 'day' result set
        # (outTemp is already present from day.outTemp, so assert the period
        # filter via a period that has only the excluded field).
        result_2m = L.compute_period_obstypes(fields, '2m')
        self.assertEqual(result_2m, {'outTemp'})

    def test_compute_period_obstypes_isolated_composites(self) -> None:
        # The shared test asserts presence, but several composites add the SAME
        # dependency (e.g. both 'wind' and 'windrun' add windDir), so removing
        # one composite's contribution is masked.  Here each composite is tested
        # ALONE with exact set equality, so dropping any single .add() is caught.
        L = user.loopdata.LoopData

        def cn(field):
            c = L.parse_cname(field)
            self.assertIsNotNone(c, msg='parse_cname failed for %s' % field)
            return c

        # wind -> itself + windSpeed, windDir, windGust, windGustDir
        self.assertEqual(
            L.compute_period_obstypes({cn('day.wind.vecavg')}, 'day'),
            {'wind', 'windSpeed', 'windDir', 'windGust', 'windGustDir'})
        # appTemp -> itself + outTemp, outHumidity, windSpeed
        self.assertEqual(
            L.compute_period_obstypes({cn('day.appTemp.avg')}, 'day'),
            {'appTemp', 'outTemp', 'outHumidity', 'windSpeed'})
        # windrun_* -> itself + windSpeed, windDir
        self.assertEqual(
            L.compute_period_obstypes({cn('day.windrun_N.sum')}, 'day'),
            {'windrun_N', 'windSpeed', 'windDir'})
        # beaufort -> itself + windSpeed
        self.assertEqual(
            L.compute_period_obstypes({cn('day.beaufort.max')}, 'day'),
            {'beaufort', 'windSpeed'})
        # plain obstype -> itself only (no expansion)
        self.assertEqual(
            L.compute_period_obstypes({cn('day.outTemp.avg')}, 'day'),
            {'outTemp'})

    def test_get_fields_to_include(self) -> None:

        specified_fields: Set[str] = {'current.dateTime.raw', 'current.outTemp', 'trend.outTemp', 'trend.barometer.code',
            'trend.barometer.desc', '2m.wind.max', '2m.wind.gustdir', '10m.wind.max', '10m.wind.gustdir',
            '10m.windSpeed.max', '10m.windDir.max', '24h.rain.sum', 'hour.inTemp.min', 'hour.inTemp.mintime',
            'day.barometer.min', 'day.barometer.max', 'day.wind.max', 'day.wind.gustdir', 'day.wind.maxtime'}

        (fields_to_include, obstypes) = user.loopdata.LoopData.get_fields_to_include(specified_fields)

        self.assertEqual(len(fields_to_include), 19)
        # Positional CheetahName args: field, prefix, prefix2, period, obstype,
        # agg_type, unit, format_spec (unit -- the override -- sits between
        # agg_type and format_spec; None here since none of these override).
        self.assertTrue(user.loopdata.CheetahName(
            'current.dateTime.raw', None, None, 'current', 'dateTime', None, None, 'raw') in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            'current.outTemp', None, None, 'current', 'outTemp', None, None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            'trend.outTemp', None, None, 'trend', 'outTemp', None, None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            'trend.barometer.code', None, None, 'trend', 'barometer', None, None, 'code') in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            'trend.barometer.desc', None, None, 'trend', 'barometer', None, None, 'desc') in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            '2m.wind.max', None, None, '2m', 'wind', 'max', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            '2m.wind.gustdir', None, None, '2m', 'wind', 'gustdir', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            '10m.wind.max', None, None, '10m', 'wind', 'max', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            '10m.wind.gustdir', None, None, '10m', 'wind', 'gustdir', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            '10m.windSpeed.max', None, None, '10m', 'windSpeed', 'max', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            '10m.windDir.max', None, None, '10m', 'windDir', 'max', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            '24h.rain.sum', None, None, '24h', 'rain', 'sum', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            'hour.inTemp.min', None, None, 'hour', 'inTemp', 'min', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            'hour.inTemp.mintime', None, None, 'hour', 'inTemp', 'mintime', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            'day.barometer.min', None, None, 'day', 'barometer', 'min', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            'day.barometer.max', None, None, 'day', 'barometer', 'max', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            'day.wind.max', None, None, 'day', 'wind', 'max', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            'day.wind.gustdir', None, None, 'day', 'wind', 'gustdir', None, None) in fields_to_include)
        self.assertTrue(user.loopdata.CheetahName(
            'day.wind.maxtime', None, None, 'day', 'wind', 'maxtime', None, None) in fields_to_include)

        self.assertEqual(len(obstypes.current), 10)
        self.assertTrue('inTemp' in obstypes.current)
        self.assertTrue('outTemp' in obstypes.current)
        self.assertTrue('barometer' in obstypes.current)
        self.assertTrue('wind' in obstypes.current)
        self.assertTrue('windDir' in obstypes.current)
        self.assertTrue('windGust' in obstypes.current)
        self.assertTrue('windGustDir' in obstypes.current)
        self.assertTrue('windSpeed' in obstypes.current)

        self.assertEqual(len(obstypes.continuous['trend']), 2)
        self.assertTrue('barometer' in obstypes.continuous['trend'])
        self.assertTrue('outTemp' in obstypes.continuous['trend'])

        self.assertEqual(len(obstypes.continuous['10m']), 5)
        self.assertTrue('wind' in obstypes.continuous['10m'])
        self.assertTrue('windDir' in obstypes.continuous['10m'])
        self.assertTrue('windGust' in obstypes.continuous['10m'])
        self.assertTrue('windGustDir' in obstypes.continuous['10m'])
        self.assertTrue('windSpeed' in obstypes.continuous['10m'])

        self.assertEqual(len(obstypes.continuous['24h']), 1)
        self.assertTrue('rain' in obstypes.continuous['24h'])

        self.assertEqual(len(obstypes.hour), 1)
        self.assertTrue('inTemp' in obstypes.hour)

        self.assertEqual(len(obstypes.day), 6)
        self.assertTrue('barometer' in obstypes.day)
        self.assertTrue('wind' in obstypes.day)
        self.assertTrue('windDir' in obstypes.day)
        self.assertTrue('windGust' in obstypes.day)
        self.assertTrue('windGustDir' in obstypes.day)
        self.assertTrue('windSpeed' in obstypes.day)

    def test_parse_almanac_field(self) -> None:
        parse = user.loopdata.LoopData.parse_almanac_field

        af = parse('almanac.sunrise')
        assert af is not None
        self.assertEqual(af.field, 'almanac.sunrise')
        self.assertEqual(af.almanac_kwargs, {})
        self.assertEqual(af.days, 0)
        self.assertEqual(af.chain, [user.loopdata.AlmanacSegment('sunrise', None)])
        self.assertEqual(af.format_spec, None)
        self.assertEqual(af.tier, 'day')

        af = parse('almanac.sunrise.raw')
        assert af is not None
        self.assertEqual(af.chain, [user.loopdata.AlmanacSegment('sunrise', None)])
        self.assertEqual(af.format_spec, 'raw')
        self.assertEqual(af.tier, 'day')

        af = parse('almanac.moon_index')
        assert af is not None
        self.assertEqual(af.tier, 'continuous')

        af = parse('almanac.sun.az')
        assert af is not None
        self.assertEqual(af.chain, [user.loopdata.AlmanacSegment('sun', None),
                                    user.loopdata.AlmanacSegment('az', None)])
        self.assertEqual(af.tier, 'continuous')

        af = parse('almanac(horizon=-6).sun(use_center=1).rise.raw')
        assert af is not None
        self.assertEqual(af.almanac_kwargs, {'horizon': -6})
        self.assertEqual(af.days, 0)
        self.assertEqual(af.chain, [user.loopdata.AlmanacSegment('sun', {'use_center': 1}),
                                    user.loopdata.AlmanacSegment('rise', None)])
        self.assertEqual(af.format_spec, 'raw')
        self.assertEqual(af.tier, 'day')

        af = parse('almanac(days=+1).sunset.raw')
        assert af is not None
        self.assertEqual(af.almanac_kwargs, {})
        self.assertEqual(af.days, 1)
        self.assertEqual(af.tier, 'day')

        af = parse('almanac(days=-1).sun.visible.raw')
        assert af is not None
        self.assertEqual(af.days, -1)
        self.assertEqual(af.tier, 'day')

        af = parse('almanac.next_solstice.raw')
        assert af is not None
        self.assertEqual(af.tier, 'event')

        af = parse('almanac.previous_equinox')
        assert af is not None
        self.assertEqual(af.tier, 'event')

        af = parse('almanac.mars.earth_distance')
        assert af is not None
        self.assertEqual(af.tier, 'continuous')

        af = parse('almanac(pressure=0, horizon=-8.5).sun.rise')
        assert af is not None
        self.assertEqual(af.almanac_kwargs, {'pressure': 0, 'horizon': -8.5})
        self.assertEqual(af.tier, 'day')

        af = parse('almanac.moon.phase.formatted')
        assert af is not None
        self.assertEqual(af.chain, [user.loopdata.AlmanacSegment('moon', None),
                                    user.loopdata.AlmanacSegment('phase', None)])
        self.assertEqual(af.format_spec, 'formatted')

        # A unit segment is an ordinary chain segment (report-tag parity:
        # ValueHelper attribute access converts), sitting before round(n)
        # and the format spec; the tier still comes from the almanac
        # attribute it follows.
        af = parse('almanac.sunrise.unix_epoch.raw')
        assert af is not None
        self.assertEqual(af.chain, [user.loopdata.AlmanacSegment('sunrise', None),
                                    user.loopdata.AlmanacSegment('unix_epoch', None)])
        self.assertEqual(af.format_spec, 'raw')
        self.assertEqual(af.tier, 'day')

        af = parse('almanac.sun.visible.hour.round(2).raw')
        assert af is not None
        self.assertEqual(af.chain, [user.loopdata.AlmanacSegment('sun', None),
                                    user.loopdata.AlmanacSegment('visible', None),
                                    user.loopdata.AlmanacSegment('hour', None)])
        self.assertEqual(af.round_ndigits, 2)
        self.assertEqual(af.format_spec, 'raw')
        self.assertEqual(af.tier, 'day')

        # Malformed entries.
        self.assertIsNone(parse('almanac'))
        self.assertIsNone(parse('almanac.'))
        self.assertIsNone(parse('almanac..sunrise'))
        self.assertIsNone(parse('almanac(days=1.5).sunrise'))
        self.assertIsNone(parse('almanac(horizon=abc).sun.rise'))
        self.assertIsNone(parse('almanac(horizon-6).sun.rise'))
        self.assertIsNone(parse('almanac(horizon=-6.sun.rise'))
        self.assertIsNone(parse('almanac.sun(rise'))
        self.assertIsNone(parse('almanac.9sun.rise'))
        self.assertIsNone(parse('almanac(horizon=-6)(use_center=1).sun.rise'))

    def test_get_almanac_fields(self) -> None:
        specified_fields = [
            'current.outTemp',
            'almanac.sunrise.raw',
            'day.outTemp.max',
            'almanac(horizon=-6).sun(use_center=1).rise.raw',
            'almanac.sunrise.raw',            # duplicate: dropped
            'almanac(horizon=abc).sun.rise',  # malformed: dropped
            'trend.barometer.desc',
        ]
        almanac_fields = user.loopdata.LoopData.get_almanac_fields(specified_fields)
        self.assertEqual([ f.field for f in almanac_fields ],
            ['almanac.sunrise.raw', 'almanac(horizon=-6).sun(use_center=1).rise.raw'])

        # Almanac entries must not leak into the observation-field parse.
        (fields_to_include, _) = user.loopdata.LoopData.get_fields_to_include(set(specified_fields))
        self.assertEqual({ cname.field for cname in fields_to_include },
            {'current.outTemp', 'day.outTemp.max', 'trend.barometer.desc'})

    def test_almanac_field_evaluator(self) -> None:
        specified_fields = [
            'almanac.stub_time',                                # continuous, plain float
            'almanac(horizon=-6).stub_horizon',                 # continuous, almanac kwargs
            'almanac.sunrise.raw',                              # day tier
            'almanac.sunrise',                                  # formatted like the report tag
            'almanac(days=1).sunrise.raw',                      # local calendar-day shift
            'almanac(days=-1).sunrise.raw',
            'almanac(horizon=-6).sun(use_center=1).rise.raw',   # chain call kwargs
            'almanac.moon_index',                               # plain int
            'almanac.moon_index.raw',                           # .raw identity on plain value
            'almanac.moon_index.formatted',                     # invalid: skipped
            'almanac.next_full_moon.raw',                       # event tier
            'almanac.no_such_attr',                             # unknown: skipped
        ]
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ['current.outTemp'])
        cfg.legacy.almanac_fields = user.loopdata.LoopData.get_almanac_fields(specified_fields)
        self.assertEqual(len(cfg.legacy.almanac_fields), len(specified_fields))
        cfg.latitude, cfg.longitude, cfg.altitude_m = 37.4, -122.1, 20.0

        stub = StubAlmanacType()
        weewx.almanac.almanacs.insert(0, stub)
        try:
            evaluator = user.loopdata.AlmanacFieldEvaluator(cfg.legacy, cfg)

            # 2020-07-01 (PDT) noon; day boundaries computed the same way the stub does.
            day1_noon = 1593630000
            def six_am(day_offset: int) -> float:
                day = date.fromtimestamp(day1_noon + day_offset * 86400)
                return time.mktime(day.timetuple()) + 6 * 3600
            stub.next_full_moon_ts = six_am(2) + 12 * 3600   # day 3, 18:00

            pkt: Dict[str, Any] = {'dateTime': day1_noon, 'usUnits': 1}
            loopdata_pkt: Dict[str, Any] = {}
            evaluator.insert_fields(loopdata_pkt, pkt)

            self.assertEqual(loopdata_pkt['almanac.stub_time'], day1_noon)
            self.assertEqual(loopdata_pkt['almanac(horizon=-6).stub_horizon'], -6)
            self.assertEqual(loopdata_pkt['almanac.sunrise.raw'], six_am(0))
            expected_vh = weewx.units.ValueHelper(
                weewx.units.ValueTuple(six_am(0), 'unix_epoch', 'group_time'),
                context='ephem_day', formatter=cfg.legacy.formatter, converter=cfg.legacy.converter)
            self.assertEqual(loopdata_pkt['almanac.sunrise'], str(expected_vh))
            self.assertEqual(loopdata_pkt['almanac(days=1).sunrise.raw'], six_am(1))
            self.assertEqual(loopdata_pkt['almanac(days=-1).sunrise.raw'], six_am(-1))
            # 06:00 less 6 degrees of horizon (one minute per degree) less ten minutes for use_center.
            self.assertEqual(loopdata_pkt['almanac(horizon=-6).sun(use_center=1).rise.raw'],
                six_am(0) - 360 - 600)
            self.assertEqual(loopdata_pkt['almanac.moon_index'], 4)
            self.assertEqual(loopdata_pkt['almanac.moon_index.raw'], 4)
            self.assertNotIn('almanac.moon_index.formatted', loopdata_pkt)
            self.assertEqual(loopdata_pkt['almanac.next_full_moon.raw'], stub.next_full_moon_ts)
            if ProcessPacketTests.unknown_almanac_body_is_refused():
                self.assertNotIn('almanac.no_such_attr', loopdata_pkt)
            else:
                # WeeWX 4.6 through 5.2 hand back a binder for a body of
                # any name and render it as its own repr, so the field is
                # published rather than omitted.  Pinned as a difference,
                # not as desired behavior: it is WeeWX's, it reaches only a
                # declaration naming something no almanac knows, and
                # loopdata does not (yet) refuse the binder itself.
                self.assertIn('almanac.no_such_attr', loopdata_pkt)

            # Four fields walk the sunrise attribute; moon_index is walked
            # three times (the .formatted variant evaluates, then fails to format).
            self.assertEqual(stub.counts['sunrise'], 4)
            self.assertEqual(stub.counts['sun.rise'], 1)
            self.assertEqual(stub.counts['moon_index'], 3)
            self.assertEqual(stub.counts['next_full_moon'], 1)

            # Same day, an hour later: continuous fields recompute, day and
            # event fields are served from cache.
            pkt = {'dateTime': day1_noon + 3600, 'usUnits': 1}
            loopdata_pkt = {}
            evaluator.insert_fields(loopdata_pkt, pkt)
            self.assertEqual(loopdata_pkt['almanac.stub_time'], day1_noon + 3600)
            self.assertEqual(loopdata_pkt['almanac.sunrise.raw'], six_am(0))
            self.assertEqual(stub.counts['stub_time'], 2)
            self.assertEqual(stub.counts['sunrise'], 4)
            self.assertEqual(stub.counts['sun.rise'], 1)
            self.assertEqual(stub.counts['moon_index'], 6)
            self.assertEqual(stub.counts['next_full_moon'], 1)

            # Day 2: day-tier fields recompute; the cached full moon (day 3
            # evening) is still ahead, so the event field is kept.
            pkt = {'dateTime': day1_noon + 86400, 'usUnits': 1}
            loopdata_pkt = {}
            evaluator.insert_fields(loopdata_pkt, pkt)
            self.assertEqual(loopdata_pkt['almanac.sunrise.raw'], six_am(1))
            self.assertEqual(loopdata_pkt['almanac(days=1).sunrise.raw'], six_am(2))
            self.assertEqual(stub.counts['sunrise'], 8)
            self.assertEqual(stub.counts['next_full_moon'], 1)

            # Day 3, noon of the full moon's day: the event (18:00) is still
            # ahead, so the group is still armed.
            pkt = {'dateTime': day1_noon + 2 * 86400, 'usUnits': 1}
            evaluator.insert_fields({}, pkt)
            self.assertEqual(stub.counts['next_full_moon'], 1)

            # Day 4: the cached event's instant has passed; the group
            # expires and the recompute yields the following full moon.
            stub.next_full_moon_ts = six_am(31)
            pkt = {'dateTime': day1_noon + 3 * 86400, 'usUnits': 1}
            loopdata_pkt = {}
            evaluator.insert_fields(loopdata_pkt, pkt)
            self.assertEqual(stub.counts['next_full_moon'], 2)
            self.assertEqual(loopdata_pkt['almanac.next_full_moon.raw'], six_am(31))

            # Backfilled packet from day 1: equality compare, so the old day
            # gets its own values, never a newer cache.
            pkt = {'dateTime': day1_noon, 'usUnits': 1}
            loopdata_pkt = {}
            evaluator.insert_fields(loopdata_pkt, pkt)
            self.assertEqual(loopdata_pkt['almanac.sunrise.raw'], six_am(0))
            # Four sunrise fields recomputed on each of the five day changes.
            self.assertEqual(stub.counts['sunrise'], 20)
            self.assertEqual(stub.counts['next_full_moon'], 3)
        finally:
            weewx.almanac.almanacs.remove(stub)

    def test_almanac_no_data_not_cached(self) -> None:
        """A day/event-tier evaluation that yields no data (an empty
        ValueHelper or plain None -- e.g. a satellite whose elements have
        not been fetched yet) must not be cached for the day: every packet
        retries, so the field picks up the real value the moment the
        almanac has data, just as report tags do on the next report cycle.
        A real value still caches for the day; the exception path still
        caches SKIP so a broken field is not walked (and logged) every
        packet."""
        specified_fields = [
            'almanac.sunrise.raw',              # day tier, raw: absent while no data
            'almanac.sunrise',                  # day tier, formatted: renders like the report tag
            'almanac.next_full_moon.raw',       # event tier
            'almanac.sunrise.no_such_unit.raw', # day tier, raises: SKIP still caches
        ]
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ['current.outTemp'])
        cfg.legacy.almanac_fields = user.loopdata.LoopData.get_almanac_fields(specified_fields)
        self.assertEqual(len(cfg.legacy.almanac_fields), len(specified_fields))
        cfg.latitude, cfg.longitude, cfg.altitude_m = 37.4, -122.1, 20.0

        stub = StubAlmanacType()
        weewx.almanac.almanacs.insert(0, stub)
        try:
            evaluator = user.loopdata.AlmanacFieldEvaluator(cfg.legacy, cfg)

            # 2020-07-01 (PDT) noon, as in test_almanac_field_evaluator.
            day1_noon = 1593630000
            def six_am(day_offset: int) -> float:
                day = date.fromtimestamp(day1_noon + day_offset * 86400)
                return time.mktime(day.timetuple()) + 6 * 3600

            stub.no_data = {'sunrise', 'next_full_moon'}
            pkt: Dict[str, Any] = {'dateTime': day1_noon, 'usUnits': 1}
            loopdata_pkt: Dict[str, Any] = {}
            evaluator.insert_fields(loopdata_pkt, pkt)

            # The no-data packet itself serves what the report tag would: the
            # raw field is absent, the formatted field renders the empty
            # ValueHelper (the formatter's no-data label).
            self.assertNotIn('almanac.sunrise.raw', loopdata_pkt)
            empty_vh = weewx.units.ValueHelper(
                weewx.units.ValueTuple(None, 'unix_epoch', 'group_time'),
                context='ephem_day', formatter=cfg.legacy.formatter, converter=cfg.legacy.converter)
            self.assertEqual(loopdata_pkt['almanac.sunrise'], str(empty_vh))
            self.assertNotIn('almanac.next_full_moon.raw', loopdata_pkt)
            self.assertNotIn('almanac.sunrise.no_such_unit.raw', loopdata_pkt)
            # Three fields walk sunrise: raw, formatted, and the failing
            # unit chain (which walks sunrise before the conversion raises).
            self.assertEqual(stub.counts['sunrise'], 3)
            self.assertEqual(stub.counts['next_full_moon'], 1)
            self.assertIs(evaluator.values['almanac.sunrise.no_such_unit.raw'],
                user.loopdata.AlmanacFieldEvaluator.SKIP)

            # Same day, next packet: the no-data fields are walked again, not
            # served from cache -- but the FAILED field stays cached as SKIP
            # (only two sunrise walks, not three), so a broken field is not
            # walked and logged every packet.
            evaluator.insert_fields({}, {'dateTime': day1_noon + 2, 'usUnits': 1})
            self.assertEqual(stub.counts['sunrise'], 5)
            self.assertEqual(stub.counts['next_full_moon'], 2)

            # The elements arrive: the very next packet has the real values.
            stub.no_data = set()
            stub.next_full_moon_ts = six_am(2)
            loopdata_pkt = {}
            evaluator.insert_fields(loopdata_pkt, {'dateTime': day1_noon + 4, 'usUnits': 1})
            self.assertEqual(loopdata_pkt['almanac.sunrise.raw'], six_am(0))
            self.assertEqual(loopdata_pkt['almanac.next_full_moon.raw'], six_am(2))
            self.assertEqual(stub.counts['sunrise'], 7)
            self.assertEqual(stub.counts['next_full_moon'], 3)

            # And real values cache at the normal cadence: nothing is walked
            # on the next packet.
            loopdata_pkt = {}
            evaluator.insert_fields(loopdata_pkt, {'dateTime': day1_noon + 6, 'usUnits': 1})
            self.assertEqual(loopdata_pkt['almanac.sunrise.raw'], six_am(0))
            self.assertEqual(loopdata_pkt['almanac.next_full_moon.raw'], six_am(2))
            self.assertEqual(stub.counts['sunrise'], 7)
            self.assertEqual(stub.counts['next_full_moon'], 3)
        finally:
            weewx.almanac.almanacs.remove(stub)

    def test_almanac_next_group_expires_at_event(self) -> None:
        """next_* fields naming one event -- here a satellite pass -- form a
        group that is computed as a unit and expires at the event's own
        instant, the latest time-typed leaf (for a pass, set): mid-pass
        packets serve the cached in-progress pass, the first packet at or
        after set recomputes, and the recompute yields the FOLLOWING pass
        with every leaf switching on the same packet.  An independent next_*
        group (the full moon) keeps its own expiry."""
        specified_fields = [
            'almanac.next_pass.rise.raw',
            'almanac.next_pass.set.raw',
            'almanac.next_pass.max_altitude',
            'almanac.next_full_moon.raw',
        ]
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ['current.outTemp'])
        cfg.legacy.almanac_fields = user.loopdata.LoopData.get_almanac_fields(specified_fields)
        self.assertEqual(len(cfg.legacy.almanac_fields), len(specified_fields))
        cfg.latitude, cfg.longitude, cfg.altitude_m = 37.4, -122.1, 20.0

        stub = StubAlmanacType()
        weewx.almanac.almanacs.insert(0, stub)
        try:
            evaluator = user.loopdata.AlmanacFieldEvaluator(cfg.legacy, cfg)
            # The three pass fields share one group; the full moon is its own.
            self.assertEqual(len(evaluator.groups), 2)

            day1_noon = 1593630000    # 2020-07-01 noon PDT
            # Pass A 13:00-13:10 at 45 degrees, pass B 16:00-16:08 at 62.
            pass_a = (day1_noon + 3600, day1_noon + 3600 + 600, 45.0)
            pass_b = (day1_noon + 4 * 3600, day1_noon + 4 * 3600 + 480, 62.0)
            stub.passes = [pass_a, pass_b]
            stub.next_full_moon_ts = day1_noon + 40 * 86400

            def insert(pkt_time: float) -> Dict[str, Any]:
                loopdata_pkt: Dict[str, Any] = {}
                evaluator.insert_fields(loopdata_pkt, {'dateTime': pkt_time, 'usUnits': 1})
                return loopdata_pkt

            # Noon: pass A is ahead; one computation walks all three leaves.
            pkt = insert(day1_noon)
            self.assertEqual(pkt['almanac.next_pass.rise.raw'], pass_a[0])
            self.assertEqual(pkt['almanac.next_pass.set.raw'], pass_a[1])
            self.assertEqual(pkt['almanac.next_pass.max_altitude'], 45.0)
            self.assertEqual(stub.counts['next_pass'], 3)
            self.assertEqual(stub.counts['next_full_moon'], 1)

            # Mid-pass (rise < now < set): the cached in-progress pass is
            # served -- the group's expiry is set, not rise.
            pkt = insert(pass_a[0] + 300)
            self.assertEqual(pkt['almanac.next_pass.rise.raw'], pass_a[0])
            self.assertEqual(pkt['almanac.next_pass.max_altitude'], 45.0)
            self.assertEqual(stub.counts['next_pass'], 3)

            # The packet at set: the pass has ended (the engines' own rule is
            # set strictly after now), so the group expires and the recompute
            # yields pass B -- rise, set and altitude switch together.
            pkt = insert(pass_a[1])
            self.assertEqual(pkt['almanac.next_pass.rise.raw'], pass_b[0])
            self.assertEqual(pkt['almanac.next_pass.set.raw'], pass_b[1])
            self.assertEqual(pkt['almanac.next_pass.max_altitude'], 62.0)
            self.assertEqual(stub.counts['next_pass'], 6)
            # The full moon group did not expire with it.
            self.assertEqual(stub.counts['next_full_moon'], 1)
            self.assertEqual(pkt['almanac.next_full_moon.raw'], stub.next_full_moon_ts)

            # Re-armed: the next packet serves pass B from cache.
            pkt = insert(pass_a[1] + 2)
            self.assertEqual(pkt['almanac.next_pass.set.raw'], pass_b[1])
            self.assertEqual(stub.counts['next_pass'], 6)
        finally:
            weewx.almanac.almanacs.remove(stub)

    def test_almanac_next_group_no_data_retries(self) -> None:
        """A next_* group whose evaluation yields no data (a satellite
        awaiting its orbital elements) is not cached AT ALL: every packet
        retries the whole group as a unit, so when the elements arrive every
        leaf heals on the same packet -- never a fresh leaf beside a stale
        one."""
        specified_fields = [
            'almanac.next_pass.rise.raw',
            'almanac.next_pass.set.raw',
            'almanac.next_pass.max_altitude',
        ]
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ['current.outTemp'])
        cfg.legacy.almanac_fields = user.loopdata.LoopData.get_almanac_fields(specified_fields)
        self.assertEqual(len(cfg.legacy.almanac_fields), len(specified_fields))
        cfg.latitude, cfg.longitude, cfg.altitude_m = 37.4, -122.1, 20.0

        stub = StubAlmanacType()
        weewx.almanac.almanacs.insert(0, stub)
        try:
            evaluator = user.loopdata.AlmanacFieldEvaluator(cfg.legacy, cfg)
            day1_noon = 1593630000    # 2020-07-01 noon PDT
            pass_a = (day1_noon + 3600, day1_noon + 3600 + 600, 45.0)

            def insert(pkt_time: float) -> Dict[str, Any]:
                loopdata_pkt: Dict[str, Any] = {}
                evaluator.insert_fields(loopdata_pkt, {'dateTime': pkt_time, 'usUnits': 1})
                return loopdata_pkt

            stub.no_data = {'next_pass'}
            pkt = insert(day1_noon)
            self.assertNotIn('almanac.next_pass.rise.raw', pkt)
            self.assertNotIn('almanac.next_pass.set.raw', pkt)
            self.assertNotIn('almanac.next_pass.max_altitude', pkt)
            self.assertEqual(stub.counts['next_pass'], 3)

            # Next packet: the whole group is walked again, not served from
            # cache.
            insert(day1_noon + 2)
            self.assertEqual(stub.counts['next_pass'], 6)

            # The elements arrive: the very next packet has every leaf.
            stub.no_data = set()
            stub.passes = [pass_a]
            pkt = insert(day1_noon + 4)
            self.assertEqual(pkt['almanac.next_pass.rise.raw'], pass_a[0])
            self.assertEqual(pkt['almanac.next_pass.set.raw'], pass_a[1])
            self.assertEqual(pkt['almanac.next_pass.max_altitude'], 45.0)
            self.assertEqual(stub.counts['next_pass'], 9)

            # And the healed group caches at the normal cadence.
            insert(day1_noon + 6)
            self.assertEqual(stub.counts['next_pass'], 9)
        finally:
            weewx.almanac.almanacs.remove(stub)

    def test_almanac_next_group_timeless_day_roll(self) -> None:
        """A next_* group with no time-typed leaf has no expiry signal --
        duration never qualifies (group_deltatime, a span not an instant) --
        so it falls back to the day roll: computed once, kept for the local
        day even past the event, recomputed when the day changes.  Include a
        pass time field to get event-time expiry."""
        specified_fields = [
            'almanac.next_pass.max_altitude',
            'almanac.next_pass.duration.raw',
        ]
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ['current.outTemp'])
        cfg.legacy.almanac_fields = user.loopdata.LoopData.get_almanac_fields(specified_fields)
        self.assertEqual(len(cfg.legacy.almanac_fields), len(specified_fields))
        cfg.latitude, cfg.longitude, cfg.altitude_m = 37.4, -122.1, 20.0

        stub = StubAlmanacType()
        weewx.almanac.almanacs.insert(0, stub)
        try:
            evaluator = user.loopdata.AlmanacFieldEvaluator(cfg.legacy, cfg)
            day1_noon = 1593630000    # 2020-07-01 noon PDT
            pass_a = (day1_noon + 3600, day1_noon + 3600 + 600, 45.0)
            pass_b = (day1_noon + 86400, day1_noon + 86400 + 480, 62.0)
            stub.passes = [pass_a, pass_b]

            def insert(pkt_time: float) -> Dict[str, Any]:
                loopdata_pkt: Dict[str, Any] = {}
                evaluator.insert_fields(loopdata_pkt, {'dateTime': pkt_time, 'usUnits': 1})
                return loopdata_pkt

            pkt = insert(day1_noon)
            self.assertEqual(pkt['almanac.next_pass.max_altitude'], 45.0)
            self.assertEqual(pkt['almanac.next_pass.duration.raw'], 600.0)
            self.assertEqual(stub.counts['next_pass'], 2)

            # Past the pass's set: the fallback has no way to see the event
            # end, so the cache stands for the rest of the day.
            pkt = insert(pass_a[1] + 3600)
            self.assertEqual(pkt['almanac.next_pass.max_altitude'], 45.0)
            self.assertEqual(stub.counts['next_pass'], 2)

            # Day 2: the day roll recomputes; now pass B is the next pass.
            pkt = insert(day1_noon + 86400 - 3600)
            self.assertEqual(pkt['almanac.next_pass.max_altitude'], 62.0)
            self.assertEqual(pkt['almanac.next_pass.duration.raw'], 480.0)
            self.assertEqual(stub.counts['next_pass'], 4)
        finally:
            weewx.almanac.almanacs.remove(stub)

    def test_almanac_previous_event_day_rolls(self) -> None:
        """previous_* fields keep the per-field day-rolled cache: their
        instant is always in the past, so expire-at-event would recompute
        every packet forever.  The value is computed once, served for the
        rest of the local day, and recomputed when the day advances."""
        specified_fields = ['almanac.previous_full_moon.raw']
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ['current.outTemp'])
        cfg.legacy.almanac_fields = user.loopdata.LoopData.get_almanac_fields(specified_fields)
        self.assertEqual(len(cfg.legacy.almanac_fields), len(specified_fields))
        # previous_* fields are per-field day-rolled, never grouped.
        self.assertIsNone(cfg.legacy.almanac_fields[0].group)
        cfg.latitude, cfg.longitude, cfg.altitude_m = 37.4, -122.1, 20.0

        stub = StubAlmanacType()
        weewx.almanac.almanacs.insert(0, stub)
        try:
            evaluator = user.loopdata.AlmanacFieldEvaluator(cfg.legacy, cfg)
            day1_noon = 1593630000    # 2020-07-01 noon PDT
            stub.previous_full_moon_ts = day1_noon - 5 * 86400

            def insert(pkt_time: float) -> Dict[str, Any]:
                loopdata_pkt: Dict[str, Any] = {}
                evaluator.insert_fields(loopdata_pkt, {'dateTime': pkt_time, 'usUnits': 1})
                return loopdata_pkt

            pkt = insert(day1_noon)
            self.assertEqual(pkt['almanac.previous_full_moon.raw'], stub.previous_full_moon_ts)
            self.assertEqual(stub.counts['previous_full_moon'], 1)

            # An hour later: served from cache although the instant is long
            # past -- never recomputed per packet.
            pkt = insert(day1_noon + 3600)
            self.assertEqual(pkt['almanac.previous_full_moon.raw'], stub.previous_full_moon_ts)
            self.assertEqual(stub.counts['previous_full_moon'], 1)

            # Day 2: the day roll recomputes.
            insert(day1_noon + 86400)
            self.assertEqual(stub.counts['previous_full_moon'], 2)
        finally:
            weewx.almanac.almanacs.remove(stub)

    def test_almanac_unit_segment(self) -> None:
        """A unit segment pins the unit no matter what the target report's
        converter says; without one, .raw follows the report's [Units]
        [[Groups]] overrides (by design: report-tag parity)."""
        specified_fields = [
            'almanac.sunrise.raw',                    # follows the override
            'almanac.sunrise.unix_epoch.raw',         # pinned
            'almanac.sun.visible.raw',                # follows the override
            'almanac.sun.visible.second.raw',         # pinned
            'almanac.sun.visible.hour.round(2).raw',  # pinned, then rounded
            'almanac.sunrise.no_such_unit.raw',       # illegal conversion: skipped
        ]
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ['current.outTemp'])
        cfg.legacy.almanac_fields = user.loopdata.LoopData.get_almanac_fields(specified_fields)
        self.assertEqual(len(cfg.legacy.almanac_fields), len(specified_fields))
        cfg.latitude, cfg.longitude, cfg.altitude_m = 37.4, -122.1, 20.0
        # The hazard the unit segment exists for: a target report that
        # overrides unit groups (skyfield issue #2's lesson -- ValueHelper
        # .raw is unformatted, NOT unconverted).
        cfg.legacy.converter = weewx.units.Converter(
            {'group_time': 'unix_epoch_ms', 'group_deltatime': 'hour'})

        stub = StubAlmanacType()
        weewx.almanac.almanacs.insert(0, stub)
        try:
            evaluator = user.loopdata.AlmanacFieldEvaluator(cfg.legacy, cfg)
            day1_noon = 1593630000    # 2020-07-01 noon PDT
            day_start = time.mktime(date.fromtimestamp(day1_noon).timetuple())
            sunrise_ts = day_start + 6 * 3600
            loopdata_pkt: Dict[str, Any] = {}
            evaluator.insert_fields(loopdata_pkt, {'dateTime': day1_noon, 'usUnits': 1})

            self.assertEqual(loopdata_pkt['almanac.sunrise.raw'], sunrise_ts * 1000)
            self.assertEqual(loopdata_pkt['almanac.sunrise.unix_epoch.raw'], sunrise_ts)
            self.assertEqual(loopdata_pkt['almanac.sun.visible.raw'], 52921.0 / 3600)
            self.assertEqual(loopdata_pkt['almanac.sun.visible.second.raw'], 52921.0)
            self.assertEqual(loopdata_pkt['almanac.sun.visible.hour.round(2).raw'], 14.7)
            self.assertNotIn('almanac.sunrise.no_such_unit.raw', loopdata_pkt)
        finally:
            weewx.almanac.almanacs.remove(stub)

    def test_almanac_autocall_parity(self) -> None:
        """Chains auto-call exactly as Cheetah's NameMapper walks a tag: a
        method is called at EVERY dotted segment, not just the chain end
        (skyfield <= 1.14's parallactic_angle was a bound method); a callable
        INSTANCE (an AlmanacBinder, skyfield 1.15's CallableRadians) is never
        auto-called -- StubRadians.__call__ raises to pin that."""
        specified_fields = [
            'almanac.sun.parallactic_angle.degrees',      # method mid-chain
            'almanac.sun.parallactic_angle.degrees.raw',
            'almanac.sun.callable_angle',                 # callable instance at chain end
            'almanac.sun.callable_angle.degrees',         # callable instance mid-chain
            'almanac.sun.duration_method',                # method at chain end
        ]
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ['current.outTemp'])
        cfg.legacy.almanac_fields = user.loopdata.LoopData.get_almanac_fields(specified_fields)
        self.assertEqual(len(cfg.legacy.almanac_fields), len(specified_fields))
        cfg.latitude, cfg.longitude, cfg.altitude_m = 37.4, -122.1, 20.0

        stub = StubAlmanacType()
        weewx.almanac.almanacs.insert(0, stub)
        try:
            evaluator = user.loopdata.AlmanacFieldEvaluator(cfg.legacy, cfg)
            loopdata_pkt: Dict[str, Any] = {}
            evaluator.insert_fields(loopdata_pkt, {'dateTime': 1593630000, 'usUnits': 1})

            self.assertEqual(loopdata_pkt['almanac.sun.parallactic_angle.degrees'],
                math.degrees(0.5))
            self.assertEqual(loopdata_pkt['almanac.sun.parallactic_angle.degrees.raw'],
                math.degrees(0.5))
            self.assertEqual(loopdata_pkt['almanac.sun.callable_angle'], 0.5)
            self.assertEqual(loopdata_pkt['almanac.sun.callable_angle.degrees'],
                math.degrees(0.5))
            self.assertEqual(loopdata_pkt['almanac.sun.duration_method'], 42.0)
        finally:
            weewx.almanac.almanacs.remove(stub)

    def test_almanac_field_end_to_end(self) -> None:
        """Almanac fields through generate_loopdata_dictionary, against the
        real weewx.almanac (PyEphem or the built-in fallback) as oracle."""
        specified_fields = [
            'current.outTemp',
            'almanac.sunrise',
            'almanac.sunrise.raw',
            'almanac.sunset.raw',
            'almanac.moon_phase',
            'almanac.moon_index.raw',
            'almanac.sunrise.unix_epoch.raw',
            'almanac(days=1).sunrise.raw',
            'almanac(horizon=-6).sun(use_center=1).rise.raw',
            'almanac.sun.visible.second.raw',
        ]
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, specified_fields)
        cfg.legacy.almanac_fields = user.loopdata.LoopData.get_almanac_fields(specified_fields)
        cfg.latitude, cfg.longitude, cfg.altitude_m = 37.4, -122.1, 20.0
        evaluator = user.loopdata.AlmanacFieldEvaluator(cfg.legacy, cfg)

        # July 1, 2020 Noon PDT
        pkt: Dict[str, Any] = {'dateTime': 1593630000, 'usUnits': 1, 'outTemp': 77.4}
        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkt['dateTime'])
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums, evaluator)

        # The oracle: the Almanac exactly as a report would build it (same
        # location, temperature from the packet, formatter/converter from the
        # target report).
        temperature_c = weewx.units.convert(
            weewx.units.as_value_tuple(pkt, 'outTemp'), 'degree_C')[0]
        oracle = weewx.almanac.Almanac(pkt['dateTime'], 37.4, -122.1, altitude=20.0,
            temperature=temperature_c, formatter=cfg.legacy.formatter, converter=cfg.legacy.converter,
            # texts= only exists from WeeWX 5.3; spell it as the running
            # WeeWX takes it, so this test runs where the fix matters.
            # The report's own [Almanac] texts, exactly as the context
            # carries them (SeasonsReport's moon_phases in the fixture).
            **user.loopdata.AlmanacFieldEvaluator.build_texts_kwargs(
                weewx.almanac.Almanac, cfg.legacy.almanac_texts))

        self.assertEqual(loopdata_pkt['current.outTemp'], '77.4°F')
        self.assertEqual(loopdata_pkt['almanac.sunrise'], str(oracle.sunrise))
        self.assertEqual(loopdata_pkt['almanac.sunrise.raw'], oracle.sunrise.raw)
        self.assertEqual(loopdata_pkt['almanac.sunset.raw'], oracle.sunset.raw)
        self.assertEqual(loopdata_pkt['almanac.moon_phase'], str(oracle.moon_phase))
        self.assertEqual(loopdata_pkt['almanac.moon_index.raw'], oracle.moon_index)
        # A pinned unit segment renders as the report tag with the same
        # explicit conversion would.
        self.assertEqual(loopdata_pkt['almanac.sunrise.unix_epoch.raw'],
            oracle.sunrise.unix_epoch.raw)
        tomorrow_oracle = oracle(almanac_time=user.loopdata.AlmanacFieldEvaluator.shift_days(
            pkt['dateTime'], 1))
        self.assertEqual(loopdata_pkt['almanac(days=1).sunrise.raw'], tomorrow_oracle.sunrise.raw)
        if oracle.hasExtras:
            self.assertEqual(loopdata_pkt['almanac(horizon=-6).sun(use_center=1).rise.raw'],
                oracle(horizon=-6).sun(use_center=1).rise.raw)
            # Civil dawn precedes sunrise.
            self.assertLess(loopdata_pkt['almanac(horizon=-6).sun(use_center=1).rise.raw'],
                loopdata_pkt['almanac.sunrise.raw'])
            self.assertEqual(loopdata_pkt['almanac.sun.visible.second.raw'],
                oracle.sun.visible.second.raw)

    def test_almanac_texts_kwargs_match_weewx_signature(self) -> None:
        """The Almanac constructor's language argument is spelled texts=
        from WeeWX 5.3 on and moon_phases= before it; loopdata must pass
        whichever the running WeeWX takes (issue #15 -- texts= on a 5.2
        Almanac is a TypeError, so every almanac field died there)."""
        phases = ['New', 'Waxing crescent', 'First quarter', 'Waxing gibbous',
                  'Full', 'Waning gibbous', 'Last quarter', 'Waning crescent']
        texts = {'moon_phases': phases, 'mars': 'Mars'}
        build = user.loopdata.AlmanacFieldEvaluator.build_texts_kwargs

        class ModernAlmanac(object):
            """WeeWX 5.3 and later."""
            def __init__(self, time_ts, lat, lon, altitude=None, temperature=None,
                    pressure=None, horizon=None, texts=None, moon_phases=None,
                    formatter=None, converter=None) -> None:
                pass

        class LegacyAlmanac(object):
            """WeeWX 5.2 and earlier."""
            def __init__(self, time_ts, lat, lon, altitude=None, temperature=None,
                    pressure=None, horizon=None, moon_phases=None,
                    formatter=None, converter=None) -> None:
                pass

        self.assertEqual(build(ModernAlmanac, texts), {'texts': texts})
        # Pre-5.3 takes the phase names alone; the rest of the section has
        # nowhere to go.
        self.assertEqual(build(LegacyAlmanac, texts), {'moon_phases': phases})
        # ...and nothing at all when the report does not override them, so
        # WeeWX's own default (weeutil.Moon.moon_phases) stands, exactly as
        # it would for a report on that version.
        self.assertEqual(build(LegacyAlmanac, {'mars': 'Mars'}), {})

        # Whatever WeeWX is installed, what gets built is accepted by it and
        # lands where the phase names belong.
        almanac = weewx.almanac.Almanac(1593630000, 37.4, -122.1,
            **build(weewx.almanac.Almanac, texts))
        self.assertEqual(almanac.moon_phases, phases)

    def test_parse_station_field(self) -> None:
        parse = user.loopdata.LoopData.parse_station_field

        sf = parse('station.uptime')
        assert sf is not None
        self.assertEqual(sf.field, 'station.uptime')
        self.assertEqual(sf.chain, ['uptime'])
        self.assertEqual(sf.format_spec, None)
        self.assertEqual(sf.format_kwargs, None)
        self.assertEqual(sf.round_ndigits, None)

        sf = parse('station.uptime.raw')
        assert sf is not None
        self.assertEqual(sf.chain, ['uptime'])
        self.assertEqual(sf.format_spec, 'raw')

        sf = parse('station.os_uptime.long_form()')
        assert sf is not None
        self.assertEqual(sf.chain, ['os_uptime'])
        self.assertEqual(sf.format_spec, 'long_form')
        self.assertEqual(sf.format_kwargs, {})

        sf = parse('station.uptime.nolabel("%.0f")')
        assert sf is not None
        self.assertEqual(sf.chain, ['uptime'])
        self.assertEqual(sf.format_spec, 'nolabel')
        self.assertEqual(sf.format_kwargs, {'format_string': '%.0f'})

        sf = parse('station.version')
        assert sf is not None
        self.assertEqual(sf.chain, ['version'])
        self.assertEqual(sf.format_spec, None)

        # A chain: later names are ValueHelper attributes (unit conversion).
        sf = parse('station.altitude.meter.raw')
        assert sf is not None
        self.assertEqual(sf.chain, ['altitude', 'meter'])
        self.assertEqual(sf.format_spec, 'raw')

        sf = parse('station.altitude.meter.round(0).formatted')
        assert sf is not None
        self.assertEqual(sf.chain, ['altitude', 'meter'])
        self.assertEqual(sf.round_ndigits, 0)
        self.assertEqual(sf.format_spec, 'formatted')

        # An unknown attribute parses (it fails at evaluation, like a report
        # tag would); only the shape is validated here.
        sf = parse('station.no_such_attr')
        assert sf is not None
        self.assertEqual(sf.chain, ['no_such_attr'])

        # Malformed entries.
        self.assertIsNone(parse('station'))
        self.assertIsNone(parse('station.'))
        self.assertIsNone(parse('station..uptime'))
        self.assertIsNone(parse('station(days=1).uptime'))
        self.assertIsNone(parse('station.9lives'))
        self.assertIsNone(parse('station.uptime(1)'))
        self.assertIsNone(parse('station.up-time'))

    def test_get_station_fields(self) -> None:
        specified_fields = [
            'current.outTemp',
            'station.uptime.raw',
            'day.outTemp.max',
            'station.version',
            'station.uptime.raw',      # duplicate: dropped
            'station.uptime(1)',       # malformed: dropped
            'almanac.sunrise.raw',
            'trend.barometer.desc',
        ]
        station_fields = user.loopdata.LoopData.get_station_fields(specified_fields)
        self.assertEqual([ f.field for f in station_fields ],
            ['station.uptime.raw', 'station.version'])

        # Station entries must not leak into the observation-field or
        # almanac-field parses.
        (fields_to_include, _) = user.loopdata.LoopData.get_fields_to_include(set(specified_fields))
        self.assertEqual({ cname.field for cname in fields_to_include },
            {'current.outTemp', 'day.outTemp.max', 'trend.barometer.desc'})
        almanac_fields = user.loopdata.LoopData.get_almanac_fields(specified_fields)
        self.assertEqual([ f.field for f in almanac_fields ], ['almanac.sunrise.raw'])

    def test_station_field_evaluator(self) -> None:
        specified_fields = [
            'current.outTemp',
            'station.uptime.raw',                  # dynamic, ticks per packet
            'station.uptime.long_form()',          # the report's $station.uptime.long_form()
            'station.os_uptime.raw',               # dynamic
            'station.version',                     # static, computed once
            'station.hardware',
            'station.location',
            'station.week_start',                  # plain int, via StationInfo passthrough
            'station.rain_year_str',
            'station.altitude',                    # ValueHelper default rendering
            'station.altitude.raw',
            'station.altitude.meter.round(0).raw', # unit-conversion chain
            'station.latitude',                    # (deg, min, hemisphere) parts as json array
            'station.version.formatted',           # invalid: str endpoint, skipped
            'station.no_such_attr',                # unknown: skipped
        ]
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, specified_fields)
        cfg.legacy.station_fields = user.loopdata.LoopData.get_station_fields(specified_fields)
        self.assertEqual(len(cfg.legacy.station_fields), len(specified_fields) - 1) # less current.outTemp

        # The Station exactly as LoopData.__init__ builds it: the engine's
        # StationInfo plus the target report's formatter/converter/skin dict.
        config_dict: Dict[str, Any] = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        target_report_dict = user.loopdata.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')
        stn_info = weewx.station.StationInfo(altitude=['700', 'foot'],
            latitude='37.4', longitude='-122.1', location='Palo Alto, California',
            station_type='Vantage', week_start='6', rain_year_start='10')
        cfg.legacy.station = weewx.station.Station(stn_info, cfg.legacy.formatter, cfg.legacy.converter,
            target_report_dict)

        saved_launchtime = weewx.launchtime_ts
        # 1 day, 1 hour, 1 minute, 1 second ago: one second past the minute,
        # so long_form stays stable for the duration of the test.
        weewx.launchtime_ts = time.time() - 90061
        try:
            evaluator = user.loopdata.StationFieldEvaluator(cfg.legacy.station_fields, cfg.legacy.station)

            # Through generate_loopdata_dictionary, as LoopProcessor drives it.
            pkt: Dict[str, Any] = {'dateTime': int(time.time()), 'usUnits': 1, 'outTemp': 77.4}
            accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkt['dateTime'])
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
                pkt, cfg, accums, None, evaluator)

            self.assertEqual(loopdata_pkt['current.outTemp'], '77.4°F')
            self.assertAlmostEqual(loopdata_pkt['station.uptime.raw'], 90061, delta=10)
            self.assertEqual(loopdata_pkt['station.uptime.long_form()'], '1 day, 1 hour, 1 minute')
            # /proc/uptime is the same source weewx.station._os_uptime reads on Linux.
            with open('/proc/uptime') as f:
                os_uptime = float(f.read().split()[0])
            self.assertAlmostEqual(loopdata_pkt['station.os_uptime.raw'], os_uptime, delta=10)
            self.assertEqual(loopdata_pkt['station.version'], weewx.__version__)
            self.assertEqual(loopdata_pkt['station.hardware'], 'Vantage')
            self.assertEqual(loopdata_pkt['station.location'], 'Palo Alto, California')
            self.assertEqual(loopdata_pkt['station.week_start'], 6)
            self.assertEqual(loopdata_pkt['station.rain_year_str'], 'Oct')
            self.assertEqual(loopdata_pkt['station.altitude'], '700 feet')
            self.assertEqual(loopdata_pkt['station.altitude.raw'], 700.0)
            # 700 feet = 213.36 meters, rounded to 0 digits.
            self.assertEqual(loopdata_pkt['station.altitude.meter.round(0).raw'], 213.0)
            # 37.4 degrees = 37 degrees 24.00 minutes North.
            self.assertEqual(loopdata_pkt['station.latitude'], ['37', '24.00', 'N'])
            self.assertNotIn('station.version.formatted', loopdata_pkt)
            self.assertNotIn('station.no_such_attr', loopdata_pkt)

            # Static values are computed once and cached; dynamic values tick.
            cfg.legacy.station.version = 'bogus'
            weewx.launchtime_ts -= 3600
            loopdata_pkt2: Dict[str, Any] = {}
            evaluator.insert_fields(loopdata_pkt2)
            self.assertEqual(loopdata_pkt2['station.version'], weewx.__version__)
            self.assertAlmostEqual(loopdata_pkt2['station.uptime.raw'], 93661, delta=10)
        finally:
            weewx.launchtime_ts = saved_launchtime

    def test_station_field_autocall_parity(self) -> None:
        """Station chains walk with the same NameMapper auto-call rule as
        almanac chains: a bound method is called at every dotted segment, a
        callable instance never is (StubRadians.__call__ raises to pin it)."""
        class StubStation:
            def altitude_method(self) -> weewx.units.ValueHelper:
                return weewx.units.ValueHelper(
                    weewx.units.ValueTuple(700.0, 'foot', 'group_altitude'),
                    formatter=weewx.units.Formatter(),
                    converter=weewx.units.Converter())

            @property
            def callable_value(self) -> StubRadians:
                return StubRadians(0.5)

        specified_fields = [
            'station.altitude_method.meter.round(1).raw', # method mid-chain, then unit segment
            'station.callable_value',                     # callable instance at chain end
            'station.callable_value.degrees',             # callable instance mid-chain
        ]
        station_fields = user.loopdata.LoopData.get_station_fields(specified_fields)
        self.assertEqual(len(station_fields), len(specified_fields))
        evaluator = user.loopdata.StationFieldEvaluator(station_fields, StubStation())
        loopdata_pkt: Dict[str, Any] = {}
        evaluator.insert_fields(loopdata_pkt)
        # 700 feet = 213.36 meters, rounded to 213.4.
        self.assertEqual(loopdata_pkt['station.altitude_method.meter.round(1).raw'], 213.4)
        self.assertEqual(loopdata_pkt['station.callable_value'], 0.5)
        self.assertEqual(loopdata_pkt['station.callable_value.degrees'], math.degrees(0.5))

    def test_get_barometer_trend_mbar(self) -> None:
        # Forecast descriptions for the 3 hour change in barometer readings.
        # Falling (or rising) slowly: 0.1 - 1.5mb in 3 hours
        # Falling (or rising): 1.6 - 3.5mb in 3 hours
        # Falling (or rising) quickly: 3.6 - 6.0mb in 3 hours
        # Falling (or rising) very rapidly: More than 6.0mb in 3 hours

        baroTrend: user.loopdata.BarometerTrend = user.loopdata.LoopProcessor.get_barometer_trend(9.0, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_VERY_RAPIDLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(6.1, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_VERY_RAPIDLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(6.0, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_QUICKLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(3.6, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_QUICKLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(3.5, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(1.6, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(1.5, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_SLOWLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.1, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_SLOWLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.09, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.STEADY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.0, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.STEADY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-0.09, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.STEADY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-0.1, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_SLOWLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-1.5, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_SLOWLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-1.6, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-3.5, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-3.6, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_QUICKLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-6.0, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_QUICKLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-6.1, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_VERY_RAPIDLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-9.0, 'mbar', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_VERY_RAPIDLY)

    def test_get_barometer_trend_inHg(self) -> None:
        # Forecast descriptions for the 3 hour change in barometer readings.
        # These are approximations (converted from mbars)
        # Falling (or rising) slowly: 0.002953 - 0.044294 inHg in 3 hours
        # Falling (or rising): 0.047248 - 0.10335 inHg in 3 hours
        # Falling (or rising) quickly: 0.106308 - 0.177179 inHg in 3 hours
        # Falling (or rising) very rapidly: More than 0.17719 inHg in 3 hours

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.26577, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_VERY_RAPIDLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.17719, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_VERY_RAPIDLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.177179, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_QUICKLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.106308, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_QUICKLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.10335, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.047248, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.044294, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_SLOWLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.002953, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_SLOWLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.002657698, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.STEADY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(0.0, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.STEADY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-0.002657698, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.STEADY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-0.002953, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_SLOWLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-0.044294, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_SLOWLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-0.047248, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-0.10335, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-0.106308, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_QUICKLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-0.177179, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_QUICKLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-0.17719, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_VERY_RAPIDLY)

        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(-0.26577, 'inHg', 'group_pressure', 10800)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.FALLING_VERY_RAPIDLY)

        # Normalization-to-3-hours: the thresholds are per-3-hours, so a
        # time_delta != 10800 must rescale the delta (delta /= time_delta/10800).
        # All cases above use 10800 (identity), so they don't exercise the
        # division.  Here a ~1.0 mbar rise over 1 hour (time_delta=3600)
        # normalizes to ~3.0 mbar/3h -> RISING; without the normalization it
        # would read ~1.0 -> RISING_SLOWLY, so the division is pinned.  The
        # value sits mid-bucket, robust to small conversion-factor differences.
        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(
            0.029530, 'inHg', 'group_pressure', 3600)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING)
        # Same delta over 6 hours normalizes DOWN (~0.5 mbar/3h) -> RISING_SLOWLY.
        baroTrend = user.loopdata.LoopProcessor.get_barometer_trend(
            0.029530, 'inHg', 'group_pressure', 21600)
        self.assertEqual(baroTrend, user.loopdata.BarometerTrend.RISING_SLOWLY)

    def test_prune_period_packet(self) -> None:
        """ test that packet is pruned to just the observations needed. """

        pkt: Dict[str, Any] = { 'dateTime': 123456789, 'usUnits': 1, 'windSpeed': 10, 'windDir': 27 }
        in_use_obstypes = {'barometer'}
        new_pkt: Dict[str, Any] = user.loopdata.LoopProcessor.prune_period_packet(pkt, in_use_obstypes)
        self.assertEqual(len(new_pkt), 2)
        self.assertEqual(new_pkt['dateTime'], 123456789)
        self.assertEqual(new_pkt['usUnits'], 1)

        pkt = { 'dateTime': 123456789, 'usUnits': 1, 'windSpeed': 10, 'windDir': 27 }
        in_use_obstypes = {'windSpeed'}
        new_pkt = user.loopdata.LoopProcessor.prune_period_packet(pkt, in_use_obstypes)
        self.assertEqual(len(new_pkt), 3)
        self.assertEqual(new_pkt['dateTime'], 123456789)
        self.assertEqual(new_pkt['usUnits'], 1)
        self.assertEqual(new_pkt['windSpeed'], 10)

        pkt = { 'dateTime': 123456789, 'usUnits': 1, 'windSpeed': 10, 'windDir': 27, 'barometer': 1035.01 }
        in_use_obstypes = {'windSpeed', 'barometer', 'windDir'}
        new_pkt = user.loopdata.LoopProcessor.prune_period_packet(pkt, in_use_obstypes)
        self.assertEqual(len(new_pkt), 5)
        self.assertEqual(new_pkt['dateTime'], 123456789)
        self.assertEqual(new_pkt['usUnits'], 1)
        self.assertEqual(new_pkt['windSpeed'], 10)
        self.assertEqual(new_pkt['barometer'], 1035.01)

    def test_changing_periods(self) -> None:
        specified_fields = [ 'current.outTemp', 'trend.outTemp',
                             '2m.outTemp.max', '2m.outTemp.min', '2m.outTemp.avg',
                             '10m.outTemp.max', '10m.outTemp.min', '10m.outTemp.avg',
                             '24h.rain.sum', '24h.outTemp.min', '24h.outTemp.avg',
                             'hour.outTemp.max', 'hour.outTemp.min', 'hour.outTemp.avg',
                             'day.outTemp.max', 'day.outTemp.min', 'day.outTemp.avg',
                             'week.outTemp.max', 'week.outTemp.min', 'week.outTemp.avg',
                             'month.outTemp.max', 'month.outTemp.min', 'month.outTemp.avg',
                             'year.outTemp.max', 'year.outTemp.min', 'year.outTemp.avg',
                             'rainyear.outTemp.max', 'rainyear.outTemp.min', 'rainyear.outTemp.avg',
                             'alltime.outTemp.max', 'alltime.outTemp.min', 'alltime.outTemp.avg']
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, specified_fields)

        # July 1, 2020 Noon PDT
        pkt: Dict[str, Any] = {'dateTime': 1593630000, 'usUnits': 1, 'outTemp': 77.4, 'rain': 0.01}

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkt['dateTime'])

        # First packet.
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Next packet 1 minute later
        pkt = {'dateTime': 1593630060, 'usUnits': 1, 'outTemp': 77.3}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)
        self.assertEqual(loopdata_pkt['current.outTemp'], '77.3°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.01 in')
        self.assertEqual(loopdata_pkt['24h.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['24h.outTemp.avg'], '77.3°F')
        # New hour, since previous record (noon) was part of prev. hour.
        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '77.3°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'], '-17.4°F')

        # Next packet 9 minute later
        pkt = {'dateTime': 1593630600, 'usUnits': 1, 'outTemp': 77.2, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '77.2°F')
        # Previous max should have dropped off of 10m.
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '77.3°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '77.2°F')
        # hour
        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '77.3°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'], '-3.6°F')
        # 24h
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.02 in')

        # Next packet 2:51 later
        pkt = {'dateTime': 1593640860, 'usUnits': 1, 'outTemp': 76.9, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '76.9°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '76.9°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '76.9°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '76.9°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'], '76.9°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'], '-0.3°F')
        # 24h
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.02 in')

        # Next packet 4:00 later
        pkt = {'dateTime': 1593655260, 'usUnits': 1, 'outTemp': 75.0, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '75.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '75.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '75.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '75.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'], '75.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'], '75.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.03 in')

        # Next packet 20:00 later
        pkt = {'dateTime': 1593727260, 'usUnits': 1, 'outTemp': 70.0, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '70.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'], '70.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)
        # 24h
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.01 in')

        # Add another temp a minute later so we get a trend
        pkt = {'dateTime': 1593727320, 'usUnits': 1, 'outTemp': 70.0, 'rain': 0.04}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],  '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],  '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],  '70.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],  '70.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],  '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],  '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],  '70.0°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'],    '0.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '77.4°F')
        # 24h
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.05 in')

        # Jump a week
        pkt = {'dateTime': 1594332120, 'usUnits': 1, 'outTemp': 66.0, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],  '66.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],  '66.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],  '66.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],  '66.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],  '66.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],  '66.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],  '66.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'], '66.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'], '66.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '66.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)
        # 24h
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.00 in')

        # Jump a month
        pkt = {'dateTime': 1597010520, 'usUnits': 1, 'outTemp': 88.0, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],   '88.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],   '88.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],   '88.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],   '88.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],   '88.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],   '88.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],   '88.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],  '88.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],  '88.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '88.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '88.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],  '66.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],  '88.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # Jump a year
        pkt = {'dateTime': 1628546520, 'usUnits': 1, 'outTemp': 99.0, 'rain': 0.02}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],   '99.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],   '99.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],   '99.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],   '99.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],  '99.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],  '99.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '99.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],  '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],  '99.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # Jump a minute
        pkt = {'dateTime': 1628546580, 'usUnits': 1, 'outTemp': 97.0, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],       '97.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],       '99.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],       '97.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],       '99.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],       '97.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],       '97.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],       '99.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],      '97.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'],     '97.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'],     '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],      '97.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.min'],  '97.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.max'],  '99.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.min'],   '66.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'],         '-348.4°F')

        # Jump to October 15 (new rain year)
        # Friday, October 15, 2021 12:00:00 PM GMT-07:00 DST
        pkt = {'dateTime': 1634324400, 'usUnits': 1, 'outTemp': 41.0, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],       '41.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],       '41.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],       '41.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],       '41.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],      '41.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'],     '41.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'],     '41.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.min'],  '41.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.max'],  '41.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.min'],   '41.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # 1s later
        pkt = {'dateTime': 1634324401, 'usUnits': 1, 'outTemp': 42.0, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],       '42.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],       '42.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.avg'],       '41.5°F')
        # One second later starts new hour.
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],       '42.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],       '42.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.avg'],       '42.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],       '42.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.avg'],       '41.5°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],      '42.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.avg'],      '41.5°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'],     '41.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'],     '42.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.avg'],     '41.5°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.avg'],      '69.8°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.min'],  '41.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.max'],  '42.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.avg'],  '41.5°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.min'],   '41.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.avg'],   '73.6°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'],         '3600.0°F')

        # About 2 days later, Sunday, October 17, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1634513067, 'usUnits': 1, 'outTemp': 88.0, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Next day, Monday, October 18, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1634599467, 'usUnits': 1, 'outTemp': 87.5, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # 6 days later, Saturday, October 23, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1635031467, 'usUnits': 1, 'outTemp': 87.0, 'rain': 0.04}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Next day, starts a new week, the high should be 85 (from today)
        # Sunday, October 24, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1635117867, 'usUnits': 1, 'outTemp': 85.0, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Make sure we have a new week accumulator that starts this Sunday 2021-10-24.
        assert accums.week_accum is not None
        self.assertEqual(timestamp_to_string(accums.week_accum.timespan.start), '2021-10-24 00:00:00 PDT (1635058800)')
        self.assertEqual(accums.week_accum['outTemp'].max, 85.0)
        self.assertEqual(loopdata_pkt['week.outTemp.max'], '85.0°F')

    def test_changing_periods_rainyear_start_1(self) -> None:
        specified_fields = [ 'current.outTemp', 'trend.outTemp',
                             '2m.outTemp.max', '2m.outTemp.min', '2m.outTemp.avg',
                             '10m.outTemp.max', '10m.outTemp.min', '10m.outTemp.avg',
                             '24h.rain.sum', '24h.outTemp.min', '24h.outTemp.avg',
                             'hour.outTemp.max', 'hour.outTemp.min', 'hour.outTemp.avg',
                             'day.outTemp.max', 'day.outTemp.min', 'day.outTemp.avg',
                             'week.outTemp.max', 'week.outTemp.min', 'week.outTemp.avg',
                             'month.outTemp.max', 'month.outTemp.min', 'month.outTemp.avg',
                             'year.outTemp.max', 'year.outTemp.min', 'year.outTemp.avg',
                             'rainyear.outTemp.max', 'rainyear.outTemp.min', 'rainyear.outTemp.avg',
                             'alltime.outTemp.max', 'alltime.outTemp.min', 'alltime.outTemp.avg']
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 1, 6, specified_fields)

        # July 1, 2020 Noon PDT
        pkt: Dict[str, Any] = {'dateTime': 1593630000, 'usUnits': 1, 'outTemp': 77.4, 'rain': 0.01}

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkt['dateTime'])

        # First packet.
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Next packet 1 minute later
        pkt = {'dateTime': 1593630060, 'usUnits': 1, 'outTemp': 77.3}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '77.3°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.01 in')
        self.assertEqual(loopdata_pkt['24h.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['24h.outTemp.avg'], '77.3°F')
        # New hour, since previous record (noon) was part of prev. hour.
        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '77.3°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'],    '-17.4°F')

        # Next packet 9 minute later
        pkt = {'dateTime': 1593630600, 'usUnits': 1, 'outTemp': 77.2, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '77.2°F')
        # Previous max should have dropped off of 10m.
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '77.3°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '77.2°F')
        # hour
        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '77.3°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'], '-3.6°F')
        # 24h
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.02 in')

        # Next packet 2:51 later
        pkt = {'dateTime': 1593640860, 'usUnits': 1, 'outTemp': 76.9, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '76.9°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '76.9°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '76.9°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '76.9°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'], '76.9°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'], '-0.3°F')
        # 24h
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.02 in')

        # Next packet 4:00 later
        pkt = {'dateTime': 1593655260, 'usUnits': 1, 'outTemp': 75.0, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '75.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '75.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '75.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '75.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'], '75.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'], '75.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.03 in')

        # Next packet 20:00 later
        pkt = {'dateTime': 1593727260, 'usUnits': 1, 'outTemp': 70.0, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '70.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'], '70.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)
        # 24h
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.01 in')

        # Add another temp a minute later so we get a trend
        pkt = {'dateTime': 1593727320, 'usUnits': 1, 'outTemp': 70.0, 'rain': 0.04}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],  '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],  '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],  '70.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],  '70.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],  '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],  '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],  '70.0°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'],    '0.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '77.4°F')
        # 24h
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.05 in')

        # Jump a week
        pkt = {'dateTime': 1594332120, 'usUnits': 1, 'outTemp': 66.0, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],  '66.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],  '66.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],  '66.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],  '66.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],  '66.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],  '66.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],  '66.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'], '66.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'], '66.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '66.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)
        # 24h
        self.assertEqual(loopdata_pkt['24h.rain.sum'], '0.00 in')

        # Jump a month
        pkt = {'dateTime': 1597010520, 'usUnits': 1, 'outTemp': 88.0, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],   '88.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],   '88.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],   '88.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],   '88.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],   '88.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],   '88.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],   '88.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],  '88.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],  '88.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '88.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '88.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],  '66.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],  '88.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # Jump a year
        pkt = {'dateTime': 1628546520, 'usUnits': 1, 'outTemp': 99.0, 'rain': 0.02}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],   '99.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],   '99.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],   '99.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],   '99.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],  '99.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],  '99.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '99.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],  '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],  '99.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # Jump a minute
        pkt = {'dateTime': 1628546580, 'usUnits': 1, 'outTemp': 97.0, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],       '97.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],       '99.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],       '97.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],       '99.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],       '97.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],       '97.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],       '99.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],      '97.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'],     '97.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'],     '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],      '97.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.min'],  '97.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.max'],  '99.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.min'],   '66.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'],         '-348.4°F')

        # Jump to October 15 (NOT a new rain year)
        # Friday, October 15, 2021 12:00:00 PM GMT-07:00 DST
        pkt = {'dateTime': 1634324400, 'usUnits': 1, 'outTemp': 41.0, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],       '41.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],       '41.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],       '41.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],       '41.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],      '41.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'],     '41.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'],     '41.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.min'],  '41.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.max'],  '99.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.min'],   '41.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # 1s later
        pkt = {'dateTime': 1634324401, 'usUnits': 1, 'outTemp': 42.0, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],       '42.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],       '42.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.avg'],       '41.5°F')
        # One second later starts new hour.
        self.assertEqual(loopdata_pkt['hour.outTemp.min'],       '42.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max'],       '42.0°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.avg'],       '42.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],       '42.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.avg'],       '41.5°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],      '42.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.avg'],      '41.5°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'],     '41.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'],     '42.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.avg'],     '41.5°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.avg'],      '69.8°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.min'],  '41.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.max'],  '99.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.avg'],  '69.8°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.min'],   '41.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.avg'],   '73.6°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'],         '3600.0°F')

        # About 2 days later, Sunday, October 17, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1634513067, 'usUnits': 1, 'outTemp': 88.0, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Next day, Monday, October 18, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1634599467, 'usUnits': 1, 'outTemp': 87.5, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # 6 days later, Saturday, October 23, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1635031467, 'usUnits': 1, 'outTemp': 87.0, 'rain': 0.04}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Next day, starts a new week, the high should be 85 (from today)
        # Sunday, October 24, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1635117867, 'usUnits': 1, 'outTemp': 85.0, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Make sure we have a new week accumulator that starts this Sunday 2021-10-24.
        assert accums.week_accum is not None
        self.assertEqual(timestamp_to_string(accums.week_accum.timespan.start), '2021-10-24 00:00:00 PDT (1635058800)')
        self.assertEqual(accums.week_accum['outTemp'].max, 85.0)
        self.assertEqual(loopdata_pkt['week.outTemp.max'], '85.0°F')

        # Jump to January 2 (new rain year)
        # Sunday, January 2, 2022 1:00:00 PM GMT-08:00
        pkt = {'dateTime': 1641157200, 'usUnits': 1, 'outTemp': 55.0, 'rain': 0.00}
        # And 1 minute later.
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)
        pkt = {'dateTime': 1641157260, 'usUnits': 1, 'outTemp': 60.0, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)
        self.assertEqual(loopdata_pkt['year.outTemp.min'],      '55.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],      '60.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.avg'],      '57.5°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.min'],  '55.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.max'],  '60.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.avg'],  '57.5°F')

    def test_changing_periods_week_start_0(self) -> None:
        specified_fields = [ 'current.outTemp', 'trend.outTemp',
                             '10m.outTemp.max', '10m.outTemp.min', '10m.outTemp.avg',
                             'day.outTemp.max', 'day.outTemp.min', 'day.outTemp.avg',
                             'week.outTemp.max', 'week.outTemp.min', 'week.outTemp.avg',
                             'month.outTemp.max', 'month.outTemp.min', 'month.outTemp.avg',
                             'year.outTemp.max', 'year.outTemp.min', 'year.outTemp.avg',
                             'rainyear.outTemp.max', 'rainyear.outTemp.min', 'rainyear.outTemp.avg',
                             'alltime.outTemp.max', 'alltime.outTemp.min', 'alltime.outTemp.avg']
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 0, specified_fields)
        # July 1, 2020 Noon PDT
        pkt: Dict[str, Any] = {'dateTime': 1593630000, 'usUnits': 1, 'outTemp': 77.4}
        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkt['dateTime'])
        self.assertEqual(cfg.week_start, 0)

        # First packet.
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Next packet 1 minute later
        pkt = {'dateTime': 1593630060, 'usUnits': 1, 'outTemp': 77.3}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '77.3°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['trend.outTemp']  , '-17.4°F')

        # Next packet 9 minute later
        pkt = {'dateTime': 1593630600, 'usUnits': 1, 'outTemp': 77.2}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '77.2°F')
        # Previous max should have dropped off of 10m.
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '77.3°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'], '-3.6°F')

        # Next packet 2:51 later
        pkt = {'dateTime': 1593640860, 'usUnits': 1, 'outTemp': 76.9}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '76.9°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '76.9°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '76.9°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'], '-0.3°F')

        # Next packet 4:00 later
        pkt = {'dateTime': 1593655260, 'usUnits': 1, 'outTemp': 75.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '75.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '75.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '75.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'], '75.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # Next packet 20:00 later
        pkt = {'dateTime': 1593727260, 'usUnits': 1, 'outTemp': 70.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'], '70.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # Add another temp a minute later so we get a trend
        pkt = {'dateTime': 1593727320, 'usUnits': 1, 'outTemp': 70.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],  '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],  '70.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],  '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],  '70.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],  '70.0°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'],    '0.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '70.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '77.4°F')

        # Jump a week
        pkt = {'dateTime': 1594332120, 'usUnits': 1, 'outTemp': 66.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],  '66.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],  '66.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],  '66.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],  '66.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],  '66.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'], '66.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'], '66.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '66.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # Jump a month
        pkt = {'dateTime': 1597010520, 'usUnits': 1, 'outTemp': 88.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],   '88.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],   '88.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],   '88.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],   '88.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],   '88.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],  '88.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],  '88.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '88.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '88.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],  '66.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],  '88.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # Jump a year
        pkt = {'dateTime': 1628546520, 'usUnits': 1, 'outTemp': 99.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],   '99.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],   '99.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],   '99.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],  '99.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],  '99.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'], '99.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'], '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],  '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],  '99.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # Jump a minute
        pkt = {'dateTime': 1628546580, 'usUnits': 1, 'outTemp': 97.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],       '97.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],       '99.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],       '97.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],       '97.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],       '99.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],      '97.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'],     '97.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'],     '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],      '97.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.min'],  '97.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.max'],  '99.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.min'],   '66.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'],         '-348.4°F')

        # Jump to October 15 (new rain year)
        pkt = {'dateTime': 1634324400, 'usUnits': 1, 'outTemp': 41.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],       '41.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],       '41.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],       '41.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],      '41.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'],     '41.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'],     '41.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.min'],  '41.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.max'],  '41.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt.get('trend.outTemp'), None)

        # 1s later
        pkt = {'dateTime': 1634324401, 'usUnits': 1, 'outTemp': 42.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'],       '42.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max'],       '42.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.avg'],       '41.5°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'],       '41.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.max'],       '42.0°F')
        self.assertEqual(loopdata_pkt['day.outTemp.avg'],       '41.5°F')
        self.assertEqual(loopdata_pkt['week.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.max'],      '42.0°F')
        self.assertEqual(loopdata_pkt['week.outTemp.avg'],      '41.5°F')
        self.assertEqual(loopdata_pkt['month.outTemp.min'],     '41.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.max'],     '42.0°F')
        self.assertEqual(loopdata_pkt['month.outTemp.avg'],     '41.5°F')
        self.assertEqual(loopdata_pkt['year.outTemp.min'],      '41.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.max'],      '99.0°F')
        self.assertEqual(loopdata_pkt['year.outTemp.avg'],      '69.8°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.min'],  '41.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.max'],  '42.0°F')
        self.assertEqual(loopdata_pkt['rainyear.outTemp.avg'],  '41.5°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.min'],   '41.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.max'],   '99.0°F')
        self.assertEqual(loopdata_pkt['alltime.outTemp.avg'],   '73.6°F')
        self.assertEqual(loopdata_pkt['trend.outTemp'],         '3600.0°F')

        # About 2 days later, Sunday, October 17, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1634513067, 'usUnits': 1, 'outTemp': 88.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Make sure we still have the old accumulator that started Monday 2021-10-11.
        assert accums.week_accum is not None
        self.assertEqual(timestamp_to_string(accums.week_accum.timespan.start), '2021-10-11 00:00:00 PDT (1633935600)')

        # Next day, Monday, October 18, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1634599467, 'usUnits': 1, 'outTemp': 87.5}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Make sure we still have a new accumulator that started Monday 2021-10-18.
        assert accums.week_accum is not None
        self.assertEqual(timestamp_to_string(accums.week_accum.timespan.start), '2021-10-18 00:00:00 PDT (1634540400)')

        # 6 days later, Saturday, October 23, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1635031467, 'usUnits': 1, 'outTemp': 87.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Next day DOES NOT START a new week since week_start is 0, high should be 87.5 (last Monday)
        # Sunday, October 24, 2021 04:24:27 PM PDT
        pkt = {'dateTime': 1635117867, 'usUnits': 1, 'outTemp': 85.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Make sure we still have the accumulator that started Monday 2021-10-18.
        assert accums.week_accum is not None
        self.assertEqual(timestamp_to_string(accums.week_accum.timespan.start), '2021-10-18 00:00:00 PDT (1634540400)')
        self.assertEqual(accums.week_accum['outTemp'].max, 87.5)
        self.assertEqual(loopdata_pkt['week.outTemp.max'], '87.5°F')

    def test_new_db_startup(self) -> None:
        pkts: List[Dict[str, Any]] = [ {'dateTime': 1665796967, 'usUnits': 1, 'windDir': 355.0, 'windSpeed': 4.0, 'outTemp': 69.1},
                 {'dateTime': 1665796969, 'usUnits': 1, 'windDir':   5.0, 'windSpeed': 3.0, 'outTemp': 69.2},
                 {'dateTime': 1665796971, 'usUnits': 1, 'windDir':  10.0, 'windSpeed': 2.0, 'outTemp': 69.3}]

        wind_fields = [
            '2m.outTemp.avg',
            '2m.outTemp.max',
            '2m.outTemp.maxtime.raw',
            '2m.outTemp.min',
            '2m.outTemp.mintime.raw',
            '2m.wind.avg',
            '2m.wind.rms',
            '2m.wind.max',
            '2m.wind.maxtime.raw',
            '2m.wind.min',
            '2m.wind.mintime.raw',
            '2m.wind.vecdir',
            '2m.windSpeed.avg',
            '2m.windSpeed.max',
            '2m.windSpeed.maxtime.raw',
            '2m.windSpeed.min',
            '2m.windSpeed.mintime.raw',
            '2m.windDir.avg',
            'day.outTemp.avg',
            'day.outTemp.max',
            'day.outTemp.maxtime.raw',
            'day.outTemp.min',
            'day.outTemp.mintime.raw',
            'day.wind.avg',
            'day.wind.rms',
            'day.wind.max',
            'day.wind.maxtime.raw',
            'day.wind.min',
            'day.wind.mintime.raw',
            'day.wind.vecdir',
            'day.windSpeed.avg',
            'day.windSpeed.max',
            'day.windSpeed.maxtime.raw',
            'day.windSpeed.min',
            'day.windSpeed.mintime.raw',
            'day.windDir.avg',
            'current.dateTime.raw',
            'current.dateTime',
            'current.windSpeed',
            'current.windDir',
            'current.windDir.ordinal_compass',
            'unit.label.outTemp',
            'unit.label.wind',
            'unit.label.windDir',
            'unit.label.windSpeed']

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, wind_fields)

        # Test when adding very first packet.
        pkt: Dict[str, Any] = pkts[0]
        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkt['dateTime'])
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1665796967, 'usUnits': 1, 'windDir': 355.0, 'windSpeed': 4.0, 'outTemp': 69.1}
        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['current.dateTime'], '10/14/22 18:22:47')

        self.assertEqual(loopdata_pkt['2m.outTemp.avg'], '69.1°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.min'], '69.1°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.outTemp.max'], '69.1°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.maxtime.raw'], 1665796967)

        self.assertEqual(loopdata_pkt['2m.wind.vecdir'], '355°')
        self.assertEqual(loopdata_pkt['2m.windDir.avg'], '355°')

        self.assertEqual(loopdata_pkt['2m.wind.avg'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.wind.rms'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.avg'], '4 mph')

        self.assertEqual(loopdata_pkt['2m.wind.min'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.wind.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.wind.max'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.wind.maxtime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.windSpeed.min'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.windSpeed.max'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.maxtime.raw'], 1665796967)

        # Repeat same with day.
        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '69.1°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'], '69.1°F')
        self.assertEqual(loopdata_pkt['day.outTemp.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.outTemp.max'], '69.1°F')
        self.assertEqual(loopdata_pkt['day.outTemp.maxtime.raw'], 1665796967)

        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '355°')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '355°')

        self.assertEqual(loopdata_pkt['day.wind.avg'], '4 mph')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '4 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '4 mph')

        self.assertEqual(loopdata_pkt['day.wind.min'], '4 mph')
        self.assertEqual(loopdata_pkt['day.wind.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.wind.max'], '4 mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '4 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '4 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.maxtime.raw'], 1665796967)

        # Add 2nd packet.
        pkt = pkts[1]
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1665796967, 'usUnits': 1, 'windDir': 355.0, 'windSpeed': 4.0, 'outTemp': 69.1}
        # {'dateTime': 1665796969, 'usUnits': 1, 'windDir':   5.0, 'windSpeed': 3.0, 'outTemp': 69.2},
        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1665796969)
        self.assertEqual(loopdata_pkt['current.dateTime'], '10/14/22 18:22:49')

        self.assertEqual(loopdata_pkt['2m.outTemp.avg'], '69.2°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.min'], '69.1°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.outTemp.max'], '69.2°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.maxtime.raw'], 1665796969)

        self.assertEqual(loopdata_pkt['2m.wind.vecdir'], '359°')
        self.assertEqual(loopdata_pkt['2m.windDir.avg'], '180°')  # A bogus value, which is why we need to use wind.vecdir.

        self.assertEqual(loopdata_pkt['2m.wind.avg'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.wind.rms'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.avg'], '4 mph')

        self.assertEqual(loopdata_pkt['2m.wind.min'], '3 mph')
        self.assertEqual(loopdata_pkt['2m.wind.mintime.raw'], 1665796969)
        self.assertEqual(loopdata_pkt['2m.wind.max'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.wind.maxtime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.windSpeed.min'], '3 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.mintime.raw'], 1665796969)
        self.assertEqual(loopdata_pkt['2m.windSpeed.max'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.maxtime.raw'], 1665796967)

        # Repeat same with day.
        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '69.2°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'], '69.1°F')
        self.assertEqual(loopdata_pkt['day.outTemp.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.outTemp.max'], '69.2°F')
        self.assertEqual(loopdata_pkt['day.outTemp.maxtime.raw'], 1665796969)

        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '359°')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '180°')  # A bogus value, which is why we need to use wind.vecdir.

        self.assertEqual(loopdata_pkt['day.wind.avg'], '4 mph')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '4 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '4 mph')

        self.assertEqual(loopdata_pkt['day.wind.min'], '3 mph')
        self.assertEqual(loopdata_pkt['day.wind.mintime.raw'], 1665796969)
        self.assertEqual(loopdata_pkt['day.wind.max'], '4 mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '3 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.mintime.raw'], 1665796969)
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '4 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.maxtime.raw'], 1665796967)

        # Add 3rd packet.
        pkt = pkts[2]
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1665796967, 'usUnits': 1, 'windDir': 355.0, 'windSpeed': 4.0, 'outTemp': 69.1}
        # {'dateTime': 1665796969, 'usUnits': 1, 'windDir':   5.0, 'windSpeed': 3.0, 'outTemp': 69.2}
        # {'dateTime': 1665796971, 'usUnits': 1, 'windDir':  10.0, 'windSpeed': 2.0, 'outTemp': 69.3}
        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1665796971)
        self.assertEqual(loopdata_pkt['current.dateTime'], '10/14/22 18:22:51')

        self.assertEqual(loopdata_pkt['2m.outTemp.avg'], '69.2°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.min'], '69.1°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.outTemp.max'], '69.3°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.maxtime.raw'], 1665796971)

        self.assertEqual(loopdata_pkt['2m.wind.vecdir'], '2°')
        self.assertEqual(loopdata_pkt['2m.windDir.avg'], '123°')  # A bogus value, which is why we need to use wind.vecdir.

        self.assertEqual(loopdata_pkt['2m.wind.avg'], '3 mph')
        self.assertEqual(loopdata_pkt['2m.wind.rms'], '3 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.avg'], '3 mph')

        self.assertEqual(loopdata_pkt['2m.wind.min'], '2 mph')
        self.assertEqual(loopdata_pkt['2m.wind.mintime.raw'], 1665796971)
        self.assertEqual(loopdata_pkt['2m.wind.max'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.wind.maxtime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.windSpeed.min'], '2 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.mintime.raw'], 1665796971)
        self.assertEqual(loopdata_pkt['2m.windSpeed.max'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.maxtime.raw'], 1665796967)

        # Repeat same with day.
        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '69.2°F')
        self.assertEqual(loopdata_pkt['day.outTemp.min'], '69.1°F')
        self.assertEqual(loopdata_pkt['day.outTemp.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.outTemp.max'], '69.3°F')
        self.assertEqual(loopdata_pkt['day.outTemp.maxtime.raw'], 1665796971)

        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '2°')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '123°')  # A bogus value, which is why we need to use wind.vecdir.

        self.assertEqual(loopdata_pkt['day.wind.avg'], '3 mph')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '3 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '3 mph')

        self.assertEqual(loopdata_pkt['day.wind.min'], '2 mph')
        self.assertEqual(loopdata_pkt['day.wind.mintime.raw'], 1665796971)
        self.assertEqual(loopdata_pkt['day.wind.max'], '4 mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '2 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.mintime.raw'], 1665796971)
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '4 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.maxtime.raw'], 1665796967)

    def test_wind(self) -> None:
        pkts: List[Dict[str, Any]] = [ {'dateTime': 1665796967, 'usUnits': 1, 'windDir': 355.0, 'windGust': 4.0, 'windGustDir': 355.0, 'windrun': None, 'windSpeed': 4.0},
                 {'dateTime': 1665796969, 'usUnits': 1, 'windDir':   5.0, 'windGust': 3.0, 'windGustDir':   5.0, 'windrun': None, 'windSpeed': 3.0},
                 {'dateTime': 1665796971, 'usUnits': 1, 'windDir':  10.0, 'windGust': 2.0, 'windGustDir':  10.0, 'windrun': None, 'windSpeed': 2.0}]

        wind_fields = [
            '2m.wind.avg',
            '2m.wind.rms',
            '2m.wind.max',
            '2m.wind.maxtime.raw',
            '2m.wind.min',
            '2m.wind.mintime.raw',
            '2m.wind.vecdir',
            '2m.windSpeed.avg',
            '2m.windSpeed.max',
            '2m.windSpeed.maxtime.raw',
            '2m.windSpeed.min',
            '2m.windSpeed.mintime.raw',
            '2m.windDir.avg',
            '2m.windGust.max',
            '2m.windGust.max.formatted',
            '2m.windGust.max.raw',
            '2m.windGust.maxtime',
            '2m.windGust.maxtime.raw',
            'day.wind.avg',
            'day.wind.rms',
            'day.wind.max',
            'day.wind.maxtime.raw',
            'day.wind.min',
            'day.wind.mintime.raw',
            'day.wind.vecdir',
            'day.windSpeed.avg',
            'day.windSpeed.max',
            'day.windSpeed.maxtime.raw',
            'day.windSpeed.min',
            'day.windSpeed.mintime.raw',
            'day.windDir.avg',
            'day.windGust.max',
            'day.windGust.max.formatted',
            'day.windGust.max.raw',
            'day.windGust.maxtime',
            'day.windGust.maxtime.raw',
            'current.dateTime.raw',
            'current.dateTime',
            'current.windSpeed',
            'current.windDir',
            'current.windDir.ordinal_compass',
            'unit.label.wind',
            'unit.label.windDir',
            'unit.label.windSpeed']

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, wind_fields)

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])
        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1665796971)
        self.assertEqual(loopdata_pkt['current.dateTime'], '10/14/22 18:22:51')

        self.assertEqual(loopdata_pkt['2m.wind.vecdir'], '2°')
        self.assertEqual(loopdata_pkt['2m.windDir.avg'], '123°')  # A bogus value, which is why we need to use wind.vecdir.

        self.assertEqual(loopdata_pkt['2m.wind.avg'], '3 mph')
        self.assertEqual(loopdata_pkt['2m.wind.rms'], '3 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.avg'], '3 mph')

        self.assertEqual(loopdata_pkt['2m.wind.min'], '2 mph')
        self.assertEqual(loopdata_pkt['2m.wind.mintime.raw'], 1665796971)
        self.assertEqual(loopdata_pkt['2m.wind.max'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.wind.maxtime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.windSpeed.min'], '2 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.mintime.raw'], 1665796971)
        self.assertEqual(loopdata_pkt['2m.windSpeed.max'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.maxtime.raw'], 1665796967)

        # Repeat same with day.
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '2°')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '123°')  # A bogus value, which is why we need to use wind.vecdir.

        self.assertEqual(loopdata_pkt['day.wind.avg'], '3 mph')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '3 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '3 mph')

        self.assertEqual(loopdata_pkt['day.wind.min'], '2 mph')
        self.assertEqual(loopdata_pkt['day.wind.mintime.raw'], 1665796971)
        self.assertEqual(loopdata_pkt['day.wind.max'], '4 mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '2 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.mintime.raw'], 1665796971)
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '4 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.maxtime.raw'], 1665796967)

    def test_wind2(self) -> None:

        pkts: List[Dict[str, Any]] = [ {'dateTime': 1665796967, 'usUnits': 1, 'windDir': 355.0, 'windGust': 4.0, 'windGustDir': 355.0, 'windrun': None, 'windSpeed': 4.0},
                 {'dateTime': 1665796969, 'usUnits': 1, 'windDir':   5.0, 'windGust': 100.0, 'windGustDir':   5.0, 'windrun': None, 'windSpeed': 100.0}]

        wind_fields = [
            '2m.wind.avg',
            '2m.wind.rms',
            '2m.wind.max',
            '2m.wind.maxtime.raw',
            '2m.wind.min',
            '2m.wind.mintime.raw',
            '2m.wind.vecdir',
            '2m.windSpeed.avg',
            '2m.windSpeed.max',
            '2m.windSpeed.maxtime.raw',
            '2m.windSpeed.min',
            '2m.windSpeed.mintime.raw',
            '2m.windDir.avg',
            '2m.windGust.max',
            '2m.windGust.max.formatted',
            '2m.windGust.max.raw',
            '2m.windGust.maxtime',
            '2m.windGust.maxtime.raw',
            'day.wind.avg',
            'day.wind.rms',
            'day.wind.max',
            'day.wind.maxtime.raw',
            'day.wind.min',
            'day.wind.mintime.raw',
            'day.wind.vecdir',
            'day.windSpeed.avg',
            'day.windSpeed.max',
            'day.windSpeed.maxtime.raw',
            'day.windSpeed.min',
            'day.windSpeed.mintime.raw',
            'day.windDir.avg',
            'day.windGust.max',
            'day.windGust.max.formatted',
            'day.windGust.max.raw',
            'day.windGust.maxtime',
            'day.windGust.maxtime.raw',
            'current.dateTime.raw',
            'current.dateTime',
            'current.windSpeed',
            'current.windDir',
            'current.windDir.ordinal_compass',
            'unit.label.wind',
            'unit.label.windDir',
            'unit.label.windSpeed']

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, wind_fields)

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])
        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1665796969)
        self.assertEqual(loopdata_pkt['current.dateTime'], '10/14/22 18:22:49')

        self.assertEqual(loopdata_pkt['2m.wind.vecdir'], '5°')
        self.assertEqual(loopdata_pkt['2m.windDir.avg'], '180°')  # A bogus value, which is why we need to use wind.vecdir.

        self.assertEqual(loopdata_pkt['2m.wind.avg'], '52 mph')
        self.assertEqual(loopdata_pkt['2m.wind.rms'], '71 mph')   # RMS is a better 'average' than average
        self.assertEqual(loopdata_pkt['2m.windSpeed.avg'], '52 mph')

        self.assertEqual(loopdata_pkt['2m.wind.min'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.wind.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.wind.max'], '100 mph')
        self.assertEqual(loopdata_pkt['2m.wind.maxtime.raw'], 1665796969)
        self.assertEqual(loopdata_pkt['2m.windSpeed.min'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.windSpeed.max'], '100 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.maxtime.raw'], 1665796969)

        # Repeat same with day.
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '5°')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '180°')  # A bogus value, which is why we need to use wind.vecdir.

        self.assertEqual(loopdata_pkt['day.wind.avg'], '52 mph')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '71 mph')   # RMS is a better 'average' than average
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '52 mph')

        self.assertEqual(loopdata_pkt['day.wind.min'], '4 mph')
        self.assertEqual(loopdata_pkt['day.wind.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.wind.max'], '100 mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime.raw'], 1665796969)
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '4 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '100 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.maxtime.raw'], 1665796969)

    def test_wind_rms(self) -> None:

        pkts: List[Dict[str, Any]] = [ {'dateTime': 1665796967, 'usUnits': 1, 'windGust': 0.0, 'windSpeed': 0.0},
                 {'dateTime': 1665796969, 'usUnits': 1, 'windDir':   5.0, 'windGust': 200.0, 'windGustDir':   5.0, 'windrun': None, 'windSpeed': 200.0}]

        wind_fields = [
            '2m.wind.avg',
            '2m.wind.rms',
            '2m.wind.max',
            '2m.wind.maxtime.raw',
            '2m.wind.min',
            '2m.wind.mintime.raw',
            '2m.wind.vecdir',
            '2m.windSpeed.avg',
            '2m.windSpeed.max',
            '2m.windSpeed.maxtime.raw',
            '2m.windSpeed.min',
            '2m.windSpeed.mintime.raw',
            '2m.windDir.avg',
            '2m.windGust.max',
            '2m.windGust.max.formatted',
            '2m.windGust.max.raw',
            '2m.windGust.maxtime',
            '2m.windGust.maxtime.raw',
            'day.wind.avg',
            'day.wind.rms',
            'day.wind.max',
            'day.wind.maxtime.raw',
            'day.wind.min',
            'day.wind.mintime.raw',
            'day.wind.vecdir',
            'day.windSpeed.avg',
            'day.windSpeed.max',
            'day.windSpeed.maxtime.raw',
            'day.windSpeed.min',
            'day.windSpeed.mintime.raw',
            'day.windDir.avg',
            'day.windGust.max',
            'day.windGust.max.formatted',
            'day.windGust.max.raw',
            'day.windGust.maxtime',
            'day.windGust.maxtime.raw',
            'current.dateTime.raw',
            'current.dateTime',
            'current.windSpeed',
            'current.windDir',
            'current.windDir.ordinal_compass',
            'unit.label.wind',
            'unit.label.windDir',
            'unit.label.windSpeed']

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, wind_fields)

        pkt: Dict[str, Any] = pkts[0]
        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkt['dateTime'])
        loopdata_pkt: Dict[str, Any] = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1665796967, 'usUnits': 1, 'windGust': 0.0, 'windSpeed': 0.0}
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['current.dateTime'], '10/14/22 18:22:47')

        self.assertFalse('2m.wind.vecdir' in loopdata_pkt)
        self.assertFalse('2m.windDir.avg' in loopdata_pkt)

        self.assertEqual(loopdata_pkt['2m.wind.avg'], '0 mph')
        self.assertEqual(loopdata_pkt['2m.wind.rms'], '0 mph')   # RMS is a better 'average' than average
        self.assertEqual(loopdata_pkt['2m.windSpeed.avg'], '0 mph')

        self.assertEqual(loopdata_pkt['2m.wind.min'], '0 mph')
        self.assertEqual(loopdata_pkt['2m.wind.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.wind.max'], '0 mph')
        self.assertEqual(loopdata_pkt['2m.wind.maxtime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.windSpeed.min'], '0 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.windSpeed.max'], '0 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.maxtime.raw'], 1665796967)

        # Repeat for day.
        self.assertFalse('day.wind.vecdir' in loopdata_pkt)
        self.assertFalse('day.windDir.avg' in loopdata_pkt)

        self.assertEqual(loopdata_pkt['day.wind.avg'], '0 mph')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '0 mph')   # RMS is a better 'average' than average
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '0 mph')

        self.assertEqual(loopdata_pkt['day.wind.min'], '0 mph')
        self.assertEqual(loopdata_pkt['day.wind.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.wind.max'], '0 mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '0 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '0 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.maxtime.raw'], 1665796967)

        pkt = pkts[1]
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1665796967, 'usUnits': 1, 'windGust': 0.0, 'windSpeed': 0.0}
        # {'dateTime': 1665796969, 'usUnits': 1, 'windDir':   5.0, 'windGust': 200.0, 'windGustDir':   5.0, 'windrun': None, 'windSpeed': 200.0}
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1665796969)
        self.assertEqual(loopdata_pkt['current.dateTime'], '10/14/22 18:22:49')

        self.assertEqual(loopdata_pkt['2m.wind.vecdir'], '5°')
        self.assertEqual(loopdata_pkt['2m.windDir.avg'], '5°')

        self.assertEqual(loopdata_pkt['2m.wind.avg'], '100 mph')
        self.assertEqual(loopdata_pkt['2m.wind.rms'], '141 mph')   # RMS is a better 'average' than average
        self.assertEqual(loopdata_pkt['2m.windSpeed.avg'], '100 mph')

        self.assertEqual(loopdata_pkt['2m.wind.min'], '0 mph')
        self.assertEqual(loopdata_pkt['2m.wind.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.wind.max'], '200 mph')
        self.assertEqual(loopdata_pkt['2m.wind.maxtime.raw'], 1665796969)
        self.assertEqual(loopdata_pkt['2m.windSpeed.min'], '0 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['2m.windSpeed.max'], '200 mph')
        self.assertEqual(loopdata_pkt['2m.windSpeed.maxtime.raw'], 1665796969)

        # Repeat for day.
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '5°')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '5°')

        self.assertEqual(loopdata_pkt['day.wind.avg'], '100 mph')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '141 mph')   # RMS is a better 'average' than average
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '100 mph')

        self.assertEqual(loopdata_pkt['day.wind.min'], '0 mph')
        self.assertEqual(loopdata_pkt['day.wind.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.wind.max'], '200 mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime.raw'], 1665796969)
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '0 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.mintime.raw'], 1665796967)
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '200 mph')
        self.assertEqual(loopdata_pkt['day.windSpeed.maxtime.raw'], 1665796969)

    def test_day_wind_vecdir_vecavg(self) -> None:
        # Validate that the day accumulator's vector direction and vector
        # average are computed correctly (true vector math), independent of
        # any continuous/rolling accumulator.  The expected values are computed
        # by hand from the textbook formula and asserted against loopdata's
        # output, so this test catches any regression in the vector sum:
        #
        #   For each obs (speed, dirN), with math angle theta = radians(90 - dirN):
        #       xsum += weight * speed * cos(theta)
        #       ysum += weight * speed * sin(theta)
        #   vec_dir = (90 - degrees(atan2(ysum, xsum))) mod 360
        #   vec_avg = sqrt(xsum^2 + ysum^2) / sumtime
        #
        # The chosen sequence has a vec_dir (~10.29 deg) that is wildly
        # different from the naive scalar average of the directions (144 deg),
        # and a vec_avg (~13.89 mph) different from the scalar speed average
        # (15 mph), so a broken implementation cannot pass by coincidence.
        #
        # NOTE: weight (loop_frequency) cancels out of both results -- it
        # scales xsum/ysum equally (vec_dir is the angle, scale-invariant) and
        # is divided back out of vec_avg via sumtime -- so these expectations
        # hold regardless of the configured loop_frequency.
        import math

        pkts: List[Dict[str, Any]] = [
            {'dateTime': 1665796961, 'usUnits': 1, 'windDir': 350.0, 'windGust': 10.0, 'windGustDir': 350.0, 'windrun': None, 'windSpeed': 10.0},
            {'dateTime': 1665796963, 'usUnits': 1, 'windDir':  20.0, 'windGust': 20.0, 'windGustDir':  20.0, 'windrun': None, 'windSpeed': 20.0},
            {'dateTime': 1665796965, 'usUnits': 1, 'windDir':  40.0, 'windGust': 10.0, 'windGustDir':  40.0, 'windrun': None, 'windSpeed': 10.0},
            {'dateTime': 1665796967, 'usUnits': 1, 'windDir':  10.0, 'windGust': 30.0, 'windGustDir':  10.0, 'windrun': None, 'windSpeed': 30.0},
            {'dateTime': 1665796969, 'usUnits': 1, 'windDir': 300.0, 'windGust':  5.0, 'windGustDir': 300.0, 'windrun': None, 'windSpeed':  5.0}]

        wind_fields = [
            'day.wind.vecdir',
            'day.wind.vecdir.raw',
            'day.wind.vecavg',
            'day.wind.vecavg.raw',
            'day.windDir.avg']

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, wind_fields)

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])
        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # --- Compute the expected values by hand from the same inputs. ---
        weight = cfg.loop_frequency  # cancels out, but use the real value for fidelity
        xsum = ysum = sumtime = 0.0
        for pkt in pkts:
            speed = pkt['windSpeed']
            dirN = pkt['windDir']
            theta = math.radians(90.0 - dirN)
            xsum += weight * speed * math.cos(theta)
            ysum += weight * speed * math.sin(theta)
            sumtime += weight
        expected_vecdir = 90.0 - math.degrees(math.atan2(ysum, xsum))
        if expected_vecdir < 0.0:
            expected_vecdir += 360.0
        expected_vecavg = math.sqrt(xsum ** 2 + ysum ** 2) / sumtime

        # Sanity: these expectations are the ones computed offline (~10.29, ~13.89).
        self.assertAlmostEqual(expected_vecdir, 10.2922352167, places=6)
        self.assertAlmostEqual(expected_vecavg, 13.8928679139, places=6)

        # --- Assert loopdata's day accumulator matches the hand calculation. ---
        self.assertAlmostEqual(loopdata_pkt['day.wind.vecdir.raw'], expected_vecdir, places=4)
        self.assertAlmostEqual(loopdata_pkt['day.wind.vecavg.raw'], expected_vecavg, places=4)

        # The vector direction (~10 deg) must NOT collapse to the bogus scalar
        # average of directions (144 deg); windDir.avg is the scalar mean and
        # is exactly why wind.vecdir exists.  Confirm they differ markedly.
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '10°')
        self.assertNotEqual(loopdata_pkt['day.wind.vecdir'], loopdata_pkt['day.windDir.avg'])

        # Formatted vector average rounds to 14 mph (13.89 -> 14).
        self.assertEqual(loopdata_pkt['day.wind.vecavg'], '14 mph')

    def test_continuous_wind_vecdir_expiry(self) -> None:
        # Validate the CONTINUOUS (rolling) wind accumulator's vector math
        # across window expiry.  This is the path that the sign fix in
        # ContinuousVecStats.trimExpiredEntries (xsum/ysum debit) and the
        # dirsumtime debit live in: when an observation ages out of the
        # rolling window, its full vector contribution must be SUBTRACTED.
        #
        # A '2m' tag has timelength = 120s.  A packet added at ts expires once
        # a later packet arrives at ts + 120 or beyond (trim condition is
        # debit.expiration <= current_ts, expiration = ts + timelength).
        #
        # Timeline (ts, windSpeed, windDir):
        #     1000  10  200   <- expires by ts=1160 (1000+120=1120 <= 1160)
        #     1030  10  250   <- expires by ts=1160 (1030+120=1150 <= 1160)
        #     1160  10  350   <- survivor
        #     1180  10   10   <- survivor
        #     1200  10   30   <- survivor (last packet)
        #
        # The window is walked through fill -> expire -> refill, and vecdir is
        # asserted at three stages.  The progression 225 -> 350 -> 10 degrees
        # is only producible if expired contributions are correctly removed.
        # (With the old '+=' trim bug, the final vecdir would be ~277.5 deg,
        # a 267-degree error -- so this test discriminates strongly.)
        import math

        pkts: List[Dict[str, Any]] = [
            {'dateTime': 1000, 'usUnits': 1, 'windDir': 200.0, 'windGust': 10.0, 'windGustDir': 200.0, 'windrun': None, 'windSpeed': 10.0},
            {'dateTime': 1030, 'usUnits': 1, 'windDir': 250.0, 'windGust': 10.0, 'windGustDir': 250.0, 'windrun': None, 'windSpeed': 10.0},
            {'dateTime': 1160, 'usUnits': 1, 'windDir': 350.0, 'windGust': 10.0, 'windGustDir': 350.0, 'windrun': None, 'windSpeed': 10.0},
            {'dateTime': 1180, 'usUnits': 1, 'windDir':  10.0, 'windGust': 10.0, 'windGustDir':  10.0, 'windrun': None, 'windSpeed': 10.0},
            {'dateTime': 1200, 'usUnits': 1, 'windDir':  30.0, 'windGust': 10.0, 'windGustDir':  30.0, 'windrun': None, 'windSpeed': 10.0}]

        wind_fields = [
            '2m.wind.vecdir',
            '2m.wind.vecdir.raw',
            '2m.wind.vecavg',
            '2m.wind.vecavg.raw']

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, wind_fields)
        weight = cfg.loop_frequency

        def hand_vec(survivors):
            # survivors: list of (windSpeed, windDir)
            xsum = ysum = sumtime = 0.0
            for speed, dirN in survivors:
                theta = math.radians(90.0 - dirN)
                xsum += weight * speed * math.cos(theta)
                ysum += weight * speed * math.sin(theta)
                sumtime += weight
            vec_dir = 90.0 - math.degrees(math.atan2(ysum, xsum))
            if vec_dir < 0.0:
                vec_dir += 360.0
            vec_avg = math.sqrt(xsum ** 2 + ysum ** 2) / sumtime
            return vec_dir, vec_avg

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])

        # Packet 1 (ts=1000): only the 200-degree obs is present.
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkts[0], cfg, accums)

        # Packet 2 (ts=1030): both 200 and 250 live; nothing expired yet.
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkts[1], cfg, accums)
        vd, va = hand_vec([(10.0, 200.0), (10.0, 250.0)])
        self.assertAlmostEqual(vd, 225.0, places=4)  # offline-computed checkpoint
        self.assertAlmostEqual(loopdata_pkt['2m.wind.vecdir.raw'], vd, places=4)
        self.assertAlmostEqual(loopdata_pkt['2m.wind.vecavg.raw'], va, places=4)

        # Packet 3 (ts=1160): 1000 (exp 1120) and 1030 (exp 1150) have both
        # expired (<= 1160); only the 350-degree obs survives.
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkts[2], cfg, accums)
        vd, va = hand_vec([(10.0, 350.0)])
        self.assertAlmostEqual(vd, 350.0, places=4)
        self.assertAlmostEqual(loopdata_pkt['2m.wind.vecdir.raw'], vd, places=4)
        self.assertAlmostEqual(loopdata_pkt['2m.wind.vecavg.raw'], va, places=4)

        # Packets 4 and 5 (ts=1180, 1200): window now holds 350, 10, 30.
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkts[3], cfg, accums)
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkts[4], cfg, accums)
        vd, va = hand_vec([(10.0, 350.0), (10.0, 10.0), (10.0, 30.0)])
        self.assertAlmostEqual(vd, 10.0, places=4)  # offline-computed checkpoint
        self.assertAlmostEqual(va, 9.5979508052, places=6)
        self.assertAlmostEqual(loopdata_pkt['2m.wind.vecdir.raw'], vd, places=4)
        self.assertAlmostEqual(loopdata_pkt['2m.wind.vecavg.raw'], va, places=4)

    def test_min_max_dict(self) -> None:
        # Direct unit tests for MinMaxDict, the two-heap lazy-deletion mapping
        # behind the continuous accumulators.  Expected values are computed
        # from first principles (a shadow dict with min()/max() as the
        # oracle), not from loopdata output.
        MMD = user.loopdata.MinMaxDict

        # --- Empty: peekitem raises IndexError, like any empty container. ---
        d = MMD()
        self.assertEqual(len(d), 0)
        self.assertNotIn(1.0, d)
        with self.assertRaises(IndexError):
            d.peekitem(0)
        with self.assertRaises(IndexError):
            d.peekitem(-1)

        # --- Only the two end indexes are supported. ---
        d[1.0] = 'one'
        with self.assertRaises(IndexError):
            d.peekitem(1)
        with self.assertRaises(IndexError):
            d.peekitem(-2)

        # --- Basic get/set/pop; overwriting an existing key is not a new key. ---
        self.assertIn(1.0, d)
        self.assertEqual(d[1.0], 'one')
        d[1.0] = 'uno'
        self.assertEqual(d[1.0], 'uno')
        self.assertEqual(len(d), 1)
        self.assertEqual(d.peekitem(0), (1.0, 'uno'))
        self.assertEqual(d.peekitem(-1), (1.0, 'uno'))
        self.assertEqual(d.pop(1.0), 'uno')
        self.assertEqual(len(d), 0)
        with self.assertRaises(IndexError):
            d.peekitem(0)

        # --- Long stale chains: peekitem must skim dead heap entries.  Kill
        #     the 999 smallest keys, so the min-heap top is 999 dead entries
        #     deep; then the symmetric case for the max-heap. ---
        d = MMD()
        for i in range(1000):
            d[float(i)] = i
        for i in range(999):
            d.pop(float(i))
        self.assertEqual(d.peekitem(0), (999.0, 999))
        self.assertEqual(d.peekitem(-1), (999.0, 999))
        d = MMD()
        for i in range(1000):
            d[float(i)] = i
        for i in range(1, 1000):
            d.pop(float(i))
        self.assertEqual(d.peekitem(-1), (0.0, 0))
        self.assertEqual(d.peekitem(0), (0.0, 0))

        # --- Re-adding a dead key leaves duplicate heap entries; peeks must
        #     stay correct through kill/revive cycles and after final death. ---
        d = MMD()
        d[5.0] = 'a'
        for marker in ('b', 'c', 'd'):
            d.pop(5.0)
            d[5.0] = marker
            self.assertEqual(d.peekitem(0), (5.0, marker))
            self.assertEqual(d.peekitem(-1), (5.0, marker))
        d[7.0] = 'hi'
        d.pop(5.0)
        self.assertEqual(d.peekitem(0), (7.0, 'hi'))
        self.assertEqual(d.peekitem(-1), (7.0, 'hi'))

        # --- Randomized differential fuzz against the shadow dict.  Narrow
        #     key ranges force constant key death and revival (duplicate heap
        #     entries); wide ranges force churn and compaction.  Values are
        #     mutable lists appended to in place, mirroring how the
        #     accumulators use the timestamp deques. ---
        rand = random.Random(20260711)
        for key_range, n_ops in ((5, 20000), (40, 20000), (1000, 12000)):
            d = MMD()
            shadow: Dict[float, List[int]] = {}
            for op in range(n_ops):
                key = float(rand.randrange(key_range))
                r = rand.random()
                if r < 0.50:
                    if key not in d:
                        self.assertNotIn(key, shadow)
                        d[key] = []
                        shadow[key] = d[key]  # same object in both
                    d[key].append(op)
                elif shadow:
                    victim = rand.choice(list(shadow))
                    self.assertIs(d.pop(victim), shadow.pop(victim))
                self.assertEqual(len(d), len(shadow))
                if shadow:
                    mn, mx = min(shadow), max(shadow)
                    self.assertEqual(d.peekitem(0), (mn, shadow[mn]))
                    self.assertEqual(d.peekitem(-1), (mx, shadow[mx]))
            # The heaps are rebuilt whenever an insert leaves them holding
            # more than twice the live keys, so right after an insert they
            # are bounded.  (Pops don't shrink them, so insert one key to
            # re-establish the bound before checking.)
            d[float(key_range)] = []
            self.assertLessEqual(len(d._min_heap), 2 * len(d) + 16)
            self.assertLessEqual(len(d._max_heap), 2 * len(d) + 16)

    def test_continuous_scalar_stats_edge_cases(self) -> None:
        # Direct unit tests for ContinuousScalarStats accessors, focused on the
        # empty-accumulator branches and the None/NaN rejection path in addSum.
        CS = user.loopdata.ContinuousScalarStats

        # --- Empty accumulator: every accessor degrades gracefully. ---
        s = CS(timelength=120)
        self.assertIsNone(s.first)
        self.assertIsNone(s.firsttime)
        self.assertIsNone(s.last)
        self.assertIsNone(s.lasttime)
        self.assertIsNone(s.avg)            # count is 0 -> None
        # getStatsTuple on empty: min/mintime/max/maxtime are None; the numeric
        # fields are zero (sum/wsum massaged to 0.0, count 0, sumtime 0.0).
        self.assertEqual(s.getStatsTuple(), (None, None, None, None, 0.0, 0, 0.0, 0.0))

        # --- One value (ts=100, val=5.0, weight=2). ---
        s.addSum(100, 5.0, weight=2)
        self.assertEqual(s.first, 5.0)
        self.assertEqual(s.firsttime, 100)
        self.assertEqual(s.last, 5.0)
        self.assertEqual(s.lasttime, 100)
        self.assertAlmostEqual(s.avg, 5.0)  # wsum/sumtime = 10/2
        self.assertEqual(s.getStatsTuple(), (5.0, 100, 5.0, 100, 5.0, 1, 10.0, 2))

        # --- None / NaN / non-numeric are rejected by addSum (no state change). ---
        s.addSum(110, None, weight=2)
        s.addSum(120, float('nan'), weight=2)
        s.addSum(130, 'not-a-number', weight=2)
        # Still exactly the single value from before.
        self.assertEqual(s.getStatsTuple(), (5.0, 100, 5.0, 100, 5.0, 1, 10.0, 2))
        self.assertEqual(s.lasttime, 100)

        # --- A second, larger value updates min/max ordering and last. ---
        s.addSum(140, 9.0, weight=2)
        mn, mntime, mx, mxtime, ssum, scount, swsum, ssumtime = s.getStatsTuple()
        self.assertEqual(mn, 5.0)
        self.assertEqual(mx, 9.0)
        self.assertEqual(scount, 2)
        self.assertEqual(s.last, 9.0)
        self.assertEqual(s.lasttime, 140)

    def test_continuous_vec_stats_edge_cases(self) -> None:
        # Direct unit tests for ContinuousVecStats accessors, focused on the
        # empty-accumulator branches (including the maxdir slot that must be
        # None when empty), the calm-wind (dirN is None, speed 0) path in
        # addSum, and that 'first' reports the FIRST observation's direction.
        CV = user.loopdata.ContinuousVecStats

        # --- Empty accumulator. ---
        v = CV(timelength=120)
        self.assertIsNone(v.first)
        self.assertIsNone(v.firsttime)
        self.assertIsNone(v.last)
        self.assertIsNone(v.lasttime)
        self.assertIsNone(v.avg)
        self.assertIsNone(v.rms)
        self.assertIsNone(v.vec_avg)
        self.assertIsNone(v.vec_dir)        # empty -> last is None -> None
        # getStatsTuple on empty must not raise; the maxdir slot (index 8) is
        # None (regression guard: it was previously an unbound local).
        st = v.getStatsTuple()
        self.assertEqual(len(st), 14)
        self.assertEqual(st[0:4], (None, None, None, None))  # min,mintime,max,maxtime
        self.assertEqual(st[5], 0)                            # count
        self.assertIsNone(st[8])                              # maxdir

        # --- Calm wind: speed 0 with dirN None is accepted (dirsumtime path). ---
        v.addSum(100, (0.0, None), weight=2)
        self.assertEqual(v.count, 1)
        self.assertEqual(v.first, (0.0, None))
        self.assertEqual(v.last, (0.0, None))

        # --- Two observations with DIFFERENT directions: 'first' must report
        # the first observation's direction, 'last' the last's. ---
        v2 = CV(timelength=120)
        v2.addSum(200, (10.0, 90.0), weight=2)    # first: East
        v2.addSum(210, (10.0, 270.0), weight=2)   # last: West
        self.assertEqual(v2.first, (10.0, 90.0))  # regression guard for the
                                                  # first-direction index fix
        self.assertEqual(v2.last, (10.0, 270.0))
        self.assertEqual(v2.firsttime, 200)
        self.assertEqual(v2.lasttime, 210)

        # --- None speed is rejected by addSum (no state change). ---
        before = v2.count
        v2.addSum(220, (None, 45.0), weight=2)
        self.assertEqual(v2.count, before)

        # --- Non-numeric speed: to_float raises -> speed becomes None ->
        # the whole observation is rejected (covers the except ValueError path
        # for speed). ---
        v3 = CV(timelength=120)
        v3.addSum(300, ('not-a-number', 45.0), weight=2)
        self.assertEqual(v3.count, 0)

        # --- Non-numeric dirN with valid speed: to_float(dirN) raises -> dirN
        # becomes None, but the speed is still recorded (covers the except
        # ValueError path for dirN, and the dirN-is-None branch with nonzero
        # speed where xsum/ysum are NOT updated). ---
        v4 = CV(timelength=120)
        v4.addSum(310, (10.0, 'bad-dir'), weight=2)
        self.assertEqual(v4.count, 1)
        self.assertEqual(v4.xsum, 0.0)   # no direction -> no vector components
        self.assertEqual(v4.ysum, 0.0)
        self.assertEqual(v4.last, (10.0, None))

    def test_continuous_vec_stats_trim_debits_every_field(self) -> None:
        # trimExpiredEntries must DEBIT every running sum by exactly the
        # contribution of each expired observation -- it is the precise inverse
        # of addSum.  This test pins each debited field to an independently
        # hand-computed post-trim value, so that flipping any '-=' to '+=' (or
        # otherwise corrupting a debit) is detected.  Mutation testing showed
        # these debits were previously unasserted (the original vecdir bug lived
        # in exactly this trim arithmetic).
        CV = user.loopdata.ContinuousVecStats

        v = CV(timelength=100)
        # Three observations, weight 2 each, at 90 deg apart so x/y components
        # are clean: (10, E), (20, S), (30, W).  Expirations: 200, 250, 300.
        v.addSum(100, (10.0, 90.0), weight=2)    # East
        v.addSum(150, (20.0, 180.0), weight=2)   # South
        v.addSum(200, (30.0, 270.0), weight=2)   # West

        # Sanity: full state before trimming (independently computed).
        self.assertEqual(v.sum, 60.0)
        self.assertEqual(v.count, 3)
        self.assertEqual(v.wsum, 120.0)
        self.assertEqual(v.sumtime, 6.0)
        self.assertEqual(v.squaresum, 1400.0)
        self.assertEqual(v.wsquaresum, 2800.0)
        self.assertEqual(v.dirsumtime, 6)

        # Trim at ts=205: only the first debit (expiration 200 <= 205) matures.
        v.trimExpiredEntries(205)

        # Every field must be debited by exactly the East observation's
        # contribution.  Values hand-computed, independent of the implementation.
        self.assertEqual(v.sum, 50.0)          # 60 - 10
        self.assertEqual(v.count, 2)           # 3 - 1
        self.assertEqual(v.wsum, 100.0)        # 120 - 2*10
        self.assertEqual(v.sumtime, 4.0)       # 6 - 2
        self.assertEqual(v.squaresum, 1300.0)  # 1400 - 10**2
        self.assertEqual(v.wsquaresum, 2600.0) # 2800 - 2*10**2
        self.assertEqual(v.dirsumtime, 4)      # 6 - 2  (the dirsumtime debit fix)
        # East (90 deg) contributes only to xsum (cos), nothing to ysum (sin=0).
        # So trimming it changes xsum but leaves ysum unchanged -- this pins the
        # CONDITIONAL x/y debits independently.
        self.assertAlmostEqual(v.xsum, -60.0, places=6)
        self.assertAlmostEqual(v.ysum, -40.0, places=6)

        # The expired entry must also be removed from speed_dict (speed 10 gone).
        self.assertNotIn(10.0, v.speed_dict)
        self.assertIn(20.0, v.speed_dict)
        self.assertIn(30.0, v.speed_dict)

    def test_continuous_vec_stats_trim_boundary_and_calm(self) -> None:
        # Companion to the trim-debits test, targeting three branches the first
        # one cannot reach:
        #  (1) the expiration boundary -- a debit at EXACTLY its expiration ts
        #      must mature (expiration <= ts is inclusive);
        #  (2) the ysum debit -- trimming an observation with a non-zero
        #      y-component must change ysum (the East obs used elsewhere has
        #      zero y, so it cannot pin this line);
        #  (3) the calm-wind branch (dirN is None and speed 0) -- dirsumtime is
        #      credited on add and must be debited on trim.
        CV = user.loopdata.ContinuousVecStats

        # --- (1) + (2): trim a SOUTH observation (pure -y) at exactly its
        # expiration. ---
        v = CV(timelength=100)
        v.addSum(100, (20.0, 180.0), weight=2)   # South: ysum=-40, xsum~0
        v.addSum(150, (30.0, 270.0), weight=2)   # West:  xsum=-60, ysum~0
        self.assertAlmostEqual(v.ysum, -40.0, places=6)

        # Trim at EXACTLY the first debit's expiration (100 + 100 = 200).  The
        # inclusive boundary (expiration <= ts) means it matures.
        v.trimExpiredEntries(200)
        self.assertEqual(v.count, 1)             # boundary debit did mature
        self.assertAlmostEqual(v.ysum, 0.0, places=6)   # South's -y removed
        self.assertAlmostEqual(v.xsum, -60.0, places=6) # West's x remains

        # --- (3): calm wind (speed 0, dirN None) credits then debits
        # dirsumtime via the 'or speed == 0' branch. ---
        c = CV(timelength=100)
        c.addSum(100, (0.0, None), weight=2)
        self.assertEqual(c.dirsumtime, 2)        # credited despite dirN None
        self.assertEqual(c.count, 1)
        c.trimExpiredEntries(200)                # expiration 200 <= 200 -> trim
        self.assertEqual(c.dirsumtime, 0)        # debited back to zero
        self.assertEqual(c.count, 0)

    def test_continuous_scalar_stats_sums_and_trim(self) -> None:
        # Pins every running-sum field of ContinuousScalarStats across addSum
        # (credits) and trimExpiredEntries (debits), with independently
        # hand-computed values, so a flipped +=/-= or wrong factor is detected.
        CS = user.loopdata.ContinuousScalarStats

        s = CS(timelength=100)
        s.addSum(100, 10.0, weight=2)
        s.addSum(150, 20.0, weight=2)
        s.addSum(200, 30.0, weight=2)
        # After three adds (independently computed).
        self.assertEqual(s.sum, 60.0)
        self.assertEqual(s.count, 3)
        self.assertEqual(s.wsum, 120.0)
        self.assertEqual(s.sumtime, 6.0)
        self.assertAlmostEqual(s.avg, 20.0)        # wsum/sumtime = 120/6

        # Trim at 205: only the first debit (expiration 200) matures.
        s.trimExpiredEntries(205)
        self.assertEqual(s.sum, 50.0)              # 60 - 10
        self.assertEqual(s.count, 2)               # 3 - 1
        self.assertEqual(s.wsum, 100.0)            # 120 - 10*2
        self.assertEqual(s.sumtime, 4.0)           # 6 - 2
        self.assertAlmostEqual(s.avg, 25.0)        # 100/4
        # values_dict cleanup: the trimmed value's key is removed.
        self.assertNotIn(10.0, s.values_dict)
        self.assertIn(20.0, s.values_dict)

    def test_continuous_vec_stats_addsum_credits(self) -> None:
        # Pins every running-sum field credited by ContinuousVecStats.addSum
        # (the inverse of the trim debits), with hand-computed values.  Uses
        # three observations 90 deg apart so x and y components are cleanly
        # separable -- which also pins the xsum (cos) and ysum (sin) lines
        # independently (a mutation to either must change a distinct field).
        CV = user.loopdata.ContinuousVecStats

        v = CV(timelength=100)
        v.addSum(100, (10.0, 90.0), weight=2)    # East:  +x only
        v.addSum(150, (20.0, 180.0), weight=2)   # South: -y only
        v.addSum(200, (30.0, 270.0), weight=2)   # West:  -x only

        self.assertEqual(v.sum, 60.0)
        self.assertEqual(v.count, 3)
        self.assertEqual(v.wsum, 120.0)
        self.assertEqual(v.sumtime, 6.0)
        self.assertEqual(v.squaresum, 1400.0)     # 10^2+20^2+30^2
        self.assertEqual(v.wsquaresum, 2800.0)    # 2*(above)
        self.assertEqual(v.dirsumtime, 6)
        # East(+x 20) + West(-x 60) = -40; South contributes -y 40.
        self.assertAlmostEqual(v.xsum, -40.0, places=6)
        self.assertAlmostEqual(v.ysum, -40.0, places=6)

    def test_continuous_vec_stats_getstatstuple_and_accessors(self) -> None:
        # Pins the getStatsTuple massage/return slots and the derived accessors
        # (avg, rms, vec_avg, vec_dir, first, last, firsttime, lasttime) with
        # independently computed values.
        CV = user.loopdata.ContinuousVecStats

        v = CV(timelength=100)
        v.addSum(100, (10.0, 90.0), weight=2)
        v.addSum(150, (20.0, 180.0), weight=2)
        v.addSum(200, (30.0, 270.0), weight=2)

        # Accessors (hand-computed).
        self.assertAlmostEqual(v.avg, 20.0)                      # wsum/sumtime
        self.assertAlmostEqual(v.rms, 21.602468994692867, places=6)   # sqrt(2800/6)
        self.assertAlmostEqual(v.vec_avg, 9.428090415820636, places=6)
        self.assertAlmostEqual(v.vec_dir, 225.0, places=6)       # atan2(-40,-40)
        # first = first observation's (speed, dir); last = last observation's.
        self.assertEqual(v.first, (10.0, 90.0))
        self.assertEqual(v.last, (30.0, 270.0))
        self.assertEqual(v.firsttime, 100)
        self.assertEqual(v.lasttime, 200)

        # getStatsTuple slots that feed sum/wsum/sumtime/squaresum/etc.
        st = v.getStatsTuple()
        # Indices: 0 min,1 mintime,2 max,3 maxtime,4 sum,5 count,6 wsum,
        # 7 sumtime,8 maxdir,9 xsum,10 ysum,11 dirsumtime,12 squaresum,13 wsquaresum
        self.assertEqual(st[4], 60.0)    # sum
        self.assertEqual(st[5], 3)       # count
        self.assertEqual(st[6], 120.0)   # wsum
        self.assertEqual(st[7], 6.0)     # sumtime
        self.assertAlmostEqual(st[9], -40.0, places=6)   # xsum
        self.assertAlmostEqual(st[10], -40.0, places=6)  # ysum
        self.assertEqual(st[11], 6)      # dirsumtime
        self.assertEqual(st[12], 1400.0) # squaresum
        self.assertEqual(st[13], 2800.0) # wsquaresum

    def test_add_period_obstype_scalar_agg_dispatch(self) -> None:
        # Pins the scalar agg_type dispatch in add_period_obstype (each
        # agg_type must route to the CORRECT stat).  Uses a US accum and a US
        # converter so conversion is identity for outTemp (degree_F), making the
        # '.raw' values exact and independent of any skin config.  Distinct
        # min/max/sum/avg values mean swapping any two agg branches is caught.
        import weewx.units
        US = weewx.units.unit_constants['US']

        # Build a day-period scalar accum for outTemp with known records.
        span = weeutil.weeutil.TimeSpan(0, 100000000000)
        accum = weewx.accum.Accum(span, US)
        for ts, t in ((1000, 40.0), (1300, 60.0), (1600, 50.0)):
            accum.addRecord({'dateTime': ts, 'usUnits': 1, 'outTemp': t}, weight=300)

        formatter = weewx.units.Formatter()                 # default
        converter = weewx.units.Converter(weewx.units.USUnits)

        # Conversion-identity precondition: a degree_F value must pass through
        # unchanged, so the asserted '.raw' values below are exact.
        vt = weewx.units.ValueTuple(40.0, 'degree_F', 'group_temperature')
        self.assertAlmostEqual(converter.convert(vt)[0], 40.0)

        def raw_value(agg):
            cname = user.loopdata.LoopData.parse_cname('day.outTemp.%s.raw' % agg)
            self.assertIsNotNone(cname, msg='parse failed for agg %s' % agg)
            pkt = {}
            user.loopdata.LoopProcessor.add_period_obstype(
                cname, accum, pkt, converter, formatter)
            return pkt.get(cname.field)

        # Each agg_type routes its specific stat (independently hand-computed).
        self.assertAlmostEqual(raw_value('min'), 40.0)
        self.assertAlmostEqual(raw_value('max'), 60.0)
        self.assertAlmostEqual(raw_value('sum'), 150.0)
        self.assertAlmostEqual(raw_value('avg'), 50.0)
        self.assertEqual(raw_value('mintime'), 1000)
        self.assertEqual(raw_value('maxtime'), 1300)
        # count is a valid ScalarStats agg per weewx accum.py (getStatsTuple
        # slot 5); 3 records -> count 3.
        self.assertEqual(raw_value('count'), 3)
        # Distinctness guard: min and max must differ (catches min<->max swap).
        self.assertNotEqual(raw_value('min'), raw_value('max'))

    def test_add_period_obstype_vec_agg_dispatch(self) -> None:
        # Pins the VECTOR agg_type dispatch in add_period_obstype.  Builds a
        # 'wind' VecStats accum with distinct per-agg values so each agg_type
        # routes its specific slot; a swapped branch produces a different value.
        import weewx.units
        US = weewx.units.unit_constants['US']

        span = weeutil.weeutil.TimeSpan(0, 100000000000)
        accum = weewx.accum.Accum(span, US)
        # windSpeed + windDir records (no separate gust -> gust tracks speed).
        for ts, spd, d in ((1000, 3.0, 90.0), (1300, 9.0, 180.0), (1600, 6.0, 270.0)):
            accum.addRecord({'dateTime': ts, 'usUnits': 1,
                             'windSpeed': spd, 'windDir': d, 'windGust': spd,
                             'windGustDir': d}, weight=300)

        formatter = weewx.units.Formatter()
        converter = weewx.units.Converter(weewx.units.USUnits)

        def raw_value(agg):
            cname = user.loopdata.LoopData.parse_cname('day.wind.%s.raw' % agg)
            self.assertIsNotNone(cname, msg='parse failed for agg %s' % agg)
            pkt = {}
            user.loopdata.LoopProcessor.add_period_obstype(
                cname, accum, pkt, converter, formatter)
            return pkt.get(cname.field)

        # Independently computed from the records.
        self.assertAlmostEqual(raw_value('min'), 3.0)
        self.assertAlmostEqual(raw_value('max'), 9.0)
        self.assertEqual(raw_value('mintime'), 1000)
        self.assertEqual(raw_value('maxtime'), 1300)
        # count is a valid VecStats agg per weewx accum.py; 3 records -> 3.
        # (This previously could not be requested -- 'count' was missing from
        # parse_cname's valid_agg_types -- which was a bug, now fixed.)
        self.assertEqual(raw_value('count'), 3)
        self.assertAlmostEqual(raw_value('sum'), 18.0)
        self.assertAlmostEqual(raw_value('avg'), 6.0)
        self.assertAlmostEqual(raw_value('rms'), 6.480741, places=4)
        self.assertAlmostEqual(raw_value('vecavg'), 3.162278, places=4)
        self.assertAlmostEqual(raw_value('vecdir'), 198.434949, places=4)
        # gustdir == max_dir: per weewx accum.py VecStats.addHiLo, max_dir is
        # the direction recorded at the maximum speed.  Max speed 9.0 occurred
        # at dir 180.0.
        self.assertAlmostEqual(raw_value('gustdir'), 180.0)
        # Routing-distinctness guards (catch branch swaps even without pinning
        # the exact gustdir value, whose weewx semantics we don't re-derive).
        self.assertNotEqual(raw_value('min'), raw_value('max'))
        self.assertNotEqual(raw_value('avg'), raw_value('vecavg'))
        self.assertNotEqual(raw_value('mintime'), raw_value('maxtime'))

        # Empty vec accum (count == 0): the dispatch guard 'and stats.count != 0'
        # must be false, so NO value is produced for any agg.  This pins the
        # count-guard on the VecStats branch.
        empty_accum = weewx.accum.Accum(span, US)
        # Touch 'wind' so the obstype exists but has no observations.
        empty_accum.addRecord({'dateTime': 1000, 'usUnits': 1,
                               'windDir': 90.0}, weight=300)  # dir only, no speed
        cname_e = user.loopdata.LoopData.parse_cname('day.wind.max.raw')
        pkt_e = {}
        if 'wind' in empty_accum:
            user.loopdata.LoopProcessor.add_period_obstype(
                cname_e, empty_accum, pkt_e, converter, formatter)
            self.assertNotIn('day.wind.max.raw', pkt_e)  # count==0 -> no output

    def test_agg_type_grammar_is_dispatch_union(self) -> None:
        # The grammar accepts exactly the aggregates the dispatch tables
        # implement: AGG_TYPES is derived from SCALAR_AGGS/VEC_AGGS/
        # FIRSTLAST_AGGS, and parse_cname validates against AGG_TYPES.  Pin the
        # wiring: every implemented aggregate parses...
        self.assertEqual(len(user.loopdata.AGG_TYPES), 15)
        for agg in sorted(user.loopdata.AGG_TYPES):
            self.assertIsNotNone(
                user.loopdata.LoopData.parse_cname('day.outTemp.%s' % agg),
                msg='implemented aggregate %r must parse' % agg)
        # ...and plausible-but-unimplemented aggregates are rejected (guards
        # against a relaxed membership check; not_null/diff/tderiv are real
        # WeeWX aggregations that loopdata does not implement).
        for fake in ['median', 'stdev', 'not_null', 'diff', 'tderiv']:
            self.assertIsNone(
                user.loopdata.LoopData.parse_cname('day.outTemp.%s' % fake),
                msg='unimplemented aggregate %r must not parse' % fake)

    def test_agg_extractors_reference_real_slots(self) -> None:
        # Runs every extractor in the dispatch tables against populated stats
        # objects of BOTH class families (weewx.accum and Continuous*), so a
        # typo like t.maxx or s.vecdir raises here instead of silently dropping
        # a field at runtime.  Values for the weewx family are hand-computed
        # from the adds below.
        import weewx.accum
        US = weewx.units.unit_constants['US']

        # weewx family: min/max via addHiLo, sums via addSum.
        ws = weewx.accum.ScalarStats()
        ws.addHiLo(50.0, 1000)
        ws.addHiLo(80.0, 1010)
        ws.addSum(50.0)
        ws.addSum(80.0)
        wv = weewx.accum.VecStats()
        wv.addHiLo((10.0, 90.0), 1000)
        wv.addHiLo((5.0, 180.0), 1010)
        wv.addSum((10.0, 90.0))
        wv.addSum((5.0, 180.0))

        # Continuous family: same readings via ContinuousAccum.addRecord
        # (which also builds the composite 'wind' vec stats).
        cont = user.loopdata.ContinuousAccum(100000, US)
        cont.addRecord({'dateTime': 1000, 'usUnits': 1, 'outTemp': 50.0,
                        'windSpeed': 10.0, 'windDir': 90.0,
                        'windGust': 12.0, 'windGustDir': 100.0})
        cont.addRecord({'dateTime': 1010, 'usUnits': 1, 'outTemp': 80.0,
                        'windSpeed': 5.0, 'windDir': 180.0,
                        'windGust': 6.0, 'windGustDir': 190.0})
        cs = cont['outTemp']
        cv = cont['wind']
        self.assertIsInstance(cs, user.loopdata.ContinuousScalarStats)
        self.assertIsInstance(cv, user.loopdata.ContinuousVecStats)

        # Every scalar/vec extractor must run without raising on both families.
        for stats, tuple_cls, table in [
                (ws, user.loopdata.ScalarStatsTuple, user.loopdata.SCALAR_AGGS),
                (cs, user.loopdata.ScalarStatsTuple, user.loopdata.SCALAR_AGGS),
                (wv, user.loopdata.VecStatsTuple, user.loopdata.VEC_AGGS),
                (cv, user.loopdata.VecStatsTuple, user.loopdata.VEC_AGGS)]:
            t = tuple_cls(*stats.getStatsTuple())
            for agg, extractor in table.items():
                extractor(stats, t)  # must not raise

        # Spot-check hand-computed values on the weewx family (adds above:
        # scalar 50 @ 1000, 80 @ 1010; weight 1 each).
        st = user.loopdata.ScalarStatsTuple(*ws.getStatsTuple())
        self.assertAlmostEqual(user.loopdata.SCALAR_AGGS['min'](ws, st), 50.0)
        self.assertEqual(user.loopdata.SCALAR_AGGS['mintime'](ws, st), 1000)
        self.assertAlmostEqual(user.loopdata.SCALAR_AGGS['max'](ws, st), 80.0)
        self.assertEqual(user.loopdata.SCALAR_AGGS['maxtime'](ws, st), 1010)
        self.assertAlmostEqual(user.loopdata.SCALAR_AGGS['sum'](ws, st), 130.0)
        self.assertEqual(user.loopdata.SCALAR_AGGS['count'](ws, st), 2)
        self.assertAlmostEqual(user.loopdata.SCALAR_AGGS['avg'](ws, st), 65.0)
        # Vec: max speed 10 @ 1000 with dir 90 (gustdir); min speed 5 @ 1010.
        vt = user.loopdata.VecStatsTuple(*wv.getStatsTuple())
        self.assertAlmostEqual(user.loopdata.VEC_AGGS['max'](wv, vt), 10.0)
        self.assertEqual(user.loopdata.VEC_AGGS['maxtime'](wv, vt), 1000)
        self.assertAlmostEqual(user.loopdata.VEC_AGGS['gustdir'](wv, vt), 90.0)
        self.assertAlmostEqual(user.loopdata.VEC_AGGS['min'](wv, vt), 5.0)
        self.assertAlmostEqual(user.loopdata.VEC_AGGS['sum'](wv, vt), 15.0)

        # firstlast extractors, against a Continuous firstlast accum (register
        # a string obstype, mirroring test_firstlast_obstype_end_to_end).
        weewx.accum.accum_dict.extend(
            {'flType': {'accumulator': 'firstlast', 'extractor': 'last'}})
        try:
            fl_accum = user.loopdata.ContinuousAccum(100000, US)
            fl_accum.addRecord({'dateTime': 1000, 'usUnits': 1, 'flType': 'alpha'})
            fl_accum.addRecord({'dateTime': 2000, 'usUnits': 1, 'flType': 'omega'})
            fl = fl_accum['flType']
            self.assertIsInstance(fl, user.loopdata.ContinuousFirstLastAccum)
            self.assertEqual(user.loopdata.FIRSTLAST_AGGS['first'](fl, None), 'alpha')
            self.assertEqual(user.loopdata.FIRSTLAST_AGGS['last'](fl, None), 'omega')
            self.assertEqual(user.loopdata.FIRSTLAST_AGGS['firsttime'](fl, None), 1000)
            self.assertEqual(user.loopdata.FIRSTLAST_AGGS['lasttime'](fl, None), 2000)
        finally:
            # accum_dict is a ChainMap; the entry added by extend() may live in
            # a layer that does not support del by key, so guard it (same idiom
            # as the other firstlast tests).
            try:
                maps = getattr(weewx.accum.accum_dict, 'maps', [weewx.accum.accum_dict])
                for m in maps:
                    if 'flType' in m:
                        del m['flType']
            except Exception:
                pass

    def test_add_current_obstype_format_spec_dispatch(self) -> None:
        # Pins the format_spec branches of add_current_obstype: 'raw' returns
        # the numeric value; 'formatted' returns the bare formatted string;
        # 'ordinal_compass' returns a compass label; default appends the unit
        # label.  Uses the real SeasonsReport formatter (via _get_config) so
        # 'formatted' (e.g. '72.5') genuinely differs from the default
        # toString (e.g. '72.5°F') -- with a bare Formatter() they coincide and
        # the branch cannot be distinguished.
        specified_fields = ['current.outTemp', 'current.outTemp.raw',
                            'current.outTemp.formatted',
                            'current.windDir.ordinal_compass']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, specified_fields)
        converter = cfg.legacy.converter
        formatter = cfg.legacy.formatter

        pkt = {'dateTime': 1000, 'usUnits': 1, 'outTemp': 72.5, 'windDir': 90.0}

        def field_value(spec, obstype='outTemp'):
            field = ('current.%s' % obstype) if spec is None else (
                'current.%s.%s' % (obstype, spec))
            cname = user.loopdata.LoopData.parse_cname(field)
            self.assertIsNotNone(cname, msg='parse failed %s %s' % (obstype, spec))
            out = {}
            user.loopdata.LoopProcessor.add_current_obstype(
                cname, pkt, out, converter, formatter)
            return out.get(cname.field)

        # 'raw' -> exact numeric (US identity conversion for degree_F).
        self.assertAlmostEqual(field_value('raw'), 72.5)
        # 'formatted' -> bare number string; default -> appends unit label.
        # These differ under the real skin formatter, pinning the 'formatted'
        # branch against the fall-through default.
        t_formatted = field_value('formatted', obstype='outTemp')
        t_default = field_value(None, obstype='outTemp')
        self.assertIsInstance(t_formatted, str)
        self.assertNotEqual(t_formatted, t_default)
        # 'ordinal_compass' on windDir -> a compass label, distinct from the
        # default rendering, pinning the ordinal_compass branch.
        d_compass = field_value('ordinal_compass', obstype='windDir')
        d_default = field_value(None, obstype='windDir')
        self.assertIsInstance(d_compass, str)
        self.assertNotEqual(d_compass, d_default)

    def test_create_loopdata_packet_period_routing(self) -> None:
        # Pins create_loopdata_packet's period routing: each cname.period must
        # be dispatched to its OWN accumulator.  day_accum and hour_accum hold
        # the SAME obstype (outTemp) with DIFFERENT values, so a mis-routed
        # period (e.g. a 'day'->'hour' comparison swap) reads the wrong accum
        # and produces the wrong value.  Uses '.raw' so values are exact
        # (target_unit=US -> identity conversion).
        specified_fields = ['current.outTemp.raw',
                            'day.outTemp.max.raw', 'day.outTemp.min.raw',
                            'hour.outTemp.max.raw', 'hour.outTemp.min.raw']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, specified_fields)

        # Noon PDT, July 1 2020 (same anchor the other harness tests use).
        pkt_time = 1593630000
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        self.assertIsNotNone(accums.hour_accum)   # requested -> built

        # Distinct values per period.  NOTE: archiveHoursAgoSpan(pkt_time) is
        # the PREVIOUS completed hour [11:00, 12:00], so hour records must fall
        # inside it (not at/after noon).  The day span contains noon.
        accums.day_accum.addRecord(
            {'dateTime': pkt_time - 1, 'usUnits': 1, 'outTemp': 50.0}, weight=300)
        accums.day_accum.addRecord(
            {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 80.0}, weight=300)
        accums.hour_accum.addRecord(
            {'dateTime': pkt_time - 1800, 'usUnits': 1, 'outTemp': 60.0}, weight=300)
        accums.hour_accum.addRecord(
            {'dateTime': pkt_time - 900, 'usUnits': 1, 'outTemp': 70.0}, weight=300)

        pkt = {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 65.0}
        loopdata_pkt = user.loopdata.LoopProcessor.create_loopdata_packet(
            pkt, cfg.legacy, accums, cfg)

        # Each period routed to its own accum (cross-checks routing).
        self.assertAlmostEqual(loopdata_pkt['day.outTemp.max.raw'], 80.0)
        self.assertAlmostEqual(loopdata_pkt['day.outTemp.min.raw'], 50.0)
        self.assertAlmostEqual(loopdata_pkt['hour.outTemp.max.raw'], 70.0)
        self.assertAlmostEqual(loopdata_pkt['hour.outTemp.min.raw'], 60.0)
        # 'current' routed to the live packet, not an accum.
        self.assertAlmostEqual(loopdata_pkt['current.outTemp.raw'], 65.0)

    def test_span_prop_grammar(self) -> None:
        """Spec (7.2): a period's span properties -- start, end, length and
        dateTime -- parse where an obstype stands, take no aggregate, and
        exist only on the periods that HAVE a span.  Expectations come from
        weewx.tags.TimespanBinder, which exposes exactly these four as
        properties: a property shadows __getattr__, so $day.dateTime is the
        day's start and $day.dateTime.max is not a thing."""
        L = user.loopdata.LoopData

        # Every property on every period that has a span.
        for period in ('hour', 'day', 'week', 'month', 'year', 'rainyear', 'alltime'):
            for prop in ('start', 'end', 'length', 'dateTime'):
                field = '%s.%s.raw' % (period, prop)
                cname = L.parse_cname(field)
                self.assertIsNotNone(cname, msg=field)
                self.assertEqual(cname.span_prop, prop, msg=field)
                self.assertEqual(cname.obstype, prop, msg=field)
                self.assertIsNone(cname.agg_type, msg=field)
                self.assertEqual(cname.period, period, msg=field)

        # No format spec at all, and the full spec machinery, both parse.
        self.assertEqual(L.parse_cname('week.start').span_prop, 'start')
        self.assertEqual(L.parse_cname('week.start.formatted').span_prop, 'start')
        self.assertEqual(L.parse_cname('week.length.long_form()').span_prop, 'length')
        self.assertEqual(L.parse_cname('week.start.format("%Y-%m-%d")').span_prop, 'start')
        self.assertEqual(L.parse_cname('week.length.hour.raw').unit, 'hour')
        self.assertEqual(L.parse_cname('day.start.round(0).raw').round_ndigits, 0)

        # An aggregate on a span property is nonsense; the report tag has no
        # such form.
        for field in ('week.start.max', 'day.dateTime.max', 'year.length.sum',
                      'month.end.avg.raw'):
            self.assertIsNone(L.parse_cname(field), msg=field)

        # The continuous windows roll with every packet: no span, so the
        # names fall back to being obstypes and the missing aggregate is
        # fatal, exactly as for any other unknown obstype.
        for field in ('10m.start.raw', '24h.start.raw', '1440m.length.raw'):
            self.assertIsNone(L.parse_cname(field), msg=field)

        # Where there is no span, the four names keep whatever meaning they
        # already had.  dateTime is a real observation and current.dateTime.raw
        # is the shipped packet timestamp -- it must not become a span
        # property, and unit.label.dateTime must stay the observation's label.
        for field in ('current.dateTime.raw', 'unit.label.dateTime', 'trend.dateTime'):
            cname = L.parse_cname(field)
            self.assertIsNotNone(cname, msg=field)
            self.assertIsNone(cname.span_prop, msg=field)

    def test_span_props_match_weeutil(self) -> None:
        """Spec (7.2): each span property is the corresponding edge of the
        period's weeutil span at the PACKET's time -- the same call
        create_*_accum makes.  Compared against weeutil rather than against
        literals, so the station's own week_start and rain_year_start are
        covered; the fixture uses rain_year_start=10 (October), where an
        off-by-one in the rain year shows up.  .raw must be a json NUMBER:
        the consumer compares start values numerically."""
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        # Noon PDT, Wednesday 2020-07-01.  Past October 1, so the rain year
        # that began in October 2019 is the one in force -- the case a
        # January-anchored rain year would get wrong.
        pkt_time = 1593630000
        rainyear_start = 10
        week_start = 6      # Sunday

        fields = []
        for period in ('hour', 'day', 'week', 'month', 'year', 'rainyear'):
            for prop in ('start', 'end', 'length'):
                fields.append('%s.%s.raw' % (period, prop))
            fields.append('%s.dateTime.raw' % period)
        cfg = ProcessPacketTests._get_config('us', 10800, rainyear_start, week_start, fields)
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        pkt = {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 65.0}
        out = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        spans = {
            'hour'    : weeutil.weeutil.archiveHoursAgoSpan(pkt_time),
            'day'     : weeutil.weeutil.archiveDaySpan(pkt_time),
            'week'    : weeutil.weeutil.archiveWeekSpan(pkt_time, week_start),
            'month'   : weeutil.weeutil.archiveMonthSpan(pkt_time),
            'year'    : weeutil.weeutil.archiveYearSpan(pkt_time),
            'rainyear': weeutil.weeutil.archiveRainYearSpan(pkt_time, rainyear_start),
        }
        for period, span in spans.items():
            self.assertEqual(out['%s.start.raw' % period], span.start, msg=period)
            self.assertEqual(out['%s.end.raw' % period], span.stop, msg=period)
            self.assertEqual(out['%s.length.raw' % period], span.stop - span.start, msg=period)
            # dateTime is TimespanBinder's alias for start.
            self.assertEqual(out['%s.dateTime.raw' % period], span.start, msg=period)
            # json numbers, not strings (the consumer compares numerically).
            for prop in ('start', 'end', 'length', 'dateTime'):
                self.assertNotIsInstance(out['%s.%s.raw' % (period, prop)], str,
                    msg='%s.%s.raw' % (period, prop))

        # The rain year really is the October one, not January's.
        self.assertEqual(time.localtime(out['rainyear.start.raw']).tm_mon, 10)
        self.assertEqual(time.localtime(out['rainyear.start.raw']).tm_year, 2019)

    def test_span_props_track_the_packets_time(self) -> None:
        """Spec (7.2): the span follows the PACKET's time, so a boundary
        crossed while loopdata runs moves it.  This is the whole point of
        the feature: a consumer that decides 'did this period begin today?'
        must see the new week the instant the packet does.

        The case that catches a stale span: on the FIRST day of a week,
        week.start == day.start; on the second day it does not."""
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        week_start = 6      # Sunday
        fields = ['day.start.raw', 'week.start.raw', 'month.start.raw']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, week_start, fields)

        # Sunday 2020-06-28 noon PDT -- the first day of its week, and the
        # week's own start.
        sunday = 1593370800
        self.assertEqual(time.localtime(sunday).tm_wday, 6)     # Sunday
        # The accumulators are built ONCE, on the Sunday packet, and reused
        # for the Monday one -- a span cached at build time would answer
        # Sunday's week for both.
        accums = ProcessPacketTests._get_accums(cfg, sunday)

        out = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
            {'dateTime': sunday, 'usUnits': 1, 'outTemp': 65.0}, cfg, accums)
        self.assertEqual(out['week.start.raw'], out['day.start.raw'])

        # Monday, one day on: same week, a new day.
        monday = sunday + 86400
        self.assertEqual(time.localtime(monday).tm_wday, 0)     # Monday
        out = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
            {'dateTime': monday, 'usUnits': 1, 'outTemp': 65.0}, cfg, accums)
        self.assertNotEqual(out['week.start.raw'], out['day.start.raw'])
        self.assertEqual(out['week.start.raw'], sunday - 12 * 3600)
        self.assertEqual(out['day.start.raw'], monday - 12 * 3600)

        # The next Sunday starts a new week, and the span moves with it.
        next_sunday = sunday + 7 * 86400
        out = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
            {'dateTime': next_sunday, 'usUnits': 1, 'outTemp': 65.0}, cfg, accums)
        self.assertEqual(out['week.start.raw'], out['day.start.raw'])
        self.assertEqual(out['week.start.raw'], next_sunday - 12 * 3600)
        # July 1 fell mid-week, so the month moved without the week.
        self.assertEqual(time.localtime(out['month.start.raw']).tm_mon, 7)

    def test_span_props_need_no_declared_obstypes(self) -> None:
        """Spec (7.2): a span property is a property of the SPAN, so a report
        that declares week.start.raw and no other week field must still get
        it.  create_period_accum returns None for an empty obstype set, so a
        span read off the accumulator would be silently absent here -- which
        is exactly the shape a group that declares a period's start and
        none of its observations has."""
        fields = ['current.outTemp.raw', 'week.start.raw', 'month.start.raw',
                  'year.start.raw']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, fields)
        # No week/month/year observations are declared, so none are tracked.
        self.assertEqual(cfg.obstypes.week, set())
        self.assertEqual(cfg.obstypes.month, set())
        self.assertEqual(cfg.obstypes.year, set())

        pkt_time = 1593630000
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        accums.week_accum = None
        accums.month_accum = None
        accums.year_accum = None
        out = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
            {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 65.0}, cfg, accums)
        self.assertEqual(out['week.start.raw'],
            weeutil.weeutil.archiveWeekSpan(pkt_time, cfg.week_start).start)
        self.assertEqual(out['month.start.raw'],
            weeutil.weeutil.archiveMonthSpan(pkt_time).start)
        self.assertEqual(out['year.start.raw'],
            weeutil.weeutil.archiveYearSpan(pkt_time).start)

    def test_span_props_agree_with_the_rolled_accumulator(self) -> None:
        """Spec (7.2): the span property and the period's aggregates in the
        same file must describe the SAME period.  A page showing
        week.outTemp.max beside week.start is reading one number as a
        caption for the other; if the accumulator rolls at a boundary and
        the span property does not (or the reverse), the caption lies.

        period_span computes from the packet's time and accumulate_packet
        rolls on OutOfSpan -- two independent mechanisms -- so this drives
        both through the real accumulation path and compares them.

        Every period here declares a REAL OBSERVATION as well as its span
        properties, and that is the whole point: with only span properties
        declared, compute_period_obstypes leaves the period's obstype set
        EMPTY, accumulate_packet skips it, the accumulator never raises
        OutOfSpan and never rolls -- and a test written that way passes
        while proving nothing about agreement.  The assertions on
        cfg.obstypes below pin that the fields line really did earn the
        accumulators.

        2023-01-01 00:00 PST rolls all six at once: it is a Sunday (the
        week start here), New Year's Day, and the rain year begins in
        January."""
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        periods = ['hour', 'day', 'week', 'month', 'year', 'rainyear']
        fields = []
        for period in periods:
            fields.append('%s.outTemp.max.raw' % period)
            fields.append('%s.start.raw' % period)
            fields.append('%s.end.raw' % period)
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, fields)
        # The trap this test exists to avoid: an empty obstype set means the
        # accumulator is never fed and so never rolls.
        for period in periods:
            self.assertIn('outTemp', getattr(cfg.obstypes, period), period)

        accums_of = {
            'hour'    : lambda a: a.hour_accum,
            'day'     : lambda a: a.day_accum,
            'week'    : lambda a: a.week_accum,
            'month'   : lambda a: a.month_accum,
            'year'    : lambda a: a.year_accum,
            'rainyear': lambda a: a.rainyear_accum,
        }

        before = 1672559940     # 2022-12-31 23:59:00 PST
        after  = 1672560030     # 2023-01-01 00:00:30 PST, one boundary for all six
        self.assertEqual(time.localtime(after).tm_wday, 6)       # Sunday

        # The accumulators are built on the OLD side of every boundary, so
        # each one must roll on the second packet.
        accums = ProcessPacketTests._get_accums(cfg, before)
        old_accums = {p: accums_of[p](accums) for p in periods}

        out = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
            {'dateTime': before, 'usUnits': 1, 'outTemp': 50.0}, cfg, accums)
        for period in periods:
            accum = accums_of[period](accums)
            self.assertEqual(out['%s.start.raw' % period], accum.timespan.start, period)
            self.assertEqual(out['%s.end.raw' % period], accum.timespan.stop, period)
            self.assertEqual(out['%s.outTemp.max.raw' % period], 50.0, period)

        out = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
            {'dateTime': after, 'usUnits': 1, 'outTemp': 70.0}, cfg, accums)
        for period in periods:
            accum = accums_of[period](accums)
            # It really rolled: a fresh accumulator holding only the new
            # packet, not the old one's 50.0 carried across the boundary.
            self.assertIsNot(accum, old_accums[period], period)
            self.assertEqual(out['%s.outTemp.max.raw' % period], 70.0, period)
            self.assertEqual(out['%s.start.raw' % period], accum.timespan.start, period)
            self.assertEqual(out['%s.end.raw' % period], accum.timespan.stop, period)
            # And the span moved with it, rather than both agreeing on a
            # stale span they were each handed at build time.
            self.assertEqual(out['%s.start.raw' % period], 1672560000, period)

    def test_span_props_across_a_dst_boundary(self) -> None:
        """Spec (7.2): length is ELAPSED seconds, not a nominal calendar
        constant, so the two days a year that are not 24 hours long report
        what they actually are.

        This is loopdata's own arithmetic, not weeutil's: weeutil supplies
        the span's boundaries and add_span_prop subtracts them.  It matters
        because week.length exists precisely so a page need not hardcode
        604800 -- and a page that divides elapsed by a hardcoded 604800 is
        an hour wrong twice a year, which is the mistake this field is
        meant to retire.

        Both boundaries are Sundays, and the week starts on Sunday here, so
        each short or long day is the first day of its own week and moves
        the week's length with it.  The expected values are arithmetic a
        reader can check without running anything: 23 and 25 hours, and a
        week of 167 and 169."""
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        week_start = 6                                  # Sunday
        fields = ['day.start.raw', 'day.end.raw', 'day.length.raw',
                  'week.start.raw', 'week.end.raw', 'week.length.raw']

        # (packet time, day seconds, week seconds).  Noon on each boundary
        # Sunday: 2020-03-08 (PST -> PDT, an hour vanishes) and 2020-11-01
        # (PDT -> PST, an hour repeats).
        cases = ((1583694000, 23 * 3600, 167 * 3600),
                 (1604260800, 25 * 3600, 169 * 3600))
        for pkt_time, day_secs, week_secs in cases:
            self.assertEqual(time.localtime(pkt_time).tm_wday, 6, pkt_time)
            cfg = ProcessPacketTests._get_config('us', 10800, 1, week_start, fields)
            accums = ProcessPacketTests._get_accums(cfg, pkt_time)
            out = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
                {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 50.0}, cfg, accums)

            self.assertEqual(out['day.length.raw'], day_secs, pkt_time)
            self.assertEqual(out['week.length.raw'], week_secs, pkt_time)
            # Not the nominal constants -- the whole point of the case.
            self.assertNotEqual(out['day.length.raw'], 86400, pkt_time)
            self.assertNotEqual(out['week.length.raw'], 604800, pkt_time)
            # length is exactly what end - start says, so a page can use
            # either and agree with itself.
            self.assertEqual(out['day.length.raw'],
                out['day.end.raw'] - out['day.start.raw'], pkt_time)
            self.assertEqual(out['week.length.raw'],
                out['week.end.raw'] - out['week.start.raw'], pkt_time)
            # Each boundary day is its own week's first day, so the two
            # spans start together.
            self.assertEqual(out['day.start.raw'], out['week.start.raw'], pkt_time)
            # The boundaries are real local midnights either side.
            for key in ('day.start.raw', 'day.end.raw'):
                local = time.localtime(out[key])
                self.assertEqual((local.tm_hour, local.tm_min, local.tm_sec),
                    (0, 0, 0), '%s at %s' % (key, pkt_time))

    def test_span_props_match_the_report_tags(self) -> None:
        """Spec (7.2): loopdata's span properties are the REPORT TAGS served
        live, so they are pinned against weewx.tags itself -- the same
        TimespanBinder a Cheetah template renders -- over a throwaway archive.
        Both halves are compared: the .raw instant AND the rendered string,
        because "the report tags served live" is a claim about what a page
        SEES, and only the rendering can carry a wrong time context (an
        alltime that stopped riding 'year' keeps its .raw and changes what
        the reader gets).
        This covers alltime, whose span WeeWX takes from the archive's first
        record to the report time (loopdata's report time is the packet's).
        The accumulator is no help there: its span is a fabricated 1970-2525
        window chosen to swallow every record."""
        import weewx.tags
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        pkt_time = 1593630000                   # noon PDT, 2020-07-01
        first_stamp = pkt_time - 400 * 86400    # a record well before it
        rainyear_start = 10
        week_start = 6

        props = ('start', 'end', 'length', 'dateTime')
        # 'hour' is not in this loop: weewx.tags binds the $hour tag with
        # context='day', while loopdata has always given the hour period its
        # own 'hour' TimeFormats entry (pinned by
        # test_time_context_formatting, documented in the manual).  The VALUES
        # agree, so hour would pass the .raw comparison; the FORMATTED strings
        # differ, deliberately, and that divergence is pinned on its own below
        # rather than left to a comment to assert.
        periods = ('day', 'week', 'month', 'year', 'rainyear', 'alltime')
        fields = ['%s.%s%s' % (p, s, suffix)
                  for p in periods + ('hour',) for s in props
                  for suffix in ('', '.raw')]
        cfg = ProcessPacketTests._get_config('us', 10800, rainyear_start, week_start, fields)

        with tempfile.TemporaryDirectory() as tmp:
            dbm = weewx.manager.DaySummaryManager.open_with_create(
                {'database_name': os.path.join(tmp, 'test.sdb'), 'driver': 'weedb.sqlite'},
                table_name='archive', schema=wview_extended_schema)
            try:
                dbm.addRecord({'dateTime': first_stamp, 'usUnits': 1, 'interval': 5,
                               'outTemp': 50.0})
                dbm.addRecord({'dateTime': pkt_time - 300, 'usUnits': 1, 'interval': 5,
                               'outTemp': 70.0})
                self.assertEqual(dbm.firstGoodStamp(), first_stamp)

                accums = ProcessPacketTests._get_accums(cfg, pkt_time)
                accums.first_good_stamp = dbm.firstGoodStamp()
                out = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
                    {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 65.0}, cfg, accums)

                binder = weewx.tags.TimeBinder(
                    lambda data_binding=None: dbm, pkt_time,
                    formatter=cfg.legacy.formatter, converter=cfg.legacy.converter,
                    week_start=week_start, rain_year_start=rainyear_start)
                for period in periods:
                    tag = getattr(binder, period)()
                    for prop in props:
                        expected = getattr(tag, prop).raw
                        self.assertEqual(out['%s.%s.raw' % (period, prop)], expected,
                            msg='%s.%s.raw' % (period, prop))
                        # The FORMATTED string too.  These fields are the
                        # report tags served live, so a page must see what a
                        # template would -- and comparing the rendering, not
                        # just the instant, is what derives week.length's
                        # '604800 seconds' from WeeWX instead of asserting a
                        # literal beside it.
                        self.assertEqual(out['%s.%s' % (period, prop)],
                            str(getattr(tag, prop)), msg='%s.%s' % (period, prop))
                # alltime really does run from the first record to the
                # packet's time, and so its end moves with every packet.
                self.assertEqual(out['alltime.start.raw'], first_stamp)
                self.assertEqual(out['alltime.end.raw'], pkt_time)

                # The hour period: the one place loopdata deliberately does
                # NOT render what weewx.tags renders.  Pinned here so it stays
                # deliberate -- if the formats ever converge, this fails and
                # somebody decides that on purpose rather than discovering it
                # in a skin.
                hour_tag = binder.hour()
                for prop in props:
                    # The instants agree to the second; only the rendering
                    # differs.
                    self.assertEqual(out['hour.%s.raw' % prop],
                        getattr(hour_tag, prop).raw, msg='hour.%s.raw' % prop)
                for prop in ('start', 'end', 'dateTime'):
                    # loopdata renders through the fixture's 'hour' entry
                    # (%H:%M); weewx renders through 'day' (%X).
                    self.assertEqual(out['hour.%s' % prop], time.strftime(
                        '%H:%M', time.localtime(getattr(hour_tag, prop).raw)),
                        msg='hour.%s' % prop)
                    self.assertNotEqual(out['hour.%s' % prop],
                        str(getattr(hour_tag, prop)), msg='hour.%s' % prop)
                # length is a duration and carries no time context, so it
                # agrees even here.
                self.assertEqual(out['hour.length'], str(hour_tag.length))
            finally:
                dbm.close()

    def test_span_props_never_raise_out_of_the_render(self) -> None:
        """Spec (7.2): period_span must never raise.  It is called from the
        render path, where an exception is not one lost field -- generate_output
        catches per report, logs once and omits that report's WHOLE entry from
        loop-data.txt for every packet after.

        The reachable case: weeutil.weeutil.TimeSpan raises ValueError when
        start > stop, and the alltime span is (archive's first record ->
        packet time).  A packet stamped before that record -- a console whose
        clock was reset, a machine that came up behind itself -- inverts it."""
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        pkt_time = 1593630000
        fields = ['current.outTemp.raw', 'day.outTemp.max.raw',
                  'week.start.raw', 'alltime.start.raw', 'alltime.end.raw',
                  'alltime.length.raw']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, fields)
        pkt = {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 65.0}

        # TimeSpan really does raise on an inverted span -- the premise.
        with self.assertRaises(ValueError):
            weeutil.weeutil.TimeSpan(pkt_time + 86400, pkt_time)

        # period_span absorbs it rather than passing it on.
        self.assertIsNone(user.loopdata.LoopData.period_span(
            'alltime', pkt_time, 6, 1, pkt_time + 86400))

        for stamp in (pkt_time + 86400,   # archive starts after this packet
                      pkt_time + 1,       # one second after
                      None):              # empty archive
            accums = ProcessPacketTests._get_accums(cfg, pkt_time)
            accums.first_good_stamp = stamp
            out = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
                pkt, cfg, accums)
            # The alltime span properties are omitted...
            for prop in ('start', 'end', 'length'):
                self.assertNotIn('alltime.%s.raw' % prop, out, msg=repr(stamp))
            # ...and every OTHER field still arrives.  This is the assertion
            # that matters: the failure being guarded against costs the whole
            # entry, not one key.
            self.assertAlmostEqual(out['current.outTemp.raw'], 65.0, msg=repr(stamp))
            self.assertAlmostEqual(out['day.outTemp.max.raw'], 65.0, msg=repr(stamp))
            self.assertEqual(out['week.start.raw'],
                weeutil.weeutil.archiveWeekSpan(pkt_time, 6).start, msg=repr(stamp))

        # And through the real production path, which is where an escaped
        # exception would empty the entry.
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        accums.first_good_stamp = pkt_time + 86400
        renderers = [user.loopdata.ReportRenderer.for_context(cfg.legacy, cfg)]
        failures: set = set()
        output = user.loopdata.LoopProcessor.generate_output(
            pkt, cfg, accums, renderers, failures)
        self.assertEqual(failures, set())
        self.assertAlmostEqual(output['current.outTemp.raw'], 65.0)

    def test_alltime_span_appears_at_the_first_archive_record(self) -> None:
        """Spec (7.2): a station whose archive is empty when loopdata builds
        its accumulators -- weewx and loopdata installed together -- picks up
        the alltime span at its first archive record, not at the next
        restart.  new_archive_record takes the stamp from the record itself,
        so this costs no database read.

        Why absence is not a benign default: a page deciding "did this period
        begin today?" by comparing alltime.start against day.start gets no
        answer at all while the field is missing, and on a brand-new station
        every reading IS an all-time record by arithmetic -- the one day that
        comparison most needs to work.

        The stamp travels on the QUEUE, so this drives the real path end to
        end: a real LoopData (so the binding is exercised, not asserted
        about), the real handler, and the real process_queue branch that
        applies it."""
        L = user.loopdata
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        t = 1593630000                          # 2020-07-01 12:00 PDT
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            engine = self.FakeEngine(config_dict)
            service = L.LoopData(engine, config_dict)
            try:
                # The wiring itself: __init__ really bound the handler.
                self.assertIn(weewx.NEW_ARCHIVE_RECORD, engine.bound)

                cfg = service.cfg
                accums = ProcessPacketTests._get_accums(cfg, t)
                processor = L.LoopProcessor(cfg)
                processor.accumulators = accums

                # _init_fixture's archive has no records: the fresh-install
                # case.  Nothing to report an alltime span from.
                self.assertIsNone(accums.first_good_stamp)

                def drain():
                    """Apply whatever the handler queued, through the REAL
                    process_queue branch rather than a copy of it: take the
                    items to count them, put them back, and let the
                    processor's own loop apply them, ended by the stop signal
                    it already understands.  Returns how many were queued."""
                    items = []
                    while True:
                        try:
                            items.append(cfg.queue.get_nowait())
                        except queue.Empty:
                            break
                    for item in items:
                        self.assertIsInstance(item, L.ArchiveStamp)
                        cfg.queue.put(item)
                    cfg.queue.put(None)     # the stop signal ends the loop
                    processor.process_queue()
                    return len(items)

                def archived(ts):
                    rec = {'usUnits': weewx.US, 'interval': 5}
                    if ts is not None:
                        rec['dateTime'] = ts
                    service.new_archive_record(
                        weewx.Event(weewx.NEW_ARCHIVE_RECORD, record=rec))

                class LiveThread:
                    @staticmethod
                    def is_alive():
                        return True
                    @staticmethod
                    def join(timeout=None):
                        return None

                # Each guard is exercised ALONE, with the other satisfied --
                # a live thread here, so only the payload guard can stop it.
                # Before the accumulators exist the handler queues NOTHING:
                # the database read that builds them covers every record so
                # far.  StdArchive catches up at STARTUP, so this is real.
                service.loop_thread = LiveThread()
                service.loop_processor_started = True
                self.assertFalse(service.accumulator_payload_sent)
                archived(t)
                self.assertEqual(drain(), 0,
                    'must not queue before the accumulators exist')
                self.assertIsNone(accums.first_good_stamp)

                # Now the payload guard is satisfied and only the thread
                # guard is left: a dead thread drains nothing, so queuing to
                # it would grow memory for the life of weewxd.
                service.accumulator_payload_sent = True
                dead = threading.Thread(target=lambda: None)
                dead.start()
                dead.join()
                service.loop_thread = dead
                archived(t)
                self.assertEqual(drain(), 0, 'must not queue to a dead thread')
                self.assertIsNone(accums.first_good_stamp)

                service.loop_thread = LiveThread()

                # The first record supplies the stamp, with no database read.
                archived(t)
                self.assertEqual(drain(), 1)
                self.assertEqual(accums.first_good_stamp, t)
                self.assertEqual(
                    L.LoopData.period_span('alltime', t + 60, 6, 1,
                        accums.first_good_stamp),
                    weeutil.weeutil.TimeSpan(t, t + 60))

                # A LATER record must not move the start forward.
                archived(t + 300)
                drain()
                self.assertEqual(accums.first_good_stamp, t)

                # An EARLIER one must lower it: a hardware catchup on an
                # empty archive dispatches the console's whole memory, one
                # event per record, in the driver's own order.
                archived(t - 86400)
                drain()
                self.assertEqual(accums.first_good_stamp, t - 86400)

                # A record with no dateTime is ignored rather than raising:
                # this runs on the ENGINE thread, where an exception reaches
                # weewxd itself.
                archived(None)
                self.assertEqual(drain(), 0)
                self.assertEqual(accums.first_good_stamp, t - 86400)

                # Drop the stub before shutDown: its is_alive() is
                # unconditionally True, so shutDown would join it, find it
                # still "running" and log 'Unable to shut down LoopData
                # thread'.  A suite that routinely logs an error it does not
                # mean is one where a real error goes unread.
                service.loop_thread = None
            finally:
                service.shutDown()

    def test_every_span_period_has_a_span(self) -> None:
        """Spec (7.2): the grammar and period_span must not drift apart.
        Every period parse_cname accepts a span property for must get a real
        span back -- a period admitted by one and unhandled by the other
        would omit the field on every packet with only a log.debug.

        period_span cannot assert or raise instead: it runs on the render
        path, where an exception costs the report its WHOLE entry (see
        test_span_props_never_raise_out_of_the_render), so the guard has to
        live here.  Both sides are driven from VALID_FIXED_PERIODS, so
        adding a period to that list without teaching period_span fails."""
        L = user.loopdata.LoopData
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        pkt_time = 1593630000

        accepted = set()
        for period in user.loopdata.VALID_FIXED_PERIODS:
            cname = L.parse_cname('%s.start.raw' % period)
            if cname is None or cname.span_prop is None:
                continue
            accepted.add(period)
            for prop in ('start', 'end', 'length', 'dateTime'):
                self.assertIsNotNone(L.parse_cname('%s.%s.raw' % (period, prop)),
                    msg='%s.%s.raw' % (period, prop))
            span = L.period_span(period, pkt_time, 6, 1, pkt_time - 86400)
            self.assertIsNotNone(span, msg='no span for accepted period %s' % period)
            self.assertLessEqual(span.start, span.stop, msg=period)

        # Every fixed period but 'current', which is an instant.  Pinned as an
        # exact set so a period added to VALID_FIXED_PERIODS has to be
        # accounted for here rather than slipping through the loop above.
        self.assertEqual(accepted,
            {'hour', 'day', 'week', 'month', 'year', 'rainyear', 'alltime'})
        self.assertIsNone(L.parse_cname('current.start.raw').span_prop)

    def test_archive_records_from_another_binding_are_ignored(self) -> None:
        """Spec (7.2): NEW_ARCHIVE_RECORD is dispatched by StdArchive for ITS
        data_binding, and the event does not name one.  Everything loopdata
        reads -- the accumulators, the day summaries, firstGoodStamp -- comes
        from the report binding, so the alltime span describes THAT archive.
        Where the two bindings differ, a record could otherwise lower the
        span start to a time the report's archive does not contain, and
        disagree with the alltime accumulator seeded from it.

        __init__ compares them once and the handler stands down when they
        differ, queueing nothing at all."""
        L = user.loopdata
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        t = 1593630000
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            config_dict['StdArchive']['data_binding'] = 'some_other_binding'
            service = L.LoopData(self.FakeEngine(config_dict), config_dict)
            try:
                self.assertFalse(service.archive_records_are_ours)
                # Everything else the handler checks is satisfied, so only
                # the binding gate can stop it.
                service.accumulator_payload_sent = True
                service.loop_processor_started = True

                class LiveThread:
                    @staticmethod
                    def is_alive():
                        return True
                    @staticmethod
                    def join(timeout=None):
                        return None
                service.loop_thread = LiveThread()

                service.new_archive_record(weewx.Event(weewx.NEW_ARCHIVE_RECORD,
                    record={'dateTime': t, 'usUnits': weewx.US, 'interval': 5}))
                with self.assertRaises(queue.Empty):
                    service.cfg.queue.get_nowait()
                service.loop_thread = None
            finally:
                service.shutDown()

        # The ordinary station, for contrast: same binding, record queued.
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            service = L.LoopData(self.FakeEngine(config_dict), config_dict)
            try:
                self.assertTrue(service.archive_records_are_ours)
                service.accumulator_payload_sent = True
                service.loop_processor_started = True

                class LiveThread2:
                    @staticmethod
                    def is_alive():
                        return True
                    @staticmethod
                    def join(timeout=None):
                        return None
                service.loop_thread = LiveThread2()

                service.new_archive_record(weewx.Event(weewx.NEW_ARCHIVE_RECORD,
                    record={'dateTime': t, 'usUnits': weewx.US, 'interval': 5}))
                item = service.cfg.queue.get_nowait()
                self.assertIsInstance(item, L.ArchiveStamp)
                self.assertEqual(item.timestamp, t)
                service.loop_thread = None
            finally:
                service.shutDown()

    def test_one_file_carries_one_alltime_span(self) -> None:
        """Spec (7.2): the alltime span start reaches the LoopProcessor as an
        ArchiveStamp on the QUEUE, and process_queue applies it BETWEEN
        packets -- in the same loop that renders, so never during a render.
        That is what keeps one loop-data.txt coherent: an alltime.start can
        never disagree with the alltime.length written beside it.

        The alternative, a field both threads touch, was rejected for exactly
        this: read once per field, it could omit alltime.start while
        rendering alltime.end and alltime.length from a value that arrived
        mid-render, on the packet coinciding with a station's first archive
        record."""
        L = user.loopdata
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        t = 1593630000
        fields = ['alltime.start.raw', 'alltime.end.raw', 'alltime.length.raw']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, fields)
        accums = ProcessPacketTests._get_accums(cfg, t)

        # Structural, and the point of the design: the engine thread has no
        # such field to write.  The stamp lives on the accumulators, which
        # belong to the LoopProcessor.  Pinned so a shared mutable field
        # cannot creep back in.
        self.assertFalse(hasattr(cfg, 'first_good_stamp'),
            'the alltime stamp must not live on the shared Configuration')
        self.assertTrue(hasattr(accums, 'first_good_stamp'))
        self.assertIsNone(accums.first_good_stamp)

        # The real dispatch: process_queue's own branch, reached the way
        # production reaches it, ending on the stop signal.
        processor = L.LoopProcessor(cfg)
        cfg.queue.put(accums)
        cfg.queue.put(L.ArchiveStamp(t - 3600))     # first: takes it
        cfg.queue.put(L.ArchiveStamp(t - 60))       # later: must not raise it
        cfg.queue.put(L.ArchiveStamp(t - 86400))    # earlier: must lower it
        cfg.queue.put(None)
        processor.process_queue()
        self.assertEqual(processor.accumulators.first_good_stamp, t - 86400)

        # One render off that value: all three fields present and agreeing.
        out = L.LoopProcessor.create_loopdata_packet(
            {'dateTime': t, 'usUnits': 1, 'outTemp': 65.0},
            cfg.legacy, processor.accumulators, cfg)
        for k in fields:
            self.assertIn(k, out)
        self.assertEqual(out['alltime.start.raw'], t - 86400)
        self.assertEqual(out['alltime.end.raw'], t)
        self.assertEqual(out['alltime.length.raw'],
            out['alltime.end.raw'] - out['alltime.start.raw'])

    def test_span_props_formatted_as_the_report_tags_are(self) -> None:
        """Spec (7.2): start/end/dateTime are instants and render through the
        period's [Units][TimeFormats] entry; length is a DURATION and renders
        as one.  Expectations are the fixture's own formats applied with
        time.strftime -- the same derivation test_time_context_formatting
        uses -- so a duration rendered as a date, or an instant rendered as a
        number, fails here."""
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        pkt_time = 1593630000
        week_start = 6
        fields = ['day.start', 'week.start', 'month.start', 'year.start',
                  'week.start.formatted', 'week.length', 'week.length.raw',
                  'week.length.long_form()', 'week.length.hour.raw']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, week_start, fields)
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        out = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
            {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 65.0}, cfg, accums)

        week_start_ts = weeutil.weeutil.archiveWeekSpan(pkt_time, week_start).start
        day_start_ts = weeutil.weeutil.archiveDaySpan(pkt_time).start
        # The fixture's TimeFormats: day %X, week '%X (%A)', month/year %x %X.
        self.assertEqual(out['day.start'], time.strftime('%X', time.localtime(day_start_ts)))
        self.assertEqual(out['week.start'], time.strftime('%X (%A)', time.localtime(week_start_ts)))
        self.assertEqual(out['week.start.formatted'],
            time.strftime('%X (%A)', time.localtime(week_start_ts)))
        self.assertEqual(out['month.start'], time.strftime('%x %X',
            time.localtime(weeutil.weeutil.archiveMonthSpan(pkt_time).start)))
        self.assertEqual(out['year.start'], time.strftime('%x %X',
            time.localtime(weeutil.weeutil.archiveYearSpan(pkt_time).start)))

        # length is group_deltatime: a count of seconds, never a date.
        self.assertEqual(out['week.length.raw'], 7 * 86400)
        self.assertEqual(out['week.length'], '604800 seconds')
        self.assertEqual(out['week.length.long_form()'], '7 days, 0 hours, 0 minutes')
        self.assertAlmostEqual(out['week.length.hour.raw'], 168.0)

    def test_unit_override_current(self) -> None:
        # Pins the unit-override path of add_current_obstype (6.0).  A US packet
        # (windSpeed in mph, outTemp in degree_F) is asked for in overridden
        # units.  Expected values are WeeWX's own conversions (parity is the
        # spec).  An override incompatible with the obstype's group is dropped.
        import weewx.units
        from weewx.units import ValueTuple
        specified_fields = ['current.windSpeed.beaufort',
                            'current.windSpeed.beaufort.raw',
                            'current.outTemp.degree_C.raw',
                            'current.outTemp.beaufort.raw']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, specified_fields)
        converter = cfg.legacy.converter
        formatter = cfg.legacy.formatter

        pkt = {'dateTime': 1000, 'usUnits': 1, 'windSpeed': 25.0, 'outTemp': 68.0}

        def field_value(field):
            cname = user.loopdata.LoopData.parse_cname(field)
            self.assertIsNotNone(cname, msg='parse failed %s' % field)
            out = {}
            user.loopdata.LoopProcessor.add_current_obstype(
                cname, pkt, out, converter, formatter)
            return out, cname.field

        # windSpeed 25 mph -> beaufort, matching weewx.units.convert exactly.
        expected_beaufort = weewx.units.convert(
            ValueTuple(25.0, 'mile_per_hour', 'group_speed'), 'beaufort')[0]
        self.assertEqual(expected_beaufort, 5)   # hand-check: 25 mph is force 5
        out, key = field_value('current.windSpeed.beaufort.raw')
        self.assertEqual(out[key], expected_beaufort)

        # Default rendering (no format_spec) formats with beaufort's format
        # string ('%d') -- a bare number string, beaufort has an empty label.
        out, key = field_value('current.windSpeed.beaufort')
        self.assertEqual(out[key], '5')

        # outTemp 68 degree_F -> 20.0 degree_C.
        out, key = field_value('current.outTemp.degree_C.raw')
        self.assertAlmostEqual(out[key], 20.0)

        # Incompatible override (a temperature in beaufort) is dropped, not
        # emitted, and does not raise.
        out, key = field_value('current.outTemp.beaufort.raw')
        self.assertNotIn(key, out)

    def test_unit_override_period(self) -> None:
        # Pins the unit-override path of add_period_obstype (6.0).  A day accum
        # of degree_F outTemp is read back with a degree_C override.  avg of
        # 50 and 80 degree_F is 65 degree_F -> 18.3333 degree_C.  An incompatible
        # override is dropped.  Uses the real SeasonsReport formatter (via
        # _get_config) so the default-render assertion below exercises the
        # overridden unit's real format string and label (a bare Formatter()
        # carries neither and falls back to '%f' with no label).
        import weewx.units
        US = weewx.units.unit_constants['US']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6,
                ['day.outTemp.avg.degree_C'])
        converter = cfg.legacy.converter
        formatter = cfg.legacy.formatter

        day_accum = weewx.accum.Accum(
            weeutil.weeutil.archiveDaySpan(1593630000), US)
        day_accum.addRecord({'dateTime': 1593629000, 'usUnits': 1, 'outTemp': 50.0}, weight=300)
        day_accum.addRecord({'dateTime': 1593630000, 'usUnits': 1, 'outTemp': 80.0}, weight=300)

        def period_value(field):
            cname = user.loopdata.LoopData.parse_cname(field)
            self.assertIsNotNone(cname, msg='parse failed %s' % field)
            out = {}
            user.loopdata.LoopProcessor.add_period_obstype(
                cname, day_accum, out, converter, formatter)
            return out, cname.field

        # avg 65 degree_F -> (65-32)*5/9 = 18.33333 degree_C.
        out, key = period_value('day.outTemp.avg.degree_C.raw')
        self.assertAlmostEqual(out[key], (65.0 - 32.0) * 5.0 / 9.0)

        # Without the override, the same avg comes back in the report unit
        # (degree_F, identity for a US config) -- proving the override actually
        # re-targeted the conversion.
        out, key = period_value('day.outTemp.avg.raw')
        self.assertAlmostEqual(out[key], 65.0)

        # Incompatible override (temperature in beaufort) is dropped.
        out, key = period_value('day.outTemp.avg.beaufort.raw')
        self.assertNotIn(key, out)

        # Default rendering (no format_spec) with an override must format with
        # the OVERRIDDEN unit's format string and label: 18.3°C, not 65.0°F.
        # This is the only pin on the overridden unit's LABEL lookup -- the
        # current-path beaufort test cannot catch a wrong-label bug because
        # beaufort's label is empty.
        out, key = period_value('day.outTemp.avg.degree_C')
        self.assertEqual(out[key], '18.3°C')

        # Continuous periods route through the same add_period_obstype; pin one
        # end-to-end: max windGust 20 mph -> knots (20 * 0.868976242, WeeWX's
        # mph->knot factor).
        cont = user.loopdata.ContinuousAccum(100000, US)
        cont.addRecord({'dateTime': 1000, 'usUnits': 1, 'windGust': 10.0})
        cont.addRecord({'dateTime': 1010, 'usUnits': 1, 'windGust': 20.0})
        cname = user.loopdata.LoopData.parse_cname('10m.windGust.max.knot.raw')
        self.assertIsNotNone(cname)
        out_c: dict = {}
        user.loopdata.LoopProcessor.add_period_obstype(
            cname, cont, out_c, converter, formatter)
        self.assertAlmostEqual(out_c['10m.windGust.max.knot.raw'], 20.0 * 0.868976242)

    def test_time_context_formatting(self) -> None:
        # Pins the time-context parity fix (6.0): WeeWX report tags render time
        # aggregates (maxtime et al.) with the PERIOD as the Formatter context,
        # selecting that period's [Units][TimeFormats] entry.  Expectations are
        # derived from first principles by applying the fixture's TimeFormats
        # entries (hour %H:%M, day %X, week '%X (%A)', month/year %x %X) via
        # time.strftime.  'alltime' must use the 'year' format because that is
        # the context weewx.tags binds for the $alltime tag; continuous
        # periods have no report analog and must keep the 'current' format.
        import time
        import weewx.units
        US = weewx.units.unit_constants['US']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, ['day.outTemp.maxtime'])
        converter = cfg.legacy.converter
        formatter = cfg.legacy.formatter

        t_max = 1593630000
        day_accum = weewx.accum.Accum(
            weeutil.weeutil.archiveDaySpan(t_max), US)
        day_accum.addRecord({'dateTime': t_max - 1000, 'usUnits': 1, 'outTemp': 50.0}, weight=300)
        day_accum.addRecord({'dateTime': t_max, 'usUnits': 1, 'outTemp': 80.0}, weight=300)

        def rendered(field, accum):
            cname = user.loopdata.LoopData.parse_cname(field)
            self.assertIsNotNone(cname, msg='parse failed %s' % field)
            out: dict = {}
            user.loopdata.LoopProcessor.add_period_obstype(
                cname, accum, out, converter, formatter)
            return out.get(cname.field)

        def expect(fmt):
            return time.strftime(fmt, time.localtime(t_max))

        # add_period_obstype takes the context from the cname's period, so one
        # accum can pin every span context.
        self.assertEqual(rendered('hour.outTemp.maxtime', day_accum), expect('%H:%M'))
        self.assertEqual(rendered('day.outTemp.maxtime', day_accum), expect('%X'))
        self.assertEqual(rendered('week.outTemp.maxtime', day_accum), expect('%X (%A)'))
        self.assertEqual(rendered('month.outTemp.maxtime', day_accum), expect('%x %X'))
        self.assertEqual(rendered('year.outTemp.maxtime', day_accum), expect('%x %X'))
        self.assertEqual(rendered('rainyear.outTemp.maxtime', day_accum), expect('%x %X'))
        # weewx.tags.CurrentObj.alltime binds context='year' (there is no
        # 'alltime' TimeFormats entry); loopdata must match the $alltime tag.
        self.assertEqual(rendered('alltime.outTemp.maxtime', day_accum), expect('%x %X'))
        # The fixture's year and current formats coincide (%x %X), so pin the
        # alltime->year mapping with a formatter whose entries all differ.
        distinct_formatter = weewx.units.Formatter(
            time_format_dict={'year': 'Y=%H:%M', 'current': 'C=%H:%M', 'alltime': 'A=%H:%M'})
        cname_at = user.loopdata.LoopData.parse_cname('alltime.outTemp.maxtime')
        out_at: dict = {}
        user.loopdata.LoopProcessor.add_period_obstype(
            cname_at, day_accum, out_at, converter, distinct_formatter)
        self.assertEqual(out_at.get('alltime.outTemp.maxtime'), expect('Y=%H:%M'))

        # .formatted on a time renders the same context format (times never
        # carry a label) -- NOT the numeric '%f'-fallback path.
        self.assertEqual(rendered('day.outTemp.maxtime.formatted', day_accum), expect('%X'))

        # Continuous periods have no report analog: 'current' context.
        cont = user.loopdata.ContinuousAccum(100000, US)
        cont.addRecord({'dateTime': t_max - 1000, 'usUnits': 1, 'outTemp': 50.0})
        cont.addRecord({'dateTime': t_max, 'usUnits': 1, 'outTemp': 80.0})
        self.assertEqual(rendered('10m.outTemp.maxtime', cont), expect('%x %X'))

        # current path: .formatted on a time value also routes through
        # toString ('current' context), not the numeric format-string path.
        cname = user.loopdata.LoopData.parse_cname('current.dateTime.formatted')
        self.assertIsNotNone(cname)
        out: dict = {}
        user.loopdata.LoopProcessor.add_current_obstype(
            cname, {'dateTime': t_max, 'usUnits': 1}, out, converter, formatter)
        self.assertEqual(out.get('current.dateTime.formatted'), expect('%x %X'))

    def test_unit_override_trend_offset_unit(self) -> None:
        # Pins the unit-override path of the trend machinery (6.0) for an OFFSET
        # unit (temperature), where order matters: converting each endpoint to
        # the override unit BEFORE subtracting makes the offset cancel, so a
        # 9 degree_F trend is a 5 degree_C trend -- NOT the (wrong) 9-degree_F-as-
        # a-temperature-converted-to-C that a convert-after-subtract would give.
        import weewx.units
        US = weewx.units.unit_constants['US']
        converter = weewx.units.Converter(weewx.units.USUnits)
        formatter = weewx.units.Formatter()
        baro_descs = user.loopdata.LoopData.construct_baro_trend_descs({})

        time_delta = 10800
        loop_frequency = 2.0
        t0 = 1000
        t1 = t0 + (time_delta - loop_frequency)  # actual_time_delta == time_delta, adj == 1
        accum = user.loopdata.ContinuousAccum(100000, US)
        accum.addRecord({'dateTime': t0, 'usUnits': 1, 'outTemp': 50.0})
        accum.addRecord({'dateTime': t1, 'usUnits': 1, 'outTemp': 59.0})

        pkt = {'dateTime': t1, 'usUnits': 1, 'outTemp': 59.0}

        def trend_value(field):
            cname = user.loopdata.LoopData.parse_cname(field)
            self.assertIsNotNone(cname, msg='parse failed %s' % field)
            out = {}
            user.loopdata.LoopProcessor.add_trend_obstype(
                cname, accum, pkt, out, time_delta, loop_frequency,
                baro_descs, converter, formatter)
            return out.get(cname.field)

        # Override to degree_C: 59F-50F = 9F trend -> 5C trend (offset cancels).
        self.assertAlmostEqual(trend_value('trend.outTemp.degree_C.raw'), 5.0)

        # No override: report unit (degree_F) -> 9F trend.
        self.assertAlmostEqual(trend_value('trend.outTemp.raw'), 9.0)

        # Guard against a convert-after-subtract regression: converting the 9
        # degree_F *value* to degree_C as if it were a temperature would give
        # (9-32)*5/9 = -12.78, which must NOT be the answer.
        self.assertNotAlmostEqual(
            trend_value('trend.outTemp.degree_C.raw'), (9.0 - 32.0) * 5.0 / 9.0)

        # Incompatible override on a trend (temperature in beaufort) is dropped
        # silently.  This drop happens inside get_trend's guard -- a different
        # code path from the current/period drops -- so pin it separately.
        self.assertIsNone(trend_value('trend.outTemp.beaufort.raw'))

    def test_parse_call_spec(self) -> None:
        # Grammar for call-syntax format specs (6.0): format/nolabel/string/
        # long_form parse with their arguments bound to the ValueHelper
        # method's parameter names, mirroring the report-tag call.
        parse = user.loopdata.LoopData.parse_cname

        cname = parse('day.outTemp.maxtime.format("%H:%M")')
        assert cname is not None
        self.assertEqual(cname.field, 'day.outTemp.maxtime.format("%H:%M")')
        self.assertEqual(cname.period, 'day')
        self.assertEqual(cname.obstype, 'outTemp')
        self.assertEqual(cname.agg_type, 'maxtime')
        self.assertEqual(cname.unit, None)
        self.assertEqual(cname.format_spec, 'format')
        self.assertEqual(cname.format_kwargs, {'format_string': '%H:%M'})

        # Positional arguments bind in the ValueHelper method's order.
        cname = parse("day.windGust.max.nolabel('%.1f', '--')")
        assert cname is not None
        self.assertEqual(cname.format_spec, 'nolabel')
        self.assertEqual(cname.format_kwargs,
            {'format_string': '%.1f', 'None_string': '--'})

        # Keyword arguments, including booleans.
        cname = parse('current.outTemp.format(add_label=False)')
        assert cname is not None
        self.assertEqual(cname.format_spec, 'format')
        self.assertEqual(cname.format_kwargs, {'add_label': False})

        cname = parse('day.rain.sum.format("%.2f", None_string="--", localize=False)')
        assert cname is not None
        self.assertEqual(cname.format_kwargs,
            {'format_string': '%.2f', 'None_string': '--', 'localize': False})

        # A unit override composes, ordered before the spec.
        cname = parse('day.outTemp.avg.degree_C.nolabel("%.2f")')
        assert cname is not None
        self.assertEqual(cname.unit, 'degree_C')
        self.assertEqual(cname.format_spec, 'nolabel')

        # A bare spec name is a zero-argument call (Cheetah auto-call), so
        # nolabel -- whose format_string is required -- must not parse bare
        # or empty.
        cname = parse('day.rain.sum.string')
        assert cname is not None
        self.assertEqual(cname.format_spec, 'string')
        self.assertEqual(cname.format_kwargs, {})
        cname = parse('day.sunshineDur.sum.long_form')
        assert cname is not None
        self.assertEqual(cname.format_spec, 'long_form')
        self.assertIsNone(parse('day.windGust.max.nolabel'))
        self.assertIsNone(parse('day.windGust.max.nolabel()'))

        # Quoted arguments are opaque to the splitter: dots and parens
        # inside them are argument text, not grammar.
        cname = parse('day.outTemp.maxtime.format("%d.%m (%Y)")')
        assert cname is not None
        self.assertEqual(cname.format_kwargs, {'format_string': '%d.%m (%Y)'})

        # Malformed calls reject the whole field.
        self.assertIsNone(parse('day.outTemp.max.format("%.1f", format_string="%.2f")'))  # duplicate arg
        self.assertIsNone(parse('day.outTemp.max.format(bogus=1)'))      # unknown kwarg
        self.assertIsNone(parse('day.outTemp.max.string("a", "b")'))     # too many positionals
        self.assertIsNone(parse('day.outTemp.max.format(add_label=x)'))  # non-literal argument
        self.assertIsNone(parse('day.outTemp.max.frobnicate("x")'))      # unknown spec
        self.assertIsNone(parse('day.outTemp.max.format("%.1f'))         # unterminated quote
        self.assertIsNone(parse('day.outTemp.max.format("%.1f").raw'))   # no chaining after a spec
        self.assertIsNone(parse('trend.barometer.desc()'))               # code/desc are not calls

        # round(n): a value transform, ordered between the unit override and
        # the format spec, composing with any format spec.
        cname = parse('day.barometer.max.round(2).raw')
        assert cname is not None
        self.assertEqual(cname.round_ndigits, 2)
        self.assertEqual(cname.unit, None)
        self.assertEqual(cname.format_spec, 'raw')
        cname = parse('day.barometer.max.mbar.round(1).format("%.3f")')
        assert cname is not None
        self.assertEqual(cname.unit, 'mbar')
        self.assertEqual(cname.round_ndigits, 1)
        self.assertEqual(cname.format_spec, 'format')
        cname = parse('day.barometer.max.round(ndigits=2)')  # kwarg form; no spec
        assert cname is not None
        self.assertEqual(cname.round_ndigits, 2)
        self.assertEqual(cname.format_spec, None)
        cname = parse('day.barometer.max.round()')  # identity, as vh.round()
        assert cname is not None
        self.assertEqual(cname.round_ndigits, None)
        self.assertEqual(cname.field, 'day.barometer.max.round()')
        self.assertIsNone(parse('day.barometer.max.round(1.5)'))       # ndigits must be int
        self.assertIsNone(parse('day.barometer.max.round(True)'))      # bool is not ndigits
        self.assertIsNone(parse('day.barometer.max.round(1, 2)'))      # too many positionals
        self.assertIsNone(parse('day.barometer.max.raw.round(1)'))     # round precedes the spec
        self.assertIsNone(parse('day.barometer.max.round(1).round(2)'))  # one round only

    def test_call_spec_rendering_parity(self) -> None:
        # Call-syntax format specs (6.0) are ValueHelper-method parity: for
        # period.obstype.agg.spec(...), loopdata must emit exactly what a
        # report tag's ValueHelper renders for the same value tuple, context,
        # formatter and converter.  Expected values are computed by
        # constructing that ValueHelper -- parity IS the spec.
        import weewx.units
        from weewx.units import ValueHelper, ValueTuple
        US = weewx.units.unit_constants['US']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, ['day.outTemp.max'])
        converter = cfg.legacy.converter
        formatter = cfg.legacy.formatter

        t_max = 1593630000
        day_accum = weewx.accum.Accum(weeutil.weeutil.archiveDaySpan(t_max), US)
        day_accum.addRecord({'dateTime': t_max - 1000, 'usUnits': 1,
            'outTemp': 50.0, 'sunshineDur': 300.0, 'barometer': 29.8123}, weight=300)
        day_accum.addRecord({'dateTime': t_max, 'usUnits': 1,
            'outTemp': 80.0, 'sunshineDur': 4000.0, 'barometer': 29.9271}, weight=300)

        def rendered(field) -> dict:
            cname = user.loopdata.LoopData.parse_cname(field)
            self.assertIsNotNone(cname, msg='parse failed %s' % field)
            out: dict = {}
            user.loopdata.LoopProcessor.add_period_obstype(
                cname, day_accum, out, converter, formatter)
            return out

        # Value present: the day max is 80 degree_F; context is the period.
        vh = ValueHelper(ValueTuple(80.0, 'degree_F', 'group_temperature'),
            'day', formatter, converter)
        for spec, expected in [
                ('format("%.3f")',            vh.format("%.3f")),
                ('format(add_label=False)',   vh.format(add_label=False)),
                ('format("%05.1f", localize=False)',
                                              vh.format("%05.1f", localize=False)),
                ('nolabel("%.2f")',           vh.nolabel("%.2f")),
                ('string()',                  vh.string()),
                ('string',                    vh.string())]:
            field = 'day.outTemp.max.%s' % spec
            self.assertEqual(rendered(field).get(field), expected, msg=field)

        # A unit override converts before the spec renders, as the report
        # tag's $day.outTemp.max.degree_C.nolabel(...) does.
        vh_c = vh.convert('degree_C')
        field = 'day.outTemp.max.degree_C.nolabel("%.2f")'
        self.assertEqual(rendered(field).get(field), vh_c.nolabel("%.2f"))

        # Times: format's argument is a strftime format; argument-less specs
        # render through the period's [Units][TimeFormats] context.
        vh_t = ValueHelper(ValueTuple(t_max, 'unix_epoch', 'group_time'),
            'day', formatter, converter)
        field = 'day.outTemp.maxtime.format("%H:%M")'
        self.assertEqual(rendered(field).get(field), vh_t.format("%H:%M"))
        field = 'day.outTemp.maxtime.string()'
        self.assertEqual(rendered(field).get(field), vh_t.string())

        # round(n): the value is rounded, then any spec renders the rounded
        # value -- exactly ValueHelper.round's chaining (the day max
        # barometer is 29.9271 inHg).
        vh_b = ValueHelper(ValueTuple(29.9271, 'inHg', 'group_pressure'),
            'day', formatter, converter)
        for spec, expected in [
                ('round(2).raw',            vh_b.round(2).raw),
                ('round()',                 str(vh_b.round())),
                ('round(1)',                str(vh_b.round(1))),
                ('round(2).format("%.3f")', vh_b.round(2).format("%.3f")),
                ('round(2).string()',       vh_b.round(2).string()),
                ('mbar.round(1).raw',       vh_b.convert('mbar').round(1).raw)]:
            field = 'day.barometer.max.%s' % spec
            self.assertEqual(rendered(field).get(field), expected, msg=field)

        # long_form on a delta time (sunshineDur sums 300 + 4000 seconds).
        vh_d = ValueHelper(ValueTuple(4300.0, 'second', 'group_deltatime'),
            'day', formatter, converter)
        field = 'day.sunshineDur.sum.long_form()'
        self.assertEqual(rendered(field).get(field), vh_d.long_form())
        field = 'day.sunshineDur.sum.long_form("%(hour)d h %(minute)d m")'
        self.assertEqual(rendered(field).get(field),
            vh_d.long_form("%(hour)d h %(minute)d m"))

        # Missing data: string(), or an explicit None_string, EMITS the None
        # rendering exactly as the report tag would (inTemp has no day
        # stats); everything else keeps loopdata's omit-missing default.
        vh_none = ValueHelper(ValueTuple(None, 'degree_F', 'group_temperature'),
            'day', formatter, converter)
        for spec, expected in [
                ('string()',                    vh_none.string()),
                ('string("missing")',           vh_none.string("missing")),
                ('string(None_string="--")',    vh_none.string(None_string="--")),
                ('format(None_string="--")',    vh_none.format(None_string="--")),
                ('nolabel("%.1f", "--")',       vh_none.nolabel("%.1f", "--")),
                ('round(1).string("--")',       vh_none.round(1).string("--"))]:
            field = 'day.inTemp.avg.%s' % spec
            self.assertEqual(rendered(field).get(field), expected, msg=field)
        for spec in ['format()', 'format("%.1f")', 'nolabel("%.1f")', 'formatted', '']:
            field = 'day.inTemp.avg.%s' % spec if spec else 'day.inTemp.avg'
            self.assertEqual(rendered(field), {}, msg=field)

        # The current path: context is 'current', missing obstypes emit only
        # under explicit None handling.
        pkt = {'dateTime': t_max, 'usUnits': 1, 'outTemp': 80.0}
        def rendered_current(field) -> dict:
            cname = user.loopdata.LoopData.parse_cname(field)
            self.assertIsNotNone(cname, msg='parse failed %s' % field)
            out: dict = {}
            user.loopdata.LoopProcessor.add_current_obstype(
                cname, pkt, out, converter, formatter)
            return out
        vh_cur = ValueHelper(ValueTuple(80.0, 'degree_F', 'group_temperature'),
            'current', formatter, converter)
        field = 'current.outTemp.format("%.2f", add_label=False)'
        self.assertEqual(rendered_current(field).get(field),
            vh_cur.format("%.2f", add_label=False))
        field = 'current.inTemp.string()'
        self.assertEqual(rendered_current(field).get(field), vh_none.string())
        self.assertEqual(rendered_current('current.inTemp.format("%.1f")'), {})

        # The trend path: a not-yet-computable trend (empty accumulator)
        # emits only under explicit None handling.
        baro_descs = user.loopdata.LoopData.construct_baro_trend_descs({})
        empty_accum = user.loopdata.ContinuousAccum(100000, US)
        def rendered_trend(field) -> dict:
            cname = user.loopdata.LoopData.parse_cname(field)
            self.assertIsNotNone(cname, msg='parse failed %s' % field)
            out: dict = {}
            user.loopdata.LoopProcessor.add_trend_obstype(
                cname, empty_accum, pkt, out, 10800, 2.0, baro_descs,
                converter, formatter)
            return out
        field = 'trend.outTemp.string("n/a")'
        self.assertEqual(rendered_trend(field).get(field), 'n/a')
        self.assertEqual(rendered_trend('trend.outTemp.formatted'), {})

    def test_almanac_call_spec(self) -> None:
        # Call-syntax format specs on almanac fields: the trailing call is
        # loopdata's spec, evaluated as the ValueHelper method of the same
        # name -- exactly the report tag's $almanac.sunrise.format("%H:%M").
        from weewx.units import ValueHelper, ValueTuple
        parse = user.loopdata.LoopData.parse_almanac_field

        af = parse('almanac.sunrise.format("%H:%M")')
        assert af is not None
        self.assertEqual(af.chain, [user.loopdata.AlmanacSegment('sunrise', None)])
        self.assertEqual(af.format_spec, 'format')
        self.assertEqual(af.format_kwargs, {'format_string': '%H:%M'})
        self.assertEqual(af.tier, 'day')

        # Bare call-spec names are zero-argument calls; bare renderer specs
        # keep format_kwargs None.
        af = parse('almanac.sunrise.string')
        assert af is not None
        self.assertEqual(af.format_spec, 'string')
        self.assertEqual(af.format_kwargs, {})
        af = parse('almanac.sun.az.ordinal_compass')
        assert af is not None
        self.assertEqual(af.format_spec, 'ordinal_compass')
        self.assertEqual(af.format_kwargs, None)
        self.assertEqual(af.tier, 'continuous')

        # to_json_value renders through the actual ValueHelper, so its output
        # IS the report tag's.
        cfg = ProcessPacketTests._get_config('us', 10800, 10, 6, ['current.outTemp'])
        evaluator = user.loopdata.AlmanacFieldEvaluator(cfg.legacy, cfg)
        vh = ValueHelper(ValueTuple(1593630000, 'unix_epoch', 'group_time'),
            'ephem_day', cfg.legacy.formatter, cfg.legacy.converter)
        af = parse('almanac.sunrise.format("%H:%M")')
        assert af is not None
        self.assertEqual(evaluator.to_json_value(af, vh), vh.format("%H:%M"))
        af = parse('almanac.sunrise.string(None_string="--")')
        assert af is not None
        self.assertEqual(evaluator.to_json_value(af, vh), vh.string(None_string="--"))

        # ordinal_compass is a ValueHelper METHOD (not a property); a bare
        # callable spec is invoked, as Cheetah's auto-call renders it.
        vh_dir = ValueHelper(ValueTuple(225.0, 'degree_compass', 'group_direction'),
            'current', cfg.legacy.formatter, cfg.legacy.converter)
        af = parse('almanac.sun.az.ordinal_compass')
        assert af is not None
        self.assertEqual(evaluator.to_json_value(af, vh_dir),
            vh_dir.ordinal_compass())

        # round(n) on almanac fields: peeled before the spec, applied via
        # ValueHelper.round, so the spec renders the rounded value.
        af = parse('almanac.sun.az.round(1).raw')
        assert af is not None
        self.assertEqual(af.chain, [user.loopdata.AlmanacSegment('sun', None),
                                    user.loopdata.AlmanacSegment('az', None)])
        self.assertEqual(af.round_ndigits, 1)
        self.assertEqual(af.format_spec, 'raw')
        self.assertEqual(af.tier, 'continuous')
        vh_az = ValueHelper(ValueTuple(225.6789, 'degree_compass', 'group_direction'),
            'current', cfg.legacy.formatter, cfg.legacy.converter)
        self.assertEqual(evaluator.to_json_value(af, vh_az), vh_az.round(1).raw)
        af = parse('almanac.sun.az.round(1)')  # no spec: default str() rendering
        assert af is not None
        self.assertEqual(af.round_ndigits, 1)
        self.assertEqual(af.format_spec, None)
        self.assertEqual(evaluator.to_json_value(af, vh_az), str(vh_az.round(1)))
        # round on a plain (non-ValueHelper) value is a TypeError -> the
        # evaluator skips the field, exactly like formatted on a plain value.
        with self.assertRaises(TypeError):
            evaluator.to_json_value(af, 4)

    def test_add_trend_obstype_barometer_code_desc(self) -> None:
        # Pins add_trend_obstype's barometer code/desc routing: for
        # trend.barometer.code the field gets the BarometerTrend enum VALUE;
        # for .desc it gets the description string.  A barometer rise of
        # 0.07 inHg over ~time_delta -> ~2.37 mbar/3h -> RISING (code 2).
        import weewx.units
        US = weewx.units.unit_constants['US']
        converter = weewx.units.Converter(weewx.units.USUnits)
        formatter = weewx.units.Formatter()
        baro_descs = user.loopdata.LoopData.construct_baro_trend_descs({})

        time_delta = 10800
        loop_frequency = 2.0
        # Span the accum across ~time_delta so the trend adjustment factor is ~1.
        t0 = 1000
        t1 = t0 + (time_delta - loop_frequency)  # actual_time_delta == time_delta
        accum = user.loopdata.ContinuousAccum(100000, US)
        accum.addRecord({'dateTime': t0, 'usUnits': 1, 'barometer': 30.00})
        accum.addRecord({'dateTime': t1, 'usUnits': 1, 'barometer': 30.07})

        pkt = {'dateTime': t1, 'usUnits': 1, 'barometer': 30.07}

        def trend_field(spec):
            cname = user.loopdata.LoopData.parse_cname('trend.barometer.%s' % spec)
            self.assertIsNotNone(cname, msg='parse failed for %s' % spec)
            out = {}
            user.loopdata.LoopProcessor.add_trend_obstype(
                cname, accum, pkt, out, time_delta, loop_frequency,
                baro_descs, converter, formatter)
            return out.get(cname.field)

        # code -> the enum value (RISING == 2); desc -> the description string.
        self.assertEqual(trend_field('code'), user.loopdata.BarometerTrend.RISING.value)
        self.assertEqual(trend_field('desc'), 'Rising')

    def test_get_trend_computation(self) -> None:
        # Pins the trend math in get_trend: trend = last - first, adjusted to
        # spread over time_delta:  adj = time_delta / (lasttime - firsttime +
        # loop_frequency) * trend.  Value is independently hand-computed.  US
        # config -> identity conversion for barometer (inHg).
        import weewx.units
        US = weewx.units.unit_constants['US']
        converter = weewx.units.Converter(weewx.units.USUnits)

        # Continuous accum holding two barometer readings.
        accum = user.loopdata.ContinuousAccum(100000, US)
        accum.addRecord({'dateTime': 1000, 'usUnits': 1, 'barometer': 30.00})
        accum.addRecord({'dateTime': 1900, 'usUnits': 1, 'barometer': 30.06})
        self.assertIn('barometer', accum)
        self.assertAlmostEqual(accum['barometer'].first, 30.00)
        self.assertAlmostEqual(accum['barometer'].last, 30.06)

        cname = user.loopdata.LoopData.parse_cname('trend.barometer.raw')
        self.assertIsNotNone(cname)
        pkt = {'dateTime': 1900, 'usUnits': 1, 'barometer': 30.06}
        time_delta = 10800
        loop_frequency = 2.0

        value, unit_type, group_type = user.loopdata.LoopProcessor.get_trend(
            cname, pkt, accum, converter, time_delta, loop_frequency)

        # trend = 30.06 - 30.00 = 0.06
        # actual_time_delta = 1900 - 1000 + 2.0 = 902.0
        # adj = 10800 / 902.0 * 0.06 = 0.718404...
        self.assertAlmostEqual(value, 0.7184035476718404, places=6)

        # Guard branches: identical first/last time -> None (need two readings).
        accum2 = user.loopdata.ContinuousAccum(100000, US)
        accum2.addRecord({'dateTime': 1000, 'usUnits': 1, 'barometer': 30.00})
        v2, _, _ = user.loopdata.LoopProcessor.get_trend(
            cname, pkt, accum2, converter, time_delta, loop_frequency)
        self.assertIsNone(v2)  # only one reading -> firsttime == lasttime

        # Obstype absent from accum -> None.
        cname_missing = user.loopdata.LoopData.parse_cname('trend.outTemp.raw')
        v3, _, _ = user.loopdata.LoopProcessor.get_trend(
            cname_missing, pkt, accum, converter, time_delta, loop_frequency)
        self.assertIsNone(v3)

    def test_period_accum_wrappers_use_correct_spans(self) -> None:
        # Pins the span construction in each create_<period>_accum wrapper: the
        # returned accumulator's timespan must equal the corresponding weeutil
        # span function for the same pkt_time.  weeutil is the spec for what
        # each period's span IS; a wrapper calling the wrong span function (or
        # wrong args) produces a mismatched timespan and is caught.
        import weewx.units, weewx.manager
        US = weewx.units.unit_constants['US']

        # pkt_time: 2020-07-01 12:00:00 PDT (a fixed, unambiguous instant).
        pkt_time = 1593630000
        week_start = 6
        rainyear_start = 1
        archive_interval = 5

        tmpdir = tempfile.mkdtemp()
        dbm = None
        try:
            db_dict = {'database_name': os.path.join(tmpdir, 'test.sdb'),
                       'driver': 'weedb.sqlite'}
            dbm = weewx.manager.DaySummaryManager.open_with_create(
                db_dict, table_name='archive', schema=wview_extended_schema)

            day_accum = weewx.accum.Accum(
                weeutil.weeutil.archiveDaySpan(pkt_time), US)
            day_accum.addRecord(
                {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 70.0}, weight=300)
            obstypes = {'outTemp'}

            def span_of(accum):
                return (accum.timespan.start, accum.timespan.stop)

            # year
            accum, _ = user.loopdata.LoopData.create_year_accum(
                US, archive_interval, obstypes, pkt_time, day_accum, dbm)
            self.assertEqual(span_of(accum),
                (weeutil.weeutil.archiveYearSpan(pkt_time).start,
                 weeutil.weeutil.archiveYearSpan(pkt_time).stop))
            # month
            accum, _ = user.loopdata.LoopData.create_month_accum(
                US, archive_interval, obstypes, pkt_time, day_accum, dbm)
            self.assertEqual(span_of(accum),
                (weeutil.weeutil.archiveMonthSpan(pkt_time).start,
                 weeutil.weeutil.archiveMonthSpan(pkt_time).stop))
            # week
            accum, _ = user.loopdata.LoopData.create_week_accum(
                US, archive_interval, obstypes, pkt_time, week_start, day_accum, dbm)
            self.assertEqual(span_of(accum),
                (weeutil.weeutil.archiveWeekSpan(pkt_time, week_start).start,
                 weeutil.weeutil.archiveWeekSpan(pkt_time, week_start).stop))
            # rainyear
            accum, _ = user.loopdata.LoopData.create_rainyear_accum(
                US, archive_interval, obstypes, pkt_time, rainyear_start, day_accum, dbm)
            self.assertEqual(span_of(accum),
                (weeutil.weeutil.archiveRainYearSpan(pkt_time, rainyear_start).start,
                 weeutil.weeutil.archiveRainYearSpan(pkt_time, rainyear_start).stop))
            # hour
            accum, _ = user.loopdata.LoopData.create_hour_accum(
                US, archive_interval, obstypes, pkt_time, day_accum, dbm)
            self.assertEqual(span_of(accum),
                (weeutil.weeutil.archiveHoursAgoSpan(pkt_time).start,
                 weeutil.weeutil.archiveHoursAgoSpan(pkt_time).stop))
            # alltime (fixed literal span)
            accum, _ = user.loopdata.LoopData.create_alltime_accum(
                US, archive_interval, obstypes, day_accum, dbm)
            self.assertEqual(span_of(accum), (86400, 17514144000))
        finally:
            if dbm is not None:
                dbm.close()
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_period_accum_wrappers_distinct_spans(self) -> None:
        # Reinforces the above: the five dated periods must produce DIFFERENT
        # spans from each other for the same pkt_time, so a wrapper calling
        # another period's span function (e.g. year calling month) is caught
        # even if the absolute-equality check above were somehow satisfied.
        pkt_time = 1593630000
        spans = {
            'year': weeutil.weeutil.archiveYearSpan(pkt_time),
            'month': weeutil.weeutil.archiveMonthSpan(pkt_time),
            'week': weeutil.weeutil.archiveWeekSpan(pkt_time, 6),
            'hour': weeutil.weeutil.archiveHoursAgoSpan(pkt_time),
        }
        pairs = [(a.start, a.stop) for a in spans.values()]
        self.assertEqual(len(set(pairs)), len(pairs), msg='period spans not all distinct')

    def test_continuous_firstlast_accum_empty(self) -> None:
        # A fresh (empty) ContinuousFirstLastAccum must return None from every
        # accessor rather than indexing an empty list.  This pins the empty
        # guards on first/firsttime/last/lasttime and getStatsTuple -- the
        # guards added specifically to prevent the IndexError that an unguarded
        # getStatsTuple would raise.
        fl = user.loopdata.ContinuousFirstLastAccum(timelength=100)
        self.assertIsNone(fl.first)
        self.assertIsNone(fl.firsttime)
        self.assertIsNone(fl.last)
        self.assertIsNone(fl.lasttime)
        self.assertEqual(fl.getStatsTuple(), (None, None, None, None))

    def test_firstlast_obstype_end_to_end(self) -> None:
        # Exercises the newly-implemented firstlast support end to end, mirroring
        # weewx's own test_Accum_with_string approach: register a string obstype
        # as a firstlast accumulator, feed it through a ContinuousAccum, then
        # dispatch first/last/firsttime/lasttime through add_period_obstype.
        # Verifies (1) type preservation (no str() coercion) and (2) correct
        # first/last selection.
        import weewx.units, weewx.accum
        US = weewx.units.unit_constants['US']
        converter = weewx.units.Converter(weewx.units.USUnits)
        formatter = weewx.units.Formatter()

        # Register a firstlast string obstype (cleaned up in finally).
        weewx.accum.accum_dict.extend(
            {'stringType': {'accumulator': 'firstlast', 'extractor': 'last'}})
        try:
            accum = user.loopdata.ContinuousAccum(100000, US)
            accum.addRecord({'dateTime': 1000, 'usUnits': 1, 'stringType': 'alpha'})
            accum.addRecord({'dateTime': 1500, 'usUnits': 1, 'stringType': 'beta'})
            accum.addRecord({'dateTime': 2000, 'usUnits': 1, 'stringType': 'gamma'})

            self.assertIn('stringType', accum)
            stats = accum['stringType']
            self.assertIsInstance(stats, user.loopdata.ContinuousFirstLastAccum)
            # Type preserved (strings stored as-is, not via str() of something).
            self.assertEqual(stats.first, 'alpha')
            self.assertEqual(stats.last, 'gamma')
            self.assertEqual(stats.firsttime, 1000)
            self.assertEqual(stats.lasttime, 2000)

            def field(agg):
                cname = user.loopdata.LoopData.parse_cname('day.stringType.%s' % agg)
                self.assertIsNotNone(cname, msg='parse failed for %s' % agg)
                out = {}
                user.loopdata.LoopProcessor.add_period_obstype(
                    cname, accum, out, converter, formatter)
                return out.get(cname.field)

            # first/last emit the string value as-is (string bypass).
            self.assertEqual(field('first'), 'alpha')
            self.assertEqual(field('last'), 'gamma')
            # firsttime/lasttime are timestamps (numeric, routed/formatted).
            # The raw form pins the exact value.
            cname_ft = user.loopdata.LoopData.parse_cname('day.stringType.firsttime.raw')
            out_ft = {}
            user.loopdata.LoopProcessor.add_period_obstype(
                cname_ft, accum, out_ft, converter, formatter)
            self.assertEqual(out_ft.get('day.stringType.firsttime.raw'), 1000)

            cname_lt = user.loopdata.LoopData.parse_cname('day.stringType.lasttime.raw')
            out_lt = {}
            user.loopdata.LoopProcessor.add_period_obstype(
                cname_lt, accum, out_lt, converter, formatter)
            self.assertEqual(out_lt.get('day.stringType.lasttime.raw'), 2000)

            # Rolling-window correctness: as the oldest entries expire off the
            # front, 'first' must advance to the next survivor (this is why the
            # full values_list is kept, not just two endpoints).
            # Nothing expired yet at a ts well within the window:
            stats.trimExpiredEntries(50000)
            self.assertEqual(stats.first, 'alpha')
            self.assertEqual(stats.last, 'gamma')
            # Expire alpha (added at 1000, timelength 100000): the FirstLast trim
            # condition is dateTime + timelength <= ts, so ts = 1000 + 100000
            # ages alpha out and 'first' advances to beta.
            stats.trimExpiredEntries(1000 + 100000)
            self.assertEqual(stats.first, 'beta')
            self.assertEqual(stats.firsttime, 1500)
            self.assertEqual(stats.last, 'gamma')   # last unchanged
        finally:
            # Remove the synthetic obstype so other tests are unaffected.
            # accum_dict is a ChainMap; the entry added by extend() may live in
            # a layer that does not support del by key, so guard it.
            try:
                maps = getattr(weewx.accum.accum_dict, 'maps', [weewx.accum.accum_dict])
                for m in maps:
                    if 'stringType' in m:
                        del m['stringType']
            except Exception:
                pass

    def test_continuous_firstlast_accum_basic(self) -> None:
        # ContinuousFirstLastAccum: collects first/last string observations over
        # a rolling window.  (Note: this accumulator type is registered but the
        # 'firstlast' agg is not currently surfaced through add_period_obstype;
        # this exercises the class directly.)
        FL = user.loopdata.ContinuousFirstLastAccum

        fl = FL(timelength=120)
        # None is skipped by addSum.
        fl.addSum(100, None)
        # First real value.
        fl.addSum(110, 'alpha')
        fl.addSum(120, 'omega')
        # getStatsTuple -> (first_value, first_time, last_value, last_time).
        self.assertEqual(fl.getStatsTuple(), ('alpha', 110, 'omega', 120))

        # trimExpiredEntries removes entries whose dateTime + timelength <= ts.
        # 'alpha' (110) expires once ts >= 230; 'omega' (120) once ts >= 240.
        fl.trimExpiredEntries(235)
        self.assertEqual(fl.getStatsTuple(), ('omega', 120, 'omega', 120))

        # Exact-boundary: trimming at exactly omega's expiration (120+120=240)
        # must remove it (the condition is dateTime + timelength <= ts), leaving
        # the values_list empty.  (getStatsTuple has no empty guard and the
        # 'firstlast' agg is not surfaced in production, so we check the list
        # directly rather than calling getStatsTuple on an empty accumulator.)
        fl.trimExpiredEntries(240)
        self.assertEqual(len(fl.values_list), 0)

    def test_continuous_vec_dir_wraparound_and_zero_vector(self) -> None:
        # Pins two vec_dir branches:
        #  (1) the negative-angle wraparound (_result < 0 -> += 360);
        #  (2) the zero-vector fallback: when xsum == ysum == 0 (vectors cancel)
        #      but dirsumtime > 0, vec_dir returns the LAST known direction.
        CV = user.loopdata.ContinuousVecStats

        # (1) A vector pointing up-and-left (NW quadrant in math axes) yields
        # 90 - atan2 > 90 deg negative, triggering the += 360 wraparound.
        # Two NW observations so the resultant is unambiguous.
        v = CV(timelength=1000)
        v.addSum(100, (10.0, 315.0), weight=2)   # NW
        v.addSum(200, (10.0, 315.0), weight=2)   # NW again
        # 315 deg compass -> vec_dir should report ~315 (wraparound applied).
        self.assertAlmostEqual(v.vec_dir, 315.0, places=4)

        # (2) Calm wind (speed 0 with a direction) credits dirsumtime but
        # contributes EXACTLY zero to xsum/ysum (unlike opposing non-zero
        # vectors, which leave floating-point dust and miss this branch).  With
        # xsum == ysum == 0 and dirsumtime > 0, vec_dir falls back to the last
        # known direction.
        v2 = CV(timelength=1000)
        v2.addSum(100, (0.0, 123.0), weight=2)   # calm, direction 123
        self.assertEqual(v2.xsum, 0.0)           # exactly zero
        self.assertEqual(v2.ysum, 0.0)
        self.assertEqual(v2.vec_dir, 123.0)      # last known direction

        # (3) A due-NORTH vector pins two more vec_dir branches:
        #   - line 485 (_result < 0): North gives _result == 0.0 exactly, where
        #     '<' yields no wraparound (vec_dir 0.0) but a mutated '<=' would
        #     wrap to 360.0;
        #   - line 483 (ysum or xsum): North has ysum != 0 but xsum ~ 0, so
        #     'ysum or xsum' is truthy while a mutated 'ysum and xsum' is falsy
        #     (which would wrongly take the fallback).
        v3 = CV(timelength=1000)
        v3.addSum(100, (10.0, 0.0), weight=2)    # North
        v3.addSum(200, (10.0, 0.0), weight=2)    # North
        self.assertEqual(v3.vec_dir, 0.0)        # NOT 360.0, NOT the fallback

        # (4) line 483: 'if dirsumtime and (ysum or xsum)'.  To distinguish the
        # 'or' from a mutated 'and', exactly ONE of xsum/ysum must be zero and
        # the other non-zero.  Real compass vectors leave cos/sin dust, so set
        # the internal state directly: xsum exactly 0, ysum non-zero.  With
        # 'or' the guard is truthy (compute a direction); with 'and' it would be
        # falsy (wrongly take the fallback).
        v4 = CV(timelength=1000)
        v4.addSum(100, (10.0, 45.0), weight=2)   # establish a 'last' direction
        v4.xsum = 0.0
        v4.ysum = 40.0                           # points due North in math axes
        # dirsumtime is already > 0 from the addSum above.
        self.assertEqual(v4.vec_dir, 0.0)        # 90 - atan2(40,0)=90 -> 0; not fallback (45)

    def test_continuous_vec_ysum_separation(self) -> None:
        # Pins the ysum credit (addSum) and debit (trim) independently of xsum,
        # using a SE vector (dir 135) whose x and y components are equal in
        # magnitude but OPPOSITE in sign -- so a mutation that corrupts only the
        # sin (y) term produces a ysum distinguishable from xsum.
        CV = user.loopdata.ContinuousVecStats

        v = CV(timelength=100)
        v.addSum(100, (10.0, 135.0), weight=2)   # SE: xsum=+14.142, ysum=-14.142
        self.assertAlmostEqual(v.xsum, 14.142135623730951, places=6)
        self.assertAlmostEqual(v.ysum, -14.142135623730951, places=6)

        # Trim it (expiration 200) -> both return to zero.
        v.trimExpiredEntries(200)
        self.assertAlmostEqual(v.xsum, 0.0, places=6)
        self.assertAlmostEqual(v.ysum, 0.0, places=6)

    def test_continuous_accum_units_and_wind(self) -> None:
        # Pins ContinuousAccum unit-system handling and the wind-component skip.
        CA = user.loopdata.ContinuousAccum

        # __init__ with no unit system -> isEmpty True; _check_units adopts the
        # first system, then raises on a mismatch.
        acc = CA(timelength=120)
        self.assertTrue(acc.isEmpty)             # unit_system is None
        acc._check_units(1)                      # adopt US
        self.assertFalse(acc.isEmpty)
        self.assertEqual(acc.unit_system, 1)
        acc._check_units(1)                      # matching -> no raise
        with self.assertRaises(ValueError):
            acc._check_units(16)                 # mismatch (METRIC) -> raise

        # add_wind_value: windDir/windGust/windGustDir are ALL skipped (return
        # early); only windSpeed creates the 'wind' vector accumulator.  Testing
        # all three pins the membership list (removing any element would let
        # that component through).
        acc2 = CA(timelength=120)
        rec = {'dateTime': 1000, 'usUnits': 1, 'windSpeed': 5.0, 'windDir': 90.0,
               'windGust': 8.0, 'windGustDir': 95.0}
        for skipped in ('windDir', 'windGust', 'windGustDir'):
            acc2.add_wind_value(rec, skipped, 1)
            self.assertNotIn('wind', acc2)       # none of these create 'wind'
            self.assertNotIn(skipped, acc2)
        acc2.add_wind_value(rec, 'windSpeed', 1) # processed -> 'wind' + 'windSpeed'
        self.assertIn('wind', acc2)
        self.assertIn('windSpeed', acc2)

    def test_get_trend_guard_branches(self) -> None:
        # get_trend has three early-return guards that fire BEFORE any unit
        # conversion (so converter can be None here):
        #   1. obstype not present in the accumulator
        #   2. first/last is None (empty accumulator)
        #   3. firsttime == lasttime (only one reading -> no trend)
        # Each must return (None, None, None).
        LP = user.loopdata.LoopProcessor
        CA = user.loopdata.ContinuousAccum
        CS = user.loopdata.ContinuousScalarStats

        cname = user.loopdata.LoopData.parse_cname('trend.outTemp')
        self.assertIsNotNone(cname)
        pkt = {'dateTime': 1000, 'usUnits': 1, 'outTemp': 50.0}

        # --- Guard 1: obstype absent from the accumulator. ---
        empty_accum = CA(timelength=10800)
        result = LP.get_trend(cname, pkt, empty_accum, None, 10800, 2.0)
        self.assertEqual(result, (None, None, None))

        # --- Guard 2: obstype present but accumulator empty (first is None). ---
        accum = CA(timelength=10800)
        accum['outTemp'] = CS(timelength=10800)
        result = LP.get_trend(cname, pkt, accum, None, 10800, 2.0)
        self.assertEqual(result, (None, None, None))

        # --- Guard 3: exactly one reading -> firsttime == lasttime. ---
        accum2 = CA(timelength=10800)
        stats = CS(timelength=10800)
        stats.addSum(1000, 50.0, weight=2)
        accum2['outTemp'] = stats
        result = LP.get_trend(cname, pkt, accum2, None, 10800, 2.0)
        self.assertEqual(result, (None, None, None))

    def test_day_wind_vecdir_loop_vs_quantized_archive(self) -> None:
        # Document WHY loopdata's day.wind.vecdir legitimately differs from the
        # WeeWX report's day wind direction on a Davis VP2 using hardware
        # record generation.
        #
        # loopdata vector-averages full-resolution LOOP packets.  The report
        # aggregates ARCHIVE records whose windDir is a single value per
        # interval, QUANTIZED to one of 16 compass points (22.5 deg) -- a
        # documented property of the Davis archive record (Davis spec: wind
        # direction display resolution is 16 points / 22.5 deg on the compass
        # rose).  These are different inputs, so the two day-level vecdir
        # values legitimately differ; neither is "wrong".  loopdata's is the
        # higher-resolution vector direction.
        #
        # IMPORTANT (scope): This test models ONLY the 22.5-degree quantization
        # of the archive direction, which is documented fact.  It does NOT
        # replicate the console's bin-SELECTION algorithm, which Davis has
        # never published and for which community descriptions conflict
        # (sample-count "mode" vs speed-weighted).  To stay independent of that
        # unresolved question, every archive interval below contains samples of
        # a SINGLE true direction, so count-mode and speed-weighted selection
        # necessarily pick the same bin -- the snapped archive direction is
        # unambiguous under either theory.
        #
        # Construction: four intervals whose true directions each sit 10 deg
        # clockwise of a compass point, so each snaps the same rotational way
        # (-10 deg).  The bias therefore accumulates rather than cancels, and
        # the day-level divergence is a clean 10 deg:
        #     true 10.0 -> archive 0.0    (N)
        #     true 32.5 -> archive 22.5   (NNE)
        #     true 55.0 -> archive 45.0   (NE)
        #     true 77.5 -> archive 67.5   (ENE)
        # loopdata (full-res vector avg) -> 43.75 deg
        # archive  (quantized per-interval) -> 33.75 deg
        # vecavg is identical in both paths (a control: this is a direction
        # effect, not a speed effect).
        import math

        speed = 10.0
        true_dirs = [10.0, 32.5, 55.0, 77.5]
        compass_points = [i * 22.5 for i in range(16)]

        def snap_to_compass(deg):
            deg = deg % 360.0
            return min(compass_points,
                       key=lambda c: min(abs(deg - c), 360.0 - abs(deg - c)))

        def vecdir_vecavg(samples, weight):
            # samples: list of (speed, dirN)
            xsum = ysum = sumtime = 0.0
            for s, d in samples:
                theta = math.radians(90.0 - d)
                xsum += weight * s * math.cos(theta)
                ysum += weight * s * math.sin(theta)
                sumtime += weight
            vd = 90.0 - math.degrees(math.atan2(ysum, xsum))
            if vd < 0.0:
                vd += 360.0
            return vd, math.sqrt(xsum ** 2 + ysum ** 2) / sumtime

        # Build loop packets: 3 per interval, all within a single local day,
        # spaced 2s apart (base chosen at midday so no timezone straddles a day
        # boundary over the 22-second span).
        base = 1665838800  # 2022-10-15 13:00:00 UTC -> daytime across US zones
        pkts: List[Dict[str, Any]] = []
        ts = base
        for d in true_dirs:
            for _ in range(3):
                pkts.append({'dateTime': ts, 'usUnits': 1,
                             'windDir': d, 'windGust': speed,
                             'windGustDir': d, 'windrun': None,
                             'windSpeed': speed})
                ts += 2

        wind_fields = ['day.wind.vecdir', 'day.wind.vecdir.raw',
                       'day.wind.vecavg', 'day.wind.vecavg.raw']

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, wind_fields)
        weight = cfg.loop_frequency

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])
        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # (1) loopdata's day vecdir = full-resolution vector average of all
        # loop samples.
        loop_samples = [(speed, d) for d in true_dirs for _ in range(3)]
        expected_loop_vecdir, expected_loop_vecavg = vecdir_vecavg(loop_samples, weight)
        self.assertAlmostEqual(expected_loop_vecdir, 43.75, places=4)
        self.assertAlmostEqual(loopdata_pkt['day.wind.vecdir.raw'], expected_loop_vecdir, places=4)
        self.assertAlmostEqual(loopdata_pkt['day.wind.vecavg.raw'], expected_loop_vecavg, places=4)

        # (2) The report's path: one quantized record per interval.  Computed
        # here as the reference -- loopdata does not produce this; it is what
        # the archive-based report aggregates.
        archive_records = [(speed, snap_to_compass(d)) for d in true_dirs]
        archive_vecdir, archive_vecavg = vecdir_vecavg(archive_records, weight)
        self.assertAlmostEqual(archive_vecdir, 33.75, places=4)

        # (3) The point of the test: the two legitimately diverge in direction
        # (here by a full 10 deg), while vecavg is identical -- confirming the
        # divergence is purely the direction-quantization effect.
        divergence = abs(((expected_loop_vecdir - archive_vecdir) + 180.0) % 360.0 - 180.0)
        self.assertAlmostEqual(divergence, 10.0, places=4)
        self.assertAlmostEqual(expected_loop_vecavg, archive_vecavg, places=6)

    def test_ip100_packet_processing(self) -> None:
        pkts: List[Dict[str, Any]] = ip100_packets.IP100Packets._get_packets()

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ProcessPacketTests._get_specified_fields())

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])
        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1593883054, 'usUnits': 1, 'outTemp': 71.6, 'barometer': 30.060048358389471, 'dewpoint': 60.48739574937819
        # {'dateTime': 1593883332, 'usUnits': 1, 'outTemp': 72.0, 'barometer': 30.055425865734495, 'dewpoint': 59.57749595318801

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1593883332)
        self.assertEqual(loopdata_pkt['current.dateTime'], '07/04/20 10:22:12')

        self.assertEqual(loopdata_pkt['10m.windGust.max'], '6 mph')
        self.assertEqual(loopdata_pkt['10m.windGust.max.formatted'], '6')
        self.assertEqual(loopdata_pkt['10m.windGust.max.raw'], 6.5)
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime'], '07/04/20 10:18:20')
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime.raw'], 1593883100)

        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '72.1°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.formatted'], '72.1')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.raw'], 72.1)
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime'], '07/04/20 10:22:02')
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime.raw'], 1593883322)

        self.assertEqual(loopdata_pkt['hour.windGust.max'], '6 mph')
        self.assertEqual(loopdata_pkt['hour.windGust.max.formatted'], '6')
        self.assertEqual(loopdata_pkt['hour.windGust.max.raw'], 6.5)
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime'], '10:18')
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime.raw'], 1593883100)

        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '72.1°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.formatted'], '72.1')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.raw'], 72.1)
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime'], '10:22')
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime.raw'], 1593883322)

        self.assertEqual(loopdata_pkt['current.outTemp'], '72.0°F')
        self.assertEqual(loopdata_pkt['current.barometer'], '30.055 inHg')
        self.assertEqual(loopdata_pkt['current.windSpeed'], '6 mph')
        self.assertEqual(loopdata_pkt['current.windDir'], '45°')
        self.assertEqual(loopdata_pkt['current.windDir.ordinal_compass'], 'NE')

        # 30.055425865734495 - 30.060048358389471
        self.assertEqual(loopdata_pkt['trend.barometer'], '-0.178 inHg')
        self.assertAlmostEqual(loopdata_pkt['trend.barometer.raw'], -0.1782961, 7)
        self.assertEqual(loopdata_pkt['trend.barometer.formatted'], '-0.178')
        self.assertEqual(loopdata_pkt['trend.barometer.code'], -4)
        self.assertEqual(loopdata_pkt['trend.barometer.desc'], 'Falling Very Rapidly')

        # 72.0 - 71.6
        self.assertEqual(loopdata_pkt['trend.outTemp'], '15.4°F')
        self.assertAlmostEqual(loopdata_pkt['trend.outTemp.raw'],  15.4285714, 7)
        self.assertEqual(loopdata_pkt['trend.outTemp.formatted'], '15.4')

        # 59.57749595318801 - 60.48739574937819
        self.assertEqual(loopdata_pkt['trend.dewpoint'], '-35.1°F')
        self.assertAlmostEqual(loopdata_pkt['trend.dewpoint.raw'], -35.0961350, 7)
        self.assertEqual(loopdata_pkt['trend.dewpoint.formatted'], '-35.1')

        self.assertEqual(loopdata_pkt['day.rain.sum'], '0.00 in')
        self.assertEqual(loopdata_pkt['day.rain.sum.formatted'], '0.00')
        self.assertEqual(loopdata_pkt['unit.label.rain'], ' in')

        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '72.1°F')
        self.assertEqual(loopdata_pkt['day.barometer.avg'], '30.055 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '3 mph')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '88°')
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '26°')

        self.assertEqual(loopdata_pkt['day.outTemp.max'], '89.6°F')
        self.assertEqual(loopdata_pkt['day.barometer.max'], '30.060 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '17 mph')
        self.assertEqual(loopdata_pkt['day.windDir.max'], '360°')

        self.assertEqual(loopdata_pkt['day.outTemp.min'], '71.4°F')
        self.assertEqual(loopdata_pkt['day.barometer.min'], '30.055 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '1 mph')
        self.assertEqual(loopdata_pkt['day.windDir.min'], '22°')

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')
        self.assertEqual(loopdata_pkt['unit.label.barometer'], ' inHg')
        self.assertEqual(loopdata_pkt['unit.label.windSpeed'], ' mph')
        self.assertEqual(loopdata_pkt['unit.label.windDir'], '°')

        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime'], '06:40:00')
        self.assertEqual(loopdata_pkt['day.wind.max.formatted'], '20')
        self.assertEqual(loopdata_pkt['day.wind.max'], '20 mph')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.formatted'], '244')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.ordinal_compass'], 'WSW')
        self.assertEqual(loopdata_pkt['day.wind.gustdir'], '244°')

        self.assertEqual(loopdata_pkt['day.wind.mintime'], '10:17:48')
        self.assertEqual(loopdata_pkt['day.wind.min.formatted'], '1')
        self.assertEqual(loopdata_pkt['day.wind.min'], '1 mph')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['day.wind.avg.formatted'], '3')
        self.assertEqual(loopdata_pkt['day.wind.avg'], '3 mph')

        self.assertEqual(loopdata_pkt['day.wind.rms.formatted'], '4')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '4 mph')

        self.assertEqual(loopdata_pkt['day.wind.vecavg.formatted'], '3')
        self.assertEqual(loopdata_pkt['day.wind.vecavg'], '3 mph')

        self.assertEqual(loopdata_pkt['day.wind.vecdir.formatted'], '26')
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '26°')

    def test_ip100_us_packets_to_metric_db_to_us_report_processing(self) -> None:
        pkts: List[Dict[str, Any]] = ip100_packets.IP100Packets._get_packets()

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('db-metric.report-us', 10800, 10, 6, ProcessPacketTests._get_specified_fields())

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])
        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1593883054, 'usUnits': 1, 'outTemp': 71.6, 'barometer': 30.060048358389471, 'dewpoint': 60.48739574937819
        # {'dateTime': 1593883332, 'usUnits': 1, 'outTemp': 72.0, 'barometer': 30.055425865734495, 'dewpoint': 59.57749595318801

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1593883332)
        self.assertEqual(loopdata_pkt['current.dateTime'], '07/04/20 10:22:12')

        self.assertEqual(loopdata_pkt['10m.windGust.max'], '7 mph')
        self.assertEqual(loopdata_pkt['10m.windGust.max.formatted'], '7')
        self.assertAlmostEqual(loopdata_pkt['10m.windGust.max.raw'], 6.5000162, 7)
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime'], '07/04/20 10:18:20')
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime.raw'], 1593883100)

        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '72.1°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.formatted'], '72.1')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.raw'], 72.1)
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime'], '07/04/20 10:22:02')
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime.raw'], 1593883322)

        self.assertEqual(loopdata_pkt['current.outTemp'], '72.0°F')
        self.assertEqual(loopdata_pkt['current.barometer'], '30.055 inHg')
        self.assertEqual(loopdata_pkt['current.windSpeed'], '6 mph')
        self.assertEqual(loopdata_pkt['current.windDir'], '45°')
        self.assertEqual(loopdata_pkt['current.windDir.ordinal_compass'], 'NE')

        # 30.055425865734495 - 30.060048358389471
        self.assertEqual(loopdata_pkt['trend.barometer'], '-0.178 inHg')
        self.assertAlmostEqual(loopdata_pkt['trend.barometer.raw'], -0.1782961, 7)
        self.assertEqual(loopdata_pkt['trend.barometer.formatted'], '-0.178')
        self.assertEqual(loopdata_pkt['trend.barometer.code'], -4)
        self.assertEqual(loopdata_pkt['trend.barometer.desc'], 'Falling Very Rapidly')

        # 72.0 - 71.6
        self.assertEqual(loopdata_pkt['trend.outTemp'], '15.4°F')
        self.assertAlmostEqual(loopdata_pkt['trend.outTemp.raw'], 15.4285714, 7)
        self.assertEqual(loopdata_pkt['trend.outTemp.formatted'], '15.4')

        # 59.57749595318801 - 60.48739574937819
        self.assertEqual(loopdata_pkt['trend.dewpoint'], '-35.1°F')
        self.assertAlmostEqual(loopdata_pkt['trend.dewpoint.raw'], -35.0961350, 7)
        self.assertEqual(loopdata_pkt['trend.dewpoint.formatted'], '-35.1')

        self.assertEqual(loopdata_pkt['day.rain.sum'], '0.00 in')
        self.assertEqual(loopdata_pkt['day.rain.sum.formatted'], '0.00')
        self.assertEqual(loopdata_pkt['unit.label.rain'], ' in')

        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '72.1°F')
        self.assertEqual(loopdata_pkt['day.barometer.avg'], '30.055 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '3 mph')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '88°')
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '26°')

        self.assertEqual(loopdata_pkt['day.outTemp.max'], '89.6°F')
        self.assertEqual(loopdata_pkt['day.barometer.max'], '30.060 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '17 mph')
        self.assertEqual(loopdata_pkt['day.windDir.max'], '360°')

        self.assertEqual(loopdata_pkt['day.outTemp.min'], '71.4°F')
        self.assertEqual(loopdata_pkt['day.barometer.min'], '30.055 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '1 mph')
        self.assertEqual(loopdata_pkt['day.windDir.min'], '22°')

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')
        self.assertEqual(loopdata_pkt['unit.label.barometer'], ' inHg')
        self.assertEqual(loopdata_pkt['unit.label.windSpeed'], ' mph')
        self.assertEqual(loopdata_pkt['unit.label.windDir'], '°')

        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime'], '06:40:00')
        self.assertEqual(loopdata_pkt['day.wind.max.formatted'], '20')
        self.assertEqual(loopdata_pkt['day.wind.max'], '20 mph')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.formatted'], '244')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.ordinal_compass'], 'WSW')
        self.assertEqual(loopdata_pkt['day.wind.gustdir'], '244°')

        self.assertEqual(loopdata_pkt['day.wind.mintime'], '10:17:48')
        self.assertEqual(loopdata_pkt['day.wind.min.formatted'], '1')
        self.assertEqual(loopdata_pkt['day.wind.min'], '1 mph')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['day.wind.avg.formatted'], '3')
        self.assertEqual(loopdata_pkt['day.wind.avg'], '3 mph')

        self.assertEqual(loopdata_pkt['day.wind.rms.formatted'], '4')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '4 mph')

        self.assertEqual(loopdata_pkt['day.wind.vecavg.formatted'], '3')
        self.assertEqual(loopdata_pkt['day.wind.vecavg'], '3 mph')

        self.assertEqual(loopdata_pkt['day.wind.vecdir.formatted'], '26')
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '26°')

    def test_vantage_pro2_packet_processing(self) -> None:
        pkts: List[Dict[str, Any]] = vantagepro2_packets.VantagePro2Packets._get_batch_one_packets()

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ProcessPacketTests._get_specified_fields())

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])

        # Batch One
        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'altimeter': '29.7797704917861', 'appTemp': '63.987293613602574', 'barometer': '29.777', 'cloudbase': '1277.245423375492', 'consBatteryVoltage': '3.78', 'dateTime': '1665797353', 'dayET': '0.087', 'dayRain': '0.0', 'dewpoint': '56.828520137147834', 'ET': 'None', 'extraAlarm1': '0', 'extraAlarm2': '0', 'extraAlarm3': '0', 'extraAlarm4': '0', 'extraAlarm5': '0', 'extraAlarm6': '0', 'extraAlarm7': '0', 'extraAlarm8': '0', 'extraHumid1': '63.0', 'extraHumid2': '50.0', 'extraTemp1': '72.0', 'extraTemp2': '76.9', 'forecastIcon': '6', 'forecastRule': '190', 'heatindex': '62.194', 'humidex': '68.24125795353245', 'inDewpoint': '58.70188105843598', 'inHumidity': '63.0', 'insideAlarm': '0', 'inTemp': '72.0', 'maxSolarRad': '0.004442804340921485', 'monthET': '1.49', 'monthRain': '0.0', 'outHumidity': '82.0', 'outsideAlarm1': '0', 'outsideAlarm2': '0', 'outTemp': '62.4', 'pm1_0': '4.6875', 'pm2_5': '5.080500000000001', 'pm2_5_aqi': '21', 'pm2_5_aqi_color': '32768', 'pm10_0': '8.0', 'pressure': '29.765246956632804', 'radiation': '5.0', 'rain': '0.0', 'rainAlarm': '0', 'rainRate': '0.0', 'soilLeafAlarm1': '0', 'soilLeafAlarm2': '0', 'soilLeafAlarm3': '0', 'soilLeafAlarm4': '0', 'stormRain': '0.0', 'sunrise': '1665756960', 'sunset': '1665797520', 'txBatteryStatus': '0', 'usUnits': '1', 'UV': '0.0', 'windchill': '62.4', 'windDir': '296.0', 'windGust': '3.0', 'windGustDir': '77.0', 'windrun': 'None', 'windSpeed': '1.0', 'windSpeed10': '2.0', 'yearET': '45.86', 'yearRain': '0.0'}])

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1665797353)
        self.assertEqual(loopdata_pkt['current.dateTime'], '10/14/22 18:29:13')

        self.assertEqual(loopdata_pkt['2m.windGust.max'], '3 mph')
        self.assertEqual(loopdata_pkt['2m.windGust.max.formatted'], '3')
        self.assertEqual(loopdata_pkt['2m.windGust.max.raw'], 3.0)
        self.assertEqual(loopdata_pkt['2m.windGust.maxtime'], '10/14/22 18:27:15')
        self.assertEqual(loopdata_pkt['2m.windGust.maxtime.raw'], 1665797235)

        self.assertEqual(loopdata_pkt['2m.outTemp.max'], '62.5°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.max.formatted'], '62.5')
        self.assertEqual(loopdata_pkt['2m.outTemp.max.raw'], 62.5)
        self.assertEqual(loopdata_pkt['2m.outTemp.maxtime'], '10/14/22 18:27:15')
        self.assertEqual(loopdata_pkt['2m.outTemp.maxtime.raw'], 1665797235)

        self.assertEqual(loopdata_pkt['10m.windGust.max'], '5 mph')
        self.assertEqual(loopdata_pkt['10m.windGust.max.formatted'], '5')
        self.assertEqual(loopdata_pkt['10m.windGust.max.raw'], 5.0)
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime'], '10/14/22 18:23:53')
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime.raw'], 1665797033)

        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '62.9°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.formatted'], '62.9')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.raw'], 62.9)
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime'], '10/14/22 18:22:47')
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime.raw'], 1665796967)

        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '62.4°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min.formatted'], '62.4')
        self.assertEqual(loopdata_pkt['10m.outTemp.min.raw'], 62.4)
        self.assertEqual(loopdata_pkt['10m.outTemp.mintime'], '10/14/22 18:28:37')
        self.assertEqual(loopdata_pkt['10m.outTemp.mintime.raw'], 1665797317)

        self.assertEqual(loopdata_pkt['hour.windGust.max'], '5 mph')
        self.assertEqual(loopdata_pkt['hour.windGust.max.formatted'], '5')
        self.assertEqual(loopdata_pkt['hour.windGust.max.raw'], 5.0)
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime'], '18:23')
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime.raw'], 1665797033)

        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '62.9°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.formatted'], '62.9')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.raw'], 62.9)
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime'], '18:22')
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime.raw'], 1665796967)

        self.assertEqual(loopdata_pkt['current.outTemp'], '62.4°F')
        self.assertEqual(loopdata_pkt['current.barometer'], '29.777 inHg')
        self.assertEqual(loopdata_pkt['current.windSpeed'], '1 mph')
        self.assertEqual(loopdata_pkt.get('current.windDir'), '296°')
        self.assertEqual(loopdata_pkt.get('current.windDir.ordinal_compass'), 'WNW')

        self.assertEqual(loopdata_pkt['trend.barometer'], '0.167 inHg')
        self.assertAlmostEqual(loopdata_pkt['trend.barometer.raw'], 0.1670103, 7)
        self.assertEqual(loopdata_pkt['trend.barometer.formatted'], '0.167')
        self.assertEqual(loopdata_pkt['trend.barometer.code'], 3)
        self.assertEqual(loopdata_pkt['trend.barometer.desc'], 'Rising Quickly')

        #  -0.5               (unajdusted)
        # -13.989637305699482 (adjusted)
        self.assertEqual(loopdata_pkt['trend.outTemp'], '-13.9°F')
        self.assertAlmostEqual(loopdata_pkt['trend.outTemp.raw'], -13.9175258, 7)
        self.assertEqual(loopdata_pkt['trend.outTemp.formatted'], '-13.9')

        # seconds = 1665797353 - 1665796967 = 386s
        # 10800 / 386 = 27.9792746114
        # 56.828520137147834 - 56.828520137147834 = 0.19734268078
        # 0.19734268078 * 27.9792746114 = 5.52150505809
        self.assertEqual(loopdata_pkt['trend.dewpoint'], '5.5°F')
        self.assertAlmostEqual(loopdata_pkt['trend.dewpoint.raw'], 5.4930437, 7)
        self.assertEqual(loopdata_pkt['trend.dewpoint.formatted'], '5.5')

        self.assertEqual(loopdata_pkt['day.rain.sum'], '0.00 in')
        self.assertEqual(loopdata_pkt['day.rain.sum.formatted'], '0.00')
        self.assertEqual(loopdata_pkt['unit.label.rain'], ' in')

        self.assertEqual(loopdata_pkt['day.rain.avg'], '0.00 in')
        self.assertEqual(loopdata_pkt['day.rain.avg.formatted'], '0.00')
        self.assertEqual(loopdata_pkt['day.rain.avg.raw'], 0.0)

        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '62.7°F')
        self.assertEqual(loopdata_pkt['day.barometer.avg'], '29.773 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '2 mph')
        self.assertEqual(loopdata_pkt.get('day.windDir.avg'), '207°')
        self.assertEqual(loopdata_pkt.get('day.wind.vecdir'), '343°')

        self.assertEqual(loopdata_pkt['day.outTemp.max'], '62.9°F')
        self.assertEqual(loopdata_pkt['day.barometer.max'], '29.777 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '5 mph')
        self.assertEqual(loopdata_pkt.get('day.windDir.max'), '354°')

        self.assertEqual(loopdata_pkt['day.outTemp.min'], '62.4°F')
        self.assertEqual(loopdata_pkt['day.barometer.min'], '29.771 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '0 mph')
        self.assertEqual(loopdata_pkt.get('day.windDir.min'), '1°')

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')
        self.assertEqual(loopdata_pkt['unit.label.barometer'], ' inHg')
        self.assertEqual(loopdata_pkt['unit.label.windSpeed'], ' mph')
        self.assertEqual(loopdata_pkt['unit.label.windDir'], '°')

        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime'], '18:23:53')
        self.assertEqual(loopdata_pkt['day.wind.max.formatted'], '5')
        self.assertEqual(loopdata_pkt['day.wind.max'], '5 mph')
        self.assertEqual(loopdata_pkt.get('day.wind.gustdir.formatted'), '354')
        self.assertEqual(loopdata_pkt.get('day.wind.gustdir.ordinal_compass'), 'N')
        self.assertEqual(loopdata_pkt.get('day.wind.gustdir'), '354°')

        self.assertEqual(loopdata_pkt['day.wind.mintime'], '18:24:57')
        self.assertEqual(loopdata_pkt['day.wind.min.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.min'], '0 mph')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['day.wind.avg.formatted'], '2')
        self.assertEqual(loopdata_pkt['day.wind.avg'], '2 mph')

        self.assertEqual(loopdata_pkt['day.wind.rms.formatted'], '2')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '2 mph')

        self.assertEqual(loopdata_pkt['day.wind.vecavg.formatted'], '1')
        self.assertEqual(loopdata_pkt['day.wind.vecavg'], '1 mph')

        self.assertEqual(loopdata_pkt.get('day.wind.vecdir.formatted'), '343')
        self.assertEqual(loopdata_pkt.get('day.wind.vecdir'), '343°')

        # Batch Two

        pkts = vantagepro2_packets.VantagePro2Packets._get_batch_two_packets()

        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'altimeter': '29.77677022521029', 'appTemp': '62.44239660171717', 'barometer': '29.774', 'cloudbase': '1198.7225365853292', 'consBatteryVoltage': '3.78', 'dateTime': '1665797745', 'dayET': '0.087', 'dayRain': '0.0', 'dewpoint': '56.77402083902455', 'ET': 'None', 'extraAlarm1': '0', 'extraAlarm2': '0', 'extraAlarm3': '0', 'extraAlarm4': '0', 'extraAlarm5': '0', 'extraAlarm6': '0', 'extraAlarm7': '0', 'extraAlarm8': '0', 'extraHumid1': '63.0', 'extraHumid2': '50.0', 'extraTemp1': '72.0', 'extraTemp2': '77.0', 'forecastIcon': '6', 'forecastRule': '190', 'heatindex': '61.801', 'humidex': '67.80972824587653', 'inDewpoint': '58.70188105843598', 'inHumidity': '63.0', 'insideAlarm': '0', 'inTemp': '72.0', 'maxSolarRad': '0.0', 'monthET': '1.49', 'monthRain': '0.0', 'outHumidity': '83.0', 'outsideAlarm1': '0', 'outsideAlarm2': '0', 'outTemp': '62.0', 'pm1_0': '5.5', 'pm2_5': '5.0920000000000005', 'pm2_5_aqi': '21', 'pm2_5_aqi_color': '32768', 'pm10_0': '8.5', 'pressure': '29.762248005689198', 'radiation': '0.0', 'rain': '0.0', 'rainAlarm': '0', 'rainRate': '0.0', 'soilLeafAlarm1': '0', 'soilLeafAlarm2': '0', 'soilLeafAlarm3': '0', 'soilLeafAlarm4': '0', 'stormRain': '0.0', 'sunrise': '1665756960', 'sunset': '1665797520', 'txBatteryStatus': '0', 'usUnits': '1', 'UV': '0.0', 'windchill': '62.0', 'windDir': '321.0', 'windGust': '3.0', 'windGustDir': '274.0', 'windrun': 'None', 'windSpeed': '3.0', 'windSpeed10': '1.0', 'yearET': '45.86', 'yearRain': '0.0'}])

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1665797745)
        self.assertEqual(loopdata_pkt['current.dateTime'], '10/14/22 18:35:45')

        self.assertEqual(loopdata_pkt['2m.windGust.max'], '4 mph')
        self.assertEqual(loopdata_pkt['2m.windGust.max.formatted'], '4')
        self.assertEqual(loopdata_pkt['2m.windGust.max.raw'], 4.0)
        self.assertEqual(loopdata_pkt['2m.windGust.maxtime'], '10/14/22 18:33:47')
        self.assertEqual(loopdata_pkt['2m.windGust.maxtime.raw'], 1665797627)

        self.assertEqual(loopdata_pkt['2m.outTemp.max'], '62.1°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.max.formatted'], '62.1')
        self.assertEqual(loopdata_pkt['2m.outTemp.max.raw'], 62.1)
        self.assertEqual(loopdata_pkt['2m.outTemp.maxtime'], '10/14/22 18:33:47')
        self.assertEqual(loopdata_pkt['2m.outTemp.maxtime.raw'], 1665797627)

        self.assertEqual(loopdata_pkt['10m.windGust.max'], '4 mph')
        self.assertEqual(loopdata_pkt['10m.windGust.max.formatted'], '4')
        self.assertEqual(loopdata_pkt['10m.windGust.max.raw'], 4.0)
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime'], '10/14/22 18:30:04')
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime.raw'], 1665797404)

        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '62.7°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.formatted'], '62.7')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.raw'], 62.7)
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime'], '10/14/22 18:25:47')
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime.raw'], 1665797147)

        self.assertEqual(loopdata_pkt['10m.outTemp.min'], '62.0°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.min.formatted'], '62.0')
        self.assertEqual(loopdata_pkt['10m.outTemp.min.raw'], 62.0)
        self.assertEqual(loopdata_pkt['10m.outTemp.mintime'], '10/14/22 18:34:35')
        self.assertEqual(loopdata_pkt['10m.outTemp.mintime.raw'], 1665797675)

        self.assertEqual(loopdata_pkt['hour.windGust.max'], '5 mph')
        self.assertEqual(loopdata_pkt['hour.windGust.max.formatted'], '5')
        self.assertEqual(loopdata_pkt['hour.windGust.max.raw'], 5.0)
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime'], '18:23')
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime.raw'], 1665797033)

        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '62.9°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.formatted'], '62.9')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.raw'], 62.9)
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime'], '18:22')
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime.raw'], 1665796967)

        self.assertEqual(loopdata_pkt['current.outTemp'], '62.0°F')
        self.assertEqual(loopdata_pkt['current.barometer'], '29.774 inHg')
        self.assertEqual(loopdata_pkt['current.windSpeed'], '3 mph')
        self.assertEqual(loopdata_pkt.get('current.windDir'), '321°')
        self.assertEqual(loopdata_pkt.get('current.windDir.ordinal_compass'), 'NW')

        self.assertEqual(loopdata_pkt['trend.barometer'], '0.042 inHg')
        self.assertAlmostEqual(loopdata_pkt['trend.barometer.raw'], 0.0415385, 7)
        self.assertEqual(loopdata_pkt['trend.barometer.formatted'], '0.042')
        self.assertEqual(loopdata_pkt['trend.barometer.code'], 1)
        self.assertEqual(loopdata_pkt['trend.barometer.desc'], 'Rising Slowly')

        self.assertEqual(loopdata_pkt['trend.outTemp'], '-12.5°F')
        self.assertAlmostEqual(loopdata_pkt['trend.outTemp.raw'], -12.4615385, 7)
        self.assertEqual(loopdata_pkt['trend.outTemp.formatted'], '-12.5')

        self.assertEqual(loopdata_pkt['trend.dewpoint'], '2.0°F')
        self.assertAlmostEqual(loopdata_pkt['trend.dewpoint.raw'], 1.9778315, 7)
        self.assertEqual(loopdata_pkt['trend.dewpoint.formatted'], '2.0')

        self.assertEqual(loopdata_pkt['day.rain.sum'], '0.00 in')
        self.assertEqual(loopdata_pkt['day.rain.sum.formatted'], '0.00')
        self.assertEqual(loopdata_pkt['unit.label.rain'], ' in')

        self.assertEqual(loopdata_pkt['day.rain.avg'], '0.00 in')
        self.assertEqual(loopdata_pkt['day.rain.avg.formatted'], '0.00')
        self.assertEqual(loopdata_pkt['day.rain.avg.raw'], 0.0)

        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '62.4°F')
        self.assertEqual(loopdata_pkt['day.barometer.avg'], '29.774 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '1 mph')
        self.assertEqual(loopdata_pkt.get('day.windDir.avg'), '226°')

        self.assertEqual(loopdata_pkt['day.outTemp.max'], '62.9°F')
        self.assertEqual(loopdata_pkt['day.barometer.max'], '29.777 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '5 mph')
        self.assertEqual(loopdata_pkt.get('day.windDir.max'), '354°')

        self.assertEqual(loopdata_pkt['day.outTemp.min'], '62.0°F')
        self.assertEqual(loopdata_pkt['day.barometer.min'], '29.771 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '0 mph')
        self.assertEqual(loopdata_pkt.get('day.windDir.min'), '1°')

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')
        self.assertEqual(loopdata_pkt['unit.label.barometer'], ' inHg')
        self.assertEqual(loopdata_pkt['unit.label.windSpeed'], ' mph')
        self.assertEqual(loopdata_pkt['unit.label.windDir'], '°')

        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime'], '18:23:53')
        self.assertEqual(loopdata_pkt['day.wind.max.formatted'], '5')
        self.assertEqual(loopdata_pkt['day.wind.max'], '5 mph')
        self.assertEqual(loopdata_pkt.get('day.wind.gustdir.formatted'), '354')
        self.assertEqual(loopdata_pkt.get('day.wind.gustdir.ordinal_compass'), 'N')
        self.assertEqual(loopdata_pkt.get('day.wind.gustdir'), '354°')

        self.assertEqual(loopdata_pkt['day.wind.mintime'], '18:24:57')
        self.assertEqual(loopdata_pkt['day.wind.min.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.min'], '0 mph')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['day.wind.avg.formatted'], '1')
        self.assertEqual(loopdata_pkt['day.wind.avg'], '1 mph')

        self.assertEqual(loopdata_pkt['day.wind.rms.formatted'], '2')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '2 mph')

        self.assertEqual(loopdata_pkt['day.wind.vecavg.formatted'], '1')
        self.assertEqual(loopdata_pkt['day.wind.vecavg'], '1 mph')

        self.assertEqual(loopdata_pkt.get('day.wind.vecdir.formatted'), '332')
        self.assertEqual(loopdata_pkt.get('day.wind.vecdir'), '332°')

    def test_custom_time_delta(self) -> None:
        pkts: List[Dict[str, Any]] = vantagepro2_packets.VantagePro2Packets._get_batch_one_packets()

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 600, 10, 6, ProcessPacketTests._get_specified_fields())

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])

        # Batch One
        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['trend.barometer'], '0.009 inHg')
        self.assertAlmostEqual(loopdata_pkt['trend.barometer.raw'], 0.0092784, 7)
        self.assertEqual(loopdata_pkt['trend.barometer.formatted'], '0.009')
        self.assertEqual(loopdata_pkt['trend.barometer.code'], 3)
        self.assertEqual(loopdata_pkt['trend.barometer.desc'], 'Rising Quickly')

        self.assertEqual(loopdata_pkt['trend.outTemp'], '-0.8°F')
        self.assertAlmostEqual(loopdata_pkt['trend.outTemp.raw'], -0.7731959, 7)
        self.assertEqual(loopdata_pkt['trend.outTemp.formatted'], '-0.8')

        # seconds = 1665797353 - 1665796967 = 386s
        # 10800 / 386 = 27.9792746114
        # 56.828520137147834 - 56.828520137147834 = 0.19734268078
        # 0.19734268078 * 27.9792746114 = 5.52150505809
        self.assertEqual(loopdata_pkt['trend.dewpoint'], '0.3°F')
        self.assertAlmostEqual(loopdata_pkt['trend.dewpoint.raw'], 0.3051691, 7)
        self.assertEqual(loopdata_pkt['trend.dewpoint.formatted'], '0.3')

        # Batch Two

        pkts = vantagepro2_packets.VantagePro2Packets._get_batch_two_packets()

        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['trend.barometer'], '0.002 inHg')
        self.assertAlmostEqual(loopdata_pkt['trend.barometer.raw'], 0.002, 7)
        self.assertEqual(loopdata_pkt['trend.barometer.formatted'], '0.002')
        self.assertEqual(loopdata_pkt['trend.barometer.code'], 1)
        self.assertEqual(loopdata_pkt['trend.barometer.desc'], 'Rising Slowly')

        self.assertEqual(loopdata_pkt['trend.outTemp'], '-0.7°F')
        self.assertAlmostEqual(loopdata_pkt['trend.outTemp.raw'], -0.7, 7)
        self.assertEqual(loopdata_pkt['trend.outTemp.formatted'], '-0.7')

        self.assertEqual(loopdata_pkt['trend.dewpoint'], '0.3°F')
        self.assertAlmostEqual(loopdata_pkt['trend.dewpoint.raw'], 0.33741600247, 7)
        self.assertEqual(loopdata_pkt['trend.dewpoint.formatted'], '0.3')

    def test_cc3000_packet_processing(self) -> None:
        pkts: List[Dict[str, Any]] = cc3000_packets.CC3000Packets._get_packets()

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ProcessPacketTests._get_specified_fields())

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])

        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1593975030, 'outTemp': 76.1, 'barometer': 30.014857385736513, 'dewpoint': 54.73645937493746
        # {'dateTime': 1593975366, 'outTemp': 75.4, 'barometer': 30.005222168998216, 'dewpoint': 56.53264564000546

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1593975366)
        self.assertEqual(loopdata_pkt['current.dateTime'], '07/05/20 11:56:06')

        self.assertEqual(loopdata_pkt['10m.windGust.max'], '7 mph')
        self.assertEqual(loopdata_pkt['10m.windGust.max.formatted'], '7')
        self.assertEqual(loopdata_pkt['10m.windGust.max.raw'], 7.2)
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime'], '07/05/20 11:50:30')
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime.raw'], 1593975030)

        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '76.3°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.formatted'], '76.3')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.raw'], 76.3)
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime'], '07/05/20 11:50:34')
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime.raw'], 1593975034)

        self.assertEqual(loopdata_pkt['hour.windGust.max'], '7 mph')
        self.assertEqual(loopdata_pkt['hour.windGust.max.formatted'], '7')
        self.assertEqual(loopdata_pkt['hour.windGust.max.raw'], 7.2)
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime'], '11:50')
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime.raw'], 1593975030)

        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '76.3°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.formatted'], '76.3')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.raw'], 76.3)
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime'], '11:50')
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime.raw'], 1593975034)

        self.assertEqual(loopdata_pkt['current.outTemp'], '75.4°F')
        self.assertEqual(loopdata_pkt['current.barometer'], '30.005 inHg')
        self.assertEqual(loopdata_pkt['current.windSpeed'], '2 mph')
        self.assertEqual(loopdata_pkt['current.windDir'], '45°')
        self.assertEqual(loopdata_pkt['current.windDir.ordinal_compass'], 'NE')

        self.assertEqual(loopdata_pkt['trend.barometer'], '-0.308 inHg')
        self.assertAlmostEqual(loopdata_pkt['trend.barometer.raw'], -0.3078708, 7)
        self.assertEqual(loopdata_pkt['trend.barometer.formatted'], '-0.308')
        self.assertEqual(loopdata_pkt['trend.barometer.code'], -4)
        self.assertEqual(loopdata_pkt['trend.barometer.desc'], 'Falling Very Rapidly')

        self.assertEqual(loopdata_pkt['trend.outTemp'], '-22.4°F')
        self.assertAlmostEqual(loopdata_pkt['trend.outTemp.raw'], -22.3668639, 7)
        self.assertEqual(loopdata_pkt['trend.outTemp.formatted'], '-22.4')

        # 56.53264564000546 - 54.73645937493746
        self.assertEqual(loopdata_pkt['trend.dewpoint'], '57.4°F')
        self.assertAlmostEqual(loopdata_pkt['trend.dewpoint.raw'], 57.3929339, 7)
        self.assertEqual(loopdata_pkt['trend.dewpoint.formatted'], '57.4')

        self.assertEqual(loopdata_pkt['day.rain.sum'], '0.00 in')
        self.assertEqual(loopdata_pkt['day.rain.sum.formatted'], '0.00')
        self.assertEqual(loopdata_pkt['unit.label.rain'], ' in')

        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '75.4°F')
        self.assertEqual(loopdata_pkt['day.barometer.avg'], '30.005 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '4 mph')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '166°')

        self.assertEqual(loopdata_pkt['day.outTemp.max'], '76.3°F')
        self.assertEqual(loopdata_pkt['day.barometer.max'], '30.015 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '7 mph')
        self.assertEqual(loopdata_pkt['day.windDir.max'], '360°')

        self.assertEqual(loopdata_pkt['day.outTemp.min'], '74.9°F')
        self.assertEqual(loopdata_pkt['day.barometer.min'], '30.005 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '0 mph')
        self.assertEqual(loopdata_pkt['day.windDir.min'], '22°')

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')
        self.assertEqual(loopdata_pkt['unit.label.barometer'], ' inHg')
        self.assertEqual(loopdata_pkt['unit.label.windSpeed'], ' mph')
        self.assertEqual(loopdata_pkt['unit.label.windDir'], '°')

        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime'], '11:50:30')
        self.assertEqual(loopdata_pkt['day.wind.max.formatted'], '7')
        self.assertEqual(loopdata_pkt['day.wind.max'], '7 mph')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.formatted'], '22')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.ordinal_compass'], 'NNE')
        self.assertEqual(loopdata_pkt['day.wind.gustdir'], '22°')

        self.assertEqual(loopdata_pkt['day.wind.mintime'], '11:51:58')
        self.assertEqual(loopdata_pkt['day.wind.min.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.min'], '0 mph')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['day.wind.avg.formatted'], '4')
        self.assertEqual(loopdata_pkt['day.wind.avg'], '4 mph')

        self.assertEqual(loopdata_pkt['day.wind.rms.formatted'], '4')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '4 mph')

        self.assertEqual(loopdata_pkt['day.wind.vecavg.formatted'], '3')
        self.assertEqual(loopdata_pkt['day.wind.vecavg'], '3 mph')

        self.assertEqual(loopdata_pkt['day.wind.vecdir.formatted'], '22')
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '22°')

    def test_cc3000_packet_processing_us_device_us_database_metric_report(self) -> None:

        pkts: List[Dict[str, Any]] = cc3000_packets.CC3000Packets._get_packets()

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('db-us.report-metric', 10800, 10, 6, ProcessPacketTests._get_specified_fields())

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])

        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1593975030, 'outTemp': 76.1, 'barometer': 30.014857385736513, 'dewpoint': 54.73645937493746
        # {'dateTime': 1593975366, 'outTemp': 75.4, 'barometer': 30.005222168998216, 'dewpoint': 56.53264564000546

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°C')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1593975366)
        self.assertEqual(loopdata_pkt['current.dateTime'], '07/05/20 11:56:06')

        self.assertEqual(loopdata_pkt['10m.windGust.max'], '12 km/h')
        self.assertEqual(loopdata_pkt['10m.windGust.max.formatted'], '12')
        self.assertAlmostEqual(loopdata_pkt['10m.windGust.max.raw'], 11.5872768, 7)
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime'], '07/05/20 11:50:30')
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime.raw'], 1593975030)

        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '24.6°C')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.formatted'], '24.6')
        self.assertAlmostEqual(loopdata_pkt['10m.outTemp.max.raw'], 24.6111111, 7)
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime'], '07/05/20 11:50:34')
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime.raw'], 1593975034)

        self.assertEqual(loopdata_pkt['current.outTemp'], '24.1°C')
        self.assertEqual(loopdata_pkt['current.barometer'], '1016.1 mbar')
        self.assertEqual(loopdata_pkt['current.windSpeed'], '3 km/h')
        self.assertEqual(loopdata_pkt['current.windDir'], '45°')
        self.assertEqual(loopdata_pkt['current.windDir.ordinal_compass'], 'NE')

        # 30.005222168998216 - 30.014857385736513
        self.assertEqual(loopdata_pkt['trend.barometer'], '-10.4 mbar')
        self.assertAlmostEqual(loopdata_pkt['trend.barometer.raw'], -10.4257014, 7)
        self.assertEqual(loopdata_pkt['trend.barometer.formatted'], '-10.4')
        self.assertEqual(loopdata_pkt['trend.barometer.code'], -4)
        self.assertEqual(loopdata_pkt['trend.barometer.desc'], 'Falling Very Rapidly')

        self.assertEqual(loopdata_pkt['trend.outTemp'], '-12.4°C')
        self.assertAlmostEqual(loopdata_pkt['trend.outTemp.raw'], -12.4260355, 7)
        self.assertEqual(loopdata_pkt['trend.outTemp.formatted'], '-12.4')

        # 56.53264564000546 - 54.73645937493746
        self.assertEqual(loopdata_pkt['trend.dewpoint'], '31.9°C')
        self.assertAlmostEqual(loopdata_pkt['trend.dewpoint.raw'], 31.8849633, 7)
        self.assertEqual(loopdata_pkt['trend.dewpoint.formatted'], '31.9')

        self.assertEqual(loopdata_pkt['day.rain.sum'], '0.0 mm')
        self.assertEqual(loopdata_pkt['day.rain.sum.formatted'], '0.0')
        self.assertEqual(loopdata_pkt['unit.label.rain'], ' mm')

        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '24.1°C')
        self.assertEqual(loopdata_pkt['day.barometer.avg'], '1016.1 mbar')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '6 km/h')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '166°')

        self.assertEqual(loopdata_pkt['day.outTemp.max'], '24.6°C')
        self.assertEqual(loopdata_pkt['day.barometer.max'], '1016.4 mbar')
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '12 km/h')
        self.assertEqual(loopdata_pkt['day.windDir.max'], '360°')

        self.assertEqual(loopdata_pkt['day.outTemp.min'], '23.8°C')
        self.assertEqual(loopdata_pkt['day.barometer.min'], '1016.1 mbar')
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '0 km/h')
        self.assertEqual(loopdata_pkt['day.windDir.min'], '22°')

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°C')
        self.assertEqual(loopdata_pkt['unit.label.barometer'], ' mbar')
        self.assertEqual(loopdata_pkt['unit.label.windSpeed'], ' km/h')
        self.assertEqual(loopdata_pkt['unit.label.windDir'], '°')

        self.assertEqual(loopdata_pkt['unit.label.wind'], ' km/h')
        self.assertEqual(loopdata_pkt['day.wind.maxtime'], '11:50:30')
        self.assertEqual(loopdata_pkt['day.wind.max.formatted'], '12')
        self.assertEqual(loopdata_pkt['day.wind.max'], '12 km/h')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.formatted'], '22')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.ordinal_compass'], 'NNE')
        self.assertEqual(loopdata_pkt['day.wind.gustdir'], '22°')

        self.assertEqual(loopdata_pkt['day.wind.mintime'], '11:51:58')
        self.assertEqual(loopdata_pkt['day.wind.min.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.min'], '0 km/h')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' km/h')

        self.assertEqual(loopdata_pkt['day.wind.avg.formatted'], '6')
        self.assertEqual(loopdata_pkt['day.wind.avg'], '6 km/h')

        self.assertEqual(loopdata_pkt['day.wind.rms.formatted'], '6')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '6 km/h')

        self.assertEqual(loopdata_pkt['day.wind.vecavg.formatted'], '5')
        self.assertEqual(loopdata_pkt['day.wind.vecavg'], '5 km/h')

        self.assertEqual(loopdata_pkt['day.wind.vecdir.formatted'], '22')
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '22°')

    def test_cc3000_cross_midnight_packet_processing(self) -> None:
        pkts: List[Dict[str, Any]] = cc3000_cross_midnight_packets.CC3000CrossMidnightPackets._get_pre_midnight_packets()

        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 10, 6, ProcessPacketTests._get_specified_fields())

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])

        # Pre Midnight
        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1595487600, 'outTemp': 57.3, 'outHumidity': 89.0, 'pressure': 29.85,

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1595487600)
        self.assertEqual(loopdata_pkt['current.dateTime'], '07/23/20 00:00:00')

        self.assertEqual(loopdata_pkt['2m.windGust.max'], '0 mph')
        self.assertEqual(loopdata_pkt['2m.windGust.max.formatted'], '0')
        self.assertEqual(loopdata_pkt['2m.windGust.max.raw'], 0.0)
        self.assertEqual(loopdata_pkt['2m.windGust.maxtime'], '07/22/20 23:58:02')
        self.assertEqual(loopdata_pkt['2m.windGust.maxtime.raw'], 1595487482)

        self.assertEqual(loopdata_pkt['2m.outTemp.max'], '57.3°F')
        self.assertEqual(loopdata_pkt['2m.outTemp.max.formatted'], '57.3')
        self.assertEqual(loopdata_pkt['2m.outTemp.max.raw'], 57.3)
        self.assertEqual(loopdata_pkt['2m.outTemp.maxtime'], '07/22/20 23:58:02')
        self.assertEqual(loopdata_pkt['2m.outTemp.maxtime.raw'], 1595487482)

        self.assertEqual(loopdata_pkt['10m.windGust.max'], '0 mph')
        self.assertEqual(loopdata_pkt['10m.windGust.max.formatted'], '0')
        self.assertEqual(loopdata_pkt['10m.windGust.max.raw'], 0.0)
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime'], '07/22/20 23:50:02')
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime.raw'], 1595487002)

        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '57.3°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.formatted'], '57.3')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.raw'], 57.3)
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime'], '07/22/20 23:56:10')
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime.raw'], 1595487370)

        self.assertEqual(loopdata_pkt['hour.windGust.max'], '0 mph')
        self.assertEqual(loopdata_pkt['hour.windGust.max.formatted'], '0')
        self.assertEqual(loopdata_pkt['hour.windGust.max.raw'], 0.0)
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime'], '23:45')
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime.raw'], 1595486700)

        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '57.4°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.formatted'], '57.4')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.raw'], 57.4)
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime'], '23:45')
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime.raw'], 1595486700)

        self.assertEqual(loopdata_pkt['current.outTemp'], '57.3°F')
        self.assertEqual(loopdata_pkt['current.barometer'], '29.876 inHg')
        self.assertEqual(loopdata_pkt['current.windSpeed'], '0 mph')
        self.assertEqual(loopdata_pkt.get('current.windDir'), None)
        self.assertEqual(loopdata_pkt.get('current.windDir.ordinal_compass'), None)

        self.assertEqual(loopdata_pkt['trend.barometer'], '0.000 inHg')
        # 0.000060348662600517855
        self.assertAlmostEqual(loopdata_pkt['trend.barometer.raw'], 0.0000602, 7)
        self.assertEqual(loopdata_pkt['trend.barometer.formatted'], '0.000')
        self.assertEqual(loopdata_pkt['trend.barometer.code'], 0)
        self.assertEqual(loopdata_pkt['trend.barometer.desc'], 'Steady')

        self.assertEqual(loopdata_pkt['trend.outTemp'], '-1.2°F')
        self.assertAlmostEqual(loopdata_pkt['trend.outTemp.raw'], -1.1973392, 7)
        self.assertEqual(loopdata_pkt['trend.outTemp.formatted'], '-1.2')

        self.assertEqual(loopdata_pkt['trend.dewpoint'], '6.3°F')
        self.assertAlmostEqual(loopdata_pkt['trend.dewpoint.raw'], 6.2685671, 7)
        self.assertEqual(loopdata_pkt['trend.dewpoint.formatted'], '6.3')

        self.assertEqual(loopdata_pkt['day.rain.sum'], '0.00 in')
        self.assertEqual(loopdata_pkt['day.rain.sum.formatted'], '0.00')
        self.assertEqual(loopdata_pkt['unit.label.rain'], ' in')

        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '57.3°F')
        self.assertEqual(loopdata_pkt['day.barometer.avg'], '29.877 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '0 mph')
        self.assertEqual(loopdata_pkt.get('day.windDir.avg'), None)

        self.assertEqual(loopdata_pkt['day.outTemp.max'], '57.4°F')
        self.assertEqual(loopdata_pkt['day.barometer.max'], '29.886 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '0 mph')
        self.assertEqual(loopdata_pkt.get('day.windDir.max'), None)

        self.assertEqual(loopdata_pkt['day.outTemp.min'], '57.2°F')
        self.assertEqual(loopdata_pkt['day.barometer.min'], '29.876 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '0 mph')
        self.assertEqual(loopdata_pkt.get('day.windDir.min'), None)

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')
        self.assertEqual(loopdata_pkt['unit.label.barometer'], ' inHg')
        self.assertEqual(loopdata_pkt['unit.label.windSpeed'], ' mph')
        self.assertEqual(loopdata_pkt['unit.label.windDir'], '°')

        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime'], '23:45:00')
        self.assertEqual(loopdata_pkt['day.wind.max.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.max'], '0 mph')
        self.assertEqual(loopdata_pkt.get('day.wind.gustdir.formatted'), None)
        self.assertEqual(loopdata_pkt.get('day.wind.gustdir.ordinal_compass'), None)
        self.assertEqual(loopdata_pkt.get('day.wind.gustdir'), None)

        self.assertEqual(loopdata_pkt['day.wind.mintime'], '23:45:00')
        self.assertEqual(loopdata_pkt['day.wind.min.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.min'], '0 mph')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['day.wind.avg.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.avg'], '0 mph')

        self.assertEqual(loopdata_pkt['day.wind.rms.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '0 mph')

        self.assertEqual(loopdata_pkt['day.wind.vecavg.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.vecavg'], '0 mph')

        self.assertEqual(loopdata_pkt.get('day.wind.vecdir.formatted'), None)
        self.assertEqual(loopdata_pkt.get('day.wind.vecdir'), None)

        # Post Midnight

        pkts = cc3000_cross_midnight_packets.CC3000CrossMidnightPackets._get_post_midnight_packets()

        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1595488500, 'outTemp': 58.2, 'outHumidity': 90.0, 'pressure': 29.85,

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1595488500)
        self.assertEqual(loopdata_pkt['current.dateTime'], '07/23/20 00:15:00')

        self.assertEqual(loopdata_pkt['10m.windGust.max'], '2 mph')
        self.assertEqual(loopdata_pkt['10m.windGust.max.formatted'], '2')
        self.assertEqual(loopdata_pkt['10m.windGust.max.raw'], 1.9)
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime'], '07/23/20 00:13:02')
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime.raw'], 1595488382)

        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '58.2°F')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.formatted'], '58.2')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.raw'], 58.2)
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime'], '07/23/20 00:14:10')
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime.raw'], 1595488450)

        self.assertEqual(loopdata_pkt['hour.windGust.max'], '2 mph')
        self.assertEqual(loopdata_pkt['hour.windGust.max.formatted'], '2')
        self.assertEqual(loopdata_pkt['hour.windGust.max.raw'], 1.9)
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime'], '00:13')
        self.assertEqual(loopdata_pkt['hour.windGust.maxtime.raw'], 1595488382)

        self.assertEqual(loopdata_pkt['hour.outTemp.max'], '58.2°F')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.formatted'], '58.2')
        self.assertEqual(loopdata_pkt['hour.outTemp.max.raw'], 58.2)
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime'], '00:14')
        self.assertEqual(loopdata_pkt['hour.outTemp.maxtime.raw'], 1595488450)

        self.assertEqual(loopdata_pkt['current.outTemp'], '58.2°F')
        self.assertEqual(loopdata_pkt['current.barometer'], '29.876 inHg')
        self.assertEqual(loopdata_pkt['current.windSpeed'], '2 mph')
        self.assertEqual(loopdata_pkt['current.windDir'], '45°')
        self.assertEqual(loopdata_pkt['current.windDir.ordinal_compass'], 'NE')

        self.assertEqual(loopdata_pkt['trend.barometer'], '-0.000 inHg')
        self.assertAlmostEqual(loopdata_pkt['trend.barometer.raw'], -0.0002407, 7)
        self.assertEqual(loopdata_pkt['trend.barometer.formatted'], '-0.000')
        self.assertEqual(loopdata_pkt['trend.barometer.code'], 0)
        self.assertEqual(loopdata_pkt['trend.barometer.desc'], 'Steady')

        self.assertEqual(loopdata_pkt['trend.outTemp'], '4.8°F')
        self.assertAlmostEqual(loopdata_pkt['trend.outTemp.raw'], 4.7946726, 7)
        self.assertEqual(loopdata_pkt['trend.outTemp.formatted'], '4.8')

        self.assertEqual(loopdata_pkt['trend.dewpoint'], '10.3°F')
        self.assertAlmostEqual(loopdata_pkt['trend.dewpoint.raw'], 10.2986508, 7)
        self.assertEqual(loopdata_pkt['trend.dewpoint.formatted'], '10.3')

        self.assertEqual(loopdata_pkt['day.rain.sum'], '0.00 in')
        self.assertEqual(loopdata_pkt['day.rain.sum.formatted'], '0.00')
        self.assertEqual(loopdata_pkt['unit.label.rain'], ' in')

        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '57.6°F')
        self.assertEqual(loopdata_pkt['day.barometer.avg'], '29.878 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '0 mph')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '45°')

        self.assertEqual(loopdata_pkt['day.outTemp.max'], '58.2°F')
        self.assertEqual(loopdata_pkt['day.barometer.max'], '29.886 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '2 mph')
        self.assertEqual(loopdata_pkt['day.windDir.max'], '45°')

        self.assertEqual(loopdata_pkt['day.outTemp.min'], '57.3°F')
        self.assertEqual(loopdata_pkt['day.barometer.min'], '29.876 inHg')
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '0 mph')
        self.assertEqual(loopdata_pkt['day.windDir.min'], '45°')

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°F')
        self.assertEqual(loopdata_pkt['unit.label.barometer'], ' inHg')
        self.assertEqual(loopdata_pkt['unit.label.windSpeed'], ' mph')
        self.assertEqual(loopdata_pkt['unit.label.windDir'], '°')

        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')
        self.assertEqual(loopdata_pkt['day.wind.maxtime'], '00:13:02')
        self.assertEqual(loopdata_pkt['day.wind.max.formatted'], '2')
        self.assertEqual(loopdata_pkt['day.wind.max'], '2 mph')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.formatted'], '45')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.ordinal_compass'], 'NE')
        self.assertEqual(loopdata_pkt['day.wind.gustdir'], '45°')

        self.assertEqual(loopdata_pkt['day.wind.mintime'], '00:00:02')
        self.assertEqual(loopdata_pkt['day.wind.min.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.min'], '0 mph')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' mph')

        self.assertEqual(loopdata_pkt['day.wind.avg.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.avg'], '0 mph')

        self.assertEqual(loopdata_pkt['day.wind.rms.formatted'], '1')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '1 mph')

        self.assertEqual(loopdata_pkt['day.wind.vecavg.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.vecavg'], '0 mph')

        self.assertEqual(loopdata_pkt['day.wind.vecdir.formatted'], '45')
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '45°')

    def test_simulator_packet_processing(self) -> None:
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('metric', 10800, 10, 6, ProcessPacketTests._get_specified_fields())

        pkts: List[Dict[str, Any]] = simulator_packets.SimulatorPackets._get_packets()

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkts[0]['dateTime'])

        for pkt in pkts:
            loopdata_pkt: Dict[str, Any] = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # {'dateTime': 1593976709, 'outTemp': 0.3770915275499615,  'barometer': 1053.1667173695532, 'dewpoint': -2.6645899102645934
        # {'dateTime': 1593977615, 'outTemp': 0.032246952164187964,'barometer': 1053.1483031344253, 'dewpoint': -3.003421962855377

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°C')

        self.assertEqual(loopdata_pkt['current.dateTime.raw'], 1593977615)
        self.assertEqual(loopdata_pkt['current.dateTime'], '07/05/20 12:33:35')

        self.assertEqual(loopdata_pkt['10m.windGust.max'], '0 km/h')
        self.assertEqual(loopdata_pkt['10m.windGust.max.formatted'], '0')
        self.assertAlmostEqual(loopdata_pkt['10m.windGust.max.raw'], 0.0052507, 7)
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime'], '07/05/20 12:33:35')
        self.assertEqual(loopdata_pkt['10m.windGust.maxtime.raw'], 1593977615)

        self.assertEqual(loopdata_pkt['10m.outTemp.max'], '1.4°C')
        self.assertEqual(loopdata_pkt['10m.outTemp.max.formatted'], '1.4')
        self.assertAlmostEqual(loopdata_pkt['10m.outTemp.max.raw'], 1.3578938, 7)
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime'], '07/05/20 12:33:19')
        self.assertEqual(loopdata_pkt['10m.outTemp.maxtime.raw'], 1593977599)

        self.assertEqual(loopdata_pkt['current.outTemp'], '0.0°C')
        self.assertEqual(loopdata_pkt['current.barometer'], '1053.1 mbar')
        self.assertEqual(loopdata_pkt['current.windSpeed'], '0 km/h')
        self.assertEqual(loopdata_pkt['current.windDir'], '360°')
        self.assertEqual(loopdata_pkt['current.windDir.ordinal_compass'], 'N')

        # 1053.1483031344253 - 1053.1667173695532
        self.assertEqual(loopdata_pkt['trend.barometer'], '-0.2 mbar')
        self.assertAlmostEqual(loopdata_pkt['trend.barometer.raw'], -0.2190239, 7)
        self.assertEqual(loopdata_pkt['trend.barometer.formatted'], '-0.2')
        self.assertEqual(loopdata_pkt['trend.barometer.code'], -1)
        self.assertEqual(loopdata_pkt['trend.barometer.desc'], 'Falling Slowly')

        # 0.032246952164187964 - 0.3770915275499615
        self.assertEqual(loopdata_pkt['trend.outTemp'], '-4.1°C')
        self.assertAlmostEqual(loopdata_pkt['trend.outTemp.raw'], -4.1016756, 7)
        self.assertEqual(loopdata_pkt['trend.outTemp.formatted'], '-4.1')

        # -3.003421962855377 - -2.6645899102645934
        self.assertEqual(loopdata_pkt['trend.dewpoint'], '-4.0°C')
        self.assertAlmostEqual(loopdata_pkt['trend.dewpoint.raw'], -4.0301610, 7)
        self.assertEqual(loopdata_pkt['trend.dewpoint.formatted'], '-4.0')

        self.assertEqual(loopdata_pkt['day.rain.sum'], '0.0 mm')
        self.assertEqual(loopdata_pkt['day.rain.sum.formatted'], '0.0')
        self.assertEqual(loopdata_pkt['unit.label.rain'], ' mm')

        self.assertEqual(loopdata_pkt['day.outTemp.avg'], '0.2°C')
        self.assertEqual(loopdata_pkt['day.barometer.avg'], '1053.2 mbar')
        self.assertEqual(loopdata_pkt['day.windSpeed.avg'], '0 km/h')
        self.assertEqual(loopdata_pkt['day.windDir.avg'], '360°')

        self.assertEqual(loopdata_pkt['day.outTemp.max'], '1.5°C')
        self.assertEqual(loopdata_pkt['day.barometer.max'], '1053.2 mbar')
        self.assertEqual(loopdata_pkt['day.windSpeed.max'], '0 km/h')
        self.assertEqual(loopdata_pkt['day.windDir.max'], '360°')

        self.assertEqual(loopdata_pkt['day.outTemp.min'], '0.0°C')
        self.assertEqual(loopdata_pkt['day.barometer.min'], '1053.1 mbar')
        self.assertEqual(loopdata_pkt['day.windSpeed.min'], '0 km/h')
        self.assertEqual(loopdata_pkt['day.windDir.min'], '360°')

        self.assertEqual(loopdata_pkt['unit.label.outTemp'], '°C')
        self.assertEqual(loopdata_pkt['unit.label.barometer'], ' mbar')
        self.assertEqual(loopdata_pkt['unit.label.windSpeed'], ' km/h')
        self.assertEqual(loopdata_pkt['unit.label.windDir'], '°')

        self.assertEqual(loopdata_pkt['unit.label.wind'], ' km/h')
        self.assertEqual(loopdata_pkt['day.wind.maxtime'], '12:33:35')
        self.assertEqual(loopdata_pkt['day.wind.max.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.max'], '0 km/h')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.formatted'], '360')
        self.assertEqual(loopdata_pkt['day.wind.gustdir.ordinal_compass'], 'N')
        self.assertEqual(loopdata_pkt['day.wind.gustdir'], '360°')

        self.assertEqual(loopdata_pkt['day.wind.mintime'], '12:18:29')
        self.assertEqual(loopdata_pkt['day.wind.min.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.min'], '0 km/h')
        self.assertEqual(loopdata_pkt['unit.label.wind'], ' km/h')

        self.assertEqual(loopdata_pkt['day.wind.avg.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.avg'], '0 km/h')

        self.assertEqual(loopdata_pkt['day.wind.rms.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.rms'], '0 km/h')

        self.assertEqual(loopdata_pkt['day.wind.vecavg.formatted'], '0')
        self.assertEqual(loopdata_pkt['day.wind.vecavg'], '0 km/h')

        self.assertEqual(loopdata_pkt['day.wind.vecdir.formatted'], '360')
        self.assertEqual(loopdata_pkt['day.wind.vecdir'], '360°')

    def test_various_minute_and_hour_tags(self) -> None:
        specified_fields = [ 'current.outTemp', 'trend.outTemp',
                             '1m.rain.sum', '1m.outTemp.max', '1m.outTemp.min', '1m.outTemp.avg',
                             '7m.rain.sum', '7m.outTemp.max', '7m.outTemp.min', '7m.outTemp.avg',
                             '13h.rain.sum', '13h.outTemp.max', '13h.outTemp.min', '13h.outTemp.avg']
        cfg: user.loopdata.Configuration = ProcessPacketTests._get_config('us', 10800, 1, 6, specified_fields)

        # July 1, 2020 Noon PDT
        pkt: Dict[str, Any] = {'dateTime': 1593630000, 'usUnits': 1, 'outTemp': 77.4, 'rain': 0.01}

        accums: user.loopdata.Accumulators = ProcessPacketTests._get_accums(cfg, pkt['dateTime'])

        # First packet.
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        # Next packet 1 minute later
        pkt = {'dateTime': 1593630060, 'usUnits': 1, 'outTemp': 77.3, 'rain': 0.0}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '77.3°F')

        # first packet dropped off for 1m.
        self.assertEqual(loopdata_pkt['1m.outTemp.max'], '77.3°F')
        self.assertEqual(loopdata_pkt['1m.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['1m.outTemp.avg'], '77.3°F')
        self.assertEqual(loopdata_pkt['1m.rain.sum'], '0.00 in')
        self.assertEqual(loopdata_pkt['1m.outTemp.avg'], '77.3°F')

        self.assertEqual(loopdata_pkt['7m.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['7m.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['7m.outTemp.avg'], '77.3°F')
        self.assertEqual(loopdata_pkt['7m.rain.sum'], '0.01 in')

        self.assertEqual(loopdata_pkt['13h.rain.sum'], '0.01 in')
        self.assertEqual(loopdata_pkt['13h.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['13h.outTemp.min'], '77.3°F')
        self.assertEqual(loopdata_pkt['13h.outTemp.avg'], '77.3°F')

        # Next packet 58s later
        pkt = {'dateTime': 1593630118, 'usUnits': 1, 'outTemp': 77.2, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['1m.outTemp.max'], '77.3°F')
        self.assertEqual(loopdata_pkt['1m.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['1m.outTemp.avg'], '77.2°F')
        self.assertEqual(loopdata_pkt['1m.rain.sum'], '0.00 in')

        self.assertEqual(loopdata_pkt['7m.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['7m.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['7m.outTemp.avg'], '77.3°F')
        self.assertEqual(loopdata_pkt['7m.rain.sum'], '0.01 in')

        self.assertEqual(loopdata_pkt['13h.rain.sum'], '0.01 in')
        self.assertEqual(loopdata_pkt['13h.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['13h.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['13h.outTemp.avg'], '77.3°F')

        # Next packet 2s later
        pkt = {'dateTime': 1593630120, 'usUnits': 1, 'outTemp': 77.2, 'rain': 0.00}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['1m.outTemp.max'], '77.2°F')
        self.assertEqual(loopdata_pkt['1m.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['1m.outTemp.avg'], '77.2°F')
        self.assertEqual(loopdata_pkt['1m.rain.sum'], '0.00 in')

        self.assertEqual(loopdata_pkt['7m.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['7m.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['7m.outTemp.avg'], '77.3°F')
        self.assertEqual(loopdata_pkt['7m.rain.sum'], '0.01 in')

        self.assertEqual(loopdata_pkt['13h.rain.sum'], '0.01 in')
        self.assertEqual(loopdata_pkt['13h.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['13h.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['13h.outTemp.avg'], '77.3°F')

        # Next packet 9 minutes later
        pkt = {'dateTime': 1593630600, 'usUnits': 1, 'outTemp': 77.2, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '77.2°F')

        self.assertEqual(loopdata_pkt['1m.outTemp.max'], '77.2°F')
        self.assertEqual(loopdata_pkt['1m.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['1m.outTemp.avg'], '77.2°F')
        self.assertEqual(loopdata_pkt['1m.rain.sum'], '0.01 in')

        # Everything but this packet has dropped of for 7m tag.
        # Previous max should have dropped off of 7m.
        self.assertEqual(loopdata_pkt['7m.outTemp.max'], '77.2°F')
        self.assertEqual(loopdata_pkt['7m.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['7m.outTemp.avg'], '77.2°F')
        self.assertEqual(loopdata_pkt['7m.rain.sum'], '0.01 in')

        # 13h
        self.assertEqual(loopdata_pkt['13h.outTemp.max'], '77.4°F')
        self.assertEqual(loopdata_pkt['13h.outTemp.min'], '77.2°F')
        self.assertEqual(loopdata_pkt['13h.outTemp.avg'], '77.3°F')
        self.assertEqual(loopdata_pkt['13h.rain.sum'], '0.02 in')

        # Next packet 13 hours later
        pkt = {'dateTime': 1593677400, 'usUnits': 1, 'outTemp': 75.0, 'rain': 0.01}
        loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)

        self.assertEqual(loopdata_pkt['current.outTemp'], '75.0°F')
        self.assertEqual(loopdata_pkt['7m.outTemp.max'], '75.0°F')
        self.assertEqual(loopdata_pkt['7m.outTemp.min'], '75.0°F')
        self.assertEqual(loopdata_pkt['13h.outTemp.max'], '75.0°F')
        self.assertEqual(loopdata_pkt['13h.outTemp.min'], '75.0°F')
        self.assertEqual(loopdata_pkt['13h.rain.sum'], '0.01 in')

    @staticmethod
    def _get_accums(cfg: user.loopdata.Configuration, pkt_time) -> user.loopdata.Accumulators:
        """
        Returns an Accumulators instance.
        """
        accums = user.loopdata.Accumulators(
            alltime_accum         = None,
            rainyear_accum        = None,
            year_accum            = None,
            month_accum           = None,
            week_accum            = None,
            day_accum             = weewx.accum.Accum(weeutil.weeutil.archiveDaySpan(pkt_time), cfg.unit_system),
            hour_accum            = None,
            continuous            = {})
        # Only make accums if there are obstypes for the period.
        if cfg.obstypes.alltime is not None:
            accums.alltime_accum = weewx.accum.Accum(weeutil.weeutil.TimeSpan(86400, 17514144000), cfg.unit_system)
        if cfg.obstypes.rainyear is not None:
            accums.rainyear_accum        = weewx.accum.Accum(weeutil.weeutil.archiveRainYearSpan(pkt_time, cfg.rainyear_start), cfg.unit_system)
        if cfg.obstypes.year is not None:
            accums.year_accum            = weewx.accum.Accum(weeutil.weeutil.archiveYearSpan(pkt_time), cfg.unit_system)
        if cfg.obstypes.month is not None:
            accums.month_accum           = weewx.accum.Accum(weeutil.weeutil.archiveMonthSpan(pkt_time), cfg.unit_system)
        if cfg.obstypes.week is not None:
            accums.week_accum            = weewx.accum.Accum(weeutil.weeutil.archiveWeekSpan(pkt_time, cfg.week_start), cfg.unit_system)
        if cfg.obstypes.hour is not None:
            accums.hour_accum            = weewx.accum.Accum(weeutil.weeutil.archiveHoursAgoSpan(pkt_time), cfg.unit_system)
        # Make continous accums if there are matching continous obs types.
        for per in cfg.obstypes.continuous:
            if user.loopdata.LoopData.is_trend_key(per):
                timelength = user.loopdata.LoopData.trend_key_seconds(per)
            elif user.loopdata.LoopData.is_hour_period(per):
                timelength = int(per[:-1])*3600
            elif user.loopdata.LoopData.is_minute_period(per):
                timelength = int(per[:-1])*60
            accums.continuous[per]   = user.loopdata.ContinuousAccum(timelength, cfg.unit_system)

        # Make windrose accums (unseeded; seeding is create_windrose_accums'
        # job and needs a database).
        for windrose_key, (tgt_unit, bands) in cfg.windrose_bandings.items():
            banding = user.loopdata.LoopData.create_windrose_banding(cfg.unit_system, tgt_unit, bands)
            for key, per in cfg.windrose_span_periods:
                if key == windrose_key:
                    accums.windrose_span[(key, per)] = user.loopdata.WindRoseSpanAccum(
                        banding, user.loopdata.LoopData.windrose_span_fn(
                            per, cfg.week_start, cfg.rainyear_start), pkt_time)
            for key, per in cfg.windrose_continuous_periods:
                if key == windrose_key:
                    timelength = int(per[:-1]) * (3600 if per.endswith('h') else 60)
                    accums.windrose_continuous[(key, per)] = user.loopdata.WindRoseContinuousAccum(
                        banding, timelength)

        return accums

    @staticmethod
    def _get_config(config_dict_kind, time_delta, rainyear_start, week_start, specified_fields) -> user.loopdata.Configuration:
        """A Configuration whose one context is the LEGACY one: the test's
        fields are the [[Include]] fields line, rendered flat through
        SeasonsReport -- the shape every packet assertion below reads.
        Declaring-report tests add ReportContexts to cfg.reports."""
        os.environ['TZ'] = 'America/Los_Angeles'
        config_dict: Dict[str, Any] = configobj.ConfigObj('tests/weewx.conf.%s' % config_dict_kind, encoding='utf-8')

        # Get converter and formatter from SeasonsReport.
        target_report_dict: Dict[str, Any] = user.loopdata.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')
        ctx = user.loopdata.LoopData.build_report_context(
            None, list(specified_fields), target_report_dict, None, None)
        assert type(ctx.converter) == weewx.units.Converter
        assert type(ctx.formatter) == user.loopdata.ReportFormatter
        # The test names the trend window; the skin dict's is overridden
        # (trend_key follows, being derived from it).
        ctx.time_delta = time_delta
        return ProcessPacketTests._make_config(config_dict, rainyear_start, week_start,
            legacy=ctx, reports=[])

    @staticmethod
    def _make_config(config_dict: Dict[str, Any], rainyear_start: int, week_start: int,
            legacy: Optional[user.loopdata.ReportContext],
            reports: List[user.loopdata.ReportContext]) -> user.loopdata.Configuration:
        """The shared Configuration over the given contexts, with the
        unions exactly as LoopData.__init__ computes them."""
        unit_system: int = weewx.units.unit_constants[config_dict['StdConvert'].get('target_unit', 'US').upper()]
        std_archive_dict: Dict[str, Any] = config_dict.get('StdArchive', {})
        cfg = user.loopdata.Configuration(
            queue                    = queue.SimpleQueue(), # dummy
            config_dict              = config_dict,
            unit_system              = unit_system,
            archive_interval         = to_int(std_archive_dict.get('archive_interval')),
            archive_delay            = to_int(std_archive_dict.get('archive_delay', 15)),
            loop_data_dir            = '', # dummy
            filename                 = '', # dummy
            target_report            = 'SeasonsReport',
            loop_frequency           = 2.0,
            tmpname                  = '', # dummy
            enable                   = True, # dummy
            remote_server            = '', # dummy
            remote_port              = 22, # dummy
            remote_user              = '', # dummy
            remote_dir               = '', # dummy
            compress                 = True, # dummy
            log_success              = False, # dummy
            ssh_options              = '', # dummy
            timeout                  = 1, # dummy
            skip_if_older_than       = 3, # dummy
            week_start               = week_start,
            rainyear_start           = rainyear_start,
            legacy                   = legacy,
            reports                  = list(reports))
        cfg.recompute()
        return cfg

    @staticmethod
    def _get_specified_fields() -> List[str]:
        return [
            '2m.windGust.max',
            '2m.windGust.max.formatted',
            '2m.windGust.max.raw',
            '2m.windGust.maxtime',
            '2m.windGust.maxtime.raw',
            '2m.outTemp.max',
            '2m.outTemp.max.formatted',
            '2m.outTemp.max.raw',
            '2m.outTemp.maxtime',
            '2m.outTemp.maxtime.raw',
            '10m.windGust.max',
            '10m.windGust.max.formatted',
            '10m.windGust.max.raw',
            '10m.windGust.maxtime',
            '10m.windGust.maxtime.raw',
            '10m.windSpeed.max',
            '10m.windDir.max',
            '10m.outTemp.max',
            '10m.outTemp.max.formatted',
            '10m.outTemp.max.raw',
            '10m.outTemp.maxtime',
            '10m.outTemp.maxtime.raw',
            '10m.outTemp.min',
            '10m.outTemp.min.formatted',
            '10m.outTemp.min.raw',
            '10m.outTemp.mintime',
            '10m.outTemp.mintime.raw',
            '24h.rain.sum',
            'current.dateTime.raw',
            'current.dateTime',
            'unit.label.outTemp',
            'current.outTemp',
            'current.barometer',
            'current.windSpeed',
            'current.windDir',
            'current.windDir.ordinal_compass',
            'hour.windGust.max',
            'hour.windGust.max.formatted',
            'hour.windGust.max.raw',
            'hour.windGust.maxtime',
            'hour.windGust.maxtime.raw',
            'hour.outTemp.max',
            'hour.outTemp.max.formatted',
            'hour.outTemp.max.raw',
            'hour.outTemp.maxtime',
            'hour.outTemp.maxtime.raw',
            'day.barometer.avg',
            'day.barometer.max',
            'day.barometer.min',
            'day.outTemp.avg',
            'day.outTemp.min',
            'day.outTemp.max',
            'day.rain.sum',
            'day.rain.sum.formatted',
            'day.rain.avg',
            'day.rain.avg.formatted',
            'day.rain.avg.raw',
            'day.wind.avg',
            'day.wind.avg.formatted',
            'day.wind.max',
            'day.wind.max.formatted',
            'day.wind.gustdir',
            'day.wind.gustdir.formatted',
            'day.wind.gustdir.ordinal_compass',
            'day.wind.maxtime',
            'day.wind.min',
            'day.wind.min.formatted',
            'day.wind.mintime',
            'day.wind.rms',
            'day.wind.rms.formatted',
            'day.wind.vecavg',
            'day.wind.vecavg.formatted',
            'day.wind.vecdir',
            'day.wind.vecdir.formatted',
            'day.windDir.avg',
            'day.windDir.max',
            'day.windDir.min',
            'day.windSpeed.avg',
            'day.windSpeed.max',
            'day.windSpeed.min',
            'trend.barometer',
            'trend.barometer.raw',
            'trend.barometer.formatted',
            'trend.barometer.code',
            'trend.barometer.desc',
            'trend.outTemp',
            'trend.outTemp.raw',
            'trend.outTemp.formatted',
            'trend.dewpoint',
            'trend.dewpoint.raw',
            'trend.dewpoint.formatted',
            'unit.label.barometer',
            'unit.label.rain',
            'unit.label.wind',
            'unit.label.windDir',
            'unit.label.windSpeed',
            ]

    def test_create_period_accum_from_database(self) -> None:
        # Category 2: exercise create_period_accum against a REAL (temporary)
        # SQLite weewx database -- not a mock.  This covers the day-summary
        # priming path: create_period_accum reads archive_day_<obstype> rows via
        # day_summary_records_generator and merges them with today's day_accum.
        #
        # Fixture: a temp database with archive records spanning two UTC days.
        # The earlier day's records become a day-summary row that the 'week'
        # period accumulator must merge; today's records arrive via day_accum.
        unit_system = weewx.units.unit_constants['US']  # 1

        tmpdir = tempfile.mkdtemp()
        dbm = None
        try:
            db_dict = {
                'database_name': os.path.join(tmpdir, 'test.sdb'),
                'driver': 'weedb.sqlite'}
            dbm = weewx.manager.DaySummaryManager.open_with_create(
                db_dict, table_name='archive', schema=wview_extended_schema)

            # Day 1: 2022-10-14, three records.  Day 2 (today): 2022-10-15.
            day1 = 1665750000   # 2022-10-14 12:20:00 UTC (mid-day)
            day2 = 1665838800   # 2022-10-15 13:00:00 UTC (mid-day)

            day1_temps = [40.0, 50.0, 60.0]
            archive_recs = []
            for i, t in enumerate(day1_temps):
                archive_recs.append({
                    'dateTime': day1 + i * 300, 'usUnits': 1, 'interval': 5,
                    'outTemp': t,
                    'windSpeed': 4.0 + i, 'windDir': 80.0 + i * 10,
                    'windGust': 6.0 + i, 'windGustDir': 85.0 + i * 10})
            dbm.addRecord(archive_recs)

            # Build today's day_accum and populate it with two readings each of
            # a scalar (outTemp) and a vector (wind) obstype.
            day_accum = weewx.accum.Accum(
                weeutil.weeutil.archiveDaySpan(day2), unit_system)
            today_temps = [70.0, 80.0]
            for i, t in enumerate(today_temps):
                day_accum.addRecord(
                    {'dateTime': day2 + i * 300, 'usUnits': 1, 'outTemp': t,
                     'windSpeed': 10.0 + i, 'windDir': 200.0 + i * 10,
                     'windGust': 12.0 + i, 'windGustDir': 205.0 + i * 10},
                    weight=300)

            # Day-summary inclusion follows weewx's DailySummaries spec:
            # start <= dateTime < stop.  The span brackets day1's day-start
            # (included) and stops well after day2, so day1's summary row is in
            # range.  day2 is only in day_accum (not the db), so it is not a
            # day-summary row; it is merged separately below.
            week_span = weeutil.weeutil.TimeSpan(day1 - 86400, day2 + 86400)

            # Request both a scalar and a vector obstype: this exercises the
            # ScalarStats AND VecStats type-dispatch and merge paths.
            accum, valid_obstypes = user.loopdata.LoopData.create_period_accum(
                'week', unit_system, 5, {'outTemp', 'wind'}, week_span, day_accum, dbm)

            self.assertIsNotNone(accum)
            self.assertIn('outTemp', valid_obstypes)
            self.assertIn('wind', valid_obstypes)
            self.assertIn('outTemp', accum)
            self.assertIn('wind', accum)

            # Scalar merge: min from day1 (40), max from today (80), count 3+2=5.
            stats = accum['outTemp']
            self.assertEqual(stats.min, 40.0)   # day1 low
            self.assertEqual(stats.max, 80.0)   # today's high
            self.assertEqual(stats.count, 5)

            # Vector merge: the wind accumulator must be a VecStats spanning both
            # days.  For weewx VecStats, 'min' tracks the lowest windSpeed and
            # 'max' tracks the highest windGust.  Day1 speeds 4,5,6 / gusts 6,7,8;
            # today speeds 10,11 / gusts 12,13.  So min=4 (day1), max=13 (today).
            wind_stats = accum['wind']
            self.assertEqual(type(wind_stats), weewx.accum.VecStats)
            self.assertEqual(wind_stats.count, 5)       # 3 + 2 observations
            self.assertEqual(wind_stats.max, 13.0)      # max windGust (today)
            self.assertEqual(wind_stats.min, 4.0)       # min windSpeed (day1)

        finally:
            if dbm is not None:
                dbm.close()
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_create_period_accum_empty_obstypes(self) -> None:
        # The early-return guard: no obstypes -> (None, empty set), no DB needed.
        accum, valid = user.loopdata.LoopData.create_period_accum(
            'week', 1, 5, set(),
            weeutil.weeutil.TimeSpan(0, 100), None, None)
        self.assertIsNone(accum)
        self.assertEqual(valid, set())

    def test_create_period_accum_day_summary_upper_bound(self) -> None:
        # Concern-#2 / spec test: day-summary aggregation must follow weewx's
        # DailySummaries convention (weewx.xtypes): dateTime >= start AND
        # dateTime < stop -- inclusive left, EXCLUSIVE right.  This test proves
        # the exclusive-right bound by placing the span.stop exactly on a
        # day-summary key: the day-summary row AT span.stop must be EXCLUDED,
        # while the prior day's row is INCLUDED.  The expected inclusion is
        # derived from the spec, NOT from loopdata's SQL.
        unit_system = weewx.units.unit_constants['US']

        tmpdir = tempfile.mkdtemp()
        dbm = None
        try:
            db_dict = {'database_name': os.path.join(tmpdir, 'test.sdb'),
                       'driver': 'weedb.sqlite'}
            dbm = weewx.manager.DaySummaryManager.open_with_create(
                db_dict, table_name='archive', schema=wview_extended_schema)

            # Two days of records.  Day A: 2022-10-13.  Day B: 2022-10-14.
            dayA = 1665663600   # 2022-10-13 12:20:00 UTC
            dayB = 1665750000   # 2022-10-14 12:20:00 UTC
            for d, temp in ((dayA, 40.0), (dayB, 80.0)):
                dbm.addRecord([{'dateTime': d, 'usUnits': 1, 'interval': 5,
                                'outTemp': temp}])

            # Day-summary keys use startOfArchiveDay (the same function
            # DaySummaryManager uses to key archive_day_* rows).
            dayB_key = weeutil.weeutil.startOfArchiveDay(dayB)

            # Set span.stop EXACTLY on dayB's summary key.  Per the spec
            # (dateTime < stop), dayB's row must be excluded; dayA's included.
            span = weeutil.weeutil.TimeSpan(weeutil.weeutil.startOfArchiveDay(dayA), dayB_key)

            # day_accum must CONTAIN outTemp, or create_period_accum skips the
            # obstype entirely (it only processes obstypes present in day_accum).
            # Give it one reading at value 50 -- distinct from dayA (40) and
            # dayB (80) -- so the asserted max proves which day-summary rows
            # were merged.  'today' is dayB, so the bound in force -- today's
            # start -- lands exactly on dayB's summary key, and dayB's row is
            # excluded by the same exclusive-right rule this test is about.
            today = dayB
            day_accum = weewx.accum.Accum(
                weeutil.weeutil.archiveDaySpan(today), unit_system)
            day_accum.addRecord(
                {'dateTime': today, 'usUnits': 1, 'outTemp': 50.0}, weight=300)

            accum, valid = user.loopdata.LoopData.create_period_accum(
                'week', unit_system, 5, {'outTemp'}, span, day_accum, dbm)

            self.assertIsNotNone(accum)
            self.assertIn('outTemp', accum)
            # dayA's summary (1 obs, value 40) is within [start, stop).  dayB's
            # row (value 80), keyed exactly at the bound, is EXCLUDED by the
            # exclusive-right rule.  day_accum adds 1 obs (value 50).  So:
            #   count = 1 (dayA) + 1 (day_accum) = 2
            #   max   = 50 (day_accum); NOT 80 -- proving dayB was excluded.
            self.assertEqual(accum['outTemp'].count, 2)
            self.assertEqual(accum['outTemp'].max, 50.0)
            self.assertEqual(accum['outTemp'].min, 40.0)  # dayA's value
        finally:
            if dbm is not None:
                dbm.close()
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_create_period_accum_counts_today_once(self) -> None:
        """Spec: a span accumulator is the day summary rows of the whole
        days before today plus today's running totals, day_accum.  Today has
        a summary row too -- it is what new_loop builds day_accum from -- so
        the rows must stop at today's start, or today counts twice.  Expected
        values come from the records written, not from loopdata."""
        unit_system = weewx.units.unit_constants['US']
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        with tempfile.TemporaryDirectory() as tmp:
            dbm = weewx.manager.DaySummaryManager.open_with_create(
                {'database_name': os.path.join(tmp, 'test.sdb'), 'driver': 'weedb.sqlite'},
                table_name='archive', schema=wview_extended_schema)
            try:
                yesterday = 1593543600          # 2020-06-30 12:00 PDT
                today = yesterday + 86400       # 2020-07-01 12:00 PDT
                for d, temp in ((yesterday, 40.0), (today - 600, 60.0), (today - 300, 80.0)):
                    dbm.addRecord({'dateTime': d, 'usUnits': 1, 'interval': 5,
                                   'outTemp': temp, 'rain': 0.1})
                # Today's summary row, as the populated Accum over that day
                # the manager hands back -- what the rows-before-today bound
                # must not add a second time.
                day_accum = dbm._get_day_summary(weeutil.weeutil.archiveDaySpan(today).start)

                span = weeutil.weeutil.archiveYearSpan(today)     # holds both days
                accum, valid = user.loopdata.LoopData.create_period_accum(
                    'year', unit_system, 5, {'outTemp', 'rain'}, span, day_accum, dbm)
                self.assertIsNotNone(accum)
                self.assertEqual(valid, {'outTemp', 'rain'})
                # yesterday's row (1 obs) + today's totals (2 obs); today's row
                # is not added on top of them.
                self.assertEqual(accum['outTemp'].count, 3)
                self.assertEqual(accum['outTemp'].sum, 180.0)
                self.assertAlmostEqual(accum['rain'].sum, 0.3)
                self.assertEqual(accum['outTemp'].min, 40.0)
                self.assertEqual(accum['outTemp'].max, 80.0)
            finally:
                dbm.close()

    def test_create_hour_accum_from_database(self) -> None:
        # Covers the name=='hour' path of create_period_accum, which primes the
        # hour accumulator from ARCHIVE records.
        #
        # Inclusion spec (derived independently of loopdata's SQL): the hour
        # accumulator is a weewx.accum.Accum(span), so it accepts records per
        # TimeSpan.includesArchiveTime -- start < t <= stop (exclusive left,
        # inclusive right).  archiveHoursAgoSpan(now) returns the current clock
        # hour, so span.stop is in the FUTURE relative to now; the inclusive-
        # right edge is therefore never exercised by real data (nothing is
        # newer than now).  The testable boundary is the EXCLUSIVE LEFT edge: a
        # record at exactly span.start must be EXCLUDED.  The hour path does NOT
        # merge day_accum (unlike longer periods), so count reflects archive
        # records only.
        import time as _time
        unit_system = weewx.units.unit_constants['US']

        tmpdir = tempfile.mkdtemp()
        dbm = None
        try:
            db_dict = {'database_name': os.path.join(tmpdir, 'test.sdb'),
                       'driver': 'weedb.sqlite'}
            dbm = weewx.manager.DaySummaryManager.open_with_create(
                db_dict, table_name='archive', schema=wview_extended_schema)

            now = int(_time.time())
            hour_span = weeutil.weeutil.archiveHoursAgoSpan(now)

            # Records must be both inside the span (dateTime > hour_span.start)
            # AND not future-dated relative to now (the create_period_accum hour
            # path applies the archive_delay future-record rejection).  Because
            # archiveHoursAgoSpan(now) is the CURRENT clock hour, span.stop is in
            # the future and 'now' may be anywhere within the hour -- so anchor
            # the included records to 'now' (always in the past) rather than to
            # span.start (which risks placing them after 'now' early in the
            # hour).  They remain > span.start as long as the test runs at least
            # a few seconds into the clock hour, which is effectively always.
            # (reuse the now sampled above for hour_span)
            # One record EXACTLY at span.start: excluded by the exclusive-left
            # rule (get_archive_packets uses dateTime > earliest_time).
            recs = [{'dateTime': hour_span.start, 'usUnits': 1, 'interval': 5,
                     'outTemp': 99.0}]
            # Three included records a few seconds in the past, distinct and
            # strictly inside (span.start, now].
            for i, off in enumerate((3, 2, 1)):
                recs.append({'dateTime': now - off, 'usUnits': 1,
                             'interval': 5, 'outTemp': 60.0 + i})
            dbm.addRecord(recs)

            # day_accum for today, populated so 'outTemp' dispatches as ScalarStats.
            day_accum = weewx.accum.Accum(
                weeutil.weeutil.archiveDaySpan(now), unit_system)
            day_accum.addRecord(
                {'dateTime': now, 'usUnits': 1, 'outTemp': 65.0}, weight=300)

            accum, valid = user.loopdata.LoopData.create_period_accum(
                'hour', unit_system, 5, {'outTemp'}, hour_span, day_accum, dbm)

            self.assertIsNotNone(accum)
            self.assertIn('outTemp', valid)
            self.assertIn('outTemp', accum)
            # Exactly the 3 in-span records (values 60, 61, 62).  The boundary
            # record at span.start (99.0) is EXCLUDED by the exclusive-left rule;
            # if it leaked in, count would be 4 and max would be 99.
            self.assertEqual(accum['outTemp'].count, 3)
            self.assertEqual(accum['outTemp'].min, 60.0)
            self.assertEqual(accum['outTemp'].max, 62.0)  # NOT 99 -> start excluded

        finally:
            if dbm is not None:
                dbm.close()
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_create_continuous_accum_from_database(self) -> None:
        # Covers create_continuous_accum, which primes a ContinuousAccum from
        # archive records.
        #
        # Inclusion spec (the continuous accumulator's own rolling-window rule,
        # stated independently of loopdata's SQL): at priming, the window is
        # anchored to wall-clock time (there is no current observation yet).  A
        # record survives iff ts > now - timelength; a record at or before
        # now - timelength is trimmed.  This test verifies both sides of that
        # boundary.
        #
        # To avoid a sub-second race between the test's 'now' and the code's
        # internal time.time(), the boundary records are placed a few seconds
        # inside and outside the edge rather than exactly on it.
        import time as _time
        unit_system = weewx.units.unit_constants['US']

        tmpdir = tempfile.mkdtemp()
        dbm = None
        try:
            db_dict = {'database_name': os.path.join(tmpdir, 'test.sdb'),
                       'driver': 'weedb.sqlite'}
            dbm = weewx.manager.DaySummaryManager.open_with_create(
                db_dict, table_name='archive', schema=wview_extended_schema)

            timelength = 3600   # 1 hour rolling window ('1h')
            now = int(_time.time())
            # Records strictly inside the window (ts > now - timelength).
            inside = [now - 900, now - 600, now - 300]
            # Just OUTSIDE the left edge: a few seconds older than the boundary
            # (now - timelength - 30) -> must be trimmed.
            just_outside = now - timelength - 30
            # Far outside, to be unambiguous as well.
            far_outside = now - 7200
            recs = [
                {'dateTime': far_outside, 'usUnits': 1, 'interval': 5, 'outTemp': 99.0},
                {'dateTime': just_outside, 'usUnits': 1, 'interval': 5, 'outTemp': 88.0}]
            for i, ts in enumerate(inside):
                recs.append({'dateTime': ts, 'usUnits': 1, 'interval': 5,
                             'outTemp': 50.0 + i})
            dbm.addRecord(recs)

            day_accum = weewx.accum.Accum(
                weeutil.weeutil.archiveDaySpan(now), unit_system)
            day_accum.addRecord(
                {'dateTime': now - 60, 'usUnits': 1, 'outTemp': 55.0}, weight=300)

            accum, valid = user.loopdata.LoopData.create_continuous_accum(
                '1h', unit_system, 5, {'outTemp'}, timelength, day_accum, dbm)

            self.assertIsNotNone(accum)
            self.assertIn('outTemp', valid)
            self.assertIn('outTemp', accum)
            self.assertEqual(type(accum), user.loopdata.ContinuousAccum)
            self.assertEqual(type(accum['outTemp']), user.loopdata.ContinuousScalarStats)
            # Only the 3 in-window records prime the accumulator.  Both the
            # far-outside (99.0) and just-outside (88.0) records are older than
            # now - timelength and must be trimmed.  count == 3 verifies the
            # left-edge exclusion; if either out-of-window record leaked in,
            # count would be 4 or 5.
            self.assertEqual(accum['outTemp'].count, 3)

        finally:
            if dbm is not None:
                dbm.close()
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_windrose_seed_from_database(self) -> None:
        # Spec test against a REAL sqlite archive: seed_windrose_span_accum's
        # GROUP BY must reproduce, per (bin, band) cell, the by-hand sums of
        # seconds and windSpeed*seconds -- including calm routing (speed below
        # the calm threshold OR null windDir), exclusion of null-windSpeed
        # rows, unit conversion of distances to the accumulator's system, and
        # compass wraparound.  Continuous seeding replays the same records
        # with per-record timestamps (so they can later expire).
        unit_system = weewx.US
        tmpdir = tempfile.mkdtemp()
        dbm = None
        try:
            db_dict = {
                'database_name': os.path.join(tmpdir, 'test.sdb'),
                'driver': 'weedb.sqlite'}
            dbm = weewx.manager.DaySummaryManager.open_with_create(
                db_dict, table_name='archive', schema=wview_extended_schema)

            t0 = 1665750000
            # (offset, windSpeed mph, windDir) -- interval 5 minutes = 300s.
            recs = [
                (300,  4.0,  80.0),   # bin 4 (E),  band 0: 300s, 4*300 mph*s
                (600,  6.0,  85.0),   # bin 4 (E),  band 1: 300s, 6*300
                (900,  0.5,  90.0),   # calm (below 1.0 threshold): 300s
                (1200, 12.0, None),   # calm (no direction): 300s
                (1500, None, 100.0),  # excluded entirely (no windSpeed)
                (1800, 20.0, 350.0),  # bin 0 (N, wraparound), band 2: 300s, 20*300
            ]
            dbm.addRecord([
                {'dateTime': t0 + off, 'usUnits': 1, 'interval': 5,
                 'windSpeed': ws, 'windDir': wd} for off, ws, wd in recs])

            banding = user.loopdata.WindRoseBanding(
                unit_system=unit_system, edges=[1.0, 5.0, 10.0],
                seconds_per_distance=3600.0)
            accum = user.loopdata.WindRoseSpanAccum(banding, None, t0)
            user.loopdata.LoopData.seed_windrose_span_accum(
                accum, dbm, 0, t0 + 86400)

            self.assertAlmostEqual(accum.time_bins[4][0], 300.0)
            self.assertAlmostEqual(accum.dist_bins[4][0], 4.0 * 300 / 3600)   # 1/3 mile
            self.assertAlmostEqual(accum.time_bins[4][1], 300.0)
            self.assertAlmostEqual(accum.dist_bins[4][1], 0.5)
            self.assertAlmostEqual(accum.time_bins[0][2], 300.0)
            self.assertAlmostEqual(accum.dist_bins[0][2], 20.0 * 300 / 3600)  # 5/3 mile
            self.assertAlmostEqual(accum.calm_seconds, 600.0)
            # Nothing leaked anywhere else.
            self.assertAlmostEqual(sum(accum.bin_times()), 900.0)
            self.assertAlmostEqual(sum(accum.bin_distances()), (4.0 + 6.0 + 20.0) * 300 / 3600)

            # db US -> METRIC accumulator: edges convert into db units for the
            # query, distances convert out of them; times are unit-free.
            kmh = lambda mph: weewx.units.convert(
                (mph, 'mile_per_hour', 'group_speed'), 'km_per_hour')[0]
            banding_m = user.loopdata.WindRoseBanding(
                unit_system=weewx.METRIC,
                edges=[kmh(1.0), kmh(5.0), kmh(10.0)],
                seconds_per_distance=3600.0)
            accum_m = user.loopdata.WindRoseSpanAccum(banding_m, None, t0)
            user.loopdata.LoopData.seed_windrose_span_accum(
                accum_m, dbm, 0, t0 + 86400)
            self.assertAlmostEqual(accum_m.time_bins[4][0], 300.0)
            self.assertAlmostEqual(accum_m.calm_seconds, 600.0)
            self.assertAlmostEqual(
                accum_m.dist_bins[4][0], (4.0 * 300 / 3600) * 1.609344, places=5)

            # Continuous: a 900s window ending at t0+2100 replays only records
            # newer than t0+1200 -- the null-windSpeed row is skipped, leaving
            # exactly the t0+1800 record, queued as a future debit.
            caccum = user.loopdata.WindRoseContinuousAccum(banding, 900)
            user.loopdata.LoopData.seed_windrose_continuous_accums(
                {'15m': caccum}, dbm, unit_system, float(t0 + 2100), 15)
            self.assertAlmostEqual(caccum.time_bins[0][2], 300.0)
            self.assertAlmostEqual(caccum.dist_bins[0][2], 20.0 * 300 / 3600)
            self.assertAlmostEqual(caccum.calm_seconds, 0.0)
            self.assertAlmostEqual(sum(caccum.bin_times()), 300.0)
            self.assertEqual(len(caccum.future_debits), 1)

        finally:
            if dbm is not None:
                dbm.close()
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_windrose_end_to_end(self) -> None:
        # Feed loop packets through generate_loopdata_dictionary with windrose
        # fields configured and verify every projection of the output json:
        # .sum (distances in report units), .time, .banded, .calm, the
        # windrose.bands legend helper and unit.label.windrose.  Expected
        # values are by-hand: default US bands are 1.1, 4.7, 8.1, 12.8, 19.7,
        # 24.8 mph; each loop packet weighs loop_frequency = 2.0 seconds.
        specified_fields = [
            'day.windrose.sum.round(3)',
            'day.windrose.sum.km.round(3)',
            'day.windrose.sum.formatted',
            'day.windrose.time',
            'day.windrose.banded',
            'day.windrose.calm',
            '30m.windrose.time',
            'unit.label.windrose',
        ]
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, specified_fields)
        key = cfg.legacy.windrose_key
        self.assertEqual(cfg.windrose_span_periods, {(key, 'day')})
        self.assertEqual(cfg.windrose_continuous_periods, {(key, '30m')})
        # windrose needs the underlying observations in the packet.
        self.assertIn('windSpeed', cfg.obstypes.current)
        self.assertIn('windDir', cfg.obstypes.current)

        pkt_time = 1593630000  # noon PDT, 2020-07-01 (TZ set by _get_config)
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        self.assertIn((key, 'day'), accums.windrose_span)
        self.assertIn((key, '30m'), accums.windrose_continuous)

        pkts = [
            {'dateTime': pkt_time,     'usUnits': 1, 'windSpeed': 7.2,  'windDir': 90.0},   # bin 4, band 1
            {'dateTime': pkt_time + 2, 'usUnits': 1, 'windSpeed': 0.5,  'windDir': 90.0},   # calm
            {'dateTime': pkt_time + 4, 'usUnits': 1, 'windSpeed': 20.0, 'windDir': 350.0},  # bin 0, band 4
        ]
        for pkt in pkts:
            loopdata_pkt = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
                pkt, cfg, accums)

        expected_e = 7.2 * 2.0 / 3600.0    # 0.004 miles east
        expected_n = 20.0 * 2.0 / 3600.0   # 0.0111... miles north
        sums = loopdata_pkt['day.windrose.sum.round(3)']
        self.assertEqual(len(sums), 16)
        self.assertAlmostEqual(sums[4], round(expected_e, 3))
        self.assertAlmostEqual(sums[0], round(expected_n, 3))
        self.assertEqual(sum(1 for v in sums if v != 0.0), 2)

        sums_km = loopdata_pkt['day.windrose.sum.km.round(3)']
        self.assertAlmostEqual(sums_km[4], round(expected_e * 1.609344, 3))

        fmt = cfg.legacy.formatter.get_format_string('mile')
        formatted = loopdata_pkt['day.windrose.sum.formatted']
        self.assertEqual(formatted[4], fmt % expected_e)

        times = loopdata_pkt['day.windrose.time']
        self.assertAlmostEqual(times[4], 2.0)
        self.assertAlmostEqual(times[0], 2.0)
        self.assertAlmostEqual(sum(times), 4.0)

        banded = loopdata_pkt['day.windrose.banded']
        self.assertEqual(len(banded), 16)
        self.assertEqual(len(banded[0]), 6)
        self.assertAlmostEqual(banded[4][1], 2.0)
        self.assertAlmostEqual(banded[0][4], 2.0)

        self.assertAlmostEqual(loopdata_pkt['day.windrose.calm'], 2.0)
        self.assertEqual(loopdata_pkt['30m.windrose.time'], times)
        self.assertEqual(loopdata_pkt['windrose.bands'],
                         [1.1, 4.7, 8.1, 12.8, 19.7, 24.8])
        self.assertEqual(loopdata_pkt['unit.label.windrose'],
                         cfg.legacy.formatter.get_label_string('mile'))

    # ---- Sample-report i18n (6.4) -----------------------------------------
    # The translation plumbing ported from weewx-skyfield 1.12/weewx-celestial
    # 7.2: [Texts] is gettext-style (the English string IS the key; a report
    # falls back to it one string at a time), and everything the live
    # javascript composes is translated at generation time and fed in as the
    # T/CARDINALS globals through json.dumps.  These tests scrape the
    # template sources, so their expectations derive from spec, not from
    # loopdata output.

    I18N_SKIN_DIR = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), '..', 'skins', 'LoopData')
    I18N_BODIES = ['sun', 'moon', 'mercury', 'venus', 'earth', 'mars',
                   'jupiter', 'saturn', 'uranus', 'neptune', 'pluto',
                   'proxima_centauri']

    @staticmethod
    def i18n_lang_conf(dirname: str, name: str) -> configobj.ConfigObj:
        return configobj.ConfigObj(os.path.join(dirname, name),
                                   encoding='utf-8', file_error=True)

    @classmethod
    def i18n_rendered_keys(cls) -> Set[str]:
        """Every translation key the page can render, read from the
        $gettext("...")/$gettext('...') literals in the template and the
        include (keys are single-line literals by convention)."""
        keys: Set[str] = set()
        for name in ('index.html.tmpl', 'realtime_updater.inc'):
            with open(os.path.join(cls.I18N_SKIN_DIR, name), encoding='utf-8') as f:
                found = re.findall(r'\$gettext\(\s*(?:"([^"]+)"|\'([^\']+)\')\s*\)',
                                   f.read())
            assert found, name
            keys |= {a or b for a, b in found}
        return keys

    @classmethod
    def i18n_served_keys(cls) -> Set[str]:
        """The page-rendered keys plus the value-side keys loopdata itself
        reads from the target report's [Texts] (the trend.barometer.desc
        descriptions) -- everything the shipped lang files must carry."""
        return cls.i18n_rendered_keys() | set(
            user.loopdata.BARO_TREND_DESCS.values())

    def test_i18n_en_conf_ships_exactly_what_renders(self):
        # Both directions: a rendered key missing from lang/en.conf fails,
        # and an en.conf key nothing renders fails -- the English file is
        # the reference dictionary for translators, and it must grow and
        # shrink with the features that render it.
        conf = self.i18n_lang_conf(os.path.join(self.I18N_SKIN_DIR, 'lang'), 'en.conf')
        shipped = dict(conf['Texts'])
        rendered = self.i18n_served_keys()
        self.assertEqual(sorted(rendered - set(shipped)), [],
                         'rendered/served but not in en.conf')
        self.assertEqual(sorted(set(shipped) - rendered), [],
                         'in en.conf but never rendered/served')
        # English is the identity translation: every value equals its key
        # (so the file doubles as the untranslated reference).
        self.assertEqual([k for k, v in shipped.items() if v != k], [])
        # Every English format string must itself format cleanly: the
        # javascript's fmt and the template fall back to it.
        for k in rendered:
            k.format(**{name: 'x' for name in set(re.findall(r'\{(\w+)\}', k))})

    def test_i18n_javascript_lookups_match_the_t_feed(self):
        # The include's javascript looks composed strings up in T by
        # English-key literal (non-ASCII \u-escaped to survive the
        # html_entities output filter and match json.dumps' escaping).  A
        # lookup key that is not fed into T -- or a T entry whose dict key
        # differs from its $gettext argument -- falls back to English
        # silently, so pin all three sets together.
        with open(os.path.join(self.I18N_SKIN_DIR, 'realtime_updater.inc'),
                  encoding='utf-8') as f:
            source = f.read()
        t_pairs = re.findall(
            r"#silent \$t\.update\(\{'([^']+)': \$gettext\('([^']+)'\)\}\)", source)
        self.assertTrue(t_pairs)
        for dict_key, gettext_key in t_pairs:
            self.assertEqual(dict_key, gettext_key)
        t_keys = {k for k, _ in t_pairs}
        js = re.sub(r'^\s*#.*$', '', source, flags=re.MULTILINE)
        fmt_keys = {bytes(k, 'ascii').decode('unicode_escape')
                    for k in re.findall(r"fmt\('([^']+)'", js)}
        self.assertTrue(fmt_keys)
        self.assertEqual(sorted(fmt_keys - t_keys), [], 'fmt key never fed into T')
        self.assertEqual(sorted(t_keys - fmt_keys), [], 'T entry no fmt call reads')

    def test_skin_theme_tokens_are_complete(self):
        """The palette is css, and both themes must cover all of it.

        Since 7.5 the instruments are SVG dressed by css classes, so the
        javascript names no color at all, and the old drift -- two lists
        of colors falling out of step -- cannot happen.  The drift that
        CAN happen is quieter: add a token to :root and forget it in the
        light theme and the light page silently keeps the dark value,
        which looks like a design choice rather than a bug.  So every
        token must be themed, the two places that select the light values
        must select the SAME set, and nothing may use a token nobody
        declares.
        """
        with open(os.path.join(self.I18N_SKIN_DIR, 'index.html.tmpl'),
                  encoding='utf-8') as f:
            template = f.read()
        with open(os.path.join(self.I18N_SKIN_DIR, 'realtime_updater.inc'),
                  encoding='utf-8') as f:
            include = f.read()

        root = re.search(r':root\s*\{(.*?)\n      \}', template, re.DOTALL)
        self.assertIsNotNone(root, 'no :root block in index.html.tmpl')
        declared = re.findall(r'--([\w-]+)\s*:', root.group(1))
        palette = {n for n in declared if not n.startswith('light-')}
        values = {n[len('light-'):] for n in declared if n.startswith('light-')}
        self.assertTrue(palette, 'no palette tokens in :root')

        # Every token has a light counterpart and vice versa.  Names, not
        # values: the values are deliberately different.
        self.assertEqual(sorted(palette - values), [],
                         'a palette token has no --light- value')
        self.assertEqual(sorted(values - palette), [],
                         'a --light- value themes a token that does not exist')

        # The two selectors that apply the light theme.  A media query for
        # a viewer whose system asks for it, and the [data-theme] pin.
        media = re.search(
            r'@media \(prefers-color-scheme: light\)\s*\{\s*'
            r':root:not\(\[data-theme="dark"\]\)\s*\{(.*?)\n        \}',
            template, re.DOTALL)
        self.assertIsNotNone(media, 'no prefers-color-scheme block')
        pinned = re.search(r':root\[data-theme="light"\]\s*\{(.*?)\n      \}',
                           template, re.DOTALL)
        self.assertIsNotNone(pinned, 'no [data-theme="light"] block')

        def applied(block):
            return dict(re.findall(r'--([\w-]+)\s*:\s*var\(--light-([\w-]+)\)\s*;',
                                   block))
        self.assertEqual(applied(media.group(1)), applied(pinned.group(1)),
                         'the media query and the [data-theme] pin apply '
                         'different tokens; a viewer following their system '
                         'would get a different page from one pinned by config')
        self.assertEqual(sorted(applied(media.group(1))), sorted(palette),
                         'the light theme does not cover every palette token; '
                         'the ones missing silently keep their dark value')
        for token, value in applied(media.group(1)).items():
            self.assertEqual(token, value,
                             '--%s takes its light value from --light-%s'
                             % (token, value))

        # Nothing may USE a token nobody declares: an undeclared var() is
        # invalid at computed time, and the stroke or fill falls back to
        # its initial value -- black -- which looks like a palette choice
        # rather than a bug.  The css uses them by name; the windrose's
        # band fills are built in the javascript as var(--rose<n>), n
        # from 1 to 6.
        used = set(re.findall(r'var\(--([\w-]+)\)', template))
        anywhere = set(re.findall(r'--([\w-]+)\s*:', template))
        self.assertTrue(used & palette, 'the css uses no palette tokens')
        self.assertEqual(sorted(used - anywhere), [],
                         'the css uses a custom property nothing declares')
        self.assertIn("'var(--rose'", include,
                      'the windrose no longer builds its fills from --rose<n>')
        self.assertEqual({'rose%d' % n for n in range(1, 7)} - palette, set(),
                         'the six --rose stops are not all declared')

        # No color literal may survive anywhere in the include.  The
        # drawing names classes and the stylesheet dresses them; a color
        # written in the javascript cannot follow the theme.
        strays = [line.strip() for line in include.split('\n')
                  if re.search(r"'#[0-9a-fA-F]{3,8}'", line)
                  or re.search(r"rgba?\([0-9]", line)]
        self.assertEqual(strays, [],
                         'a color literal is left in the drawing code; it '
                         'cannot follow the theme')

    # Which surface each color is used ON, and the floor it must clear
    # there.  4.5 for text, 3.0 for a graphic a reading depends on.
    #
    # This table exists because of a real defect: in 7.3 the LIVE /
    # OFFLINE / BAD DATA / CLICK-ME indicator was painted with a color
    # tuned against the dial FACE, on the GROUND.  In the light theme that
    # measured 1.67:1 and the indicator vanished, CLICK-ME with it, which
    # is the control that restarts an expired page.  The token pairs are
    # what a theme actually has to get right, each on the surface it is
    # actually drawn on.
    CONTRAST_FLOORS = (
        # On the ground: the title, the timestamp, the status indicator.
        ('ink', 'ground', 4.5), ('muted', 'ground', 4.5), ('live', 'ground', 4.5),
        # On the card: the heading and every line under a dial.
        ('heading', 'card', 4.5), ('ink', 'card', 4.5), ('ink-2', 'card', 4.5),
        ('muted', 'card', 4.5), ('hi', 'card', 4.5), ('lo', 'card', 4.5),
        # On the face: the numerals and letters, then the marks.
        ('ink-2', 'face', 4.5), ('letter', 'face', 4.5), ('major', 'face', 4.5),
        ('muted', 'face', 4.5),
        ('needle', 'face', 3.0), ('range', 'face', 3.0), ('tick', 'face', 3.0),
        ('gust', 'face', 3.0),
        # The face stands barely off its card, so the rim draws the disc;
        # the legend's swatch edges sit on the card.
        ('rim', 'card', 3.0), ('swatch-edge', 'card', 3.0),
        # The windrose sits on a face of its own, where its calmest band
        # and its rings must show.  The rings were 1.26:1 in dark and
        # 1.37:1 in light as a hairline, and all but invisible.
        ('rose1', 'face', 3.0), ('ring', 'face', 3.0),
    )

    @staticmethod
    def _contrast(a, b):
        def channel(c):
            c = c / 255
            return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
        def lum(h):
            h = h.lstrip('#')
            return sum(w * channel(int(h[i:i + 2], 16)) for w, i
                       in zip((0.2126, 0.7152, 0.0722), (0, 2, 4)))
        first, second = lum(a), lum(b)
        hi, lo = max(first, second), min(first, second)
        return (hi + 0.05) / (lo + 0.05)

    def test_skin_theme_contrast_floors(self):
        """Every themed color must clear the surface it is used on.

        The token-coverage test above sees that a theme defines every
        color.  It cannot see that a color is READABLE, and the two
        failures this release had were both of that kind and both the
        same shape: a value tuned against the dial face, used on the page
        ground instead.  The status indicator measured 1.67:1 that way,
        and the windrose legend chips 1.05:1.

        Sabotage it by moving any --light-* value a few steps toward its
        own background.
        """
        with open(os.path.join(self.I18N_SKIN_DIR, 'index.html.tmpl'),
                  encoding='utf-8') as f:
            template = f.read()
        root = re.search(r':root\s*\{(.*?)\n      \}', template, re.DOTALL)
        self.assertIsNotNone(root, 'no :root block in index.html.tmpl')
        values = dict(re.findall(r'--([\w-]+)\s*:\s*(#[0-9a-fA-F]{6})\s*;',
                                 root.group(1)))
        themes = {
            'dark': {k: v for k, v in values.items()
                     if not k.startswith('light-')},
            'light': {k[len('light-'):]: v for k, v in values.items()
                      if k.startswith('light-')},
        }
        bad = []
        for name, palette in sorted(themes.items()):
            for fore, back, floor in self.CONTRAST_FLOORS:
                self.assertIn(fore, palette, '%s theme has no --%s' % (name, fore))
                self.assertIn(back, palette, '%s theme has no --%s' % (name, back))
                got = self._contrast(palette[fore], palette[back])
                if got < floor:
                    bad.append('%s: --%s on --%s is %.2f:1, wants %.1f'
                               % (name, fore, back, got, floor))
        self.assertEqual(bad, [], 'a themed color cannot be read where it '
                                  'is used:\n' + '\n'.join(bad))

    def test_i18n_lang_files_consistent(self):
        # Every shipped lang file must parse, translate only keys en.conf
        # ships (a stale key would silently never render), keep each value's
        # placeholders exactly its key's set (a renamed one knocks the
        # string back to English at run time), and carry the sections a
        # loopdata TARGET report in this language serves: ordinates for
        # .ordinal_compass fields, moon phases, body and constellation
        # names for almanac fields, hemispheres for station lat/lon fields.
        lang_dir = os.path.join(self.I18N_SKIN_DIR, 'lang')
        rendered = self.i18n_served_keys()
        abbrs = set(self.i18n_lang_conf(lang_dir, 'en.conf')['Almanac']['Constellations'])
        self.assertEqual(len(abbrs), 88)
        names = sorted(os.listdir(lang_dir))
        self.assertIn('en.conf', names)
        self.assertIn('de.conf', names)
        self.assertIn('fr.conf', names)
        self.assertIn('nl.conf', names)
        self.assertIn('es.conf', names)
        self.assertIn('da.conf', names)
        self.assertIn('it.conf', names)
        self.assertIn('no.conf', names)
        self.assertIn('sv.conf', names)
        for name in names:
            conf = self.i18n_lang_conf(lang_dir, name)
            for key, val in dict(conf['Texts']).items():
                self.assertIn(key, rendered, (name, key))
                self.assertIsInstance(val, str, (name, key))
                self.assertEqual(set(re.findall(r'\{(\w+)\}', val)),
                                 set(re.findall(r'\{(\w+)\}', key)), (name, key))
            self.assertEqual(len(conf['Labels']['hemispheres']), 4, name)
            self.assertEqual(len(conf['Units']['Ordinates']['directions']), 17, name)
            self.assertEqual(len(conf['Almanac']['moon_phases']), 8, name)
            for body in self.I18N_BODIES:
                self.assertTrue(conf['Almanac'][body], (name, body))
            self.assertEqual(set(conf['Almanac']['Constellations']), abbrs, name)

    def test_i18n_de_conf_is_complete(self):
        # German is a full translation: every rendered key is covered, so a
        # new feature's strings fail here until de.conf learns them.
        conf = self.i18n_lang_conf(os.path.join(self.I18N_SKIN_DIR, 'lang'), 'de.conf')
        self.assertEqual(sorted(self.i18n_served_keys() - set(conf['Texts'])), [])

    def test_i18n_fr_conf_is_complete(self):
        # French likewise ships complete.
        conf = self.i18n_lang_conf(os.path.join(self.I18N_SKIN_DIR, 'lang'), 'fr.conf')
        self.assertEqual(sorted(self.i18n_served_keys() - set(conf['Texts'])), [])

    def test_i18n_nl_conf_is_complete(self):
        # Dutch likewise ships complete.
        conf = self.i18n_lang_conf(os.path.join(self.I18N_SKIN_DIR, 'lang'), 'nl.conf')
        self.assertEqual(sorted(self.i18n_served_keys() - set(conf['Texts'])), [])

    def test_i18n_es_conf_is_complete(self):
        # Spanish likewise ships complete.
        conf = self.i18n_lang_conf(os.path.join(self.I18N_SKIN_DIR, 'lang'), 'es.conf')
        self.assertEqual(sorted(self.i18n_served_keys() - set(conf['Texts'])), [])

    def test_i18n_da_conf_is_complete(self):
        # Danish likewise ships complete.
        conf = self.i18n_lang_conf(os.path.join(self.I18N_SKIN_DIR, 'lang'), 'da.conf')
        self.assertEqual(sorted(self.i18n_served_keys() - set(conf['Texts'])), [])

    def test_i18n_it_conf_is_complete(self):
        # Italian likewise ships complete.
        conf = self.i18n_lang_conf(os.path.join(self.I18N_SKIN_DIR, 'lang'), 'it.conf')
        self.assertEqual(sorted(self.i18n_served_keys() - set(conf['Texts'])), [])

    def test_i18n_no_conf_is_complete(self):
        # Norwegian (Bokmål) likewise ships complete.
        conf = self.i18n_lang_conf(os.path.join(self.I18N_SKIN_DIR, 'lang'), 'no.conf')
        self.assertEqual(sorted(self.i18n_served_keys() - set(conf['Texts'])), [])

    def test_i18n_sv_conf_is_complete(self):
        # Swedish likewise ships complete.
        conf = self.i18n_lang_conf(os.path.join(self.I18N_SKIN_DIR, 'lang'), 'sv.conf')
        self.assertEqual(sorted(self.i18n_served_keys() - set(conf['Texts'])), [])

    def test_i18n_lang_files_in_step_with_siblings(self):
        # The shared vocabulary is copied verbatim from weewx-skyfield's and
        # weewx-celestial's lang files (German, French and Danish
        # native-speaker reviewed; Dutch, Spanish, Italian, Norwegian and
        # Swedish Beta): body names, moon phases, hemispheres,
        # ordinates, all 88 constellation names, and every [Texts] key
        # the pages share -- the same cross-repo rule celestial pins
        # against skyfield.  Skips when no sibling lang directory is
        # available.
        lang_dir = os.path.join(self.I18N_SKIN_DIR, 'lang')
        repo_parent = os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.abspath(__file__))))
        siblings = [d for d in (
            os.path.join(repo_parent, 'weewx-skyfield', 'skins', 'Skyfield', 'lang'),
            os.path.join(repo_parent, 'weewx-celestial', 'skins', 'Celestial', 'lang'),
            '/home/weewx/weewx-data/skins/Skyfield/lang',
        ) if os.path.exists(os.path.join(d, 'de.conf'))]
        if not siblings:
            self.skipTest('no sibling lang directory is available')
        for sib_dir in siblings:
            for name in ('en.conf', 'de.conf', 'fr.conf', 'nl.conf', 'es.conf',
                         'da.conf', 'it.conf', 'no.conf', 'sv.conf'):
                if not os.path.exists(os.path.join(sib_dir, name)):
                    continue     # a sibling that has not shipped this language
                sib = self.i18n_lang_conf(sib_dir, name)
                ld = self.i18n_lang_conf(lang_dir, name)
                self.assertEqual(dict(ld['Almanac']['Constellations']),
                                 dict(sib['Almanac']['Constellations']),
                                 (sib_dir, name))
                for body in self.I18N_BODIES:
                    if body in sib['Almanac']:
                        self.assertEqual(ld['Almanac'][body], sib['Almanac'][body],
                                         (sib_dir, name, body))
                self.assertEqual(list(ld['Almanac']['moon_phases']),
                                 list(sib['Almanac']['moon_phases']), (sib_dir, name))
                self.assertEqual(list(ld['Labels']['hemispheres']),
                                 list(sib['Labels']['hemispheres']), (sib_dir, name))
                self.assertEqual(list(ld['Units']['Ordinates']['directions']),
                                 list(sib['Units']['Ordinates']['directions']),
                                 (sib_dir, name))
                for key in set(ld['Texts']) & set(sib['Texts']):
                    self.assertEqual(ld['Texts'][key], sib['Texts'][key],
                                     (sib_dir, name, key))

    # ------------------------------------------------------------------
    # Manual/code lockstep audits
    # ------------------------------------------------------------------
    # Every list that exists BOTH in code and in prose is a place a release
    # can quietly make the manual wrong.  These audits pin the two together.
    #
    # Four rules, each of which caught something real when this set was
    # written (see the release that added them):
    #   1. Compare in BOTH directions.  "In the code, missing from the docs"
    #      is the obvious half; "documented but nothing reads it" is the half
    #      users report as a bug.  remote_port was found by the first,
    #      foo.bar.com by the second.
    #   2. Every exemption carries its REASON, inline.  An exemption without
    #      one is how an audit quietly stops auditing.  When one of these
    #      fails, the fix is almost always the manual -- widening a skip list
    #      should feel wrong.
    #   3. Extractors assert a landmark and a plausible count.  An audit that
    #      parses nothing is green in exactly the way an audit that works is.
    #   4. Each was mutation-tested when written: break the thing it checks,
    #      confirm it fails, restore.
    #
    # These read only repo sources (never loopdata output), so they are
    # spec-derived and belong in spec_only_runner.py.

    REPO_ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    DOCS_DIR = os.path.join(REPO_ROOT, 'docs')

    # Home is exempt from the in-body link line: it would point at the page
    # the reader is already on, and it carries the three buttons instead.
    DOC_HOME = 'index.md'

    MANUAL_URL = 'https://chaunceygardiner.github.io/weewx-loopdata/'
    REPO_URL = 'https://github.com/chaunceygardiner/weewx-loopdata'

    @classmethod
    def doc_pages(cls) -> List[str]:
        """Every manual page, Home included."""
        names = sorted(n for n in os.listdir(cls.DOCS_DIR) if n.endswith('.md'))
        # Landmark + plausible count: the manual has always had at least
        # Home, installation, configuration and the field reference.
        for landmark in (cls.DOC_HOME, 'installation.md', 'configuration.md',
                         'field-reference.md'):
            assert landmark in names, (landmark, names)
        assert len(names) >= 10, names
        return names

    @classmethod
    def doc_text(cls, name: str) -> str:
        with open(os.path.join(cls.DOCS_DIR, name), encoding='utf-8') as f:
            return f.read()

    @classmethod
    def repo_text(cls, *parts: str) -> str:
        with open(os.path.join(cls.REPO_ROOT, *parts), encoding='utf-8') as f:
            return f.read()

    @staticmethod
    def heading_slug(heading: str) -> str:
        """kramdown's id for a heading, as GitHub Pages builds it.

        NB kramdown emits one hyphen per SPACE, not one per run: dropping an
        em dash from `The chart -- name` leaves both surrounding spaces and
        thus TWO hyphens.  test_manual_heading_slug_rule pins that case
        against the real built output.
        """
        slug = heading.strip().lower()
        slug = slug.replace('`', '')
        slug = re.sub(r'\[([^\]]*)\]\([^)]*\)', r'\1', slug)   # link text only
        slug = re.sub(r'[^\w\s-]', '', slug)
        return re.sub(r'\s', '-', slug)

    def test_manual_heading_slug_rule(self):
        # An executable counterexample for the kramdown gotcha above.  The
        # whole anchor audit rests on heading_slug, and this rule was
        # verified against every id in a real GitHub-Pages build of the
        # manual before being written down.
        self.assertEqual(self.heading_slug('## 5. Handle missing fields'
                                           .lstrip('# ')), '5-handle-missing-fields')
        self.assertEqual(self.heading_slug('The chart — `name`'),
                         'the-chart--name')
        self.assertEqual(self.heading_slug('`[[RsyncSpec]]`'), 'rsyncspec')
        self.assertEqual(self.heading_slug('Translating `trend.barometer.desc`'),
                         'translating-trendbarometerdesc')

    def test_manual_internal_links_and_anchors_resolve(self):
        # A cross-page link whose target page was renamed, or whose #anchor
        # no longer names a heading, lands the reader in the wrong place and
        # nothing else in the suite can see it.  Checks every relative link
        # on every page, including same-page fragments.
        pages = set(self.doc_pages())
        anchors: Dict[str, Set[str]] = {}
        for name in pages:
            anchors[name] = {
                self.heading_slug(h) for h in
                re.findall(r'^#{2,6}\s+(.*)$', self.doc_text(name), re.M)}
        total = sum(len(v) for v in anchors.values())
        assert total >= 50, total      # landmark: the manual is heading-rich
        checked = 0
        problems: List[str] = []
        for name in sorted(pages):
            for target in re.findall(r'\]\((?!https?:|mailto:)([^)]+)\)',
                                     self.doc_text(name)):
                checked += 1
                path, _, frag = target.partition('#')
                # The manual is built by Jekyll, so pages cross-link as
                # .html even though they are .md in the repo.
                if path.endswith('.html'):
                    path = path[:-len('.html')] + '.md'
                if path.startswith('images/'):
                    self.assertTrue(os.path.exists(
                        os.path.join(self.DOCS_DIR, path)), (name, target))
                    continue
                if path and path not in pages:
                    problems.append('%s -> missing page %s' % (name, target))
                    continue
                if frag and frag not in anchors[path or name]:
                    problems.append('%s -> %s (no such heading)' % (name, target))
        assert checked >= 30, checked  # landmark: pages do cross-link
        self.assertEqual(problems, [])

    def test_manual_page_furniture(self):
        # Part of a house convention shared with weewx-skyfield and
        # weewx-celestial: every content page carries an in-body link line
        # under its H1, because the manual ranks on Google where the GitHub
        # project does not -- and a reader of the raw markdown (release zip,
        # github blob view) sees no theme sidebar at all.  Nothing but this
        # audit can see that class of drift.
        for name in self.doc_pages():
            lines = self.doc_text(name).split('\n')
            h1s = [i for i, ln in enumerate(lines) if ln.startswith('# ')]
            self.assertTrue(h1s, name)
            if name == self.DOC_HOME:
                # Home carries the three buttons instead of the link line.
                buttons = re.findall(r'\[([^\]]+)\]\([^)]+\)\{:\s*\.btn',
                                     self.doc_text(name))
                self.assertEqual(len(buttons), 3, (name, buttons))
                continue
            where = next((i for i, ln in enumerate(lines)
                          if '%s manual](' % 'weewx-loopdata' in ln), None)
            self.assertIsNotNone(where, '%s: no in-body link line' % name)
            self.assertEqual(where, h1s[0] + 2,
                             '%s: link line must sit under the H1' % name)
            # All three destinations, so none can quietly go missing.
            self.assertIn(self.MANUAL_URL, lines[where], name)
            self.assertIn(self.REPO_URL, lines[where], name)
            self.assertIn(self.REPO_URL + '/issues', lines[where], name)
            # The rule below it, with a blank line between.  The blank is
            # load-bearing: `---` directly under text is setext syntax, and
            # kramdown would read the link line as an <h2>, silently turning
            # navigation furniture into a heading.
            rule = next((i for i in range(where, min(where + 5, len(lines)))
                         if lines[i].strip() == '---'), None)
            self.assertIsNotNone(rule, '%s: no rule after the link line' % name)
            self.assertEqual(lines[rule - 1].strip(), '',
                             '%s: blank line before the rule (setext risk)' % name)

    def test_published_manual_urls_are_not_trailing_slash(self):
        # Jekyll builds <page>.html, NOT <page>/index.html, and GitHub Pages
        # does not map a trailing-slash path onto the .html file.  Measured
        # against the live site:
        #     /                    200      /installation.html  200
        #     /installation        200      /installation/      404
        # So an absolute deep link written in the natural directory form is
        # simply dead.  Only the site ROOT may end in a slash.  A sibling
        # repo shipped twelve such links on its README front page; nothing
        # in the internal-link audit can see them, because these are
        # absolute URLs to the published site rather than links between
        # local pages.
        #
        # The bare extensionless form (/installation) does work, but only
        # via Pages' fallback rather than a file that was built, so this
        # requires the explicit .html that jekyll's own sitemap advertises.
        site = self.MANUAL_URL.rstrip('/')
        sources = [('README.md', self.repo_text('README.md')),
                   ('install.py', self.repo_text('install.py')),
                   ('changes.md', self.repo_text('changes.md'))]
        sources += [(n, self.doc_text(n)) for n in self.doc_pages()]
        checked = 0
        problems: List[str] = []
        for where, text in sources:
            for url in re.findall(re.escape(site) + r"[^\s)\"'`<>\]]*", text):
                checked += 1
                path, _, frag = url[len(site):].partition('#')
                if path in ('', '/'):
                    continue                       # the site root is fine
                if not path.endswith('.html'):
                    problems.append('%s: %s (must end in .html)' % (where, url))
                    continue
                # Shape alone is not enough: a correctly-formed .html URL
                # that names no page is equally dead.  These point into our
                # OWN manual, so the page must exist in docs/.  (Links into
                # the SIBLING manuals are deliberately shape-checked only --
                # verifying those would need the network, and a test that
                # fails when GitHub is unreachable is worse than the bug it
                # guards.)
                page = path.lstrip('/')[:-len('.html')] + '.md'
                if not os.path.exists(os.path.join(self.DOCS_DIR, page)):
                    problems.append('%s: %s (no such page)' % (where, url))
                    continue
                # A well-formed URL naming a real page is still dead if its
                # #fragment names no heading -- rename the section and the
                # link passes every other check here while landing the
                # reader at the top of the page.  Nothing else covers it:
                # test_manual_internal_links_and_anchors_resolve walks only
                # RELATIVE links between pages in docs/, and these are
                # absolute URLs to the published site.
                if frag and frag not in {
                        self.heading_slug(h) for h in re.findall(
                            r'^#{2,6}\s+(.*)$', self.doc_text(page), re.M)}:
                    problems.append('%s: %s (no such heading)' % (where, url))
        assert checked >= 12, checked   # landmark: the links were found
        self.assertEqual(problems, [],
                         'absolute links to the published manual must be the '
                         'bare root or name a real page as .html, and any '
                         '#fragment must name a heading on that page (a '
                         'trailing slash 404s, and so does a well-formed '
                         'wrong name)')
        # jekyll-redirect-from's redirect_to is site-absolute and gets
        # baseurl prefixed BY THE PLUGIN.  A slash form would send an old
        # indexed URL to a 404 -- the opposite of the redirect's point --
        # and writing baseurl in by hand yields /weewx-loopdata/weewx-loopdata/...
        for name in self.doc_pages():
            for target in re.findall(r'^redirect_to:\s*(\S+)\s*$',
                                     self.doc_text(name), re.M):
                self.assertTrue(target.endswith('.html'), (name, target))
                self.assertNotIn('/weewx-loopdata/', target, (name, target))
                self.assertTrue(os.path.exists(os.path.join(
                    self.DOCS_DIR, os.path.basename(target)[:-len('.html')]
                    + '.md')), (name, target))

    def test_manual_theme_is_pinned_and_uncredited(self):
        # An unpinned remote_theme lets an upstream change restyle the manual
        # with no commit here.  And the theme prints a credit for itself, and
        # a link to its own repository, on every page unless the capture of
        # nav_footer_custom.html is NON-empty -- which cuts against the very
        # reason the in-body link line above exists.
        config = self.repo_text('docs', '_config.yml')
        self.assertIn('remote_theme: just-the-docs/just-the-docs@v', config)
        # jekyll-relative-links is a GitHub Pages default, but a LOCAL build
        # renders every .md cross-link dead without it named explicitly.
        self.assertIn('jekyll-relative-links', config)
        override = self.repo_text('docs', '_includes', 'nav_footer_custom.html')
        self.assertTrue(override.strip(),
                        'nav_footer_custom.html must be NON-empty: the theme '
                        'takes its self-credit branch when this renders empty')
        # Doubled hyphens INSIDE the comment are legal in HTML but make the
        # document unmappable to XML 1.0, which Nu reports and --Werror
        # fails.  (The delimiters' own hyphens are stripped first, and this
        # is the exact defect a sibling manual shipped on every page.)
        interior = re.sub(r'^\s*<!--|-->\s*$', '', override.strip())
        self.assertNotIn('--', interior)
        # footer_custom.html is a DIFFERENT include -- it renders
        # site.footer_content, the copyright.  Overriding it would delete the
        # copyright and leave the advertisement, which is backwards.
        self.assertFalse(os.path.exists(os.path.join(
            self.DOCS_DIR, '_includes', 'footer_custom.html')))
        self.assertIn('footer_content:', config)

    # Config options the code reads, by [LoopData] sub-section.  The audits
    # below derive this from loopdata.py rather than hand-listing it.
    CONFIG_DICTS = {
        'file_spec_dict': 'FileSpec',
        'formatting_spec_dict': 'Formatting',
        'loop_frequency_spec_dict': 'LoopFrequency',
        'rsync_spec_dict': 'RsyncSpec',
        'include_spec_dict': 'Include',
    }

    @classmethod
    def config_options_read(cls) -> Dict[str, str]:
        """option name -> code default ('' when the code supplies none)."""
        source = cls.repo_text('bin', 'user', 'loopdata.py')
        found: Dict[str, str] = {}
        pattern = re.compile(
            r"(%s)\.get\(\s*'([A-Za-z_0-9]+)'\s*"
            r"(?:,\s*('[^']*'|\"[^\"]*\"|\[\]|\{\}|[-\w.]+))?\s*\)"
            % '|'.join(cls.CONFIG_DICTS))
        for _dict, key, dflt in pattern.findall(source):
            found.setdefault(key, (dflt or '').strip('\'"'))
        # loopdata.py reads windrose_bands off [LoopData] itself, not a
        # sub-section, so it is matched separately.
        if re.search(r"loop_config_dict\.get\('windrose_bands'", source):
            found.setdefault('windrose_bands', '')
        # Landmarks + a plausible count: if the extractor ever stops
        # matching, these are the options it must never lose.
        for landmark in ('filename', 'target_report', 'seconds', 'fields',
                         'remote_server', 'timeout'):
            assert landmark in found, (landmark, sorted(found))
        assert len(found) >= 14, sorted(found)
        return found

    def test_manual_documents_every_config_option(self):
        # BOTH directions.  An option the code reads but nothing documents is
        # invisible to users (this is how remote_port went undocumented in
        # every file for its whole life); an option the docs describe but no
        # code reads is the kind users report as a bug.
        options = set(self.config_options_read())
        for where, text in (('docs/configuration.md',
                             self.doc_text('configuration.md')),
                            ('README.md', self.repo_text('README.md'))):
            documented = set(re.findall(r'`([a-z_0-9]+)`', text))
            documented |= set(re.findall(r'^\s*\*\s*`?([a-z_0-9]+)`?\s*:', text, re.M))
            missing = sorted(o for o in options if o not in documented)
            self.assertEqual(missing, [],
                             '%s documents no such option: %s' % (where, missing))
        # The other direction, against the option tables only: a name in
        # backticks in a table row that the code never reads.
        rows = re.findall(r'^\|\s*`([a-z_0-9]+)`\s*\|',
                          self.doc_text('configuration.md'), re.M)
        assert len(rows) >= 14, rows          # landmark: tables were parsed
        stale = sorted(set(rows) - options)
        self.assertEqual(stale, [],
                         'configuration.md tables list options no code reads: %s'
                         % stale)

    @classmethod
    def installer_module(cls) -> Any:
        """install.py, loaded as a module.

        Loading it needs weecfg.extension imported first: that module
        aliases itself as 'setup' in sys.modules for installers written
        against the pre-5.0 name, which is what install.py's own import
        resolves through.  A module rather than an ast.literal_eval of the
        source, because the stanza is weewx.conf TEXT, not a Python
        literal.
        """
        importlib.import_module('weecfg.extension')   # registers the alias
        spec = importlib.util.spec_from_file_location(
            'loopdata_install', os.path.join(cls.REPO_ROOT, 'install.py'))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    @classmethod
    def installer_config(cls) -> configobj.ConfigObj:
        """The stanza install.py writes into a fresh weewx.conf.

        It is a ConfigObj rather than a dict so the option comments ride
        along -- weecfg merges with weeutil.config.conditional_merge, which
        copies a key's comments only if the source has them.
        """
        return cls.installer_module().LoopDataInstaller()['config']

    @classmethod
    def installer_files(cls) -> List[str]:
        """Every file install.py ships, repo-relative."""
        return [f for _dest, files in cls.installer_module().LoopDataInstaller()['files']
                for f in files]

    @classmethod
    def installer_loopdata_config(cls) -> Dict[str, Any]:
        """The [LoopData] section install.py writes into weewx.conf."""
        config = cls.installer_config()['LoopData']
        assert set(config) >= {'FileSpec', 'LoopFrequency', 'RsyncSpec'}, sorted(config)
        return config

    # A commented-out ASSIGNMENT ('#timeout = 1'), never a prose comment,
    # which by convention always has a space after the '#'.
    COMMENTED_OPTION_RE = re.compile(r'^(\s*)#(\w+)\s*=\s*(.*?)\s*$')
    CONFIG_SECTION_RE = re.compile(r'^(\s*)(\[+)([^\]]+)\]+\s*$')

    @classmethod
    def installer_commented_options(cls) -> Dict[str, Dict[str, str]]:
        """install.py's commented-out assignments, as {section: {option:
        value}}, keyed by the innermost section name.

        Read out of CONFIG as TEXT, because a commented-out option is by
        definition absent from the parsed ConfigObj -- which is the whole
        point (absent, the code's own fallback governs) and also the reason
        test_installer_stanza_is_commented, which walks the parsed object,
        cannot see any of these.
        """
        found: Dict[str, Dict[str, str]] = {}
        section = None
        for line in cls.installer_module().CONFIG.splitlines():
            header = cls.CONFIG_SECTION_RE.match(line)
            if header:
                section = header.group(3).strip()
                continue
            option = cls.COMMENTED_OPTION_RE.match(line)
            if option:
                found.setdefault(section, {})[option.group(2)] = option.group(3)
        return found

    @classmethod
    def documented_sample_config(cls, text: str) -> Tuple[Dict[str, str],
                                                          Dict[str, str],
                                                          List[str]]:
        """The page's full [LoopData] sample block, parsed into its LIVE
        assignments, its COMMENTED-OUT ones and the fields line.

        Selected by content, not position: the README has 37 fenced blocks
        and six of them mention [LoopData], but only the complete sample
        carries every sub-section.

        The two kinds of assignment are kept apart rather than lumped
        together: the block prints both, and which side a line is on is
        the very thing the page is claiming.  Lumping them was
        also the old parser's bug -- it kept any line containing '=' that
        did not start with '[', so '#timeout = 1' parsed as an option
        literally named '#timeout'.
        """
        # Odd indices only: splitting on the fence puts block CONTENTS at
        # odd positions and surrounding prose at even ones, and the prose
        # before the first fence contains the whole page.
        blocks = [b for i, b in enumerate(text.split('```'))
                  if i % 2 == 1 and '[LoopData]' in b and '[[FileSpec]]' in b
                  and '[[RsyncSpec]]' in b and '[[LoopFrequency]]' in b]
        assert len(blocks) == 1, 'expected exactly one full sample block, got %d' % len(blocks)
        block = blocks[0]
        values: Dict[str, str] = {}
        commented: Dict[str, str] = {}
        fields: List[str] = []
        for line in block.split('\n'):
            line = line.strip()
            if line.startswith('['):
                continue
            option = cls.COMMENTED_OPTION_RE.match(line)
            if option:
                commented[option.group(2)] = option.group(3)
                continue
            if '=' not in line or line.startswith('#'):
                continue
            key, _, value = line.partition('=')
            if key.strip() == 'fields':
                fields = [f.strip() for f in value.split(',')]
            else:
                values[key.strip()] = value.strip()
        return values, commented, fields

    def test_manual_sample_config_matches_the_installer(self):
        # Both the manual and the README print a [LoopData] block under the
        # claim that it is "exactly what a fresh install writes".  That claim
        # is falsifiable, and it was false: install.py wrote
        # www.foobar.com / /home/weewx/loop-data while both documents printed
        # foo.bar.com / /var/www/html.
        config = self.installer_loopdata_config()
        installed: Dict[str, str] = {}
        for section in config.values():
            if isinstance(section, dict):
                for key, value in section.items():
                    installed[key] = str(value)
        assert len(installed) >= 7, sorted(installed)
        # The commented-out half of the same claim.  install.py's stanza
        # carries commented options under [StdReport] too; only the
        # [LoopData] ones belong in this block.
        installer_commented = self.installer_commented_options()
        commented_here: Dict[str, str] = {}
        for name in config.sections:
            commented_here.update(installer_commented.get(name, {}))
        assert commented_here, 'no commented options found in [LoopData]'
        for where, text in (('docs/configuration.md',
                             self.doc_text('configuration.md')),
                            ('README.md', self.repo_text('README.md'))):
            values, commented, fields = self.documented_sample_config(text)
            for key, value in sorted(installed.items()):
                self.assertIn(key, values, (where, key))
                self.assertEqual(values[key].lower(), value.lower(), (where, key))
            for key, value in sorted(commented_here.items()):
                self.assertIn(key, commented, (where, key))
                self.assertEqual(commented[key].lower(), value.lower(), (where, key))
            # BOTH directions: a documented option the installer no longer
            # writes (7.0 dropped target_report and the fields line) is a
            # stale claim too -- and so is printing as live an option that
            # the installer now writes commented out, or the other way round.
            self.assertEqual(sorted(values), sorted(installed), where)
            self.assertEqual(sorted(commented), sorted(commented_here), where)
            self.assertEqual(fields, [], where)

    def test_manual_field_grammar_matches_the_code(self):
        # The field reference enumerates the grammar's accepted sets.  Each
        # of these is derived in loopdata.py from a dispatch table, so a new
        # aggregate or format spec lands in the code's set automatically --
        # and silently leaves the manual behind.
        text = self.doc_text('field-reference.md')
        # Fenced blocks must go FIRST: ``` is three backticks, so leaving
        # the fences in desynchronizes inline-code pairing for everything
        # after the first one (this silently shrank the set to 9 names).
        prose = re.sub(r'```.*?```', ' ', text, flags=re.S)
        # Names appear in backticks in three shapes: bare (`avg`), with a
        # leading dot as a format spec (`.raw`), and as a call with its
        # signature (`format(format_string, ...)`).  Take the identifier out
        # of each.
        quoted = {re.match(r'[a-z_0-9]*', q.lstrip('.')).group(0)
                  for q in re.findall(r'`([^`]+)`', prose)}
        quoted.discard('')
        assert len(quoted) >= 40, sorted(quoted)   # landmark: names parsed
        for agg in user.loopdata.AGG_TYPES:
            self.assertIn(agg, quoted, 'aggregate not in the field reference')
        for agg in user.loopdata.WINDROSE_AGG_TYPES:
            self.assertIn(agg, self.doc_text('windrose.md') + text, agg)
        for spec in user.loopdata.FORMAT_SPECS:
            self.assertIn(spec, quoted, 'format spec not in the field reference')
        for spec in user.loopdata.CALL_FORMAT_SPECS:
            self.assertIn(spec, quoted, 'call spec not in the field reference')
        # Periods, both directions.  'trend' and the rolling windows are
        # spelled as ranges in the manual's table, so only the fixed span
        # periods compare as literal names.
        periods = {'current', 'hour', 'day', 'week', 'month', 'year',
                   'rainyear', 'alltime'}
        rows = set(re.findall(r'^\|\s*`([a-z]+)`\s*\|', text, re.M))
        assert 'day' in rows, rows            # landmark: the table was parsed
        self.assertEqual(sorted(periods - rows), [], 'period missing from table')
        self.assertEqual(sorted(rows - periods - {'trend'}), [],
                         'table lists a period the code does not accept')

    def test_manual_almanac_cache_tiers_match_the_code(self):
        # The day tier's membership is the difference between "recomputed
        # once a day" and "recomputed every packet" in the manual's cost
        # table, and it is a hand-maintained list in prose.  antitransit and
        # visible_change were both missing from it.
        text = self.doc_text('almanac-fields.md')
        rows = [ln for ln in text.split('\n') if ln.startswith('| day |')]
        self.assertEqual(len(rows), 1, 'expected exactly one day-tier row')
        listed = set(re.findall(r'`([a-z_]+)`', rows[0]))
        self.assertEqual(sorted(user.loopdata.LoopData.almanac_day_attrs - listed),
                         [], 'day-tier attribute missing from the manual')
        self.assertEqual(sorted(listed - user.loopdata.LoopData.almanac_day_attrs),
                         [], 'manual lists a day-tier attribute the code lacks')

    def test_manual_documents_every_skin_extra(self):
        # [Extras] are the options a user actually sees.  They come from TWO
        # files and the manual owes both: skin.conf, and the [[[Extras]]]
        # the installer writes into weewx.conf -- which is the copy that
        # wins when they disagree.  refresh_rate -- the page's poll rate --
        # shipped undocumented.
        #
        # Reading skin.conf alone is what hid googleAnalyticsId and
        # analytics_host through 6.11.2.  They sit COMMENTED OUT in
        # skin.conf, so ConfigObj never sees them and an exemption for them
        # here was doing nothing; meanwhile the installer had been writing
        # both into every weewx.conf, undocumented, with semantics
        # (present-but-empty) that turned out to be broken.
        #
        # The installer's COMMENTED-OUT options count too, for the same
        # reason and read the same way -- out of the stanza's text, since a
        # commented option is absent from the parsed object.  An option is
        # no less a user-facing knob for arriving commented out; if reading
        # only what ConfigObj can see were enough, demoting an option would
        # quietly excuse the manual from documenting it.  (The two asserts
        # below are the landmark that catches exactly that.)
        skin = configobj.ConfigObj(
            os.path.join(self.I18N_SKIN_DIR, 'skin.conf'),
            encoding='utf-8', file_error=True)
        installed = self.installer_config()['StdReport']['LoopDataReport']['Extras']
        extras = (set(skin['Extras']) | set(installed)
                  | set(self.installer_commented_options().get('Extras', {})))
        assert 'loop_data_file' in extras, sorted(extras)
        assert 'googleAnalyticsId' in extras, sorted(extras)
        documented = set(re.findall(r'`([a-z_A-Z0-9]+)`',
                                    self.doc_text('sample-skin.md')))
        exempt = {
            # Written by install/release tooling, not a user-facing knob.
            'version',
        }
        missing = sorted(extras - documented - exempt)
        self.assertEqual(missing, [],
                         'sample-skin.md documents no such [Extras]: %s' % missing)

    def test_manual_language_list_matches_the_shipped_lang_files(self):
        # The shipped languages are named in three places that drift apart:
        # the Translations page, the sample skin page's count, and
        # skin.conf's own header comment (which sat four releases stale at
        # "German, French, Dutch and Spanish").
        lang_dir = os.path.join(self.I18N_SKIN_DIR, 'lang')
        codes = sorted(n[:-len('.conf')] for n in os.listdir(lang_dir)
                       if n.endswith('.conf'))
        assert 'en' in codes and len(codes) >= 5, codes
        translations = [c for c in codes if c != 'en']   # en is the reference
        i18n = self.doc_text('i18n.md')
        for code in translations:
            self.assertIn('lang/%s.conf' % code, i18n,
                          'docs/i18n.md does not name lang/%s.conf' % code)
        for code in re.findall(r'lang/([a-z]{2})\.conf', i18n):
            self.assertIn(code, codes,
                          'docs/i18n.md names lang/%s.conf, which does not ship'
                          % code)
        # skin.conf's comment must name every shipped translation too.
        header = self.repo_text('skins', 'LoopData', 'skin.conf').split('[Extras]')[0]
        for code in translations:
            self.assertIn('%s.conf' % code, header,
                          'skin.conf header does not name %s.conf' % code)
        # The sample skin page states the count, spelled out in prose.  It
        # counts TRANSLATIONS, not lang files: en.conf is the reference
        # dictionary (the identity translation), so nine files ship eight
        # translations.  The page says so explicitly -- the bare word
        # "languages" was ambiguous against the nine files on disk.
        words = {2: 'two', 3: 'three', 4: 'four', 5: 'five', 6: 'six',
                 7: 'seven', 8: 'eight', 9: 'nine', 10: 'ten', 11: 'eleven',
                 12: 'twelve'}
        count = len(translations)
        self.assertIn(count, words, 'spell out %d in the words table' % count)
        # Whitespace-normalized: the phrase wraps across source lines.
        prose = ' '.join(self.doc_text('sample-skin.md').split())
        self.assertIn('%s translations ship' % words[count], prose,
                      'sample-skin.md must say "%s translations ship"'
                      % words[count])
        self.assertIn('en.conf', prose,
                      'sample-skin.md must name en.conf as the ninth file')

    @classmethod
    def logged_messages(cls) -> Dict[str, List[str]]:
        """level -> the literal log messages loopdata.py can emit."""
        source = cls.repo_text('bin', 'user', 'loopdata.py')
        found: Dict[str, List[str]] = {}
        # BOTH quote styles.  A message written with double quotes -- which
        # is what an apostrophe in the text invites -- was invisible here, so
        # it could never fail the documentation check below.  That was not
        # hypothetical: rsync_data's error had been written that way and went
        # undocumented for as long as the table has existed.
        for level, _quote, msg in re.findall(
                r"""log\.(error|warning|info)\(\s*(['"])((?:(?!\2).)+)\2""", source):
            found.setdefault(level, []).append(msg)
        # Landmarks + a plausible count: the extractor must keep finding the
        # fatal ones, which are the whole point of the table.
        assert any('Could not find target_report' in m
                   for m in found.get('error', [])), sorted(found)
        assert len(found.get('error', [])) >= 6, found.get('error')
        return found

    def test_manual_windrose_defaults_match_the_code(self):
        # The default band edges and the compass-bin count are code
        # constants quoted as literal numbers on two pages each.  Nothing
        # else would notice if a constant changed and the prose did not --
        # and a wrong band edge silently misdescribes every rose drawn from
        # the defaults.
        edges = user.loopdata.WINDROSE_DEFAULT_BANDS_MPS
        assert len(edges) >= 4, edges          # landmark: real constant
        config = self.doc_text('configuration.md')
        windrose = self.doc_text('windrose.md')
        for page_name, text in (('configuration.md', config),
                                ('windrose.md', windrose)):
            for edge in edges:
                self.assertIn(str(edge), text,
                              '%s does not quote default band edge %s'
                              % (page_name, edge))
        # Sixteen compass bins, spelled out in the windrose page's prose.
        words = {8: 'eight', 12: 'twelve', 16: 'sixteen', 32: 'thirty-two'}
        bins = user.loopdata.WINDROSE_BINS
        self.assertIn(bins, words, 'spell out %d in the words table' % bins)
        self.assertIn('%s compass' % words[bins], windrose,
                      'windrose.md must say "%s compass bins"' % words[bins])

    def test_station_fields_page_lists_the_real_station_surface(self):
        # The page enumerates what `$station` exposes, which is WeeWX's own
        # Station object plus whatever it delegates to StationInfo through
        # __getattr__.  That list lives in another project, so a WeeWX
        # release can silently make it wrong in either direction.
        import inspect
        own = set(re.findall(r'self\.([a-z_]+)\s*=',
                             inspect.getsource(weewx.station.Station.__init__)))
        own |= {n for n, v in vars(weewx.station.Station).items()
                if isinstance(v, property)}
        delegated = set(re.findall(
            r'self\.([a-z_]+)\s*=',
            inspect.getsource(weewx.station.StationInfo.__init__)))
        # Not user-facing field material: the formatter/converter are the
        # rendering machinery, and stn_info is the delegation target itself.
        plumbing = {'formatter', 'converter', 'stn_info'}
        surface = (own | delegated) - plumbing
        assert 'uptime' in surface and 'hardware' in surface, sorted(surface)
        assert len(surface) >= 12, sorted(surface)

        text = self.doc_text('station-fields.md')
        listed = {m.lstrip('.') for m in
                  re.findall(r'`(?:station\.)?([a-z_]+)`', text)}
        missing = sorted(a for a in surface if a not in listed)
        self.assertEqual(missing, [],
                         'station-fields.md does not mention $station.%s'
                         % (missing[0] if missing else ''))

    def test_troubleshooting_documents_every_logged_error(self):
        # Every log.error is something the user can act on, and the log is
        # where they meet it -- so each must be findable in the manual by the
        # text they actually see.  Before this table existed the page said
        # "check the log" four times and quoted no message at all.
        #
        # Compared on the message's literal PREFIX (the text before the first
        # %s), because the page shows placeholders as <name> rather than the
        # format spec.
        text = ' '.join(self.doc_text('troubleshooting.md').split())
        for msg in self.logged_messages()['error']:
            # The literal text before the first placeholder.  A trailing
            # "Exception:" is dropped: the page renders the exception itself
            # as prose ("the exception follows on the same line") rather than
            # quoting a label with nothing after it.
            prefix = msg.split('%')[0].strip()
            prefix = re.sub(r'\s*Exception:$', '', prefix)
            # Normalize the needle too: log strings carry the house
            # two-spaces-between-sentences, and the haystack was collapsed.
            prefix = ' '.join(prefix.split())
            self.assertIn(prefix, text,
                          'troubleshooting.md does not document the error '
                          'the user will see: %r' % msg)

    def test_troubleshooting_invents_no_log_messages(self):
        # The other direction: a message quoted in the manual that the code
        # cannot emit sends the reader hunting for a string that will never
        # appear.  Every backticked line in the log tables must be real.
        # Only the log tables: the page's first table lists the sample
        # panel's LIVE/OFFLINE indicator states, which are javascript strings
        # rather than anything loopdata.py logs.
        section = self.doc_text('troubleshooting.md').split(
            '## What LoopData writes to the log')
        self.assertEqual(len(section), 2, 'log section heading not found')
        quoted = re.findall(r'^\|\s*`([^`]+)`\s*\|', section[1], re.M)
        assert len(quoted) >= 12, quoted   # landmark: the tables were parsed
        emitted = [m for msgs in self.logged_messages().values() for m in msgs]
        for row in quoted:
            # A row may show several related messages ("a`, `b, ...");
            # check each, and compare on the literal prefix as above.
            for shown in re.split(r'`,\s*`', row):
                shown = shown.split('<')[0].split('…')[0].strip().rstrip(',')
                if not shown:
                    continue
                self.assertTrue(
                    any(m.split('%')[0].strip().startswith(shown)
                        or shown.startswith(m.split('%')[0].strip())
                        for m in emitted),
                    'troubleshooting.md quotes a log message no code emits: %r'
                    % shown)

    def test_version_is_in_lockstep(self):
        # Three places, and skin.conf's copy shipped stale at 3.9 through the
        # 4.0 release.  The manual's own "describes X and later" line is
        # deliberately NOT pinned here: it names the oldest version the
        # manual covers, which is not the current version.
        version = user.loopdata.LOOP_DATA_VERSION
        self.assertRegex(version, r'^\d+\.\d+(\.\d+)?$')
        self.assertIn("version = \"%s\"" % version, self.repo_text('install.py'))
        skin = configobj.ConfigObj(
            os.path.join(self.I18N_SKIN_DIR, 'skin.conf'),
            encoding='utf-8', file_error=True)
        self.assertEqual(skin['Extras']['version'], version)
        # changes.md must carry a heading for the shipping version, and it
        # must be the FIRST one (entries are newest-first under the file's
        # own title).
        headings = re.findall(r'^## (\d+\.\d+(?:\.\d+)?)\s',
                              self.repo_text('changes.md'), re.M)
        assert len(headings) >= 5, headings   # landmark: the file was parsed
        self.assertEqual(headings[0], version,
                         'changes.md leads with %s, not %s'
                         % (headings[0], version))


    def test_installer_stanza_is_commented(self):
        # The whole point of writing the stanza as a ConfigObj rather than a
        # Python dict: weectl merges it into a fresh weewx.conf with
        # weeutil.config.conditional_merge, which carries a key's comments
        # across only if the source has them.  A dict has none, which is why
        # this stanza used to land as bare key = value lines.  Every option
        # and every section must therefore arrive explained.
        #
        # This walks the PARSED stanza, so it reaches only the LIVE options.
        # A commented-out one is absent from the parsed object -- demote an
        # option and it drops out of this test's coverage without anything
        # failing.  test_installer_commented_defaults is where those are
        # covered instead.
        def walk(section, path: str) -> None:
            for key in section.scalars:
                comment = [line for line in section.comments.get(key, [])
                           if line.strip()]
                self.assertTrue(comment, 'uncommented option: %s%s' % (path, key))
                for line in comment:
                    self.assertTrue(line.strip().startswith('#'),
                                    (path + key, line))
            for name in section.sections:
                # [StdReport] is WeeWX's own section, not ours: it is always
                # already in weewx.conf, so conditional_merge never writes a
                # header for it and a comment here would be a comment on
                # somebody else's section.  Everything under it is ours.
                if path or name != 'StdReport':
                    self.assertTrue(
                        [line for line in section.comments.get(name, [])
                         if line.strip()],
                        'uncommented section: %s[%s]' % (path, name))
                walk(section[name], '%s%s.' % (path, name))
        config = self.installer_config()
        self.assertEqual(sorted(config.sections), ['LoopData', 'StdReport'])
        walk(config, '')

    # The commented-out options, section by section, with the value each
    # shows.  Named here rather than derived from a rule: purple tried a
    # derived rule twice and mis-sorted its `enable` both times.
    COMMENTED_DEFAULTS = {
        'RsyncSpec': {
            'compress': 'false',
            'log_success': 'false',
            'timeout': '1',
            'skip_if_older_than': '3',
        },
        'Extras': {
            'loop_data_file': 'loop-data.txt',
            'expiration_time': '24',
            'theme': 'auto',
            'googleAnalyticsId': 'G-XXXXXXXXXX',
            'analytics_host': 'www.example.com',
        },
    }

    # The two whose default is ABSENCE, not a value: their assignment is an
    # EXAMPLE (and says so), so there is no fallback for it to equal.
    COMMENTED_EXAMPLES = {'googleAnalyticsId', 'analytics_host'}

    def test_installer_commented_defaults(self):
        """The options a fresh install receives commented out, pinned as a
        COMPLETE SET, values included.

        An option that only selects a default is written commented out:
        conditional_merge fills in absent keys and never rewrites, so a
        live value freezes that station on today's default for ever, while
        a commented one leaves the code's own fallback to answer --
        including a better one a later release brings.

        Pinned as a complete set in both directions, not by checking that
        today's demoted names are absent: a release that adds a new option
        LIVE against a fallback in the code is the very drift this scheme
        exists to prevent, and would sail past a named-absence check.
        Adding or demoting an option has to be a deliberate act that edits
        this test.
        """
        self.assertEqual(self.installer_commented_options(),
                         self.COMMENTED_DEFAULTS)
        # And each one still arrives explained.  walk() above cannot see
        # these -- they are not in the parsed object at all -- so the
        # comment requirement is re-stated here against the source text.
        #
        # The line IMMEDIATELY above must be prose, with nothing skipped.
        # An earlier form scanned back over blanks and over other commented
        # assignments to the nearest prose line anywhere above, which an
        # option with no comment of its own could satisfy with its
        # NEIGHBOR's: delete log_success's comment, sit it directly under
        # compress, and that form passed.
        lines = self.installer_module().CONFIG.splitlines()
        for index, line in enumerate(lines):
            option = self.COMMENTED_OPTION_RE.match(line)
            if not option:
                continue
            above = lines[index - 1] if index else ''
            self.assertTrue(above.strip().startswith('# '),
                            'commented-out option with no comment of its '
                            'own directly above it: %s' % line)

    def test_installer_commented_defaults_match_the_value_that_governs(self):
        """The drift guard.  A commented-out option shows the user the
        value that will actually be used, so it must equal what answers
        when the key is absent.

        WHICH SIDE MOVES WHEN THIS FAILS IS A JUDGMENT, NOT A FORMALITY.
        While an option was written live, the installer's value is what
        every fresh install has actually been running and the fallback was
        never reached, so editing the assignment down to the fallback turns
        this green while silently changing what new stations get.  Moving
        the fallback is what preserves behavior; moving the assignment is a
        deliberate change of default and belongs in changes.md.  Existing
        stations are unaffected either way -- their weewx.conf already
        carries the value the installer wrote, and an upgrade never
        rewrites it.
        """
        commented = self.installer_commented_options()

        # [[RsyncSpec]]: read the fallbacks the way a station with no
        # [[RsyncSpec]] section reads them -- through a real __init__.
        # (That configuration used to RAISE: to_bool(None) is a ValueError,
        # so the three booleans had no fallback at all until this release
        # gave them one.)
        rsync = dict(commented['RsyncSpec'])
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            del config_dict['LoopData']['RsyncSpec']
            service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
        self.assertEqual(to_bool(rsync.pop('compress')), cfg.compress)
        self.assertEqual(to_bool(rsync.pop('log_success')), cfg.log_success)
        self.assertEqual(to_int(rsync.pop('timeout')), cfg.timeout)
        self.assertEqual(to_int(rsync.pop('skip_if_older_than')),
                         cfg.skip_if_older_than)
        # Anything else demoted here is a default nothing checks.
        self.assertEqual(rsync, {})

        # [[[Extras]]] are read by the sample page, so what answers when
        # weewx.conf is silent is the skin's own [Extras] -- shipped anew
        # on every upgrade, which is the point of demoting them.  (Only
        # what answers, not what governs: build_skin_dict merges skin.conf,
        # then [[Defaults]], then [StdReport] scalars, then the report's
        # own stanza, so a station can still override either.)
        extras = dict(commented['Extras'])
        skin = configobj.ConfigObj(
            os.path.join(self.REPO_ROOT, 'skins', 'LoopData', 'skin.conf'),
            encoding='utf-8', file_error=True)['Extras']
        for name in sorted(self.COMMENTED_EXAMPLES):
            # An example, not a default: its default is ABSENCE, so the
            # skin must not set it either.
            self.assertNotIn(name, skin, name)
            extras.pop(name)
        for name, value in sorted(extras.items()):
            self.assertIn(name, skin, name)
            self.assertEqual(str(skin[name]), value, name)

    def test_installer_comment_blocks_land_where_they_are_written(self):
        """Rule 3, checked on the source: ConfigObj attaches a comment
        block to the NEXT key and writes it at THAT key's indent.  So a
        comment block indented more deeply than the line that follows it
        does not stay where its author put it -- it is re-indented out of
        the block it documents, by as many levels as the next key is
        shallower, reaching column 0 whenever that key is top-level.

        That is what a virgin weewx.conf shows.  The production case is
        worse and invisible: conditional_merge transfers comments only
        inside its `k not in a_dict` branch, so a block attached to a key
        the target ALREADY HAS -- [StdReport] always -- is dropped
        entirely.  Nothing is left to measure, which is why
        test_installer_merged_comments_stay_in_their_section counts.

        The practical rule this enforces: every section ends with a LIVE
        key.  It catches prose blocks as well as demoted options -- the
        [[ScriptData]] "Your fields go here" example used to sit after the
        section's last key and merged at [StdReport]'s indent, reading as
        an option of somebody else's section.
        """
        lines = self.installer_module().CONFIG.splitlines()
        for index, line in enumerate(lines):
            if not line.strip().startswith('#'):
                continue
            following = [l for l in lines[index + 1:] if l.strip()]
            assert following, 'CONFIG ends with a comment: %r' % line
            self.assertLessEqual(
                len(line) - len(line.lstrip()),
                len(following[0]) - len(following[0].lstrip()),
                'comment is indented deeper than the key it attaches to, so '
                'it merges outside the block it documents: %r before %r'
                % (line, following[0]))

    def test_installer_merged_comments_stay_in_their_section(self):
        """Rule 3 again, through the real weeutil.config.conditional_merge,
        against BOTH merge targets.

        Two things are checked, and the second is the one that matters.
        The indent of every commented-out assignment that survives says it
        landed inside the section it documents.  The COUNT says none went
        missing -- and only the count can say that, because a comment block
        attached to a key that already exists in the target is dropped
        without a trace, leaving no line to measure.  A weewx.conf that
        already has [StdReport] (every real one does) is exactly where that
        happens, so it is merged into here as well as a virgin file.
        """
        expected = sum(len(options)
                       for options in self.COMMENTED_DEFAULTS.values())
        for label, text in (
                # Parsed from TEXT, not built empty: ConfigObj takes its
                # indent_type from what it read, and a config that was
                # never read has indent_type = '' and writes flush left.
                ('virgin', '[Station]\n    location = home\n'),
                ('with [StdReport]',
                 '[Station]\n    location = home\n'
                 '[StdReport]\n    HTML_ROOT = public_html\n'
                 '    [[SeasonsReport]]\n        skin = Seasons\n')):
            merged = configobj.ConfigObj(io.StringIO(text), encoding='utf-8')
            weeutil.config.conditional_merge(merged, self.installer_config())
            out = io.BytesIO()
            merged.write(out)

            depth = 0
            seen = 0
            for line in out.getvalue().decode('utf-8').splitlines():
                header = self.CONFIG_SECTION_RE.match(line)
                if header:
                    depth = len(header.group(2))
                    continue
                option = self.COMMENTED_OPTION_RE.match(line)
                if option:
                    seen += 1
                    self.assertEqual(
                        len(option.group(1)), 4 * depth,
                        '%s: wrong indentation, so it merged outside its '
                        'section: %r' % (label, line))
            self.assertEqual(
                seen, expected,
                '%s: %d of %d commented-out options reached weewx.conf.  A '
                'comment block attached to a key the target already has is '
                'dropped entirely: order a LIVE key last in every section.'
                % (label, seen, expected))

    def test_installer_comments_survive_the_merge(self):
        """The stanza's comments reach weewx.conf, through weecfg's own code.

        This drives ExtensionEngine._inject_config -- not conditional_merge
        directly -- because _inject_config is where the stanza is COPIED
        before it is merged, and the copy is what decides whether comments
        survive at all: weeutil.config.deep_copy carries them, a plain
        dict() would drop them.  Calling conditional_merge on its own skips
        precisely the step under test.  It is also the step that rewrites
        HTML_ROOT, pinned below.
        """
        target = configobj.ConfigObj(
            io.StringIO('WEEWX_ROOT = %s\n'
                        '[StdReport]\n'
                        '    HTML_ROOT = public_html\n'
                        '    [[SeasonsReport]]\n'
                        '        skin = Seasons\n' % tempfile.gettempdir()),
            encoding='utf-8')
        engine = weecfg.extension.ExtensionEngine(
            os.path.join(tempfile.gettempdir(), 'weewx.conf'), target)
        engine._inject_config(self.installer_config(), 'loopdata')
        buf = io.BytesIO()
        target.write(buf)
        written = buf.getvalue().decode('utf-8')
        for landmark in [
                '#   This section is for the weewx-loopdata extension',
                '# Where to write the loop-data file.',
                '# How often your station emits loop packets, in seconds.',
                '# PLACEHOLDER -- replace with the server to copy the file to.',
                '# Hours the page keeps polling before it gives up',
        ]:
            self.assertIn(landmark, written)
        # The user's own [StdReport] survives, and the report is added under it.
        self.assertEqual(target['StdReport']['SeasonsReport']['skin'], 'Seasons')
        self.assertEqual(target['StdReport']['LoopDataReport']['skin'], 'LoopData')
        # prepend_path put the installation's HTML_ROOT in front of the bare
        # subdirectory the stanza asks for -- exactly once.  Shipping
        # 'public_html/loopdata' in the stanza would give
        # public_html/public_html/loopdata here.
        self.assertEqual(target['StdReport']['LoopDataReport']['HTML_ROOT'],
                         os.path.join('public_html', 'loopdata'))

    def test_service_init_leaves_no_temp_file(self):
        """__init__ reserves a name to write each packet to before renaming
        it onto the loop-data file.  It must reserve the NAME only.

        It used to leave the zero-byte file behind, and loop_data_dir is
        inside the web-served report tree by default, so every process that
        built the service without ever reaching a packet dropped another
        LoopData* file into a directory the web server hands out.  The one
        that does that in practice is `weectl report run`: report_services
        carries LoopData, so __init__ runs, while the processor thread whose
        finally-clause was the only cleanup never starts.  Nine tests in
        this file used to unlink it by hand."""
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            self.assertFalse(os.path.exists(cfg.tmpname),
                             '%s left behind by __init__' % cfg.tmpname)
            left = [f for f in os.listdir(cfg.loop_data_dir) if f.startswith('LoopData')]
            self.assertEqual([], left, 'temp files left in loop_data_dir: %s' % left)

            # The reserved name still works: a write lands on the loop-data
            # file and takes the temp name away again.
            user.loopdata.LoopProcessor.write_packet_to_file(
                {'current.outTemp': 1.0}, cfg.tmpname, cfg.loop_data_dir, cfg.filename)
            written = os.path.join(cfg.loop_data_dir, cfg.filename)
            self.assertTrue(os.path.exists(written))
            self.assertFalse(os.path.exists(cfg.tmpname))

    def test_queue_loop_writes_the_file(self):
        """The path production runs and the test entry point skips: the
        service's own first-packet build (accumulators seeded from the
        database, payload queued ahead of the packet), the LoopProcessor
        thread dequeuing, computing windrun and beaufort, rendering and
        replacing the loop-data file -- and, stopped by shutDown, taking
        its temp file with it and leaving the last packet on disk.

        generate_loopdata_dictionary feeds accumulators it built itself, so
        every other packet test here would pass with new_loop never having
        opened the database or the thread never having written a byte.

        The packets are stamped in 2020, not today, so the day seed is
        right only if it reads the summary of the PACKET's day; and the
        archive holds records from that day, so a span seed that counted
        today's summary row as well as today's running totals shows
        double."""
        L = user.loopdata
        os.environ['TZ'] = 'America/Los_Angeles'    # t below is noon here and midnight at UTC+5
        time.tzset()
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            # A weewx.conf-side group beside the sample skin's own: the two
            # types only the thread computes, plus enough to tell a seeded
            # accumulator from one the packets alone would have filled.
            config_dict['StdReport']['LoopDataReport']['LoopData'] = {'fields': {'thread': [
                'current.dateTime.raw', 'current.outTemp.raw', 'current.windrun.raw',
                'current.beaufort.raw', 'day.outTemp.max.raw', '10m.outTemp.max.raw',
                'month.rain.sum.raw', 'month.outTemp.count.raw']}}

            # Records 15 to 25 minutes before the packets: inside their day,
            # outside the 10m window.
            t = 1593630000                                  # 2020-07-01 12:00 PDT
            dbm = weewx.manager.open_manager_with_config(config_dict, 'wx_binding')
            try:
                for dt, temp in ((t - 1500, 65.0), (t - 1200, 60.0), (t - 900, 90.0)):
                    dbm.addRecord({'dateTime': dt, 'usUnits': weewx.US, 'interval': 5,
                                   'outTemp': temp, 'rain': 0.2, 'windSpeed': 4.0, 'windDir': 180.0})
            finally:
                dbm.close()

            service = L.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            written = os.path.join(cfg.loop_data_dir, cfg.filename)
            self.assertIsNone(service.loop_thread)
            service.shutDown()                       # nothing to stop yet: a no-op
            service.pre_loop(None)
            thread = service.loop_thread
            self.assertIsNotNone(thread)
            self.assertTrue(thread.daemon)

            # weewx prints a one-time deprecation of the beaufort TYPE from
            # calc_beaufort, on the processor thread, so the redirect has to
            # cover the stop as well as the packets.
            with contextlib.redirect_stdout(io.StringIO()):
                try:
                    for dt, temp in ((t, 70.0), (t + 2, 72.0), (t + 4, 71.0)):
                        service.new_loop(weewx.Event(weewx.NEW_LOOP_PACKET, packet={
                            'dateTime': dt, 'usUnits': weewx.US, 'outTemp': temp,
                            'windSpeed': 10.0, 'windDir': 90.0, 'barometer': 30.0, 'rain': 0.0}))
                    # shutDown discards whatever is still queued, so let the
                    # thread take every packet first.  Once the queue is empty
                    # the last one is in hand, and the join waits for it to be
                    # written.  Bounded by shutDown's own twenty seconds, so a
                    # loaded machine waits rather than failing.
                    deadline = time.time() + 20
                    while not cfg.queue.empty() and time.time() < deadline:
                        time.sleep(0.01)
                    self.assertTrue(cfg.queue.empty())
                finally:
                    service.shutDown()
            self.assertFalse(thread.is_alive())

            with open(written) as f:
                out = json.load(f)
            self.assertEqual(sorted(out), ['LoopDataReport'])      # no legacy line: nothing flat
            entry = out['LoopDataReport']
            self.assertEqual(entry['current.dateTime.raw'], t + 4)  # the last packet, written before the stop
            self.assertEqual(entry['current.outTemp.raw'], 71.0)
            # Seeded by the first-packet build from the database, not the packets.
            self.assertEqual(entry['day.outTemp.max.raw'], 90.0)
            # The 10m window reaches back 600 s; the records sit 900 s and more back.
            self.assertEqual(entry['10m.outTemp.max.raw'], 72.0)
            # Spans seed from the whole days in the summary table plus today's
            # running totals; today's own row must not be counted as well.
            self.assertAlmostEqual(entry['month.rain.sum.raw'], 0.6)     # three records; the packets add 0.0
            self.assertEqual(entry['month.outTemp.count.raw'], 6)         # three records and three packets
            # Computed by the thread, per packet, with loop_frequency as the interval.
            self.assertAlmostEqual(entry['current.windrun.raw'], 10.0 * (cfg.loop_frequency / 60.0) / 60.0)
            self.assertEqual(entry['current.beaufort.raw'], 3)      # 10 mph = 8.7 knots
            # The sample skin's own declaration rendered in the same entry.
            self.assertEqual(entry['current.windDir.ordinal_compass'], 'E')

            # Once the loop has stopped only the loop-data file remains: the
            # temp name is unlinked.
            self.assertFalse(os.path.exists(cfg.tmpname))
            self.assertEqual(os.listdir(cfg.loop_data_dir), [cfg.filename])

            # A packet arriving with the thread gone is not queued -- nothing
            # drains the queue, so it would grow for the life of weewxd -- and
            # the loss is logged once.  A stopped thread and a dead one look
            # the same to is_alive(), so this is the death path as it runs.
            late = weewx.Event(weewx.NEW_LOOP_PACKET, packet={'dateTime': t + 6, 'usUnits': weewx.US, 'outTemp': 70.0})
            with self.assertLogs('user.loopdata', level='ERROR') as logs:
                service.new_loop(late)
            self.assertEqual(len(logs.output), 1, logs.output)
            self.assertIn('LoopData thread is not running', logs.output[0])
            # The second is silent: capture at DEBUG, which new_loop always
            # writes, and look for an error among what arrived.
            with self.assertLogs('user.loopdata', level='DEBUG') as logs:
                service.new_loop(late)
            self.assertEqual([m for m in logs.output if not m.startswith('DEBUG')], [], logs.output)
            self.assertTrue(cfg.queue.empty())

            # The same guard covers a thread pre_loop failed to start: it
            # marks the processor started before its try block, and a
            # failure leaves the handle None.
            failed = L.LoopData(self.FakeEngine(config_dict), config_dict)
            failed.loop_processor_started = True
            with self.assertLogs('user.loopdata', level='ERROR') as logs:
                failed.new_loop(late)
            self.assertIn('LoopData thread is not running', logs.output[0])
            self.assertTrue(failed.cfg.queue.empty())

    def test_archive_stamps_interleave_with_packets_on_the_real_thread(self):
        """Spec (7.2): the alltime stamp travels on the queue so that a
        stamp arriving mid-run can never land inside a render.  Every file
        written must therefore carry an alltime.start, .end and .length
        that describe ONE span -- all three absent, or all three present and
        arithmetically consistent -- however the engine thread's archive
        records fall among its loop packets.

        test_one_file_carries_one_alltime_span drives process_queue
        SYNCHRONOUSLY, from one thread, so it reads the design back rather
        than running it.  This runs it: the real LoopProcessor thread
        rendering and writing while new_archive_record is called from this
        thread, with no synchronization of any kind between the two.

        Every write is captured, not just the last, because the fault this
        guards against is transient by nature: a torn file appears for one
        packet and is overwritten by the next.  An assertion on the file
        left on disk at the end would never see it.

        The archive starts EMPTY -- weewx and loopdata installed together --
        so the run crosses the transition from no alltime span to one, which
        is the moment a stamp can arrive mid-render."""
        L = user.loopdata
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        t = 1593630000                                  # 2020-07-01 12:00 PDT
        with tempfile.TemporaryDirectory() as tmp:
            # No sample declaration: this report declares the alltime span
            # and one alltime observation and nothing else, so the renders
            # are cheap enough to run hundreds of packets through the thread.
            config_dict = self._init_fixture(tmp, declare_sample=False)
            config_dict['StdReport']['LoopDataReport']['LoopData'] = {'fields': {'alltime': [
                'current.dateTime.raw', 'alltime.start.raw', 'alltime.end.raw',
                'alltime.length.raw', 'alltime.outTemp.max.raw']}}

            captured: List[Dict[str, Any]] = []
            real_write = L.LoopProcessor.write_packet_to_file

            def capturing_write(selective_pkt, tmpname, loop_data_dir, filename):
                # Snapshot before the write, on the processor thread: the
                # dict is rebuilt per packet, but the report entries are
                # copied anyway so nothing downstream can edit history.
                captured.append({k: dict(v) if isinstance(v, dict) else v
                                 for k, v in selective_pkt.items()})
                return real_write(selective_pkt, tmpname, loop_data_dir, filename)

            service = L.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            L.LoopProcessor.write_packet_to_file = staticmethod(capturing_write)
            try:
                service.pre_loop(None)
                thread = service.loop_thread
                self.assertIsNotNone(thread)

                def archived(ts):
                    service.new_archive_record(weewx.Event(weewx.NEW_ARCHIVE_RECORD,
                        record={'dateTime': ts, 'usUnits': weewx.US, 'interval': 5,
                                'outTemp': 68.0}))

                # Records at packets 40, 80 and 120, delivered from THIS
                # thread while the processor thread renders: the first
                # supplies the stamp, the second is later and must not raise
                # it, the third is earlier and must lower it (a hardware
                # catchup dispatches the console's memory in driver order).
                stamps = {40: t - 3600, 80: t - 1800, 120: t - 86400}
                with contextlib.redirect_stdout(io.StringIO()):
                    try:
                        for i in range(200):
                            service.new_loop(weewx.Event(weewx.NEW_LOOP_PACKET, packet={
                                'dateTime': t + i, 'usUnits': weewx.US, 'outTemp': 70.0 + i,
                                'windSpeed': 10.0, 'windDir': 90.0, 'barometer': 30.0}))
                            if i in stamps:
                                archived(stamps[i])
                        deadline = time.time() + 20
                        while not cfg.queue.empty() and time.time() < deadline:
                            time.sleep(0.01)
                        self.assertTrue(cfg.queue.empty())
                    finally:
                        service.shutDown()
                self.assertFalse(thread.is_alive())
            finally:
                L.LoopProcessor.write_packet_to_file = staticmethod(real_write)

            self.assertEqual(len(captured), 200)

            # Every file, in order.  A start that ever rises, or a length
            # that ever disagrees with the end beside it, is the tear.
            with_span = 0
            previous_start = None
            for i, out in enumerate(captured):
                entry = out['LoopDataReport']
                present = [k for k in ('alltime.start.raw', 'alltime.end.raw',
                                       'alltime.length.raw') if k in entry]
                self.assertIn(len(present), (0, 3),
                    'packet %d wrote a partial alltime span: %s' % (i, present))
                if not present:
                    continue
                with_span += 1
                self.assertEqual(entry['alltime.end.raw'], entry['current.dateTime.raw'],
                    'packet %d: the span ends at the packet in hand' % i)
                self.assertEqual(entry['alltime.length.raw'],
                    entry['alltime.end.raw'] - entry['alltime.start.raw'],
                    'packet %d: length disagrees with the start and end beside it' % i)
                self.assertIn(entry['alltime.start.raw'], set(stamps.values()),
                    'packet %d: a start no archive record supplied' % i)
                if previous_start is not None:
                    self.assertLessEqual(entry['alltime.start.raw'], previous_start,
                        'packet %d: the start rose' % i)
                previous_start = entry['alltime.start.raw']

            # The run really crossed the transition it was built to cross:
            # files before the first stamp carry no span, later ones do, and
            # the last start is the earliest record delivered.
            self.assertNotIn('alltime.start.raw', captured[0]['LoopDataReport'])
            self.assertGreater(with_span, 0)
            self.assertLess(with_span, len(captured))
            self.assertEqual(captured[-1]['LoopDataReport']['alltime.start.raw'], t - 86400)
            # The alltime observation rode the same files, so the entries
            # were real renders and not an empty dict written 200 times.
            self.assertEqual(captured[-1]['LoopDataReport']['alltime.outTemp.max.raw'], 70.0 + 199)

    def test_a_report_of_span_properties_alone_runs_end_to_end(self):
        """Spec (7.2): a report may declare span properties and NOTHING
        else, and every one of them must reach the file.  This is the shape
        a page that only wants to know when its periods began has -- and
        it is the shape in which nothing else works: with no observation
        declared anywhere, every period's obstype set is empty,
        create_period_accum returns None for each, and the packet is pruned
        to its dateTime and usUnits before it is accumulated.

        test_span_props_need_no_declared_obstypes reaches that state by
        nulling the accumulators by hand, which proves the render but takes
        the service's word for the rest.  This runs the real one --
        __init__ parsing the declaration, pre_loop starting the thread,
        new_loop building accumulators from the database and rendering --
        and reads the file the thread wrote.  A crash on the way (a None
        accumulator dereferenced during the build, a pruned packet with no
        dateTime to take a span from) shows up here and nowhere else.

        One archive record is written first, so alltime -- the one period
        whose span comes from the database -- answers too."""
        L = user.loopdata
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        t = 1593630000                                  # 2020-07-01 12:00 PDT
        first_record = t - 86400
        fields = ['hour.start.raw', 'day.start.raw', 'day.end.raw', 'day.length.raw',
                  'week.start.raw', 'week.dateTime.raw', 'month.start.raw',
                  'year.start.raw', 'rainyear.start.raw', 'alltime.start.raw',
                  'alltime.end.raw', 'alltime.length.raw']
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp, declare_sample=False)
            config_dict['StdReport']['LoopDataReport']['LoopData'] = {'fields': {'spans': list(fields)}}
            dbm = weewx.manager.open_manager_with_config(config_dict, 'wx_binding')
            try:
                dbm.addRecord({'dateTime': first_record, 'usUnits': weewx.US, 'interval': 5,
                               'outTemp': 65.0})
            finally:
                dbm.close()

            service = L.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            # The state this test exists to run in: not one observation is
            # tracked anywhere, in any period.
            for period in ('current', 'hour', 'day', 'week', 'month', 'year',
                           'rainyear', 'alltime'):
                self.assertEqual(getattr(cfg.obstypes, period), set(), period)
            self.assertEqual(cfg.obstypes.continuous, {})

            written = os.path.join(cfg.loop_data_dir, cfg.filename)
            # The accumulators the RENDER was handed, taken on the processor
            # thread: pre_loop keeps the LoopProcessor to itself, and the
            # object the render used is the one worth asserting about.
            seen: List[Any] = []
            real_generate = L.LoopProcessor.generate_output

            def capturing_generate(in_pkt, cfg_, accums_, renderers, render_failures=None):
                seen.append(accums_)
                return real_generate(in_pkt, cfg_, accums_, renderers, render_failures)

            L.LoopProcessor.generate_output = staticmethod(capturing_generate)
            try:
                service.pre_loop(None)
                thread = service.loop_thread
                with contextlib.redirect_stdout(io.StringIO()):
                    try:
                        service.new_loop(weewx.Event(weewx.NEW_LOOP_PACKET, packet={
                            'dateTime': t, 'usUnits': weewx.US, 'outTemp': 70.0}))
                        deadline = time.time() + 20
                        while not cfg.queue.empty() and time.time() < deadline:
                            time.sleep(0.01)
                        self.assertTrue(cfg.queue.empty())
                    finally:
                        service.shutDown()
            finally:
                L.LoopProcessor.generate_output = staticmethod(real_generate)
            self.assertFalse(thread.is_alive())

            # The real build really did leave the accumulators empty: these
            # spans were computed with nothing to read them off.
            self.assertEqual(len(seen), 1)
            accums = seen[0]
            for attr in ('hour_accum', 'week_accum', 'month_accum', 'year_accum',
                         'rainyear_accum', 'alltime_accum'):
                self.assertIsNone(getattr(accums, attr), attr)
            self.assertEqual(accums.continuous, {})
            self.assertEqual(accums.first_good_stamp, first_record)

            with open(written) as f:
                entry = json.load(f)['LoopDataReport']
            # Exactly what was declared: every field arrived, and a period
            # with no accumulator contributed nothing else.
            self.assertEqual(sorted(entry), sorted(fields))
            w = weeutil.weeutil
            self.assertEqual(entry['hour.start.raw'], w.archiveHoursAgoSpan(t).start)
            self.assertEqual(entry['day.start.raw'], w.archiveDaySpan(t).start)
            self.assertEqual(entry['day.end.raw'], w.archiveDaySpan(t).stop)
            self.assertEqual(entry['day.length.raw'], 86400)
            self.assertEqual(entry['week.start.raw'],
                w.archiveWeekSpan(t, cfg.week_start).start)
            self.assertEqual(entry['week.dateTime.raw'], entry['week.start.raw'])
            self.assertEqual(entry['month.start.raw'], w.archiveMonthSpan(t).start)
            self.assertEqual(entry['year.start.raw'], w.archiveYearSpan(t).start)
            self.assertEqual(entry['rainyear.start.raw'],
                w.archiveRainYearSpan(t, cfg.rainyear_start).start)
            # alltime runs from the archive's earliest record to the packet.
            self.assertEqual(entry['alltime.start.raw'], first_record)
            self.assertEqual(entry['alltime.end.raw'], t)
            self.assertEqual(entry['alltime.length.raw'], t - first_record)

    def test_span_props_on_the_legacy_fields_line(self):
        """Spec (7.2): a span property works on the deprecated [[Include]]
        fields line like any other field -- flat at the top level of the
        file -- and takes part in the sharing that keeps a legacy line from
        being rendered twice: a property the target_report also declares is
        computed once, in that report's entry, and copied flat.

        Worth its own test because sharing is keyed on the field NAME and
        the report's render_signature, and a span property is the one kind
        of field that reaches neither an accumulator nor an observation
        lookup on the way to its value.  A property shared but not copied
        would simply be missing flat; one copied but not shared would be
        computed twice per packet, which is what the sharing exists to
        stop.

        Run end to end, so the flat copy is read out of the file the
        processor thread wrote rather than out of generate_output's return
        value."""
        L = user.loopdata
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        t = 1593630000                                  # 2020-07-01 12:00 PDT
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp, declare_sample=False)
            config_dict['StdReport']['LoopDataReport']['LoopData'] = {'fields': {'spans': [
                'current.outTemp.raw', 'week.start.raw', 'day.start.raw']}}
            # week.start.raw is declared by the target report and is shared;
            # month.start.raw is not, and stays in the legacy context.
            config_dict['LoopData']['Include'] = {'fields': ['week.start.raw', 'month.start.raw']}
            config_dict['LoopData']['Formatting'] = {'target_report': 'LoopDataReport'}

            service = L.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            self.assertEqual(cfg.legacy_shared, {'week.start.raw': 'LoopDataReport'})
            self.assertEqual(cfg.legacy.specified_fields, ['month.start.raw'])
            # month is nobody's tracked observation, so the legacy context
            # renders its span with no accumulator behind it either.
            self.assertEqual(cfg.obstypes.month, set())

            written = os.path.join(cfg.loop_data_dir, cfg.filename)
            service.pre_loop(None)
            thread = service.loop_thread
            with contextlib.redirect_stdout(io.StringIO()):
                try:
                    service.new_loop(weewx.Event(weewx.NEW_LOOP_PACKET, packet={
                        'dateTime': t, 'usUnits': weewx.US, 'outTemp': 70.0}))
                    deadline = time.time() + 20
                    while not cfg.queue.empty() and time.time() < deadline:
                        time.sleep(0.01)
                    self.assertTrue(cfg.queue.empty())
                finally:
                    service.shutDown()
            self.assertFalse(thread.is_alive())

            with open(written) as f:
                out = json.load(f)
            entry = out['LoopDataReport']
            w = weeutil.weeutil
            # The shared property: one value, in both places.
            self.assertEqual(out['week.start.raw'], entry['week.start.raw'])
            self.assertEqual(out['week.start.raw'],
                w.archiveWeekSpan(t, cfg.week_start).start)
            # The unshared one: flat only, and never in the report's entry --
            # the report did not declare it.
            self.assertEqual(out['month.start.raw'], w.archiveMonthSpan(t).start)
            self.assertNotIn('month.start.raw', entry)
            # day.start.raw was the report's alone and stays there.
            self.assertEqual(entry['day.start.raw'], w.archiveDaySpan(t).start)
            self.assertNotIn('day.start.raw', out)
            self.assertEqual(sorted(k for k in out if k != 'LoopDataReport'),
                             ['month.start.raw', 'week.start.raw'])

    # ------------------------------------------------------------------
    # The report's locale
    # ------------------------------------------------------------------

    @staticmethod
    @contextlib.contextmanager
    def process_locale(name: str):
        """Hold the PROCESS locale for the body and put it back.  Used to
        build an oracle (what strftime says with the locale really set) and
        to stand in for a report generating while a packet renders."""
        saved = locale.setlocale(locale.LC_ALL)
        try:
            locale.setlocale(locale.LC_ALL, name)
            yield
        finally:
            locale.setlocale(locale.LC_ALL, saved)

    @staticmethod
    @contextlib.contextmanager
    def weewx_without(module: Any, name: str):
        """The running WeeWX with one attribute taken away, so a release
        that predates it can be rendered against for the length of the
        body.  Restored however the body leaves -- a module attribute
        deleted for the rest of the suite would fail tests far from here."""
        missing = object()
        saved = getattr(module, name, missing)
        if saved is not missing:
            delattr(module, name)
        try:
            yield
        finally:
            if saved is not missing:
                setattr(module, name, saved)

    @staticmethod
    def unknown_almanac_body_is_refused() -> bool:
        """Does the running WeeWX refuse an almanac attribute that nothing
        knows?  Every version hands back an AlmanacBinder for it; RENDERING
        that binder raises AttributeError from 5.3, where _get_ephem_body
        turns PyEphem's KeyError into one, and yields the binder's default
        repr before that.  Asked of the library, never of
        weewx.__version__ -- the question is what it does, and that is what
        decides whether such a field is omitted or published."""
        try:
            str(getattr(weewx.almanac.Almanac(1593630000, 37.4, -122.2),
                        'no_such_attr_at_all'))
        except Exception:
            return True
        return False

    @staticmethod
    def usable_locales() -> List[str]:
        """The locales this host actually has compiled, beyond C.  A fixed
        order, so a failure names the same one on a re-run."""
        found: List[str] = []
        for name in ('de_DE.utf8', 'fr_FR.utf8', 'es_ES.utf8',
                     'nl_NL.utf8', 'en_US.utf8'):
            try:
                with ProcessPacketTests.process_locale(name):
                    found.append(name)
            except locale.Error:
                pass
        return found

    def test_render_locale_strftime_matches_the_c_library(self):
        """Spec: RenderLocale.strftime renders a format string exactly as
        time.strftime would with that locale set.  That is the whole claim
        -- the point of capturing tables per report is to render a report's
        times WITHOUT setting the process locale to the report's, so the
        tables have to be indistinguishable from the real thing.

        The oracle is the C library itself.  A test that only compared
        German output against German output would pass with the tables
        empty; this one fails the moment a directive is substituted
        differently from how strftime substitutes it, including the
        composite %c/%x/%X and the literal-percent and modifier cases that
        a naive scanner gets wrong."""
        L = user.loopdata
        names = self.usable_locales()
        if not names:
            self.skipTest('no locale beyond C is compiled on this host')
        # EVERY directive, not a list someone thought of.  The hand-written
        # list this replaced was the reason two defects survived a review:
        # %P and %Eb were simply not in it, and an oracle only covers what
        # it is handed.  So the space itself is swept -- every ASCII letter
        # as a conversion, each bare, behind both modifiers, and under each
        # flag and a field width -- plus the literal and percent-escape
        # cases a scanner gets wrong.
        letters = string.ascii_letters
        formats = ['%' + modifier + letter
                   for modifier in ('', 'O', 'E') for letter in letters]
        flags = ('-', '_', '0', '^', '#', '10', '-10', '010', '2', '020')
        formats += ['%' + flag + letter
                    for flag in flags for letter in 'aAbBhpPcxXr']
        # Flag AND modifier together.  Neither sweep above generates this
        # corner, and both of the last review's findings lived in it:
        # strftime applies the flags to the literal it falls back to for a
        # modified form it does not support, so '%^2Ea' is '%^2EA' and
        # '%-10Ed' is padded.
        formats += ['%' + flag + modifier + letter
                    for flag in flags for modifier in ('O', 'E')
                    for letter in 'aAbBdHy']
        # A modifier in front of something that is not a conversion at all.
        # strftime emits the whole thing literally; stripping the modifier
        # to '%!' was a divergence a letters-only sweep could not see.
        formats += ['%' + modifier + ch
                    for modifier in ('O', 'E') for ch in '!-_^#. :/0%']
        formats += [
            '%x %X',                 # WeeWX's own default TimeFormats 'current'
            '%d-%b-%Y %H:%M',        # weewx.units.DEFAULT_TIME_FORMAT
            '%A %B %-d, %Y', '%a %b %e %I:%M %p',
            '%H:%M:%S', 'no directives here',
            '100%% sure it is %A',   # a literal percent just before a name
            '%%A',                   # ... and one that must NOT become a name
            '%', '%%', '%%%A', '%O', '%E',   # truncated and doubled edges
        ]
        assert len(formats) > 250, len(formats)   # landmark: the sweep is real
        times = [datetime(2025, m, d, h, 34, 56).timetuple()
                 for m in range(1, 13) for d in (3, 21) for h in (9, 15)]
        assert len(times) == 48, len(times)      # landmark: the loop is real
        # Every month, weekday and half of the day is covered by the times
        # above; one of them is enough for the per-directive sweep, and all
        # of them for the formats that compose several directives.
        sweep_times = times[:1] + times[6:7] + times[25:26]
        checked = 0
        for name in names:
            L._RENDER_LOCALE_CACHE.pop(name, None)
            render_locale = L.RenderLocale.capture(name)
            for fmt in formats:
                for tm in (sweep_times if fmt.startswith('%') and len(fmt) <= 3
                           else times):
                    with self.process_locale(name):
                        expected = time.strftime(fmt, tm)
                    # Rendered with the process locale back at the suite's
                    # C, which is the entire point of the exercise.
                    self.assertEqual(render_locale.strftime(fmt, tm), expected,
                                     '%s: %r at %s' % (name, fmt, time.asctime(tm)))
                    checked += 1
        assert checked >= 2000, checked          # landmark: nothing was skipped

    def test_render_locale_captured_something(self):
        """Spec: the oracle above compares two renderings and would pass
        with every table empty if the fallback happened to be right, so the
        tables themselves are pinned here: a real locale's names are its
        own, and they are not C's."""
        L = user.loopdata
        if 'de_DE.utf8' not in self.usable_locales():
            self.skipTest('needs de_DE.utf8')
        L._RENDER_LOCALE_CACHE.pop('de_DE.utf8', None)
        german = L.RenderLocale.capture('de_DE.utf8')
        self.assertEqual(german.names['B'][5], 'Juni')
        self.assertEqual(german.names['A'][5], 'Samstag')    # tm_wday 5, Saturday
        self.assertEqual(german.decimal_point, ',')
        # The alternative form is a table of its own, because a locale's
        # standalone month name is not always its in-a-date one.  German
        # writes Januar for both, so this pins that %OB was captured at all
        # rather than left for the process locale to answer.
        self.assertEqual(german.names['OB'][5], 'Juni')
        # %x is where the DATE ORDER lives, and WeeWX's default TimeFormats
        # for 'current' is '%x %X' -- so this is the entry that decides
        # whether a German station reads 21.06.2025 or 06/21/25.
        self.assertIn('x', german.composites)
        self.assertNotEqual(german.composites['x'], L.RenderLocale.capture('C').composites.get('x'))

    def test_a_report_renders_under_its_own_locale_not_the_process_one(self):
        """Spec: the defect this closes.  WeeWX renders a report inside
        reportengine.set_locale, which sets the PROCESS locale for as long
        as that report's generators run, while the LoopProcessor thread
        renders every loop packet.  So the same field used to render one
        way for a packet that landed while some report was generating and
        another way for the packet after it.  A captured locale must be
        immune to whatever the process happens to hold at the moment of the
        render."""
        L = user.loopdata
        names = self.usable_locales()
        if 'de_DE.utf8' not in names or 'fr_FR.utf8' not in names:
            self.skipTest('needs both de_DE.utf8 and fr_FR.utf8')
        L._RENDER_LOCALE_CACHE.pop('de_DE.utf8', None)
        german = L.RenderLocale.capture('de_DE.utf8')
        tm = datetime(2025, 6, 21, 15, 0, 0).timetuple()
        # Derived from the German language, not from loopdata's own output.
        for holding in ('C', 'fr_FR.utf8', 'de_DE.utf8', 'en_US.utf8'):
            if holding != 'C' and holding not in names:
                continue
            with self.process_locale(holding):
                self.assertEqual(german.strftime('%A, %-d. %B %Y', tm),
                                 'Samstag, 21. Juni 2025', holding)

    def test_report_formatter_carries_every_formatter_attribute(self):
        """Spec: ReportFormatter is built from WeeWX's own Formatter by
        COPYING its attributes, not by re-passing the five its constructor
        takes today.  WeeWX has added one before -- deltatime_format_dict --
        and a call naming five would drop a sixth silently, leaving every
        field that depends on it rendering on a default with nothing
        logged."""
        L = user.loopdata
        config_dict = configobj.ConfigObj('tests/weewx.conf.metric', encoding='utf-8')
        skin_dict = L.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')
        base = weewx.units.Formatter.fromSkinDict(skin_dict)
        ours = L.ReportFormatter.from_skin_dict(skin_dict, L.RenderLocale.capture('C'))

        assert len(vars(base)) >= 5, sorted(vars(base))   # landmark: real object
        for key, value in vars(base).items():
            self.assertIn(key, vars(ours), key)
            self.assertEqual(getattr(ours, key), value, key)

        # And the consequence, not just the shape: a rendering that reads an
        # attribute rather than being handed one.  long_form with no format
        # argument takes it from deltatime_format_dict.
        vt = weewx.units.ValueTuple(7350, 'second', 'group_deltatime')
        for context in sorted(base.deltatime_format_dict):
            self.assertEqual(ours.long_form(vt, context),
                             base.long_form(vt, context), context)

    def test_formatted_and_the_formatter_agree_on_what_a_time_is(self):
        """Spec: .formatted and the formatter must not disagree about which
        units hold a point in time.  They did -- .formatted tested the epoch
        units alone while the formatter also knew the Dublin julian day --
        so a local_djd field's .formatted came out as a bare 45828.416667
        where the report beside it showed a date."""
        L = user.loopdata
        config_dict = configobj.ConfigObj('tests/weewx.conf.metric', encoding='utf-8')
        skin_dict = L.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')
        formatter = L.ReportFormatter.from_skin_dict(skin_dict, L.RenderLocale.capture('C'))

        assert 'local_djd' in L.TIME_UNITS, sorted(L.TIME_UNITS)
        assert len(L.TIME_UNITS) >= 4, sorted(L.TIME_UNITS)
        epoch = 1750558260
        values = {'unix_epoch': epoch, 'unix_epoch_ms': epoch * 1000,
                  'unix_epoch_ns': epoch * 1000000000,
                  'local_djd': 45828.416666666664}
        self.assertEqual(set(values), set(L.TIME_UNITS),
                         'a time unit was added without a value here')
        if not hasattr(weewx.units, 'dublin_to_epoch'):
            # The Dublin julian day is a WeeWX 5.3 unit -- nothing below it
            # can produce one, and loopdata's own branch for it is guarded
            # on the same name -- so there is nothing to render here.  Kept
            # in TIME_UNITS above, which is the contract this test is for.
            del values['local_djd']
        for unit, value in sorted(values.items()):
            value_t = (value, unit, 'group_time')
            self.assertTrue(formatter.is_time(value_t), unit)
            pkt: Dict[str, Any] = {}
            cname = L.LoopData.parse_cname('current.dateTime.formatted')
            L._render_formatted(cname, value_t, pkt, formatter, 'current', False)
            # A date, not a number -- and the same one the formatter gives.
            self.assertEqual(pkt['current.dateTime.formatted'],
                             formatter.toString(value_t, context='current',
                                                addLabel=False), unit)
            self.assertIn('/', pkt['current.dateTime.formatted'])

    def test_number_rendering_matches_weewx_for_every_conversion(self):
        """Spec: the strftime oracle's twin, for numbers.  loopdata renders
        with WeeWX's localization switched OFF and puts the report's decimal
        point in itself, so it has to make the same decision
        locale.format_string makes about WHICH conversions are localized at
        all.  Guessing that got %s wrong: WeeWX leaves %s exactly as plain
        formatting left it, so a German report's page shows 12.345 while
        loopdata was writing 12,345 beside it.

        So the conversion space is SWEPT rather than sampled -- every
        conversion character, bare and with a precision and a width --
        against WeeWX itself with the locale actually set.  A hand-written
        list is what let %s through; an oracle covers only what it is
        handed."""
        L = user.loopdata
        if 'de_DE.utf8' not in self.usable_locales():
            self.skipTest('needs de_DE.utf8')
        config_dict = configobj.ConfigObj('tests/weewx.conf.metric', encoding='utf-8')
        skin_dict = L.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')
        base = weewx.units.Formatter.fromSkinDict(skin_dict)
        ours = L.ReportFormatter.from_skin_dict(
            skin_dict, L.RenderLocale.capture('de_DE.utf8'))
        self.assertEqual(ours.render_locale.decimal_point, ',')

        # WeeWX rejects a handful of conversions that plain % formatting
        # accepts, so the two disagree about whether there is a value at
        # all.  Measured: %a is the whole of it -- Python's ascii()
        # conversion, which locale.format_string refuses.  Pinned by name
        # rather than waved through, so a Python or WeeWX that changes the
        # set says so here.
        weewx_rejects_but_python_accepts = {'a'}

        # Every numeric TYPE a loop packet can carry, not only int and
        # float.  A guard naming those two excluded bool and Decimal and
        # sent them back under the process locale -- and '%f' on a boolean
        # really does produce a decimal point ('1.000000'), which was the
        # reasoning that excluded it.
        values = [0, 1, -1, 12.345, -0.5, 1234567.891, 0.0001, 0.0,
                  True, False, decimal.Decimal('1.5'), decimal.Decimal('-20')]
        checked = 0
        localized = 0
        both_valued = 0
        surprises = set()
        for conv in string.ascii_letters:
            for spec in ('', '.3', '10.2', '-8.1', '08.2', '#.2', '#', '#10.4'):
                fmt = '%' + spec + conv
                for value in values:
                    vt = weewx.units.ValueTuple(value, 'degree_C', 'group_temperature')
                    try:
                        with self.process_locale('de_DE.utf8'):
                            expected = base.toString(vt, useThisFormat=fmt, addLabel=False)
                        raised = False
                    except Exception:
                        expected, raised = None, True
                    # Rendered with the process locale back at the suite's C.
                    try:
                        got = ours.toString(vt, useThisFormat=fmt, addLabel=False)
                        ours_raised = False
                    except Exception:
                        got, ours_raised = None, True
                    checked += 1
                    if not raised and not ours_raised:
                        # The claim that matters: where WeeWX produces a
                        # value, loopdata produces the SAME one.
                        self.assertEqual(got, expected, (fmt, value))
                        both_valued += 1
                        if ',' in expected:
                            localized += 1
                    elif raised and not ours_raised:
                        if conv not in weewx_rejects_but_python_accepts:
                            surprises.add(fmt)
                    elif ours_raised and not raised:
                        self.fail('loopdata refuses %r on %r, WeeWX renders %r'
                                  % (fmt, value, expected))
        self.assertEqual(surprises, set(),
                         'loopdata renders conversions WeeWX rejects: %s'
                         % sorted(surprises))
        assert checked >= 3000, checked      # landmark: the sweep is real
        assert both_valued >= 300, both_valued
        # ... and not vacuous: a decimal comma really did appear.
        assert localized >= 50, localized

    def test_long_form_matches_the_base_formatter(self):
        """Spec: ReportFormatter repeats WeeWX's long-form delta-time
        composition, so that it can format with plain % and put the
        report's own decimal point in rather than letting
        locale.format_string read the process locale.  Repeating that
        arithmetic is the price; THIS is the guard against it drifting.

        The comparison runs against the base class's own output, so a WeeWX
        that changes what goes in the dictionary -- adds a week, folds days
        into hours differently, pluralizes a label another way -- fails here
        loudly instead of letting loopdata quietly disagree with the page
        beside it.  It drives the public method, which no
        longer short-circuits to the base class for a period decimal point:
        that short circuit ended in locale.format_string, and so
        reintroduced this release's own defect for every English station."""
        L = user.loopdata
        config_dict = configobj.ConfigObj('tests/weewx.conf.metric', encoding='utf-8')
        skin_dict = L.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')
        base = weewx.units.Formatter.fromSkinDict(skin_dict)
        ours = L.ReportFormatter.from_skin_dict(skin_dict, L.RenderLocale.capture('C'))

        contexts = sorted(base.deltatime_format_dict)
        assert len(contexts) >= 4, contexts          # landmark: real formats
        durations = [0, 1, 2, 59, 60, 61, 119, 3599, 3600, 3601, 7200,
                     86399, 86400, 86401, 90061, 172800, 1234567, -7200]
        checked = 0
        for context in contexts:
            label_format = base.deltatime_format_dict[context]
            for secs in durations:
                vt = weewx.units.ValueTuple(secs, 'second', 'group_deltatime')
                self.assertEqual(
                    ours.delta_time_to_string(vt, label_format, None),
                    base.delta_time_to_string(vt, label_format, None),
                    '%s / %ss' % (context, secs))
                checked += 1
        assert checked >= 70, checked                # landmark: nothing skipped

        # The no-value renderings hold no number and stay the base class's,
        # None_string and all.
        for none_string in (None, 'nothing yet', 17):
            for vt in (None, weewx.units.ValueTuple(None, 'second', 'group_deltatime')):
                self.assertEqual(
                    ours.delta_time_to_string(vt, contexts and
                        base.deltatime_format_dict[contexts[0]], none_string),
                    base.delta_time_to_string(vt,
                        base.deltatime_format_dict[contexts[0]], none_string))

    def test_long_form_carries_the_reports_decimal_point(self):
        """Spec: the defect the override above exists to close.  A
        [[DeltaTimeFormats]] entry with a float conversion used to render
        its decimal point from whatever locale the process held at that
        instant -- '2.0' or '2,0' for the same field, packet to packet,
        depending on whether a report happened to be generating."""
        L = user.loopdata
        config_dict = configobj.ConfigObj('tests/weewx.conf.metric', encoding='utf-8')
        skin_dict = L.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')
        skin_dict.setdefault('Units', {}).setdefault('DeltaTimeFormats', {})['current'] = \
            '%(hour).1f%(hour_label)s and %(minute).2f%(minute_label)s'
        ours = L.ReportFormatter.from_skin_dict(
            skin_dict, L.RenderLocale(name='test', names={}, composites={},
                                      decimal_point=','))
        # 7350s is 2 hours, 2 minutes, 30 seconds -- the parts are whole
        # counts, so the decimal places come from the format, not from the
        # arithmetic.
        vt = weewx.units.ValueTuple(7350, 'second', 'group_deltatime')
        rendered = ours.long_form(vt, 'current')
        # BOTH conversions localized, and only the conversions: the literal
        # ' and ' between them is untouched, and so are the labels.
        self.assertEqual(rendered, '2,0 hours and 2,00 minutes')
        self.assertNotIn('.', rendered)
        # The process locale is the suite's C, so this cannot have passed
        # by the process happening to be comma-decimal.
        self.assertEqual(locale.localeconv()['decimal_point'], '.')

        # A literal percent stays one, and a format WeeWX itself rejects is
        # left to WeeWX to reject rather than quietly rendered here.
        skin_dict['Units']['DeltaTimeFormats']['current'] = '%(hour).1f%% done'
        pct = L.ReportFormatter.from_skin_dict(
            skin_dict, L.RenderLocale(name='test', names={}, composites={},
                                      decimal_point=','))
        self.assertEqual(pct.long_form(vt, 'current'), '2,0% done')
        skin_dict['Units']['DeltaTimeFormats']['current'] = '%(nosuchkey)d'
        bad = L.ReportFormatter.from_skin_dict(
            skin_dict, L.RenderLocale(name='test', names={}, composites={},
                                      decimal_point=','))
        with self.assertRaises(KeyError):
            bad.long_form(vt, 'current')

    def test_station_rain_year_str_follows_the_report(self):
        """Spec: $station renders lazily through the formatter, with one
        exception -- weewx.station.Station's constructor computes
        rain_year_str with strftime('%b') EAGERLY, so its month name is
        fixed by whatever locale is set when the object is built.  WeeWX
        builds its own $station inside the report's set_locale, so
        loopdata's must be built there too, or a German report's page says
        Okt while loop-data.txt says Oct."""
        L = user.loopdata
        if 'de_DE.utf8' not in self.usable_locales():
            self.skipTest('needs de_DE.utf8')
        config_dict = configobj.ConfigObj('tests/weewx.conf.metric', encoding='utf-8')
        skin_dict = L.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')
        skin_dict['lang'] = 'de_DE.utf8'
        # A rain year starting in October, so the month name is one that
        # actually differs between English and German.
        stn_info = weewx.station.StationInfo(altitude=['700', 'foot'],
            latitude='37.4', longitude='-122.1', location='Palo Alto, California',
            station_type='Vantage', week_start='6', rain_year_start='10')
        ctx = L.LoopData.build_report_context(
            None, ['station.rain_year_str'], skin_dict, None, stn_info)
        self.assertIsNotNone(ctx.station)

        # What the REPORT shows: WeeWX's own Station, built the way
        # cheetahgenerator builds it -- inside set_locale.
        with weewx.reportengine.set_locale('de_DE.utf8'):
            expected = weewx.station.Station(
                stn_info, ctx.formatter, ctx.converter, skin_dict).rain_year_str
        self.assertEqual(expected, 'Okt')          # derived from German
        # The process locale is the suite's C, so nothing below can pass
        # because the process happened to be German.
        self.assertEqual(locale.setlocale(locale.LC_TIME), 'C')
        self.assertEqual(ctx.station.rain_year_str, expected)

        evaluator = L.StationFieldEvaluator(ctx.station_fields, ctx.station)
        pkt: Dict[str, Any] = {}
        evaluator.insert_fields(pkt)
        self.assertEqual(pkt['station.rain_year_str'], 'Okt')

    def test_a_value_that_is_not_a_tuple_reaches_the_base_formatter(self):
        """Spec: Formatter.toString deliberately passes an UnknownObsType
        through to be rendered as a string, and the base class decides what
        None means.  The override must not get between them: it subscripts
        the value tuple, and a TypeError on the render path costs a report
        its whole entry for that packet.  Third-party AlmanacTypes are
        handed this formatter, so the case is not loopdata's to rule out."""
        L = user.loopdata
        config_dict = configobj.ConfigObj('tests/weewx.conf.metric', encoding='utf-8')
        skin_dict = L.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')
        ours = L.ReportFormatter.from_skin_dict(skin_dict, L.RenderLocale.capture('C'))
        base = weewx.units.Formatter.fromSkinDict(skin_dict)

        unknown = weewx.units.UnknownObsType('nosuch')
        self.assertEqual(ours.toString(unknown), base.toString(unknown))
        self.assertIn('nosuch', ours.toString(unknown))

        # None raises on the base formatter too, so the override must raise
        # the SAME way rather than being "fixed" into disagreeing with it.
        for formatter in (base, ours):
            with self.assertRaises(TypeError):
                formatter.toString(None)

    def test_formatted_localizes_without_any_locale_installed(self):
        """Spec: the same claim as
        test_formatted_carries_the_reports_decimal_point -- .formatted
        carries the report's decimal point -- but pinned on a host that has
        no German locale compiled, where that test can only skip.

        The locale is supplied directly rather than read from the system,
        so this runs everywhere and the fix is never left uncovered by an
        accident of which locales a machine happens to have.  What it gives
        up is the comparison against WeeWX's own ValueHelper; the other
        test is what pins the two together."""
        L = user.loopdata
        config_dict = configobj.ConfigObj('tests/weewx.conf.metric', encoding='utf-8')
        skin_dict = L.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')
        formatter = L.ReportFormatter.from_skin_dict(
            skin_dict, L.RenderLocale(name='test', names={}, composites={},
                                      decimal_point=','))
        temp_t = (12.345, 'degree_C', 'group_temperature')
        pkt: Dict[str, Any] = {}
        for field in ('current.outTemp',
                      'current.outTemp.formatted',
                      'current.outTemp.format(add_label=False)',
                      'current.outTemp.raw'):
            cname = L.LoopData.parse_cname(field)
            self.assertIsNotNone(cname, field)
            L.LoopProcessor.render_field(cname, temp_t, pkt, formatter)
        # .formatted and .format(add_label=False) are the same call in a
        # report.  They must be the same string here, and both must carry
        # the comma -- .formatted was the one that did not.
        self.assertEqual(pkt['current.outTemp.formatted'], '12,3')
        self.assertEqual(pkt['current.outTemp.format(add_label=False)'], '12,3')
        self.assertTrue(pkt['current.outTemp'].startswith('12,3'),
                        pkt['current.outTemp'])
        # .raw never goes near the formatter: it is a json number, not a
        # string, and a decimal comma in one would not even be json.
        self.assertEqual(pkt['current.outTemp.raw'], 12.345)
        self.assertIn('"current.outTemp.raw": 12.345', json.dumps(pkt))

    def test_formatted_carries_the_reports_decimal_point(self):
        """Spec: a report tag's .formatted IS toString(addLabel=False),
        which localizes the decimal point, and loopdata's .formatted must
        be the same string.  It used to skip localization altogether, so a
        German station's own page said 12,3 while .formatted beside it in
        loop-data.txt said 12.3 -- the same number, in the same file, for
        the same packet.

        Everything here is pinned against WeeWX's own ValueHelper rather
        than against a string typed out here, because 'what the report
        would render' is the claim being made."""
        L = user.loopdata
        if 'de_DE.utf8' not in self.usable_locales():
            self.skipTest('needs de_DE.utf8')
        config_dict = configobj.ConfigObj('tests/weewx.conf.metric', encoding='utf-8')
        skin_dict = L.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')
        skin_dict['lang'] = 'de_DE.utf8'
        L._RENDER_LOCALE_CACHE.pop('de_DE.utf8', None)
        ctx = L.LoopData.build_report_context(
            None, ['current.outTemp', 'current.outTemp.formatted',
                   'current.dateTime'], skin_dict, None, None)

        ts = int(datetime(2025, 6, 21, 15, 0, 0).timestamp())
        temp_t = (12.345, 'degree_C', 'group_temperature')
        time_t = (ts, 'unix_epoch', 'group_time')

        # What the REPORT produces: WeeWX's own tags, with the locale really
        # set, which is what reportengine does for a lang'd report.
        plain = weewx.units.Formatter.fromSkinDict(skin_dict)
        with self.process_locale('de_DE.utf8'):
            vh = weewx.units.ValueHelper(weewx.units.ValueTuple(*temp_t), 'current', plain)
            expected_bare      = vh.toString()
            expected_formatted = vh.formatted
            expected_time = weewx.units.ValueHelper(
                weewx.units.ValueTuple(*time_t), 'current', plain).toString()
        # The claim is only interesting if German is not what C would say.
        self.assertIn(',', expected_formatted)

        # The process locale is the suite's C throughout the rendering
        # below, so nothing here can pass by the process happening to be
        # German.
        self.assertEqual(locale.localeconv()['decimal_point'], '.')

        pkt: Dict[str, Any] = {}
        for field in ('current.outTemp', 'current.outTemp.formatted', 'current.dateTime'):
            cname = L.LoopData.parse_cname(field)
            self.assertIsNotNone(cname, field)
            L.LoopProcessor.render_field(
                cname, time_t if field == 'current.dateTime' else temp_t,
                pkt, ctx.formatter)
        self.assertEqual(pkt['current.outTemp'], expected_bare)
        self.assertEqual(pkt['current.outTemp.formatted'], expected_formatted)
        self.assertEqual(pkt['current.dateTime'], expected_time)

        # A complex value has no single format string: WeeWX composes it
        # out of two further renderings, one per part, so the decimal point
        # has to arrive through that recursion.  Switching localization off
        # for the whole switches it off for the parts too -- the base class
        # passes the flag down -- and the points come back as periods.
        complex_t = (complex(12.345, 6.789), 'degree_C', 'group_temperature')
        with self.process_locale('de_DE.utf8'):
            expected_complex = weewx.units.ValueHelper(
                weewx.units.ValueTuple(*complex_t), 'current', plain).toString()
        # '(12,3, 6,8)\N{DEGREE SIGN}C' -- both parts localized, and the
        # comma that separates them is WeeWX's own punctuation.
        self.assertIn('12,3', expected_complex)
        self.assertIn('6,8', expected_complex)
        self.assertEqual(
            weewx.units.ValueHelper(weewx.units.ValueTuple(*complex_t),
                                    'current', ctx.formatter).toString(),
            expected_complex)

        # The almanac and station fields evaluate real ValueHelpers built
        # with this formatter -- a rendered time deep in an attribute chain,
        # which is what weewx-celestial declares -- so the ValueHelper path
        # has to carry the report's locale too, not only loopdata's own
        # renderers.
        self.assertEqual(
            str(weewx.units.ValueHelper(weewx.units.ValueTuple(*time_t),
                                        'current', ctx.formatter)),
            expected_time)

    def test_localize_number_moves_only_the_numbers_point(self):
        """Spec: the report's decimal point goes into the number the format
        string produced, and into nothing else.  A unit format is free to
        carry a literal period -- an inch mark, a dotted abbreviation -- and
        a blanket replacement would corrupt it; a format with no decimal at
        all must come back untouched, and so must a value there was nothing
        to format."""
        L = user.loopdata
        comma = L.RenderLocale(name='test', names={}, composites={},
                               decimal_point=',')
        for fmt_str, value, rendered, expected in (
                ('%.1f',     12.345, '12.3 \N{DEGREE SIGN}C', '12,3 \N{DEGREE SIGN}C'),
                ('%.0f',     12.345, '12 \N{DEGREE SIGN}C',   '12 \N{DEGREE SIGN}C'),
                ('%d',       12,     '12',                   '12'),
                ('%.1f in.', 0.25,   '0.2 in.',              '0,2 in.'),
                ('v.%.2f',   1.5,    'v.1.50',               'v.1,50'),
                # The '#' flag keeps a TRAILING point, with no digit after
                # it -- WeeWX localizes that too.
                ('%#.2G',    12.345, '12.',                  '12,'),
                ('%#.0f',    7.0,    '7.',                   '7,'),
                # A literal that is ITSELF a number: the conversion's own
                # output is what moves, not the first decimal point in the
                # rendering.
                ('1.5m above %.1f', 12.345, '1.5m above 12.3', '1.5m above 12,3'),
                ('%.1f%% of 2.5',   12.345, '12.3% of 2.5',    '12,3% of 2.5'),
                ('%.1f',     None,   '   N/A',               '   N/A'),
                ('%s',       'calm', 'calm',                 'calm')):
            self.assertEqual(comma.localize_number(rendered, fmt_str, value),
                             expected, (fmt_str, value))
        # A locale whose point is already a period changes nothing, which is
        # every English station and is the path almost every packet takes.
        period = L.RenderLocale(name='test', names={}, composites={},
                                decimal_point='.')
        self.assertEqual(period.localize_number('12.3', '%.1f', 12.345), '12.3')

    def test_render_signature_separates_two_locales(self):
        """Spec: the signature decides when one report's rendering may
        stand in for another's.  The month names and the decimal point come
        from the locale and from none of the sections the signature reads,
        so two reports alike but for a lang that resolves differently must
        not be treated as twins -- while two genuinely identical ones still
        must."""
        L = user.loopdata
        names = self.usable_locales()
        if 'de_DE.utf8' not in names or 'fr_FR.utf8' not in names:
            self.skipTest('needs both de_DE.utf8 and fr_FR.utf8')
        config_dict = configobj.ConfigObj('tests/weewx.conf.metric', encoding='utf-8')
        base = L.LoopData.get_target_report_dict(config_dict, 'SeasonsReport')

        def signature(lang: Optional[str]) -> str:
            skin_dict = weeutil.config.deep_copy(base)
            if lang is not None:
                skin_dict['lang'] = lang
            return L.LoopData.render_signature(skin_dict, [1.0, 2.0])

        self.assertEqual(signature('de_DE.utf8'), signature('de_DE.utf8'))
        self.assertNotEqual(signature('de_DE.utf8'), signature('fr_FR.utf8'))

    def test_weewx_formats_values_the_way_loopdata_assumes(self):
        """Spec: ReportFormatter takes over a private WeeWX method, so what
        it assumes about that method is checked here -- loudly, in the
        suite -- rather than discovered at a station, where the fallback
        quietly hands every report weewxd's locale instead of its own."""
        self.assertTrue(
            user.loopdata.ReportFormatter.base_signature_is_known(),
            'weewx.units.Formatter._to_string has moved; ReportFormatter '
            'needs revisiting, and until it is every report renders under '
            'weewxd\'s locale')

    def test_default_time_format_falls_back_before_weewx_5_3(self):
        """Spec: WeeWX 5.3 lifted the default time format out of
        Formatter._to_string into weewx.units.DEFAULT_TIME_FORMAT; 4.6
        through 5.2 -- releases this extension supports, and its floor is
        4.6 -- spell the same string inline there and have no such
        attribute.  7.4 read it on the render path, where it is evaluated
        for EVERY time, in a named context or not, so on any of those a
        report that declares a time field lost its whole entry, every
        packet, with an AttributeError logged (issue #17).

        Two things are pinned, both with the attribute deleted: the
        resolver answers with the string those releases hard-code, and
        nothing on the render path reaches for the attribute itself."""
        L = user.loopdata
        cfg = ProcessPacketTests._get_config(
            'us', 10800, 1, 6, ['current.dateTime.formatted'])
        formatter = cfg.legacy.formatter
        t = 1593630000
        # The context the fixture's [[TimeFormats]] names, and one it does
        # not.  The second is what the default answers for; the FIRST is
        # what made this total -- a default argument is evaluated whether
        # or not the dict has the key.
        assert 'current' in formatter.time_format_dict, sorted(formatter.time_format_dict)
        assert 'no_such_context' not in formatter.time_format_dict

        with ProcessPacketTests.weewx_without(weewx.units, 'DEFAULT_TIME_FORMAT'):
            # No assertion here that the module CONSTANT still holds the
            # running WeeWX's value: WeeWX's own default and the literal
            # below are the same string, so no comparison of values can
            # tell resolved-at-import from read-live.  What matters is
            # pinned instead by the renderings below -- they fail with the
            # exact AttributeError of issue #17 the moment anything on the
            # render path reaches for the attribute.
            self.assertEqual(L.weewx_default_time_format(), '%d-%b-%Y %H:%M')
            # The production path for a time: .formatted routes through
            # toString with the period's context.
            cname = L.LoopData.parse_cname('current.dateTime.formatted')
            self.assertIsNotNone(cname)
            out: Dict[str, Any] = {}
            L.LoopProcessor.add_current_obstype(
                cname, {'dateTime': t, 'usUnits': 1}, out, cfg.legacy.converter, formatter)
            self.assertEqual(out.get('current.dateTime.formatted'),
                             time.strftime('%x %X', time.localtime(t)))
            value_t = (t, 'unix_epoch', 'group_time')
            self.assertEqual(
                formatter.toString(value_t, context='no_such_context', addLabel=False),
                time.strftime('%d-%b-%Y %H:%M', time.localtime(t)))

    def test_default_time_format_matches_the_running_weewx(self):
        """Spec: the literal in weewx_default_time_format is not a default
        of loopdata's choosing -- it is what 4.6 through 5.2 hard-code.
        Where the constant EXISTS it is what answers, so a WeeWX that
        changes its default is followed here rather than quietly
        diverging from the report beside it."""
        L = user.loopdata
        if not hasattr(weewx.units, 'DEFAULT_TIME_FORMAT'):
            self.skipTest('this WeeWX predates weewx.units.DEFAULT_TIME_FORMAT')
        self.assertEqual(L.weewx_default_time_format(),
                         weewx.units.DEFAULT_TIME_FORMAT)

    def test_an_unknown_lang_renders_as_weewx_would(self):
        """Spec: WeeWX passes lang straight to setlocale, and the lang
        codes every shipped language file uses -- de, fr, nl, es -- are not
        names glibc knows, so set_locale raises and falls back to weewxd's
        own locale.  loopdata captures what RESOLVED rather than what was
        asked for, so it stays in step with the report in that case too:
        the German report says June, and so does loopdata."""
        L = user.loopdata
        tm = datetime(2025, 6, 21, 15, 0, 0).timetuple()
        for lang in ('de', 'fr', 'nl', 'es', 'not-a-locale-at-all', ''):
            L._RENDER_LOCALE_CACHE.pop(lang, None)
            captured = L.RenderLocale.capture(lang)
            with weewx.reportengine.set_locale(lang):
                expected = time.strftime('%A %B %x', tm)
            self.assertEqual(captured.strftime('%A %B %x', tm), expected, lang)
        # And the suite pins LC_ALL=C, so that fallback is C here -- which
        # is what makes the assertion above a real comparison rather than
        # German against German.
        self.assertEqual(L.RenderLocale.capture('de').strftime('%B', tm), 'June')

    def test_skip_if_older_than_must_be_at_least_one(self):
        """Spec: a stale-packet cutoff below one second would ship every
        packet however late, so zero and negatives are refused with a
        warning and the default of 3 answers; 1 and above are taken as
        given.  And the cutoff is applied unconditionally: a packet older
        than it is skipped, logged, before rsync is ever run."""
        L = user.loopdata
        # A blank value, or an explicit none, converts to None, and anything
        # non-numeric raises: both must be refused like any other value below
        # 1, since either reaching the comparison stops weewxd at startup.
        for spec, expected in (('0', 3), ('-5', 3), ('', 3), ('None', 3), ('0.9', 3),
                               ('3s', 3), ('abc', 3), ('1', 1), ('7', 7)):
            with tempfile.TemporaryDirectory() as tmp:
                config_dict = self._init_fixture(tmp)
                config_dict['LoopData']['RsyncSpec']['skip_if_older_than'] = spec
                with self.assertLogs('user.loopdata', level='INFO') as logs:
                    service = L.LoopData(self.FakeEngine(config_dict), config_dict)
                self.assertEqual(service.cfg.skip_if_older_than, expected, spec)
                warned = [m for m in logs.output if 'Ignoring skip_if_older_than' in m]
                if spec in ('1', '7'):
                    self.assertEqual(warned, [], spec)
                else:
                    self.assertEqual(len(warned), 1, logs.output)
                    # Reported as configured, not as converted: 0.9 is not 0.
                    self.assertIn('skip_if_older_than = %s (must be at least 1)' % spec, warned[0])
        # Ten seconds old against a cutoff of 3: skipped, and rsync never runs
        # (there is no server here to run it against).
        with self.assertLogs('user.loopdata', level='INFO') as logs:
            L.LoopProcessor.rsync_data(int(time.time()) - 10, 3, '/nonexistent', 'loop-data.txt',
                                       '/remote', 'nowhere.invalid', None, 1, 'nobody', '', False, False)
        self.assertEqual(len(logs.output), 1, logs.output)
        self.assertIn('skipping packet', logs.output[0])

    def test_legacy_bands_follow_the_target_report(self):
        """The [[Include]] line is rendered through target_report, so it
        bands the way that report bands.  A station that moved
        windrose_bands to [StdReport] [[Defaults]] while still on the line
        -- what the manual tells it to do -- must not have the flat rose
        revert to the WRPLOT defaults, and the shared rendering must
        survive."""
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            fields = ['current.outTemp.formatted', 'day.windrose.calm']
            config_dict['LoopData']['Include'] = {'fields': fields}
            config_dict['LoopData']['Formatting'] = {'target_report': 'LoopDataReport'}
            # The value moved to [[Defaults]]; nothing under [LoopData].
            config_dict['StdReport']['Defaults']['windrose_bands'] = ['1', '4', '8']
            service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            twin = [c for c in cfg.reports if c.report_name == 'LoopDataReport'][0]
            self.assertEqual(cfg.legacy.windrose_bands, [1.0, 4.0, 8.0])
            self.assertEqual(twin.windrose_bands, [1.0, 4.0, 8.0])
            # Agreeing, they share one windrose set and the fields render once.
            self.assertEqual(len(cfg.windrose_bandings), 1)
            self.assertEqual(set(cfg.legacy_shared), set(fields) | {'windrose.bands'})
            self.assertEqual(set(cfg.legacy_shared.values()), {'LoopDataReport'})

        # And with the value still under [LoopData] -- every pre-7.0
        # station -- the answer is what it always was.
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            config_dict['LoopData']['Include'] = {'fields': ['current.outTemp']}
            config_dict['LoopData']['windrose_bands'] = ['2', '5']
            with self.assertLogs('user.loopdata', level='WARNING'):
                service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            self.assertEqual(service.cfg.legacy.windrose_bands, [2.0, 5.0])

    def test_legacy_fields_are_shared_with_any_matching_report(self):
        """The fields line carries other extensions' entries -- what every
        celestial and weatherboard installer wrote for years -- and those
        reports are not target_report.  Any report whose rendering is
        identical may stand in, so those fields are computed ONCE instead
        of twice per packet; a report that renders differently may not."""
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            # A second declaring report, not the target, declaring fields
            # the sample skin does not -- the celestial case.
            other = os.path.join(tmp, 'skins', 'Other')
            os.makedirs(other)
            with open(os.path.join(other, 'skin.conf'), 'w') as f:
                f.write('[Generators]\n    generator_list = weewx.cheetahgenerator.CheetahGenerator\n'
                        '[LoopData]\n    [[fields]]\n        a = hour.outTemp.max.raw, week.rain.sum\n')
            # And a third whose trend window differs, so it renders trends
            # differently and must NOT be used as a stand-in.  The window
            # goes on the report's stanza: [[Defaults]] beats a skin.conf.
            odd = os.path.join(tmp, 'skins', 'Odd')
            os.makedirs(odd)
            with open(os.path.join(odd, 'skin.conf'), 'w') as f:
                f.write('[Generators]\n    generator_list = weewx.cheetahgenerator.CheetahGenerator\n'
                        '[LoopData]\n    [[fields]]\n        a = trend.outTemp.raw\n')
            config_dict['StdReport']['Other'] = {'skin': 'Other', 'HTML_ROOT': 'public_html/other'}
            config_dict['StdReport']['Odd'] = {'skin': 'Odd', 'HTML_ROOT': 'public_html/odd',
                                               'Units': {'Trend': {'time_delta': '3600'}}}
            config_dict['LoopData']['Include'] = {'fields': [
                'current.outTemp.formatted',        # LoopDataReport's (the target)
                'hour.outTemp.max.raw',   # Other's
                'week.rain.sum',          # Other's
                'trend.outTemp.raw',      # Odd's -- different trend window
                'current.inHumidity.raw']}   # nobody's
            config_dict['LoopData']['Formatting'] = {'target_report': 'LoopDataReport'}
            with self.assertLogs('user.loopdata', level='INFO') as logs:
                service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            self.assertEqual(cfg.legacy_shared, {
                'current.outTemp.formatted': 'LoopDataReport',
                'hour.outTemp.max.raw': 'Other',
                'week.rain.sum': 'Other'})
            # Odd renders trends over a different window, so its field stays
            # the legacy context's own, along with the one nobody declares.
            self.assertEqual(sorted(cfg.legacy.specified_fields),
                             ['current.inHumidity.raw', 'trend.outTemp.raw'])
            self.assertTrue(any('LoopDataReport: 1' in m and 'Other: 2' in m for m in logs.output),
                            logs.output)
            odd_ctx = [c for c in cfg.reports if c.report_name == 'Odd'][0]
            self.assertEqual(odd_ctx.time_delta, 3600)
            self.assertNotEqual(odd_ctx.render_signature, cfg.legacy.render_signature)
            # Two trend accumulators, since the windows genuinely differ.
            self.assertEqual(sorted(k for k in cfg.obstypes.continuous
                                    if user.loopdata.LoopData.is_trend_key(k)),
                             ['trend@10800', 'trend@3600'])

            # The flat keys are all still there, and each shared one is
            # byte-identical to the entry it was copied from.
            pkt_time = 1593630000
            accums = ProcessPacketTests._get_accums(cfg, pkt_time)
            renderers = user.loopdata.LoopProcessor(cfg).renderers
            for offset in (0, 2):
                out = user.loopdata.LoopProcessor.generate_output(
                    {'dateTime': pkt_time + offset, 'usUnits': 1, 'outTemp': 77.0 + offset,
                     'inHumidity': 40.0, 'rain': 0.0, 'windSpeed': 4.0, 'windDir': 90.0},
                    cfg, accums, renderers)
            for field, report in cfg.legacy_shared.items():
                self.assertIn(field, out, field)
                self.assertEqual(out[field], out[report][field], field)
            self.assertIn('current.inHumidity.raw', out)      # the legacy context's own
            self.assertIn('trend.outTemp.raw', out['Odd'])

    def test_a_failing_report_does_not_stop_the_file(self):
        """Every enabled report's declaration is rendered, including skins
        this station never wrote.  One of them raising must cost that
        report its entry, not the whole file -- process_queue re-raises,
        which would end the LoopProcessor thread and freeze loop-data.txt
        for good."""
        L = user.loopdata.LoopData
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        skin_dict = L.get_target_report_dict(config_dict, 'SeasonsReport')
        good = L.build_report_context('Good', ['current.outTemp'], skin_dict, None, None)
        bad = L.build_report_context('Bad', ['current.outTemp'], skin_dict, None, None)
        cfg = ProcessPacketTests._make_config(config_dict, 1, 6, legacy=None, reports=[good, bad])
        t = 1593630000
        accums = ProcessPacketTests._get_accums(cfg, t)
        renderers = [user.loopdata.ReportRenderer.for_context(c, cfg) for c in cfg.contexts]

        class Exploding:
            fields = []
            def insert_fields(self, loopdata_pkt, pkt):
                raise ValueError('boom')
        renderers[1].almanac_eval = Exploding()   # the 'Bad' context blows up

        pkt = {'dateTime': t, 'usUnits': 1, 'outTemp': 77.0}
        failures: Set[str] = set()
        with self.assertLogs('user.loopdata', level='ERROR') as logs:
            out = user.loopdata.LoopProcessor.generate_output(pkt, cfg, accums, renderers, failures)
        self.assertEqual(sorted(out), ['Good'])              # Bad is dropped, Good survives
        self.assertEqual(out['Good']['current.outTemp'], '77.0°F')
        self.assertTrue(any('Could not render report Bad' in m for m in logs.output), logs.output)
        # Logged once, not on every packet -- and the record of that is the
        # processor's own, not shared class state.
        out = user.loopdata.LoopProcessor.generate_output(pkt, cfg, accums, renderers, failures)
        self.assertEqual(sorted(out), ['Good'])
        self.assertEqual(failures, {'report Bad'})
        self.assertFalse(hasattr(user.loopdata.LoopProcessor, 'render_failures'))
        self.assertEqual(user.loopdata.LoopProcessor(cfg).render_failures, set())

    def test_version_tuple_is_shared_with_the_installer(self):
        """One helper, so the service's floor check and the installer's
        cannot disagree about a version string."""
        L = user.loopdata
        self.assertEqual(L.version_tuple('4.10.2'), (4, 10, 2))
        self.assertEqual(L.version_tuple('5.1'), (5, 1))
        self.assertEqual(L.version_tuple('4.6.0b7'), (4, 6, 0))
        self.assertLess(L.version_tuple('4.5.1'), (4, 6))
        self.assertGreater(L.version_tuple('4.10'), (4, 6))
        self.assertGreater(L.version_tuple('5.0.0'), (4, 6))
        # The installer defers to it rather than keeping its own rule.
        source = self.repo_text('install.py')
        self.assertIn('user.loopdata.version_tuple(version)', source)

    def test_finish_migration_reports_then_applies(self):
        """python3 -m user.loopdata: report only, and change nothing while
        any entry on the fields line is claimed by nobody; then remove the
        deprecated trio once every entry is accounted for."""
        L = user.loopdata
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            config_dict['LoopData']['Formatting'] = {'target_report': 'LoopDataReport'}
            config_dict['LoopData']['windrose_bands'] = ['1', '4', '8']
            config_dict['LoopData']['Include'] = {'fields': [
                'current.outTemp.formatted',  # LoopDataReport declares it
                'day.rain.sum.formatted',     # ditto
                'almanac.moon.rise',          # cruft: nobody declares it
                'current.extraTemp2']}        # a script's, also undeclared here
            report = L.migration_report(config_dict)
            self.assertEqual(report['owner'], {'current.outTemp.formatted': 'LoopDataReport',
                                               'day.rain.sum.formatted': 'LoopDataReport'})
            self.assertEqual(report['unclaimed'], ['almanac.moon.rise', 'current.extraTemp2'])
            self.assertEqual(report['differs'], set())      # the target renders identically
            # Nothing may be removed while anything is unclaimed.
            config_path = os.path.join(tmp, 'weewx.conf')
            config_dict.filename = config_path
            config_dict.write()
            self.assertEqual(L.main.__module__, 'user.loopdata')

            # Account for the two, and it applies.
            config_dict['LoopData']['Include']['fields'] = ['current.outTemp.formatted', 'day.rain.sum.formatted']
            report = L.migration_report(config_dict)
            self.assertEqual(report['unclaimed'], [])
            changes = L.apply_migration(config_dict, report)
            self.assertNotIn('Include', config_dict['LoopData'])
            self.assertNotIn('Formatting', config_dict['LoopData'])
            self.assertNotIn('windrose_bands', config_dict['LoopData'])
            # It bands target_report's rose, so it moves to target_report's
            # stanza -- already in that report's unit, so unconverted.
            self.assertEqual(config_dict['StdReport']['LoopDataReport']['windrose_bands'], ['1', '4', '8'])
            self.assertNotIn('windrose_bands', config_dict['StdReport']['Defaults'])
            self.assertTrue(any('moved [LoopData] windrose_bands' in c and 'LoopDataReport' in c
                                for c in changes), changes)
            self.assertTrue(any('[[Include]] fields (2 entries)' in c for c in changes), changes)
            self.assertTrue(any('target_report = LoopDataReport' in c for c in changes), changes)
            # What is left starts cleanly: no legacy context, no warning.
            config_dict.write()
            reread = configobj.ConfigObj(config_path, encoding='utf-8')
            service = user.loopdata.LoopData(self.FakeEngine(reread), reread)
            self.assertIsNone(service.cfg.legacy)

    def test_finish_migration_does_not_move_the_file(self):
        """Removing target_report re-anchors a relative loop_data_dir, so
        --apply pins the path first: a page polling the old URL must not
        start reading a 404 because the file quietly moved."""
        L = user.loopdata
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            config_dict['StdReport']['MyReport'] = {'skin': 'LoopData',
                                                    'HTML_ROOT': 'public_html/mine'}
            config_dict['LoopData']['FileSpec']['loop_data_dir'] = '.'
            config_dict['LoopData']['Formatting'] = {'target_report': 'MyReport'}
            config_dict['LoopData']['Include'] = {'fields': ['current.outTemp']}
            here = L.anchored_loop_data_dir(config_dict, 'MyReport')
            self.assertEqual(here, os.path.join(tmp, 'public_html', 'mine'))
            report = L.migration_report(config_dict)
            changes = L.apply_migration(config_dict, report)
            self.assertEqual(config_dict['LoopData']['FileSpec']['loop_data_dir'], here)
            self.assertTrue(any('pinned' in c for c in changes), changes)
            self.assertNotIn('Formatting', config_dict['LoopData'])

        # An absolute loop_data_dir needs no pinning, and neither does one
        # already anchored on LoopDataReport.
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            config_dict['LoopData']['FileSpec']['loop_data_dir'] = '/dev/shm/weewx'
            config_dict['LoopData']['Formatting'] = {'target_report': 'LoopDataReport'}
            config_dict['LoopData']['Include'] = {'fields': ['current.outTemp']}
            self.assertIsNone(L.anchored_loop_data_dir(config_dict, 'LoopDataReport'))
            changes = L.apply_migration(config_dict, L.migration_report(config_dict))
            self.assertEqual(config_dict['LoopData']['FileSpec']['loop_data_dir'], '/dev/shm/weewx')
            self.assertFalse(any('pinned' in c for c in changes), changes)

    def test_finish_migration_still_has_work_when_the_line_is_gone(self):
        """A user who deletes the last cruft entry by hand -- which the
        command itself tells them to do -- still has target_report and
        [LoopData] windrose_bands to lose."""
        L = user.loopdata
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            config_dict['LoopData']['FileSpec']['loop_data_dir'] = '/dev/shm/weewx'
            config_dict['LoopData']['Formatting'] = {'target_report': 'LoopDataReport'}
            config_dict['LoopData']['windrose_bands'] = ['1', '4', '8']
            report = L.migration_report(config_dict)
            self.assertEqual(report['line'], [])
            changes = L.apply_migration(config_dict, report)
            self.assertNotIn('Formatting', config_dict['LoopData'])
            self.assertNotIn('windrose_bands', config_dict['LoopData'])
            self.assertEqual(config_dict['StdReport']['LoopDataReport']['windrose_bands'], ['1', '4', '8'])
            self.assertNotIn('Include', config_dict['LoopData'])
            self.assertEqual([k for k in config_dict['LoopData']
                              if k in ('Include', 'Formatting', 'windrose_bands')], [])
            self.assertEqual(len(changes), 2, changes)

    def test_finish_migration_leaves_the_reports_own_bands_alone(self):
        """windrose_bands moves to target_report's stanza -- unless that
        report already sets its own, in which case the deprecated value is
        simply dropped rather than overwriting a choice already made."""
        L = user.loopdata
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            config_dict['LoopData']['Formatting'] = {'target_report': 'LoopDataReport'}
            config_dict['LoopData']['windrose_bands'] = ['1', '4', '8']
            config_dict['LoopData']['Include'] = {'fields': ['current.outTemp']}
            config_dict['StdReport']['LoopDataReport']['windrose_bands'] = ['2', '9']
            changes = L.apply_migration(config_dict, L.migration_report(config_dict))
            self.assertEqual(config_dict['StdReport']['LoopDataReport']['windrose_bands'], ['2', '9'])
            self.assertNotIn('windrose_bands', config_dict['LoopData'])
            self.assertTrue(any('already sets the bands' in c for c in changes), changes)
            # And nothing station-wide is invented on the way.
            self.assertNotIn('windrose_bands', config_dict['StdReport']['Defaults'])

    def test_shipped_skins_exist_and_scriptdata_generates_nothing(self):
        """Every file install.py ships is in the tree, and the ScriptData
        skin stays what it is for: no generators (WeeWX would run them) and
        no field declaration (this file is replaced on every upgrade, so a
        user's fields must live in weewx.conf, and ours would be a trap)."""
        shipped = self.installer_files()
        missing = [f for f in shipped
                   if not os.path.exists(os.path.join(self.REPO_ROOT, f))]
        self.assertEqual(missing, [])
        self.assertIn('skins/ScriptData/skin.conf', shipped)

        skin = configobj.ConfigObj(
            os.path.join(self.REPO_ROOT, 'skins', 'ScriptData', 'skin.conf'), encoding='utf-8')
        self.assertNotIn('Generators', skin)
        self.assertEqual(user.loopdata.LoopData.declared_fields_from_skin_dict(skin, 'ScriptData'), [])
        # It must say where fields really go, since the answer is not "here".
        text = self.repo_text('skins', 'ScriptData', 'skin.conf')
        self.assertIn('weewx.conf', text)
        self.assertIn('[[[[fields]]]]', text)

    def test_installer_defaults(self):
        """The values a fresh install writes LIVE.

        They are only ever read on a fresh `weectl extension install`, so a
        wrong one ships silently.  Compared through to_bool/to_int because a
        ConfigObj stanza yields strings where the old Python dict yielded an
        int -- the installed weewx.conf is text either way.

        What a fresh install receives commented out instead is pinned by
        test_installer_commented_defaults; the LIVE set here is complete,
        section by section, so demoting one without saying so fails.
        """
        config = self.installer_config()
        loopdata = config['LoopData']
        # [[FileSpec]] stays live in both keys: it has only these two, so
        # demoting both would empty the section -- and an empty section
        # dedents its own comments and writes a section for nothing.
        self.assertEqual(loopdata['FileSpec'].scalars,
                         ['loop_data_dir', 'filename'])
        self.assertEqual(loopdata['FileSpec']['loop_data_dir'], '.')
        self.assertEqual(loopdata['FileSpec']['filename'], 'loop-data.txt')
        # 7.0: the legacy trio is not written.  A fresh install declares
        # its fields in the sample skin's skin.conf (see
        # test_sample_skin_declares_what_the_manual_says) and every
        # declaring report is its own target.
        self.assertNotIn('Formatting', loopdata)
        self.assertNotIn('Include', loopdata)
        # The station's loop cadence stays live for a mechanical reason as
        # much as an editorial one: [[LoopFrequency]] has exactly one key,
        # so demoting it would empty that section too.
        self.assertEqual(loopdata['LoopFrequency'].scalars, ['seconds'])
        self.assertEqual(float(loopdata['LoopFrequency']['seconds']), 2.0)
        # [[RsyncSpec]]: the switch and the three PLACEHOLDERs the user has
        # to replace.  compress, log_success, timeout and skip_if_older_than
        # only select a default and are written commented out; the switch is
        # live because it is the line a user turns rsync on with, and the
        # placeholders because the code cannot supply them.  The live keys
        # are pinned as a COMPLETE SET, and the three placeholders come LAST
        # so that the commented block above them attaches to a live key
        # inside this section (see
        # test_installer_merged_comments_stay_in_their_section).
        rsync = loopdata['RsyncSpec']
        self.assertEqual(rsync.scalars,
                         ['enable', 'remote_server', 'remote_user', 'remote_dir'])
        self.assertFalse(to_bool(rsync['enable']))
        self.assertEqual(rsync['remote_server'], 'www.foobar.com')
        self.assertEqual(rsync['remote_user'], 'root')
        self.assertEqual(rsync['remote_dir'], '/home/weewx/loop-data')
        # The ScriptData report: shipped disabled, for fields read by
        # something that is not a report.  Its skin generates nothing.
        script_data = config['StdReport']['ScriptData']
        self.assertEqual(script_data.scalars, ['enable', 'skin'])
        self.assertFalse(to_bool(script_data['enable']))
        self.assertEqual(script_data['skin'], 'ScriptData')
        self.assertNotIn('LoopData', script_data)   # the user declares, not us

        report = config['StdReport']['LoopDataReport']
        # HTML_ROOT must NOT carry a public_html prefix: weecfg prepends the
        # installation's own StdReport HTML_ROOT at install time, so
        # 'public_html/loopdata' would land the report in
        # public_html/public_html/loopdata.
        self.assertEqual(report.scalars, ['HTML_ROOT', 'enable', 'skin'])
        self.assertEqual(report['HTML_ROOT'], 'loopdata')
        self.assertEqual(report['skin'], 'LoopData')
        self.assertTrue(to_bool(report['enable']))
        # Only the password stays live in [[[Extras]]] -- it is a
        # PLACEHOLDER the user must replace, and it is last so the four
        # commented options above it attach to it.
        extras = report['Extras']
        self.assertEqual(extras.scalars, ['page_update_pwd'])
        self.assertEqual(extras['page_update_pwd'], 'foobar')
        # These four stay live although they are WeeWX's own defaults.
        # They are not defaults here: they sit on the REPORT's stanza, the
        # last word in build_skin_dict's merge, precisely so a station-wide
        # [StdReport] [[Defaults]] cannot put a decimal on a wind dial that
        # has no room for one.  Commented out they would lose to it.
        weewx_defaults = weewx.defaults.defaults['Units']['StringFormats']
        self.assertEqual(report['Units']['StringFormats'], {
            'mile_per_hour': '%.0f',
            'degree_C': '%.1f',
            'km_per_hour': '%.0f',
            'degree_F': '%.1f',
        })
        for unit, spec in report['Units']['StringFormats'].items():
            self.assertEqual(weewx_defaults[unit], spec, unit)

    # ------------------------------------------------------------------
    # 7.0: reports declare their own fields; each is its own target.
    # ------------------------------------------------------------------

    def test_normalize_fields(self):
        L = user.loopdata.LoopData
        self.assertEqual(L.normalize_fields(None), [])
        # ConfigObj hands a single value back as a str: one field, not a
        # run of characters.
        self.assertEqual(L.normalize_fields('current.outTemp'), ['current.outTemp'])
        self.assertEqual(L.normalize_fields(' current.outTemp '), ['current.outTemp'])
        self.assertEqual(L.normalize_fields(['current.outTemp', ' day.rain.sum ', '', '  ']),
                         ['current.outTemp', 'day.rain.sum'])
        self.assertEqual(L.normalize_fields(''), [])
        self.assertEqual(L.normalize_fields([]), [])
        # A single quoted entry with a comma inside comes back from ConfigObj
        # as a str; it is ONE field, and splitting it would be exactly the
        # mangling the quoting prevents.
        call = 'day.rain.sum.format("%.2f", add_label=False)'
        self.assertEqual(L.normalize_fields(call), [call])
        self.assertEqual(L.normalize_fields('almanac(horizon=-6, days=1).sunrise'),
                         ['almanac(horizon=-6, days=1).sunrise'])

    def test_declared_fields_from_skin_dict(self):
        L = user.loopdata.LoopData
        self.assertEqual(L.declared_fields_from_skin_dict({}, 'R'), [])
        self.assertEqual(L.declared_fields_from_skin_dict({'LoopData': {}}, 'R'), [])
        self.assertEqual(L.declared_fields_from_skin_dict({'LoopData': {'windrose_bands': '1, 5'}}, 'R'), [])
        # Groups union in order; a field in two groups counts once.
        skin = configobj.ConfigObj([
            '[LoopData]',
            '    [[fields]]',
            '        a = current.outTemp, current.outTemp.raw',
            '        b = day.rain.sum',
            '        c = current.outTemp.raw, unit.label.outTemp',
            '        only = station.version',
            '        quoted = \'day.rain.sum.format("%.2f", add_label=False)\'',
            '        mixed = current.rain, \'almanac(horizon=-6, days=1).sunrise\'',
        ])
        self.assertEqual(L.declared_fields_from_skin_dict(skin, 'R'),
            ['current.outTemp', 'current.outTemp.raw', 'day.rain.sum',
             'unit.label.outTemp', 'station.version',
             'day.rain.sum.format("%.2f", add_label=False)',
             'current.rain', 'almanac(horizon=-6, days=1).sunrise'])
        # The likely mistake -- a single fields = line -- is refused with a
        # warning naming the report, not read as a run of characters.
        scalar = configobj.ConfigObj(['[LoopData]', '    fields = current.outTemp, day.rain.sum'])
        with self.assertLogs('user.loopdata', level='WARNING') as logs:
            self.assertEqual(L.declared_fields_from_skin_dict(scalar, 'MyReport'), [])
        self.assertTrue(any('MyReport' in m and 'named groups' in m for m in logs.output), logs.output)
        # A nested section under [[fields]] is not a group.
        nested = configobj.ConfigObj([
            '[LoopData]', '    [[fields]]', '        a = current.outTemp',
            '        [[[deeper]]]', '            b = day.rain.sum'])
        with self.assertLogs('user.loopdata', level='WARNING'):
            self.assertEqual(L.declared_fields_from_skin_dict(nested, 'R'), ['current.outTemp'])

    def test_declaration_merges_like_a_report(self):
        """The declaration is read from the MERGED skin dict, so a report's
        stanza in weewx.conf adds or replaces one group and leaves the
        skin's other groups alone -- how an extension declares fields that
        depend on the user's configuration.  Two reports on one skin each
        get the skin's groups plus their own."""
        L = user.loopdata.LoopData
        with tempfile.TemporaryDirectory() as tmp:
            skin_dir = os.path.join(tmp, 'skins', 'Declaring')
            os.makedirs(skin_dir)
            with open(os.path.join(skin_dir, 'skin.conf'), 'w') as f:
                f.write('[LoopData]\n    [[fields]]\n'
                        '        temperature = current.outTemp, current.outTemp.raw\n'
                        '        satellites = almanac.ISS.next_pass.rise\n')
            config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
            config_dict['WEEWX_ROOT'] = tmp
            config_dict['StdReport']['ReportA'] = {'skin': 'Declaring'}
            config_dict['StdReport']['ReportB'] = {'skin': 'Declaring', 'LoopData': {'fields': {
                'satellites': ['almanac.NOAA-21.next_pass.rise', 'almanac.NOAA-21.next_pass.set'],
                'extra': 'day.rain.sum'}}}
            config_dict['StdReport']['ReportOff'] = {'skin': 'Declaring', 'enable': 'false'}
            self.assertEqual(L.enabled_reports(config_dict)[-2:], ['ReportA', 'ReportB'])
            self.assertNotIn('ReportOff', L.enabled_reports(config_dict))
            self.assertNotIn('Defaults', L.enabled_reports(config_dict))
            a = L.declared_fields_from_skin_dict(L.get_target_report_dict(config_dict, 'ReportA'), 'ReportA')
            b = L.declared_fields_from_skin_dict(L.get_target_report_dict(config_dict, 'ReportB'), 'ReportB')
            self.assertEqual(a, ['current.outTemp', 'current.outTemp.raw', 'almanac.ISS.next_pass.rise'])
            # ReportB's stanza replaced the satellites group and added one;
            # the skin's temperature group is untouched.
            self.assertEqual(b, ['current.outTemp', 'current.outTemp.raw',
                                 'almanac.NOAA-21.next_pass.rise', 'almanac.NOAA-21.next_pass.set',
                                 'day.rain.sum'])

    def test_enabled_reports(self):
        L = user.loopdata.LoopData
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        reports = L.enabled_reports(config_dict)
        self.assertIn('SeasonsReport', reports)
        self.assertNotIn('SmartphoneReport', reports)     # enable = false
        self.assertNotIn('Defaults', reports)
        for scalar in ('SKIN_ROOT', 'HTML_ROOT', 'data_binding'):
            self.assertNotIn(scalar, reports)
        # A plain dict (no .sections) works the same way.
        self.assertEqual(L.enabled_reports({'StdReport': {
            'HTML_ROOT': 'public_html', 'A': {'skin': 'S'},
            'B': {'skin': 'S', 'enable': 'false'}, 'Defaults': {}}}), ['A'])
        self.assertEqual(L.enabled_reports({}), [])
        # Another report's malformed enable must not take weewxd down with
        # loopdata's __init__: warn and treat it as enabled.
        with self.assertLogs('user.loopdata', level='WARNING') as logs:
            self.assertEqual(L.enabled_reports({'StdReport': {
                'A': {'skin': 'S', 'enable': ''}, 'B': {'skin': 'S', 'enable': 'maybe'},
                'C': {'skin': 'S', 'enable': 'false'}}}), ['A', 'B'])
        self.assertEqual(len(logs.output), 2)

    def test_shared_windrose_edges_builds_the_converter_only_on_a_miss(self):
        """The [[Defaults]] converter costs a whole skin dict to build, so
        the memo must not pay for it once the value is known."""
        L = user.loopdata.LoopData
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        config_dict['StdReport']['Defaults']['windrose_bands'] = ['2', '10']
        us_dict = L.get_target_report_dict(config_dict, 'SeasonsReport')
        builds = []
        def counting_converter():
            builds.append(1)
            return L.defaults_converter(config_dict)
        shared: Dict[str, Any] = {}
        for _ in range(3):
            edges, _converter = L.shared_windrose_edges(
                shared, 'std', ['2', '10'], '[StdReport] [[Defaults]]', counting_converter)
            self.assertEqual(edges, [2.0, 10.0])
        self.assertEqual(len(builds), 1)
        # And through the real caller: three reports, one Defaults build.
        builds.clear()
        real_defaults_converter = L.defaults_converter
        try:
            user.loopdata.LoopData.defaults_converter = staticmethod(
                lambda cd: (builds.append(1), real_defaults_converter(cd))[1])
            shared = {}
            for report in ('SeasonsReport', 'SmartphoneReport', 'MobileReport'):
                self.assertEqual(
                    L.report_windrose_bands(config_dict, report, us_dict, {}, None, shared),
                    [2.0, 10.0])
        finally:
            user.loopdata.LoopData.defaults_converter = real_defaults_converter
        self.assertEqual(len(builds), 1)

    def test_shim_builds_each_evaluator_independently(self):
        """generate_loopdata_dictionary is the test-facing entry; a caller
        supplying one evaluator must still get the other, or that family's
        fields vanish from the result with no signal."""
        L = user.loopdata.LoopData
        specified_fields = ['current.outTemp', 'almanac.sunrise.raw', 'station.version']
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, specified_fields)
        cfg.latitude, cfg.longitude, cfg.altitude_m = 37.4, -122.1, 20.0
        cfg.legacy.station = weewx.station.Station(
            weewx.station.StationInfo(altitude=['700', 'foot'], latitude='37.4',
                longitude='-122.1', location='Test', station_url=''),
            cfg.legacy.formatter, cfg.legacy.converter,
            L.get_target_report_dict(cfg.config_dict, 'SeasonsReport'))
        pkt = {'dateTime': 1593630000, 'usUnits': 1, 'outTemp': 77.4}
        accums = ProcessPacketTests._get_accums(cfg, pkt['dateTime'])
        # Neither supplied: both families present.
        both = user.loopdata.LoopProcessor.generate_loopdata_dictionary(pkt, cfg, accums)
        self.assertIn('almanac.sunrise.raw', both)
        self.assertIn('station.version', both)
        # Only the almanac evaluator supplied: station fields must survive.
        almanac_eval = user.loopdata.AlmanacFieldEvaluator(cfg.legacy, cfg)
        one = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
            pkt, cfg, accums, almanac_eval)
        self.assertEqual(one['almanac.sunrise.raw'], both['almanac.sunrise.raw'])
        self.assertIn('station.version', one)
        # ... and the other way round.
        station_eval = user.loopdata.StationFieldEvaluator(cfg.legacy.station_fields, cfg.legacy.station)
        other = user.loopdata.LoopProcessor.generate_loopdata_dictionary(
            pkt, cfg, accums, None, station_eval)
        self.assertIn('almanac.sunrise.raw', other)
        self.assertEqual(other['station.version'], both['station.version'])

    def test_unit_label_windrose_is_not_a_rose(self):
        """unit.label.windrose is a label; alone it declares no windrose,
        so no banding is registered and no windrose.bands is emitted."""
        L = user.loopdata.LoopData
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        skin_dict = L.get_target_report_dict(config_dict, 'SeasonsReport')
        label_only = L.build_report_context('A', ['current.windSpeed', 'unit.label.windrose'], skin_dict, None, None)
        self.assertFalse(label_only.windrose)
        rose = L.build_report_context('B', ['day.windrose.calm'], skin_dict, None, None)
        self.assertTrue(rose.windrose)
        cfg = ProcessPacketTests._make_config(config_dict, 1, 6, legacy=None, reports=[label_only])
        self.assertEqual(cfg.windrose_bandings, {})
        accums = ProcessPacketTests._get_accums(cfg, 1593630000)
        out = user.loopdata.LoopProcessor.generate_output(
            {'dateTime': 1593630000, 'usUnits': 1, 'windSpeed': 5.0, 'windDir': 90.0}, cfg, accums,
            [user.loopdata.ReportRenderer.for_context(c, cfg) for c in cfg.contexts])
        self.assertNotIn('windrose.bands', out['A'])
        self.assertEqual(out['A']['unit.label.windrose'], ' miles')

    def test_unrecognized_field_is_reported(self):
        """A field none of the three parsers accept is logged, attributed to
        the declaring report; almanac and station fields that failed their
        own parser are not double-logged."""
        L = user.loopdata.LoopData
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        skin_dict = L.get_target_report_dict(config_dict, 'SeasonsReport')
        with self.assertLogs('user.loopdata', level='WARNING') as logs:
            ctx = L.build_report_context('MyReport',
                ['current.outTemp', 'curent.outTemp', 'nonsense', 'station.version'],
                skin_dict, None, None)
        self.assertEqual({c.field for c in ctx.fields_to_include}, {'current.outTemp'})
        self.assertEqual([f.field for f in ctx.station_fields], ['station.version'])
        warned = [m for m in logs.output if 'Ignoring unrecognized field' in m]
        self.assertEqual(len(warned), 2, logs.output)
        self.assertTrue(all('report MyReport' in m for m in warned), warned)
        self.assertTrue(any('curent.outTemp' in m for m in warned), warned)
        self.assertTrue(any("'nonsense'" in m or ' nonsense ' in m for m in warned), warned)

    def test_trend_accumulators_keyed_by_window(self):
        """Two reports with different trend windows get two trend
        accumulators, each rendering its own trend; two with the same
        window share one."""
        L = user.loopdata.LoopData
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        skin_dict = L.get_target_report_dict(config_dict, 'SeasonsReport')
        fields = ['current.outTemp', 'trend.outTemp.raw']
        def ctx(name, time_delta):
            c = L.build_report_context(name, fields, skin_dict, None, None)
            c.time_delta = time_delta
            self.assertEqual(c.trend_key, 'trend@%d' % time_delta)   # derived
            return c
        three_hours, one_hour, three_hours_too = ctx('A', 10800), ctx('B', 3600), ctx('C', 10800)
        cfg = ProcessPacketTests._make_config(config_dict, 1, 6, legacy=None,
            reports=[three_hours, one_hour, three_hours_too])
        self.assertEqual(sorted(cfg.obstypes.continuous), ['trend@10800', 'trend@3600'])
        self.assertEqual(cfg.obstypes.continuous['trend@10800'], {'outTemp'})
        self.assertEqual(cfg.obstypes.continuous['trend@3600'], {'outTemp'})

        pkt_time = 1593630000  # noon PDT, 2020-07-01
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        self.assertEqual(sorted(accums.continuous), ['trend@10800', 'trend@3600'])
        self.assertEqual(accums.continuous['trend@10800'].timelength, 10800)
        self.assertEqual(accums.continuous['trend@3600'].timelength, 3600)
        renderers = [user.loopdata.ReportRenderer.for_context(c, cfg) for c in cfg.contexts]
        for offset, temp in ((0, 60.0), (1800, 70.0), (3000, 80.0)):
            out = user.loopdata.LoopProcessor.generate_output(
                {'dateTime': pkt_time + offset, 'usUnits': 1, 'outTemp': temp},
                cfg, accums, renderers)
        self.assertEqual(sorted(out), ['A', 'B', 'C'])
        # get_trend spreads the observed change over the report's window:
        # time_delta / (lasttime - firsttime + loop_frequency) * change.
        change, actual = 20.0, 3000 + cfg.loop_frequency
        self.assertAlmostEqual(out['A']['trend.outTemp.raw'], 10800 / actual * change)
        self.assertAlmostEqual(out['C']['trend.outTemp.raw'], 10800 / actual * change)
        self.assertAlmostEqual(out['B']['trend.outTemp.raw'], 3600 / actual * change)

    def test_per_report_rendering_off_shared_accumulators(self):
        """One observation, two reports, two unit systems: each report's
        values render through its own converter and formatter, off ONE
        accumulator that saw each packet exactly once."""
        L = user.loopdata.LoopData
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        us_dict = L.get_target_report_dict(config_dict, 'SeasonsReport')
        metric_dict = L.get_target_report_dict(
            configobj.ConfigObj('tests/weewx.conf.db-us.report-metric', encoding='utf-8'),
            'SeasonsReport')
        fields = ['current.outTemp', 'day.outTemp.max', 'day.outTemp.max.raw', 'unit.label.outTemp']
        us = L.build_report_context('USReport', fields, us_dict, None, None)
        metric = L.build_report_context('MetricReport', fields, metric_dict, None, None)
        cfg = ProcessPacketTests._make_config(config_dict, 1, 6, legacy=None, reports=[us, metric])
        pkt_time = 1593630000
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        renderers = [user.loopdata.ReportRenderer.for_context(c, cfg) for c in cfg.contexts]
        for offset, temp in ((0, 68.0), (2, 77.0)):
            out = user.loopdata.LoopProcessor.generate_output(
                {'dateTime': pkt_time + offset, 'usUnits': 1, 'outTemp': temp},
                cfg, accums, renderers)
        self.assertEqual(sorted(out), ['MetricReport', 'USReport'])
        self.assertEqual(out['USReport']['current.outTemp'], '77.0°F')
        self.assertEqual(out['USReport']['day.outTemp.max'], '77.0°F')
        self.assertEqual(out['USReport']['unit.label.outTemp'], '°F')
        self.assertEqual(out['MetricReport']['current.outTemp'], '25.0°C')
        self.assertEqual(out['MetricReport']['day.outTemp.max'], '25.0°C')
        self.assertEqual(out['MetricReport']['unit.label.outTemp'], '°C')
        # The .raw value follows the report too (the accumulator holds °F).
        self.assertAlmostEqual(out['USReport']['day.outTemp.max.raw'], 77.0)
        self.assertAlmostEqual(out['MetricReport']['day.outTemp.max.raw'], 25.0)
        # Accumulated once per packet, not once per report.
        self.assertEqual(accums.day_accum['outTemp'].count, 2)

    def test_span_props_do_not_vary_by_report_unit_system(self):
        """Spec (7.2): a span property describes a SPAN, not a measurement,
        so two reports in different unit systems reading one shared span
        must render it identically -- while an observation beside it in the
        same file diverges.

        The reason it holds, and the reason it is worth pinning rather than
        assumed: group_time is unix_epoch and group_deltatime is second in
        EVERY WeeWX unit system, so each report's converter is a no-op on
        the way out of add_span_prop.  A span property routed through the
        observation machinery instead -- or given a unit taken from the
        report rather than from SPAN_PROPS -- would diverge here and
        nowhere else.

        current.outTemp is the control, and the test needs one: without an
        observation that DOES differ, two identical entries would prove
        only that the fixture never set up two unit systems at all."""
        L = user.loopdata.LoopData
        os.environ['TZ'] = 'America/Los_Angeles'
        time.tzset()
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        us_dict = L.get_target_report_dict(config_dict, 'SeasonsReport')
        metric_dict = L.get_target_report_dict(
            configobj.ConfigObj('tests/weewx.conf.db-us.report-metric', encoding='utf-8'),
            'SeasonsReport')
        span_fields = ['week.start.raw', 'week.end.raw', 'week.length.raw',
                       'week.length.hour.raw', 'week.length', 'week.start']
        fields = ['current.outTemp.raw', 'unit.label.outTemp'] + span_fields
        us = L.build_report_context('USReport', list(fields), us_dict, None, None)
        metric = L.build_report_context('MetricReport', list(fields), metric_dict, None, None)
        cfg = ProcessPacketTests._make_config(config_dict, 1, 6, legacy=None, reports=[us, metric])
        pkt_time = 1593630000                           # 2020-07-01 12:00 PDT
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        renderers = [user.loopdata.ReportRenderer.for_context(c, cfg) for c in cfg.contexts]
        out = user.loopdata.LoopProcessor.generate_output(
            {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 77.0}, cfg, accums, renderers)
        self.assertEqual(sorted(out), ['MetricReport', 'USReport'])

        # The control: the two reports really are in different unit systems.
        self.assertAlmostEqual(out['USReport']['current.outTemp.raw'], 77.0)
        self.assertAlmostEqual(out['MetricReport']['current.outTemp.raw'], 25.0)
        self.assertEqual(out['USReport']['unit.label.outTemp'], '°F')
        self.assertEqual(out['MetricReport']['unit.label.outTemp'], '°C')

        # Every span property, formatted and raw, identical in both entries.
        # The raw values are identical because of the unit groups above; the
        # FORMATTED ones additionally need the two fixtures to agree on
        # [Units][TimeFormats], which they do -- a report may legitimately
        # format an instant differently, so a failure here is worth reading
        # before it is called a unit bug.
        for field in span_fields:
            self.assertEqual(out['USReport'][field], out['MetricReport'][field], field)

        # And they are the right values, not merely the same wrong one.
        span = weeutil.weeutil.archiveWeekSpan(pkt_time, cfg.week_start)
        self.assertEqual(out['USReport']['week.start.raw'], span.start)
        self.assertEqual(out['USReport']['week.end.raw'], span.stop)
        self.assertEqual(out['USReport']['week.length.raw'], 604800)
        # An explicit unit override is unit-system-independent too: a week
        # is 168 hours in a metric report and in a US one.
        self.assertAlmostEqual(out['USReport']['week.length.hour.raw'], 168.0)

    def test_legacy_flat_beside_report_keys(self):
        """An upgraded station: the [[Include]] fields line renders flat at
        the top level exactly as before, and the declaring reports land
        beside it under their names, in the same file."""
        L = user.loopdata.LoopData
        cfg = ProcessPacketTests._get_config('us', 10800, 1, 6, ['current.outTemp', 'day.outTemp.max'])
        config_dict = cfg.config_dict
        skin_dict = L.get_target_report_dict(config_dict, 'SeasonsReport')
        cfg.reports.append(L.build_report_context('LoopDataReport',
            ['current.outTemp', 'current.outTemp.raw'], skin_dict, None, None))
        cfg.recompute()
        pkt_time = 1593630000
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        renderers = [user.loopdata.ReportRenderer.for_context(c, cfg) for c in cfg.contexts]
        out = user.loopdata.LoopProcessor.generate_output(
            {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 77.0}, cfg, accums, renderers)
        self.assertEqual(sorted(out), ['LoopDataReport', 'current.outTemp', 'day.outTemp.max'])
        self.assertEqual(out['current.outTemp'], '77.0°F')
        self.assertEqual(out['LoopDataReport'],
            {'current.outTemp': '77.0°F', 'current.outTemp.raw': 77.0})
        # And the legacy line alone: the file is what it always was.
        cfg.reports.clear()
        out = user.loopdata.LoopProcessor.generate_output(
            {'dateTime': pkt_time + 2, 'usUnits': 1, 'outTemp': 77.0}, cfg, accums, renderers[:1])
        self.assertEqual(sorted(out), ['current.outTemp', 'day.outTemp.max'])

    def test_windrose_accumulators_keyed_by_bands(self):
        """Two reports with different band edges get two windrose sets,
        each banding the same packet its own way and each publishing its
        own legend; the same edges share one set."""
        L = user.loopdata.LoopData
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        skin_dict = L.get_target_report_dict(config_dict, 'SeasonsReport')
        fields = ['day.windrose.banded']
        default_a = L.build_report_context('A', fields, skin_dict, None, None)
        custom = L.build_report_context('B', fields, skin_dict, [1.0, 5.0, 10.0], None)
        default_c = L.build_report_context('C', fields, skin_dict, None, None)
        self.assertEqual(default_a.windrose_key, default_c.windrose_key)
        self.assertNotEqual(default_a.windrose_key, custom.windrose_key)
        cfg = ProcessPacketTests._make_config(config_dict, 1, 6, legacy=None,
            reports=[default_a, custom, default_c])
        self.assertEqual(len(cfg.windrose_bandings), 2)
        self.assertEqual(cfg.windrose_span_periods,
            {(default_a.windrose_key, 'day'), (custom.windrose_key, 'day')})
        pkt_time = 1593630000
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        self.assertEqual(len(accums.windrose_span), 2)
        renderers = [user.loopdata.ReportRenderer.for_context(c, cfg) for c in cfg.contexts]
        # 9 mph from the east: band 2 of the WRPLOT mph edges
        # (1.1, 4.7, 8.1, ...), band 1 of the custom edges (1, 5, 10).
        out = user.loopdata.LoopProcessor.generate_output(
            {'dateTime': pkt_time, 'usUnits': 1, 'windSpeed': 9.0, 'windDir': 90.0},
            cfg, accums, renderers)
        east = 4
        self.assertEqual(out['A']['windrose.bands'], [1.1, 4.7, 8.1, 12.8, 19.7, 24.8])
        self.assertEqual(out['B']['windrose.bands'], [1.0, 5.0, 10.0])
        self.assertEqual(out['A']['day.windrose.banded'][east][2], cfg.loop_frequency)
        self.assertEqual(out['A']['day.windrose.banded'][east][1], 0)
        self.assertEqual(out['B']['day.windrose.banded'][east][1], cfg.loop_frequency)
        self.assertEqual(out['B']['day.windrose.banded'][east][2], 0)
        self.assertEqual(out['C'], out['A'])

    def test_almanac_evaluators_are_per_report(self):
        """The same almanac field in two reports with different [Almanac]
        texts renders differently: the evaluator's cache holds RENDERED
        values, so it must be one per report."""
        L = user.loopdata.LoopData
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        skin_dict = L.get_target_report_dict(config_dict, 'SeasonsReport')
        phases = ['P0', 'P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7']
        a = L.build_report_context('A', ['almanac.moon_phase'], skin_dict, None, None)
        b = L.build_report_context('B', ['almanac.moon_phase'], skin_dict, None, None)
        b.almanac_texts = {'moon_phases': phases}
        cfg = ProcessPacketTests._make_config(config_dict, 1, 6, legacy=None, reports=[a, b])
        cfg.latitude, cfg.longitude, cfg.altitude_m = 37.4, -122.1, 20.0
        pkt_time = 1593630000
        accums = ProcessPacketTests._get_accums(cfg, pkt_time)
        renderers = [user.loopdata.ReportRenderer.for_context(c, cfg) for c in cfg.contexts]
        self.assertIsNot(renderers[0].almanac_eval, renderers[1].almanac_eval)
        pkt = {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 77.4}
        out = user.loopdata.LoopProcessor.generate_output(pkt, cfg, accums, renderers)
        def oracle(texts):
            return str(weewx.almanac.Almanac(pkt_time, 37.4, -122.1, altitude=20.0,
                formatter=skin_dict and a.formatter, converter=a.converter,
                **user.loopdata.AlmanacFieldEvaluator.build_texts_kwargs(
                    weewx.almanac.Almanac, texts)).moon_phase)
        self.assertEqual(out['A']['almanac.moon_phase'], oracle(a.almanac_texts))
        self.assertEqual(out['B']['almanac.moon_phase'], oracle(b.almanac_texts))
        self.assertNotEqual(out['A']['almanac.moon_phase'], out['B']['almanac.moon_phase'])
        self.assertIn(out['B']['almanac.moon_phase'], phases)

    def test_sample_skin_declares_what_the_manual_says(self):
        """skins/LoopData/skin.conf declares the panel's fields; every one
        parses, and the set is exactly the manual's "What each gauge reads"
        (plus the clock and dial-scale fields named under the table)."""
        L = user.loopdata.LoopData
        skin = configobj.ConfigObj(os.path.join(self.I18N_SKIN_DIR, 'skin.conf'), encoding='utf-8')
        declared = L.declared_fields_from_skin_dict(skin, 'LoopDataReport')
        self.assertGreaterEqual(len(declared), 40)
        for field in declared:
            self.assertTrue(L.parse_cname(field) is not None
                            or L.parse_almanac_field(field) is not None
                            or L.parse_station_field(field) is not None, field)
        text = self.doc_text('sample-skin.md')
        section = text.split('## What each gauge reads')[1].split('\n## ')[0]
        section = re.split(r'\n\{: \.', section)[0]   # the table and the paragraph under it, not the callout
        documented = set(re.findall(r'`([^`]+)`', section))
        documented.discard('--')
        documented.discard('windrose.bands')     # automatic, never declared
        documented.discard('.raw')
        self.assertEqual(set(declared), documented,
            'skins/LoopData/skin.conf and docs/sample-skin.md disagree: %s'
            % sorted(set(declared) ^ documented))
        # The page reads its own report's entries.
        updater = self.repo_text('skins', 'LoopData', 'realtime_updater.inc')
        self.assertIn("(await response.json())[$json.dumps($REPORT_NAME)]", updater)
        self.assertNotIn("'$REPORT_NAME'", updater)

    def test_defaults_unit_follows_stdreport_however_it_is_written(self):
        """A [StdReport]-level windrose_bands is in the units [StdReport]
        specifies -- and WeeWX lets that be said three ways: an explicit
        [[[Units]]] [[[[Groups]]]], a unit_system, or a lang whose language
        file carries one.  All three must be honored, or the edges are
        converted from the wrong unit into every report."""
        L = user.loopdata.LoopData
        base = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        self.assertEqual(L.defaults_converter(base).getTargetUnit('windSpeed')[0], 'mile_per_hour')

        # 1: explicit Groups (the fixture's own form) -- already US above.
        # 2: unit_system, with Groups removed.
        by_system = weeutil.config.deep_copy(base)
        del by_system['StdReport']['Defaults']['Units']['Groups']
        by_system['StdReport']['Defaults']['unit_system'] = 'metricwx'
        self.assertEqual(L.defaults_converter(by_system).getTargetUnit('windSpeed')[0],
                         'meter_per_second')

        # 3: lang alone.  WeeWX's own de.conf declares unit_system = metricwx,
        # and a report inheriting the language renders in it -- so a value
        # written at [[Defaults]] level is in that unit too.
        by_lang = weeutil.config.deep_copy(base)
        del by_lang['StdReport']['Defaults']['Units']['Groups']
        by_lang['StdReport']['Defaults']['lang'] = 'de'
        report_unit = weewx.units.Converter.fromSkinDict(
            L.get_target_report_dict(by_lang, 'SeasonsReport')).getTargetUnit('windSpeed')[0]
        self.assertEqual(L.defaults_converter(by_lang).getTargetUnit('windSpeed')[0], report_unit)
        self.assertEqual(L.lang_unit_system(by_lang, 'de'), 'metricwx')

        # An explicit setting still wins over the language's.
        both = weeutil.config.deep_copy(by_lang)
        both['StdReport']['Defaults']['unit_system'] = 'us'
        self.assertEqual(L.defaults_converter(both).getTargetUnit('windSpeed')[0], 'mile_per_hour')
        # And an explicit GROUP wins over the language's unit system for
        # that group alone, which is the order build_skin_dict uses: the
        # unit system underneath, the explicit groups on top.
        mixed = weeutil.config.deep_copy(by_lang)
        mixed['StdReport']['Defaults']['Units'] = {'Groups': {'group_pressure': 'mbar'}}
        converter = L.defaults_converter(mixed)
        self.assertEqual(converter.getTargetUnit('barometer')[0], 'mbar')          # explicit
        self.assertEqual(converter.getTargetUnit('windSpeed')[0], 'meter_per_second')  # the language's

        # get_lang_dict's second parameter is the language directory only
        # from WeeWX 5.3; from 4.6 through 5.2 it is the whole config_dict.
        # Both must work, or a station below 5.3 silently loses the
        # language's unit system -- the extension's floor is 4.6.
        real = weewx.reportengine.get_lang_dict
        passed: List[str] = []
        # Its parameters are (lang_spec, config_dict, report) before 5.3, so
        # a stand-in with no 'lang_spec_dir' parameter is what a 4.6-5.2
        # WeeWX looks like.  WeeWX's own merge_lang calls it too, with a
        # Path, so take either and record what loopdata passed.
        def pre_5_3(lang_spec, config_dict, report):
            passed.append(type(config_dict).__name__)
            lang_dir = config_dict if not isinstance(config_dict, dict) else pathlib.Path(
                config_dict['WEEWX_ROOT'], config_dict['StdReport']['SKIN_ROOT'],
                config_dict['StdReport'][report].get('skin', ''), 'lang')
            return real(lang_spec, lang_dir, report)
        # ... unless the suite is ALREADY on a WeeWX below 5.3, where the
        # real function IS the older shape: wrapping it would hand a Path
        # to something expecting the config, and the stand-in would be
        # testing itself.  There, drive the real one -- the better test,
        # and what lets tools/check_against_weewx.sh run this suite
        # unchanged against an older WeeWX.
        stand_in = pre_5_3 if 'lang_spec_dir' in inspect.signature(real).parameters else None
        try:
            if stand_in is not None:
                weewx.reportengine.get_lang_dict = stand_in
            passed.clear()
            self.assertEqual(L.lang_unit_system(by_lang, 'de'), 'metricwx')
            if stand_in is not None:
                self.assertIn('ConfigObj', passed)  # the whole config, not a Path
            self.assertEqual(L.defaults_converter(by_lang).getTargetUnit('windSpeed')[0],
                             'meter_per_second')
        finally:
            weewx.reportengine.get_lang_dict = real
        # A language nothing ships is simply not found.
        self.assertIsNone(L.lang_unit_system(by_lang, 'xx'))
        # A station that repeats lang on every report still resolves: the
        # language file asked for is the same file whichever report points
        # at the skin holding it.
        repeated = weeutil.config.deep_copy(by_lang)
        for report in L.enabled_reports(repeated):
            if 'skin' in repeated['StdReport'][report]:
                repeated['StdReport'][report]['lang'] = 'de'
        self.assertEqual(L.lang_unit_system(repeated, 'de'), 'metricwx')
        self.assertEqual(L.defaults_converter(repeated).getTargetUnit('windSpeed')[0],
                         'meter_per_second')

        # And the whole point: edges written at [[Defaults]] level in the
        # language's unit reach a report unconverted, not multiplied.
        by_lang['StdReport']['Defaults']['windrose_bands'] = ['1', '5', '12']
        skin_dict = L.get_target_report_dict(by_lang, 'SeasonsReport')
        self.assertEqual(L.report_windrose_bands(by_lang, 'SeasonsReport', skin_dict, {}, None),
                         [1.0, 5.0, 12.0])

    def test_windrose_bands_resolution(self):
        """windrose_bands is a report option, and where it is written says
        its unit: the report's stanza or its skin.conf, in the report's
        unit; [StdReport] [[Defaults]], in the Defaults' unit, converted to
        each report's; then the deprecated [LoopData] windrose_bands (in
        target_report's unit, converted) as the upgrade fallback; then the
        WRPLOT defaults."""
        L = user.loopdata.LoopData
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        us_dict = L.get_target_report_dict(config_dict, 'SeasonsReport')       # mph
        metric_config = configobj.ConfigObj('tests/weewx.conf.db-us.report-metric', encoding='utf-8')
        km_dict = L.get_target_report_dict(metric_config, 'SeasonsReport')      # km/h
        self.assertEqual(weewx.units.Converter.fromSkinDict(us_dict).getTargetUnit('windSpeed')[0], 'mile_per_hour')
        self.assertEqual(weewx.units.Converter.fromSkinDict(km_dict).getTargetUnit('windSpeed')[0], 'km_per_hour')
        wrplot_mph = [1.1, 4.7, 8.1, 12.8, 19.7, 24.8]

        # Nothing anywhere: the defaults, in the report's unit.
        self.assertEqual(L.report_windrose_bands(config_dict, 'SeasonsReport', us_dict, {}, None), wrplot_mph)
        # The report's own stanza, in its unit, verbatim.
        config_dict['StdReport']['SeasonsReport']['windrose_bands'] = ['1', '5', '10']
        self.assertEqual(L.report_windrose_bands(config_dict, 'SeasonsReport', us_dict, {}, None), [1.0, 5.0, 10.0])
        del config_dict['StdReport']['SeasonsReport']['windrose_bands']
        # [StdReport] [[Defaults]]: in the Defaults' unit (mph in this
        # fixture), converted and rounded for a km/h report.
        config_dict['StdReport']['Defaults']['windrose_bands'] = ['2', '10']
        self.assertEqual(L.defaults_converter(config_dict).getTargetUnit('windSpeed')[0], 'mile_per_hour')
        self.assertEqual(L.report_windrose_bands(config_dict, 'SeasonsReport', us_dict, {}, None), [2.0, 10.0])
        self.assertEqual(L.report_windrose_bands(config_dict, 'MetricReport', km_dict, {}, None), [3.2, 16.1])
        # A stock weewx.conf sets the Defaults' units as unit_system = ...
        # with [[[Units]]] [[[[Groups]]]] commented out; the Defaults'
        # converter must honor it exactly as WeeWX's skin-dict build does.
        stock = weeutil.config.deep_copy(config_dict)
        del stock['StdReport']['Defaults']['Units']['Groups']
        stock['StdReport']['Defaults']['unit_system'] = 'metricwx'
        self.assertEqual(L.defaults_converter(stock).getTargetUnit('windSpeed')[0], 'meter_per_second')
        # unit_system PLUS an explicit group: WeeWX applies unit_system first
        # and the explicit group over it, and so must the Defaults converter.
        both = weeutil.config.deep_copy(stock)
        both['StdReport']['Defaults']['Units'] = {'Groups': {'group_speed': 'km_per_hour'}}
        self.assertEqual(L.defaults_converter(both).getTargetUnit('windSpeed')[0], 'km_per_hour')
        self.assertEqual(weewx.units.Converter.fromSkinDict(
            L.get_target_report_dict(both, 'SeasonsReport')).getTargetUnit('windSpeed')[0], 'km_per_hour')
        # No [[Defaults]] at all: WeeWX's own defaults.
        bare = weeutil.config.deep_copy(config_dict)
        del bare['StdReport']['Defaults']
        self.assertEqual(L.defaults_converter(bare).getTargetUnit('windSpeed')[0], 'mile_per_hour')
        stock['StdReport']['Defaults']['windrose_bands'] = ['1', '5', '10']
        mps_dict = L.get_target_report_dict(stock, 'SeasonsReport')
        self.assertEqual(weewx.units.Converter.fromSkinDict(mps_dict).getTargetUnit('windSpeed')[0], 'meter_per_second')
        self.assertEqual(L.report_windrose_bands(stock, 'SeasonsReport', mps_dict, {}, None), [1.0, 5.0, 10.0])
        self.assertEqual(L.report_windrose_bands(stock, 'MetricReport', km_dict, {}, None), [3.6, 18.0, 36.0])
        stock['StdReport']['Defaults']['unit_system'] = 'metric'
        self.assertEqual(L.defaults_converter(stock).getTargetUnit('windSpeed')[0], 'km_per_hour')
        # The report's stanza beats Defaults, and is in the report's unit.
        config_dict['StdReport']['MetricReport'] = {'skin': 'Seasons', 'windrose_bands': ['3', '9']}
        self.assertEqual(L.report_windrose_bands(config_dict, 'MetricReport', km_dict, {}, None), [3.0, 9.0])
        del config_dict['StdReport']['MetricReport']
        # A bare [StdReport] scalar is the older spelling of a default and
        # wins over [[Defaults]], as in WeeWX's own skin-dict build.
        config_dict['StdReport']['windrose_bands'] = ['4', '8']
        self.assertEqual(L.report_windrose_bands(config_dict, 'SeasonsReport', us_dict, {}, None), [4.0, 8.0])
        del config_dict['StdReport']['windrose_bands']
        del config_dict['StdReport']['Defaults']['windrose_bands']
        # skin.conf's own top-level windrose_bands, in the report's unit.
        skin_with = weeutil.config.deep_copy(us_dict)
        skin_with['windrose_bands'] = ['1', '2', '3']
        self.assertEqual(L.report_windrose_bands(config_dict, 'SeasonsReport', skin_with, {}, None), [1.0, 2.0, 3.0])
        # The deprecated [LoopData] windrose_bands bands target_report's
        # rose and NO other: before 7.0 it banded the one rose in the flat
        # file, which was rendered through target_report.  Every other
        # report's rose is new in 7.0 and takes the defaults.
        loop = {'windrose_bands': ['3', '6']}
        self.assertEqual(L.legacy_windrose_bands(config_dict, 'SeasonsReport', us_dict, loop), [3.0, 6.0])
        self.assertEqual(L.report_windrose_bands(config_dict, 'SeasonsReport', us_dict, loop, us_dict,
                                                 None, 'SeasonsReport'), [3.0, 6.0])
        self.assertEqual(L.report_windrose_bands(config_dict, 'MetricReport', km_dict, loop, us_dict,
                                                 None, 'SeasonsReport'),
                         L.parse_windrose_bands(None, weewx.units.Converter.fromSkinDict(km_dict)))
        # ... and not even target_report, once it has its own.
        self.assertEqual(L.report_windrose_bands(config_dict, 'SeasonsReport', skin_with, loop, us_dict,
                                                 None, 'SeasonsReport'), [1.0, 2.0, 3.0])
        # An invalid shared value: reported ONCE through the memo, and every
        # report takes the defaults in its OWN unit -- never the source
        # unit's defaults converted and rounded again.
        config_dict['StdReport']['Defaults']['windrose_bands'] = ['1', 'foo']
        shared = {}
        with self.assertLogs('user.loopdata', level='ERROR') as logs:
            self.assertEqual(L.report_windrose_bands(config_dict, 'SeasonsReport', us_dict, {}, None, shared), wrplot_mph)
            self.assertEqual(L.report_windrose_bands(config_dict, 'MetricReport', km_dict, {}, None, shared),
                             L.parse_windrose_bands(None, weewx.units.Converter.fromSkinDict(km_dict)))
        self.assertEqual(len(logs.output), 1, logs.output)
        del config_dict['StdReport']['Defaults']['windrose_bands']
        bad_legacy = {'windrose_bands': ['5', '2']}
        with self.assertLogs('user.loopdata', level='ERROR') as logs:
            shared = {}
            self.assertEqual(L.legacy_windrose_bands(config_dict, 'SeasonsReport', us_dict, bad_legacy, shared), wrplot_mph)
        self.assertEqual(len(logs.output), 1, logs.output)
        # windrose_bands inside the skin's [LoopData] section, beside
        # [[fields]], counts as the skin's own (the natural first guess).
        skin_section = weeutil.config.deep_copy(us_dict)
        skin_section['LoopData'] = {'windrose_bands': ['2', '4', '6'], 'fields': {'a': 'day.windrose.calm'}}
        self.assertEqual(L.report_windrose_bands(config_dict, 'SeasonsReport', skin_section, {}, None), [2.0, 4.0, 6.0])
        # Conversion that would collapse two edges keeps the exact values.
        us_conv = weewx.units.Converter.fromSkinDict(us_dict)
        km_conv = weewx.units.Converter.fromSkinDict(km_dict)
        self.assertEqual(L.convert_windrose_bands([1.0, 2.0], us_conv, us_conv), [1.0, 2.0])
        self.assertEqual(L.convert_windrose_bands([1.0, 2.0], us_conv, km_conv), [1.6, 3.2])
        tight = L.convert_windrose_bands([1.0, 1.02], km_conv, us_conv)
        self.assertLess(tight[0], tight[1])

    class FakeEngine:
        """Just enough of a weewx engine for LoopData.__init__."""
        def __init__(self, config_dict):
            self.config_dict = config_dict
            self.stn_info = weewx.station.StationInfo(
                altitude=['700', 'foot'], latitude='37.4', longitude='-122.1',
                location='Test', station_url='')
            self.bound = []
        def bind(self, event, callback):
            self.bound.append(event)

    @staticmethod
    def _init_fixture(tmp: str, declare_sample: bool = True) -> Dict[str, Any]:
        """A weewx.conf, skin tree and database under tmp for a real
        LoopData.__init__: the sample skin (declaring), an uploader-style
        report whose skin declares nothing, and SeasonsReport whose
        skin.conf is absent (declares nothing either)."""
        config_dict = configobj.ConfigObj('tests/weewx.conf.us', encoding='utf-8')
        config_dict['WEEWX_ROOT'] = tmp
        os.makedirs(os.path.join(tmp, 'archive'))
        dbm = weewx.manager.DaySummaryManager.open_with_create(
            {'database_name': os.path.join(tmp, 'archive', 'weewx.sdb'), 'driver': 'weedb.sqlite'},
            table_name='archive', schema=wview_extended_schema)
        dbm.close()
        skin_dir = os.path.join(tmp, 'skins', 'LoopData')
        os.makedirs(skin_dir)
        if declare_sample:
            shutil.copy(os.path.join(ProcessPacketTests.I18N_SKIN_DIR, 'skin.conf'), skin_dir)
        else:
            with open(os.path.join(skin_dir, 'skin.conf'), 'w') as f:
                f.write('[Generators]\n    generator_list = weewx.cheetahgenerator.CheetahGenerator\n')
        ftp_dir = os.path.join(tmp, 'skins', 'Ftp')
        os.makedirs(ftp_dir)
        with open(os.path.join(ftp_dir, 'skin.conf'), 'w') as f:
            f.write('[Generators]\n    generator_list = weewx.reportengine.FtpGenerator\n')
        config_dict['StdReport']['LoopDataReport'] = {'skin': 'LoopData', 'HTML_ROOT': 'public_html/loopdata'}
        config_dict['StdReport']['FTP'] = {'skin': 'Ftp', 'enable': 'true'}
        config_dict['LoopData'] = {'FileSpec': {'loop_data_dir': '.', 'filename': 'loop-data.txt'},
                                   'RsyncSpec': {'enable': 'false', 'compress': 'false', 'log_success': 'false'}}
        return config_dict

    def test_init_wires_the_contexts(self):
        """LoopData.__init__ end to end against a real config, skin tree and
        database: the declaring report, the legacy line through
        target_report, the anchor for a relative loop_data_dir, and the
        two failure paths of the legacy line."""
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            # Two of the three legacy fields are declared by LoopDataReport,
            # the target_report: they are rendered once, in its entry, and
            # copied flat; only the third stays in the legacy context.
            config_dict['LoopData']['Include'] = {'fields': ['current.outTemp.formatted', 'day.rain.sum.formatted', 'day.outTemp.min']}
            config_dict['LoopData']['Formatting'] = {'target_report': 'LoopDataReport'}
            with self.assertLogs('user.loopdata', level='INFO') as logs:
                service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            self.assertEqual(cfg.legacy_shared,
                             {'current.outTemp.formatted': 'LoopDataReport', 'day.rain.sum.formatted': 'LoopDataReport'})
            self.assertEqual(cfg.legacy.specified_fields, ['day.outTemp.min'])
            self.assertTrue(any('2 of the 3 [[Include]] fields are declared by reports that render '
                                'them identically (LoopDataReport: 2)' in m
                                for m in logs.output), logs.output)
            pkt_time = 1593630000
            accums = ProcessPacketTests._get_accums(cfg, pkt_time)
            out = user.loopdata.LoopProcessor.generate_output(
                {'dateTime': pkt_time, 'usUnits': 1, 'outTemp': 77.0, 'rain': 0.0},
                cfg, accums, user.loopdata.LoopProcessor(cfg).renderers)
            self.assertEqual(out['current.outTemp.formatted'], out['LoopDataReport']['current.outTemp.formatted'])
            self.assertEqual(out['day.rain.sum.formatted'], out['LoopDataReport']['day.rain.sum.formatted'])
            self.assertIn('day.outTemp.min', out)
            self.assertNotIn('day.outTemp.min', out['LoopDataReport'])
            # An exact set, deliberately: a new binding is new work on the
            # engine thread and must be a decision, not a side effect.
            # NEW_ARCHIVE_RECORD (7.2) keeps first_good_stamp -- the alltime
            # span's start -- current on a station whose archive was empty
            # when the accumulators were built.
            self.assertEqual(set(service.engine.bound),
                {weewx.NEW_LOOP_PACKET, weewx.PRE_LOOP, weewx.NEW_ARCHIVE_RECORD})
            # One declaring report: SeasonsReport has no skin.conf here and
            # FTP's skin declares nothing, so neither counts.
            self.assertEqual([ctx.report_name for ctx in cfg.reports], ['LoopDataReport'])
            declared = set(cfg.reports[0].specified_fields)
            self.assertIn('day.windrose.banded', declared)          # from skin.conf
            self.assertGreaterEqual(len(declared), 50)
            # The legacy line, rendered through target_report.
            self.assertIsNotNone(cfg.legacy)
            self.assertTrue(any('deprecated' in m for m in logs.output))
            # The union: obstypes from both contexts, one trend key.
            self.assertIn('rain', cfg.obstypes.day)
            self.assertIn('barometer', cfg.obstypes.current)     # the sample skin's
            self.assertEqual([k for k in cfg.obstypes.continuous if user.loopdata.LoopData.is_trend_key(k)], ['trend@10800'])
            # A relative loop_data_dir anchors on target_report's directory.
            self.assertEqual(os.path.normpath(cfg.loop_data_dir),
                             os.path.join(tmp, 'public_html', 'loopdata'))
            self.assertTrue(os.path.isdir(cfg.loop_data_dir))

        # No fields line at all, but the deprecated [LoopData] windrose_bands
        # still set: it bands target_report's rose only, so a declaring
        # report that is not the target keeps the defaults.  And a
        # non-default target_report kept without a fields line is warned
        # about: it still anchors loop_data_dir and will be removed.
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            config_dict['LoopData']['windrose_bands'] = ['1', '4', '8']
            config_dict['StdReport']['Other'] = {'skin': 'LoopData', 'HTML_ROOT': 'public_html/other', 'enable': 'false'}
            config_dict['LoopData']['Formatting'] = {'target_report': 'Other'}
            with self.assertLogs('user.loopdata', level='INFO') as logs:
                service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            self.assertIsNone(cfg.legacy)
            self.assertEqual(cfg.reports[0].report_name, 'LoopDataReport')   # not the target
            self.assertEqual(cfg.reports[0].windrose_bands,
                             [1.1, 4.7, 8.1, 12.8, 19.7, 24.8])              # the defaults
            self.assertTrue(any('windrose_bands is deprecated' in m for m in logs.output), logs.output)
            self.assertTrue(any('target_report = Other is deprecated' in m for m in logs.output), logs.output)
            self.assertEqual(os.path.normpath(cfg.loop_data_dir), os.path.join(tmp, 'public_html', 'other'))

        # A target_report that exists but cannot be built (a broken
        # skin.conf) is reported as such, exception included -- not as
        # "not found".
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            broken = os.path.join(tmp, 'skins', 'Broken')
            os.makedirs(broken)
            with open(os.path.join(broken, 'skin.conf'), 'w') as f:
                f.write('[Extras\n    oops = 1\n')
            config_dict['StdReport']['BrokenReport'] = {'skin': 'Broken', 'enable': 'false'}
            config_dict['LoopData']['Include'] = {'fields': ['current.outTemp']}
            config_dict['LoopData']['Formatting'] = {'target_report': 'BrokenReport'}
            with self.assertLogs('user.loopdata', level='INFO') as logs:
                service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            self.assertIsNone(cfg.legacy)
            self.assertTrue(any('Could not build target_report BrokenReport' in m and 'Exception:' in m
                                for m in logs.output), logs.output)
            self.assertFalse(any('Could not find target_report' in m for m in logs.output), logs.output)

        # A target_report that does not exist: the legacy line is dropped
        # with the honest message, the declaring report is still served, and
        # a relative loop_data_dir falls back to [StdReport] HTML_ROOT with a
        # WARNING saying so (the installer puts [[LoopDataReport]] back, so
        # this is a hand-edited station between upgrades).
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            config_dict['LoopData']['Include'] = {'fields': ['current.outTemp']}
            config_dict['LoopData']['Formatting'] = {'target_report': 'Nope'}
            with self.assertLogs('user.loopdata', level='INFO') as logs:
                service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            self.assertIsNone(cfg.legacy)
            self.assertEqual([ctx.report_name for ctx in cfg.reports], ['LoopDataReport'])
            self.assertTrue(any('Could not find target_report: Nope' in m for m in logs.output), logs.output)
            self.assertEqual(os.path.normpath(cfg.loop_data_dir), os.path.join(tmp, 'public_html'))
            self.assertTrue(any('WARNING' in m and 'relative to [StdReport] HTML_ROOT' in m for m in logs.output), logs.output)

        # A disabled LoopDataReport still anchors: enable = false is how the
        # sample page is turned off, and the section stays.
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp)
            config_dict['StdReport']['LoopDataReport']['enable'] = 'false'
            config_dict['LoopData']['Include'] = {'fields': ['current.outTemp']}
            with self.assertLogs('user.loopdata', level='INFO'):
                service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            cfg = service.cfg
            self.assertEqual(cfg.reports, [])          # disabled: declares nothing
            self.assertIsNotNone(cfg.legacy)          # but the line still renders through it
            self.assertEqual(os.path.normpath(cfg.loop_data_dir), os.path.join(tmp, 'public_html', 'loopdata'))

        # The same with nothing else declaring: LoopData exits, and says the
        # line was there but could not be set up -- not that it is absent.
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp, declare_sample=False)
            config_dict['LoopData']['Include'] = {'fields': ['current.outTemp']}
            config_dict['LoopData']['Formatting'] = {'target_report': 'Nope'}
            with self.assertLogs('user.loopdata', level='ERROR') as logs:
                service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            self.assertFalse(hasattr(service, 'cfg'))
            self.assertEqual(service.engine.bound, [])
            self.assertTrue(any('could not be set up (see above)' in m for m in logs.output), logs.output)
            self.assertFalse(any('there is no [LoopData] [[Include]] fields line' in m for m in logs.output), logs.output)

        # And with no fields line at all, the message says so.
        with tempfile.TemporaryDirectory() as tmp:
            config_dict = self._init_fixture(tmp, declare_sample=False)
            with self.assertLogs('user.loopdata', level='ERROR') as logs:
                service = user.loopdata.LoopData(self.FakeEngine(config_dict), config_dict)
            self.assertFalse(hasattr(service, 'cfg'))
            self.assertTrue(any('there is no [LoopData] [[Include]] fields line' in m for m in logs.output), logs.output)

    # ------------------------------------------------------------------
    # American English
    # ------------------------------------------------------------------
    #
    # A ratchet.  Prose drifts one word at a time and the drift is
    # invisible in review, because every one of these spellings is
    # correct somewhere -- just not here.  This is a sweep of every
    # tracked text file, so it covers comments, docstrings, templates,
    # changes.md, the manual and the shipped skin, which is where all
    # twenty-two of the words fixed on 2026-09-08 were living.
    #
    # THIS BLOCK IS SHARED VERBATIM with weewx-loopdata, weewx-celestial,
    # weewx-skyfield and one private sibling.  Naming all four the same
    # way keeps this sentence identical in every copy, and names no
    # private repository in a public one.  The word lists, the guards and
    # the oracle are byte for byte the same, so a fix made in one is
    # pasted into the rest rather than rediscovered there.  Four
    # independent versions of this test is what the sharing exists to
    # prevent.
    #
    # EXACTLY FIVE THINGS ARE PER-REPO, and they are marked PER-REPO where
    # they are defined: NOT_OURS, QUOTED_PROPER_NOUNS, LANG_DIR,
    # LANG_IN_ENGLISH and A_TRACKED_FILE.  An earlier version of this
    # comment said two, having forgotten that the sanity check names a
    # file; whoever pasted it next met a failure that blamed their working
    # directory.  If you add a sixth, say so HERE -- the next person
    # should read what differs, not discover it.
    #
    # IN A PYTEST-ONLY SUITE, host it as
    # `class TestAmericanEnglish(unittest.TestCase)` with `REPO_ROOT` as a
    # class attribute.  pytest collects a TestCase without complaint and
    # every method body below stays byte-identical, where translating the
    # assertions to bare asserts would end the sharing at the first edit.
    #
    # THE '*' IN EVERY ENTRY IS STRIPPED BEFORE USE.  It is there so that
    # no British spelling appears literally in this file, which is what
    # lets the sweep cover this file too -- no self-exclusion, and so no
    # blind spot in the eleven thousand lines of tests around it.  A word
    # added without its '*' fails the sweep on its own line, which is the
    # right way round to get that wrong.
    #
    # Add a word here when one turns up, rather than fixing a file
    # quietly.  If a British spelling is ever legitimate -- a quoted
    # product name, a proper noun -- this is the place to record it.
    BRITISH_SPELLINGS = (
        'label*led', 'unlabel*led', 'label*ling', 'colo*ur', 'colo*urs',
        'colo*ured', 'colo*uring', 'behavio*ur', 'behavio*urs', 'hono*ur',
        'cent*re', 'cent*res', 'cent*red', 'gr*ey', 'gr*eyer', 'gr*eyish',
        'judge*ment', 'judge*ments', 'age*ing', 'whil*st', 'among*st',
        'analog*ue', 'orientat*ed', 'defen*ce', 'licen*ce', 'program*me',
        'catalog*ue', 'cancel*led', 'model*led', 'travel*ling',
        'signal*ling', 'met*re', 'met*res', 'fib*re', 'scept*ic',
        'artef*act', 'enr*ol', 'fulf*il', 'inst*il', 'skil*ful',
        'favo*ur', 'flavo*ur', 'neighbo*ur', 'labo*ur', 'vapo*ur',
        'armo*ur', 'rumo*ur', 'savo*ur', 'harbo*ur', 'humo*ur', 'odo*ur',
        'valo*ur', 'cando*ur', 'demeano*ur', 'endeavo*ur', 'splendo*ur',
        'savio*ur', 'clamo*ur', 'parlo*ur',
        'theat*re', 'lit*re', 'calib*re', 'somb*re', 'spect*re', 'lust*re',
        'manoeuv*re', 'offen*ce', 'preten*ce', 'practi*se', 'practi*sing',
        'cent*ring',
        'cancel*ling', 'model*ling', 'travel*led', 'signal*led',
        'level*led', 'level*ling', 'total*led', 'fuel*led', 'dial*led',
        'dial*ling', 'equal*led', 'channel*led', 'marvel*lous',
        'mo*uld', 'plo*ugh', 'dra*ught', 'lear*nt',
        # The -y*se verbs and the four -i*se verbs whose AMERICAN form is
        # itself the stem.  These CANNOT become stems below: analy*sis,
        # emphas*is, Polar*is and Borealis are all correct, and a stem
        # would flag every one of them.  Because they are entered as
        # whole words, each inflection has to be listed -- which is the
        # very cost the stems exist to avoid, so keep this list short.
        'analy*se', 'analy*sed', 'analy*sing',
        'paraly*se', 'paraly*sed', 'paraly*sing',
        'cataly*se', 'cataly*sed', 'cataly*sing',
        'reali*se', 'reali*sed', 'reali*sing', 'reali*sation',
        'emphasi*se', 'emphasi*sed', 'emphasi*sing',
        'polari*se', 'polari*sed', 'polari*sing', 'polari*sation',
        # DELIBERATELY ABSENT: glamo*ur, which is the ordinary American
        # spelling as well, and dialog*ue, which American style accepts
        # alongside dialog.  A word only belongs here if the American
        # form is the ONLY correct one.
    )

    # The -i*se verbs, as STEMS ENDING IN `is` rather than as words.
    #
    # This is the whole reason the list above is not simply longer.  The
    # four inflections do not contain one another: token*ise does NOT
    # match token*ising, because the letter after `is` is an i and not an
    # e, and neither of them matches token*isation.  A list of -i*se
    # WORDS therefore sees roughly one inflection in three -- measured on
    # this tree, twenty of twenty -ing and -ation forms were invisible,
    # and a recogn*ising in docs/troubleshooting.md had been sitting
    # through a green suite because of it.  One stem catches all four.
    #
    # Every stem is guarded (?![mt]), uniformly rather than by naming
    # exceptions, because each one runs into the -ism and -ist nouns:
    # unguarded, these flag characteristics, realistic, optimistic,
    # specialist, finalist, apologist, organism and criticism, all
    # correct American.  Nothing is lost, because no British-only
    # spelling puts an m or a t after `is`.
    #
    # The guard is a constant rather than a value inlined in the builder
    # so that it can be taken away and the loss measured.  It is already
    # pinned: emptying it fails test_british_spelling_pattern, because
    # MUST_SPARE carries characteristics, organism, specialist and the
    # rest of the -ism and -ist nouns it exists to spare.
    IS_STEM_GUARD = 'mt'

    BRITISH_IS_STEMS = (
        'util*is', 'custom*is', 'optim*is', 'normal*is', 'initial*is',
        'serial*is', 'standard*is', 'synchron*is', 'visual*is',
        'special*is', 'priorit*is', 'minim*is', 'maxim*is', 'apolog*is',
        'critic*is', 'token*is', 'author*is', 'categor*is', 'character*is',
        'familiar*is', 'final*is', 'general*is', 'item*is', 'memor*is',
        'modern*is', 'random*is', 'stabil*is', 'symbol*is', 'sanit*is',
        'summar*is', 'recogn*is', 'organ*is', 'local*is',
    )

    # Letters that must NOT follow a spelling, where it is a prefix of a
    # correct American word.  Without these, substring matching cries
    # wolf on fulfill, instill, enrolled, greyhound, programmer and
    # PROGRAMMED -- the last of which is ordinary American and cost a
    # code review to find, because a single-letter guard for programmer
    # let it through.  The -se guards spare analyses, paralyses and
    # catalyses, the ordinary American plurals of analysis, paralysis
    # and catalysis.  (The cost is that the British VERB analyses goes
    # unseen; a false alarm on correct prose would be worse, and
    # analy*sed is still caught.)
    PREFIX_OF_AN_AMERICAN_WORD = {
        'fulf*il': 'l', 'inst*il': 'l', 'enr*ol': 'l', 'gr*ey': 'h',
        'program*me': 'rd', 'analy*se': 's', 'paraly*se': 's',
        'cataly*se': 's',
    }

    # Files this repo ships but does not AUTHOR.  The rule is about the
    # bytes we write; someone else's verbatim text is not ours to
    # correct, and "fix the spelling" and "keep it verbatim" cannot both
    # be obeyed.  PER-REPO: this tuple is the one part of the shared
    # block that differs between the four repos.
    #
    # LICENSE is the FSF's text.  It happens to clear the pattern today
    # -- this is a guard against a future revision of it, not a fix for
    # a present failure.
    #
    # The four weewx.conf fixtures are Tom Keffer's WEEWX CONFIGURATION
    # FILE, copied whole so the tests parse what a real station parses.
    # Editing them would be a worse bug than the one it prevents: they
    # would stop matching what WeeWX ships, which is the only reason
    # they exist.  The word in them is WeeWX's own comment on its meter
    # label, offering the British spelling to the reader as a choice --
    # a sentence that cannot survive having its subject corrected.
    # Identifiers from other people's code that this project only
    # QUOTES.  Python's asyncio really does spell it Cancel*ledError, and
    # the British word is a strict PREFIX of that name, so no guard
    # letter can separate them -- the only way is to remove the token
    # from the text before matching.  Shared, not per-repo: it is
    # Python's name, and any repo that mentions asyncio meets it the day
    # it pastes this block.  Stripped before splitlines(), so the
    # whole-file pass and the line pass agree.
    FOREIGN = ('Cancel*ledError',)

    # Phrases in OUR OWN prose that are somebody else's name: a
    # publication title, an organization's English name, a product.
    # NOT_OURS exempts whole files we did not author; this exempts a
    # PHRASE inside a file we did.  A sibling repo needs it for a
    # catalog title and an institute's name that appear in a credit its
    # data license requires verbatim -- Americanizing either would
    # misquote a title or rename an organization, which is a worse fault
    # than the spelling.
    #
    # PER-REPO, like NOT_OURS.  Most repos have none, and an empty tuple
    # is the normal case; this repo quotes no such title.  The mechanism
    # is carried anyway so that it is here the day one is quoted, and so
    # that the copies stay identical -- the same reason the lang
    # constants below are carried by a repo with no translations.
    #
    # Three properties, each of which cost a sibling something to learn:
    # entries carry the '*' like every other list here, because literal
    # ones would be blanked out of THIS file too and it would pass while
    # containing what it forbids; the blanking is scoped to the PHRASE
    # and never the line, since a misspelling typed beside a quoted title
    # is still a mistake and those paragraphs are the ones most likely to
    # be re-edited; and a phrase is replaced by a SPACE rather than
    # removed, so the words on either side cannot run together into a
    # match.  Matching is literal, so a phrase must sit on one line --
    # the staleness assertion at the end of the sweep is what says so
    # when a citation gets reflowed.
    QUOTED_PROPER_NOUNS = ()

    # PER-REPO.  A file the sweep can be sure is tracked, so that an
    # empty or wrong listing is reported as such instead of passing as a
    # clean tree.
    A_TRACKED_FILE = 'bin/user/loopdata.py'

    # PER-REPO.
    NOT_OURS = (
        'LICENSE',
        'tests/weewx.conf.us',
        'tests/weewx.conf.metric',
        'tests/weewx.conf.db-us.report-metric',
        'tests/weewx.conf.db-metric.report-us',
    )

    # The translations are not English, and an English spelling rule
    # applied to them is simply wrong: fr.conf's French for "they use",
    # and no.conf's and sv.conf's Norwegian and Swedish for
    # "standardizes", all carry the British verb ending and all three
    # are correct in their own language.
    #
    # But only the TRANSLATED half is exempt.  Every lang file opens
    # with an English header this repo wrote -- nineteen to twenty-seven
    # lines of it, explaining where the vocabulary came from and where
    # to send corrections -- and a file-level exemption hid all of it
    # while this test's docstring claimed every tracked byte.  So the
    # sweep runs down to the first [section] and stops there, which is
    # where the translated text starts in all nine files.
    #
    # en.conf is swept whole: it is English, and it is the reference
    # dictionary every other lang file is checked against.  Derived from
    # the PATH rather than listed, so a new translation is exempt the day
    # it lands.  PER-REPO: a repo with no lang directory keeps these
    # constants and the code, so the rule is already in place when one
    # arrives.
    LANG_DIR = 'skins/LoopData/lang/'
    LANG_IN_ENGLISH = 'skins/LoopData/lang/en.conf'

    def _british_spelling_re(self):
        """One alternation, matched ANYWHERE in a line.

        Lower case only, and the caller lowers the text to match.  The
        obvious re.IGNORECASE costs 5.4 seconds over this tree against
        0.7 for lowering the text first -- a third of the whole suite,
        and paid again on every mutant, since this test is in the
        spec-only runner and can never kill one.  The entries must
        therefore stay lower case, guard letters included.
        """
        words, bars = self._british_words_and_bars()
        # A guard on the guards: a typo in a PREFIX key would silently
        # stop guarding the word it names, and the false alarm that
        # follows looks like a spelling error in correct prose.
        self.assertEqual(
            sorted(set(bars) - set(words)), [],
            'PREFIX_OF_AN_AMERICAN_WORD names a word in neither list')
        self.assertEqual(
            [entry for entry in self.BRITISH_SPELLINGS + self.BRITISH_IS_STEMS
             if entry.lower() != entry], [],
            'the word lists must be lower case; see _british_spelling_re')
        return re.compile(
            '|'.join(re.escape(word) +
                     ('(?![%s])' % bars[word] if bars.get(word) else '')
                     for word in words))

    def _british_words_and_bars(self):
        """Every spelling to look for, and the letters barred after it."""
        bars = {word.replace('*', ''): letters for word, letters
                in self.PREFIX_OF_AN_AMERICAN_WORD.items()}
        words = [entry.replace('*', '') for entry in self.BRITISH_SPELLINGS]
        for stem in self.BRITISH_IS_STEMS:
            stem = stem.replace('*', '')
            words.append(stem)
            bars[stem] = self.IS_STEM_GUARD
        return words, bars

    # What the pattern must catch, and what it must leave alone.  Same
    # '*' convention as the lists above.
    MUST_FLAG = (
        'colo*ur', 'colo*urs', 'recolo*ur', 'colo*urful', 'behavio*ur',
        'hono*urs', 'neighbo*ur', 'cent*re', 'centimet*re', 'met*res',
        'gr*ey', 'judge*ment', 'label*led', 'cancel*ling', 'travel*led',
        'level*ling', 'program*me', 'program*mes', 'fulf*il', 'inst*il',
        'enr*ol', 'licen*ce', 'defen*ce', 'offen*ce', 'preten*ce',
        'practi*se', 'theat*re', 'lit*re', 'calib*re', 'mo*uld',
        'smo*ulder', 'plo*ugh', 'dra*ught', 'lear*nt', 'artef*act',
        'scept*ical', 'whil*st', 'among*st', 'age*ing', 'analog*ue',
        'catalog*ue', 'orientat*ed', 'local*isation', 'local*ised',
        'scept*icism', 'practi*sing', 'cent*ring',
        # The four inflections of a stem, which is the whole point of
        # BRITISH_IS_STEMS -- delete the stems and the last two of these
        # go unseen while everything else here still passes.
        'token*ise', 'token*ised', 'token*ising', 'token*isation',
        'recogn*ising', 'organ*isation', 'normal*ising',
        'character*ised', 'critic*ising', 'special*isation',
        # The words that had to stay whole because their American form
        # is the stem.
        'analy*sed', 'analy*sing', 'paraly*sed', 'reali*se',
        'reali*sing', 'reali*sation', 'emphasi*sed', 'emphasi*sing',
        'polari*sed', 'polari*sing',
        # An identifier, with no word boundary anywhere near the word.
        'test_colo*urs_arrive',
    )

    MUST_SPARE = (
        # Correct American spellings of the words above.
        'color', 'colors', 'colorful', 'behavior', 'honor', 'honorable',
        'neighbor', 'center', 'centered', 'concentrate', 'centimeter',
        'meters', 'barometer', 'thermometer', 'diameter', 'parameters',
        'gray', 'grayscale', 'judgment', 'labeled', 'canceling',
        'traveled', 'leveling', 'license', 'licensed', 'defense',
        'offense', 'pretense', 'practice', 'theater', 'liter', 'caliber',
        'mold', 'smolder', 'plow', 'draft', 'learned', 'artifact',
        'skeptical', 'skeptic', 'skepticism', 'analog', 'catalog',
        'oriented', 'fiber', 'somber', 'localization', 'localized',
        'practicing', 'centering',
        # The prefix traps, every one of which a naive matcher flags.
        'programmed', 'programmer', 'programming', 'fulfill', 'fulfilled',
        'instill', 'install', 'installer', 'enroll', 'enrolled',
        'enrollment', 'greyhound', 'cancellation', 'skillful',
        # American plurals and nouns that ARE the British verb's stem.
        'analyses', 'analysis', 'paralyses', 'paralysis', 'catalyses',
        'emphasis', 'synthesis', 'hypothesis',
        # Proper nouns.  Every one of these is a star or a constellation
        # this family of extensions names, and Borealis is what a
        # real*is stem flagged in en.conf before it was entered whole.
        'Polaris', 'Corona Borealis', 'Corona Australis',
        # The -ism and -ist nouns the (?![mt]) guard exists for.
        'characteristics', 'realistic', 'optimistic', 'specialist',
        'finalist', 'apologist', 'organism', 'criticism', 'symbolism',
        'modernist', 'journalist', 'scientist', 'utility',
        # American -ize forms, which must never be mistaken for their
        # British cousins.
        'recognized', 'organized', 'normalizing', 'tokenization',
        'initialized', 'summarized', 'authorized', 'categorized',
        # Verbs that end in -ise in AMERICAN English.
        'advertise', 'exercise', 'surprise', 'compromise', 'supervise',
        'franchise', 'enterprise', 'comprise', 'precise', 'concise',
        'otherwise', 'revise', 'devise', 'improvise', 'disguise',
        'promise', 'premise', 'wise',
        # Ordinary words that happen to contain a fragment of one.
        'should', 'shoulder', 'could', 'would', 'through', 'thorough',
        'drought', 'learning', 'aging', 'managing', 'messaging',
    )

    def test_british_spelling_pattern(self):
        """The oracle, and it is not optional.

        A PASSING SWEEP PROVES NOTHING ABOUT THE WORD LIST.  An empty
        list passes.  So does one whose guards are so wide they spare
        the words they were meant to catch, and so does one that misses
        two inflections in four.  Both of those were real here: the
        sweep, a green suite and eleven hand-run sabotage cases all
        passed while `programmed` was being flagged as British and every
        -i*sing and -i*sation form was invisible.  This test is what
        sees that class, by asserting on the compiled pattern directly
        rather than on the tree.

        Add to MUST_SPARE whenever a guard is widened, and to MUST_FLAG
        whenever a word or a stem is added.
        """
        want = self._british_spelling_re()
        missed = [entry.replace('*', '') for entry in self.MUST_FLAG
                  if not want.search(entry.replace('*', '').lower())]
        self.assertEqual(missed, [],
                         'the pattern does not catch these British spellings')
        flagged = []
        for word in self.MUST_SPARE:
            found = want.search(word.lower())
            if found is not None:
                flagged.append('%s (matched %r)' % (word, found.group(0)))
        self.assertEqual(flagged, [],
                         'the pattern flags correct American English')

    def test_every_entry_can_still_be_reached(self):
        """A guard can retire the word it was meant to protect.

        Widen one -- 'gr*ey': 'h' to 'hs', say, to spare some new word --
        and gr*eys stops being caught while every other test here stays
        green, because MUST_FLAG holds the bare word and a bare word
        always matches: the lookahead sits at the end of the string with
        nothing to reject.  Seventy-nine of the entries are not in
        MUST_FLAG at all, so most of the list can be retired this way
        without anything noticing.

        Two assertions close it.  The first appends a letter the guard
        PERMITS, so an entry made unreachable is seen.  The second is the
        one that matters: every letter barred by a hand-written guard
        must be JUSTIFIED by a word in MUST_SPARE that needs it -- which
        is what widening a guard legitimately means.  Widen one without
        adding the American word that forced it, and this fails.

        The uniform stem guard is deliberately exempt from the second
        rule: it is one policy justified once, by the -ism and -ist nouns
        in MUST_SPARE, not a per-word judgment, and no British-only
        spelling puts an m or a t after `is`.
        """
        want = self._british_spelling_re()
        words, bars = self._british_words_and_bars()
        spare = [word.lower() for word in self.MUST_SPARE]
        stems = {stem.replace('*', '') for stem in self.BRITISH_IS_STEMS}
        unreachable, unjustified = [], []
        for word in words:
            barred = bars.get(word, '')
            allowed = next((c for c in 'abcdefghijklmnopqrstuvwxyz'
                            if c not in barred), None)
            self.assertIsNotNone(
                allowed, '%s bars every letter there is' % word)
            if not want.search(word + allowed):
                unreachable.append(word + allowed)
            if word in stems:
                continue
            for letter in barred:
                if not any(word + letter in word_spared for word_spared in spare):
                    unjustified.append('%s(?!%s)' % (word, letter))
        self.assertEqual(unreachable, [],
                         'these spellings can no longer be matched at all')
        self.assertEqual(
            unjustified, [],
            'a guard bars a letter with no MUST_SPARE word needing it; '
            'add the American word that forced the guard, or narrow it')

    def test_no_british_spellings(self):
        """American English, in every byte this repo tracks.

        MATCHING IS BY SUBSTRING, NOT BY WHOLE WORD.  A word-boundary
        search has two blind spots, and a sibling repo fell into both.
        It misses a spelling inside an IDENTIFIER, because '_' is
        itself a word character and the boundary never appears -- a
        test named test_colo*urs_arrive went unseen that way.  And it
        misses a spelling inside a longer WORD, because to such a
        search hono*urs is simply a different word from hono*ur.  Hence
        no boundaries; the handful of British spellings that are
        prefixes of correct American words carry an explicit guard
        instead of relying on \\b to do it by accident.

        Sabotage it by putting one British spelling in any tracked text
        file, including this one.
        """
        listed = subprocess.run(['git', 'ls-files'], cwd=self.REPO_ROOT,
                                capture_output=True, text=True)
        self.assertEqual(listed.returncode, 0, listed.stderr)
        names = [name for name in listed.stdout.split('\n') if name]
        self.assertIn(self.A_TRACKED_FILE, names,
                      'git ls-files listed nothing useful; is REPO_ROOT right?')
        # An exemption for a file that no longer exists is not a
        # harmless leftover.  Rename a fixture and its NOT_OURS entry
        # stops matching, so WeeWX's text is swept as though it were
        # ours; rename the skin and every translation is.  Either way
        # the failure that follows is a pile of correct prose, and the
        # obvious reading of it is that the sweep is broken.  Say which
        # exemption went stale instead.
        for name in self.NOT_OURS:
            self.assertIn(name, names,
                          'NOT_OURS names a file git does not track')
        translations = [n for n in names if n.startswith(self.LANG_DIR)
                        and n != self.LANG_IN_ENGLISH]
        # Only where a lang directory actually exists.  A repo with no
        # translations still carries the constants and the line-level
        # exemption below, dormant, so the rule is already in place the
        # day one lands -- and an unconditional assertion here would
        # mean such a repo could not paste this block at all.
        if any(name.startswith(self.LANG_DIR) for name in names):
            self.assertIn(self.LANG_IN_ENGLISH, names,
                          'the reference lang file moved; LANG_DIR is stale')
            self.assertTrue(translations,
                            'no translations under LANG_DIR; the path is stale')
        want = self._british_spelling_re()
        hits = []
        seen_quoted = set()
        for name in names:
            if name in self.NOT_OURS:
                continue
            try:
                with open(os.path.join(self.REPO_ROOT, name), 'rb') as f:
                    blob = f.read()
            except OSError:
                # Tracked but not on disk: a deleted file, a half-done
                # rename, or a path git has quoted.  There is nothing to
                # sweep, and erroring the whole run over it would read
                # as the sweep being broken.
                continue
            if b'\x00' in blob:
                continue                # an image, not text
            # errors='replace' rather than a skip on failure: a file
            # that will not decode cleanly is still swept, so one stray
            # byte cannot hide the rest of it.
            text = blob.decode('utf-8', 'replace')
            for token in self.FOREIGN:
                text = text.replace(token.replace('*', ''), '')
            for phrase in self.QUOTED_PROPER_NOUNS:
                phrase = phrase.replace('*', '')
                if phrase in text:
                    seen_quoted.add(phrase)
                    text = text.replace(phrase, ' ')
            lines = text.splitlines()
            if name in translations:
                # The English header only, down to the first [section].
                cut = next((i for i, line in enumerate(lines)
                            if line.lstrip().startswith('[')), None)
                self.assertIsNotNone(
                    cut, '%s has no [section]; the header cannot be found, '
                         'and sweeping it whole would flag its translation'
                         % name)
                lines = lines[:cut]
            # Whole file first, line by line only when that hits, so the
            # line numbers cost nothing on the files that are clean --
            # which is all of them, every run but the one that matters.
            if want.search('\n'.join(lines).lower()) is None:
                continue
            for number, line in enumerate(lines, 1):
                found = want.search(line.lower())
                if found is not None:
                    hits.append('%s:%d: %s' % (name, number, line.strip()))
        self.assertEqual(
            hits, [],
            'British spellings found; this project writes American English:\n'
            + '\n'.join(hits))
        self.assertEqual(
            sorted(phrase.replace('*', '') for phrase in
                   self.QUOTED_PROPER_NOUNS
                   if phrase.replace('*', '') not in seen_quoted), [],
            'QUOTED_PROPER_NOUNS names a phrase that is not in the tree on '
            'one line; reword the entry or reflow the prose')

if __name__ == '__main__':
    unittest.main()
